﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace ModelEntity.Migrations
{
    public partial class refresh : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
        }
    }
}
