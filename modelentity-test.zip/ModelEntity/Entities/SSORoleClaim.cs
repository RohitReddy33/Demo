﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity;

namespace ModelEntity.Entities
{
    public class SSORoleClaim : IdentityRoleClaim<string>
    {
        public virtual SSORole Role { get; set; }
    }
}
