﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Identity;

namespace ModelEntity.Entities
{
    // Add profile data for application users by adding properties to the SSOUser class
    public class SSOUser : IdentityUser
    {
        public string GivenName { get; set; }
        public string Surname { get; set; }
        public string Company { get; set; }
        public DateTime? PasswordChanged { get; set; }
        public DateTime? AccountCreated { get; set; }
        public DateTime? LoggedIn { get; set; }
        public bool ForcePasswordChange { get; set; }
        public int CompanyId { get; set; }
        public virtual Agents Agent { get; set; }
        public virtual ICollection<SSOClaim> Claims { get; set; }
        public virtual ICollection<SSOLogin> Logins { get; set; }
        public virtual ICollection<SSOToken> Tokens { get; set; }
        public virtual ICollection<SSOUserRole> UserRoles { get; set; }

    }
}