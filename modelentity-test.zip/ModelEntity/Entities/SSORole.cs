﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity;

namespace ModelEntity.Entities
{
    public class SSORole : IdentityRole
    {
        public virtual ICollection<SSOUserRole> UserRoles { get; set; }
        public virtual ICollection<SSORoleClaim> RoleClaims { get; set; }
    }
}
