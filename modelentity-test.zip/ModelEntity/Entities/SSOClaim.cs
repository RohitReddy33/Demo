﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity;

namespace ModelEntity.Entities
{
    public class SSOClaim : IdentityUserClaim<string>
    {
        public virtual SSOUser User { get; set; }
    }
}
