﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity;

namespace ModelEntity.Entities
{
    public class SSOUserRole : IdentityUserRole<string>
    {
        public virtual SSOUser User { get; set; }
        public virtual SSORole Role { get; set; }
    }
}
