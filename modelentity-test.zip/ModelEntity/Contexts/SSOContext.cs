﻿using System.IO;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using ModelEntity.Entities;

namespace ModelEntity.Contexts
{
    public partial class SSOContext : IdentityDbContext<SSOUser>
    {
        public SSOContext()
        {
        }

        public SSOContext(DbContextOptions<SSOContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Agents> Agents { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (optionsBuilder.IsConfigured) return;

            var configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();
            var connectionString = configuration.GetConnectionString("SSOContextConnection");
            optionsBuilder.UseSqlServer(connectionString);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<SSOUser>(ssoUser =>
            {
                // Each User can have many UserClaims
                ssoUser.HasMany(e => e.Claims)
                    .WithOne(e => e.User)
                    .HasForeignKey(uc => uc.UserId)
                    .IsRequired();

                // Each User can have many UserLogins
                ssoUser.HasMany(e => e.Logins)
                    .WithOne(e => e.User)
                    .HasForeignKey(ul => ul.UserId)
                    .IsRequired();

                // Each User can have many UserTokens
                ssoUser.HasMany(e => e.Tokens)
                    .WithOne(e => e.User)
                    .HasForeignKey(ut => ut.UserId)
                    .IsRequired();

                // Each User can have many entries in the UserRole join table
                ssoUser.HasMany(e => e.UserRoles)
                    .WithOne(e => e.User)
                    .HasForeignKey(ur => ur.UserId)
                    .IsRequired();
            });

            modelBuilder.Entity<SSORole>(ssoRole =>
            {
                // Each Role can have many entries in the UserRole join table
                ssoRole.HasMany(e => e.UserRoles)
                    .WithOne(e => e.Role)
                    .HasForeignKey(ur => ur.RoleId)
                    .IsRequired();

                // Each Role can have many associated RoleClaims
                ssoRole.HasMany(e => e.RoleClaims)
                    .WithOne(e => e.Role)
                    .HasForeignKey(rc => rc.RoleId)
                    .IsRequired();
            });

            modelBuilder.Entity<Agents>()
                .HasMany(c => c.SSOUsers)
                .WithOne(e => e.Agent).HasForeignKey(x => x.CompanyId)
                .IsRequired();

            modelBuilder.Entity<Agents>(entity =>
            {
                entity.HasKey(e => e.CompanyId)
                    .HasName("PK_Company");

                entity.HasIndex(e => e.CompanyId)
                    .HasName("IX_Agents")
                    .IsUnique();

                entity.HasIndex(e => new { e.CompanyId, e.IsTestAgent })
                    .HasName("ix_Agents_CompanyID_IsTestAgent");

                entity.HasIndex(e => new { e.UniqueAgentReference, e.CompanyId })
                    .HasName("ix_Agents_UniqueAgentReference_CompanyID");

                entity.HasIndex(e => new { e.CompanyName, e.UniqueAgentReference, e.ShortName, e.CompanyId })
                    .HasName("ix_Agents_CompanyID_Includes");

                entity.HasIndex(e => new { e.CompanyId, e.IsTempTablesTesting, e.Bcaimintegration, e.Bcalisintegration, e.UniqueAgentReference })
                    .HasName("ix_Agents_UniqueAgentReference_Includes");

                entity.HasIndex(e => new { e.WstriggersEmailSubmissionReport, e.WstriggersEmailSubmissionReportSendUpToDate, e.UniqueAgentReference, e.CompanyId, e.CompanyName })
                    .HasName("ix_Agents_UniqueAgentReference_CompanyID_CompanyName_Includes");

                entity.Property(e => e.CompanyId)
                    .HasColumnName("CompanyID")
                    .ValueGeneratedNever();

                entity.Property(e => e.AgentLogo).HasColumnType("image");

                entity.Property(e => e.AgentLogoContentType)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AgentLogoFileName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.AmigagentNo)
                    .HasColumnName("AMIGAgentNo")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.AmigliveDocucorp).HasColumnName("AMIGLiveDocucorp");

                entity.Property(e => e.Amigxlsagent)
                    .HasColumnName("AMIGXLSAgent")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Amsclaims)
                    .HasColumnName("AMSClaims")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Amspremiums)
                    .HasColumnName("AMSPremiums")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Bcaimintegration)
                    .HasColumnName("BCAIMIntegration")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Bcalisintegration)
                    .HasColumnName("BCALISIntegration")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.CompanyName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DefaultAvatar).HasColumnType("image");

                entity.Property(e => e.DefaultAvatarContentType)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DefaultAvatarFileName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpPdfoptionEnabled)
                    .HasColumnName("DocucorpPDFOptionEnabled")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.DocucorpStatus)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.FormSetIdreversalProcessing)
                    .HasColumnName("FormSetIDReversalProcessing")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.GlobalClientCode)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.GlukclientId).HasColumnName("GLUKClientID");

                entity.Property(e => e.Glukxlsagent)
                    .HasColumnName("GLUKXLSAgent")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.IsClaimsTpa)
                    .HasColumnName("IsClaimsTPA")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IsTestAgent).HasDefaultValueSql("((0))");

                entity.Property(e => e.ManagementSystem)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Notes).IsUnicode(false);

                entity.Property(e => e.OverLimitEscalationEmailAddresses).IsUnicode(false);

                entity.Property(e => e.PolicyPrefix)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.RoofConstructionScheme)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.RoofShapeScheme)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.RtdcloneOpenNotReportedAllowed).HasColumnName("RTDCloneOpenNotReportedAllowed");

                entity.Property(e => e.SendAutomaticEmails).HasDefaultValueSql("((0))");

                entity.Property(e => e.ShortName)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.TpalegacyXlsoffice)
                    .HasColumnName("TPALegacyXLSOffice")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.UniqueAgentReference)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.WstriggersEmailSubmissionReport)
                    .HasColumnName("WSTriggersEmailSubmissionReport")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.WstriggersEmailSubmissionReportSendUpToDate)
                    .HasColumnName("WSTriggersEmailSubmissionReportSendUpToDate")
                    .HasColumnType("datetime");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
