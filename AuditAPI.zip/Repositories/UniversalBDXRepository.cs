﻿using Microsoft.EntityFrameworkCore;
using Models;
using Repositories.DBContext;
using Repositories.Entities;
using Repositories.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Repositories
{
    public class UniversalBDXRepository : IUniversalBDXRepository
    {
        private readonly UniversalBdxContext _universalBdxContext;
        public UniversalBDXRepository(UniversalBdxContext universalBdxContext)
        {
            _universalBdxContext = universalBdxContext;
            _universalBdxContext.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
        }
        public DbSet<TempPolicyTransaction> GetTempPolicyTransactions()
        {
            return _universalBdxContext.Set<TempPolicyTransaction>();
        }
        public DbSet<TempPolicyTransactionsLocationsBuildingsIsoglclass> GetTempPolicyTransactionsLocationsBuildingsIsoglclass()
        {
            return _universalBdxContext.Set<TempPolicyTransactionsLocationsBuildingsIsoglclass>();
        }
        public DbSet<TempPolicyTransactionsIsoglclass> GetTempPolicyTransactionsIsoglclass()
        {
            return _universalBdxContext.Set<TempPolicyTransactionsIsoglclass>();
        }
        public DbSet<TempPolicyTransactionsLocation> GetTempPolicyTransactionsLocations()
        {
            return _universalBdxContext.Set<TempPolicyTransactionsLocation>();
        }

        public DbSet<TempPolicyTransactionsContract> GetTempPolicyTransactionsContracts()
        {
            return _universalBdxContext.Set<TempPolicyTransactionsContract>();
        }
        public DbSet<TempPolicyTransactionsTransportation> GetTempPolicyTransactionsTransportation()
        {
            return _universalBdxContext.Set<TempPolicyTransactionsTransportation>();
        }
        public DbSet<TempPolicyTransactionsTransportationVehicleDetail> GetTempPolicyTransactionsTransportationVehicleDetails()
        {
            return _universalBdxContext.Set<TempPolicyTransactionsTransportationVehicleDetail>();
        }

        public DbSet<TempPolicyTransactionsTransportationApdacvunitBanding> GetTempPolicyTransactionsTransportationAPDACVUnitBanding()
        {
            return _universalBdxContext.Set<TempPolicyTransactionsTransportationApdacvunitBanding>();
        }

        public DbSet<TempPolicyTransactionsLocationsTransportation> GetTempPolicyTransactionsLocationsTransportation()
        {
            return _universalBdxContext.Set<TempPolicyTransactionsLocationsTransportation>();
        }

        public DbSet<TempPolicyTransactionsTransportationTrailerDetail> GetTempPolicyTransactionsTransportationTrailerDetails()
        {
            return _universalBdxContext.Set<TempPolicyTransactionsTransportationTrailerDetail>();
        }

        public DbSet<TempPolicyTransactionsTransportationCargoCommodity> GetTempPolicyTransactionsTransportationCargoCommodities()
        {
            return _universalBdxContext.Set<TempPolicyTransactionsTransportationCargoCommodity>();
        }

        public DbSet<TempPolicyTransactionsTransportationApdcommodity> GetTempPolicyTransactionsTransportationApdcommodities()
        {
            return _universalBdxContext.Set<TempPolicyTransactionsTransportationApdcommodity>();
        }

        public DbSet<TempPolicyTransactionsTransportationApdacvunitBanding> GetTempPolicyTransactionsTransportationApdacvunitBanding()
        {
            return _universalBdxContext.Set<TempPolicyTransactionsTransportationApdacvunitBanding>();
        }
        public DbSet<Agent> GetAgents()
        {
            return _universalBdxContext.Set<Agent>();
        }

        public DbSet<TempPolicyTransactionsProfessionalLiabilityAttorney> GetTempPolicyTransactionsProfessionalLiabilityAttorneys()
        {
            return _universalBdxContext.Set<TempPolicyTransactionsProfessionalLiabilityAttorney>();
        }

        public DbSet<TempPolicyTransactionsProfessionalLiabilityClientIndustry> GetTempPolicyTransactionsProfessionalLiabilityClientIndustries()
        {
            return _universalBdxContext.Set<TempPolicyTransactionsProfessionalLiabilityClientIndustry>();
        }

        public DbSet<TempPolicyTransactionsProfessionalLiabilityContinuingLegalEducation> GetTempPolicyTransactionsProfessionalLiabilityContinuingLegalEducations()
        {
            return _universalBdxContext.Set<TempPolicyTransactionsProfessionalLiabilityContinuingLegalEducation>();
        }

        public DbSet<TempPolicyTransactionsProfessionalLiabilityLitigationHistory> GetTempPolicyTransactionsProfessionalLiabilityLitigationHistories()
        {
            return _universalBdxContext.Set<TempPolicyTransactionsProfessionalLiabilityLitigationHistory>();
        }

        public DbSet<TempPolicyTransactionsProfessionalLiabilityLoyaltyCredit> GetTempPolicyTransactionsProfessionalLiabilityLoyaltyCredits()
        {
            return _universalBdxContext.Set<TempPolicyTransactionsProfessionalLiabilityLoyaltyCredit>();
        }

        public DbSet<TempPolicyTransactionsLocationsIsoglclassProfessionalLiabilityLawyer> GetTempPolicyTransactionsLocationsIsoglclassProfessionalLiabilityLawyers()
        {
            return _universalBdxContext.Set<TempPolicyTransactionsLocationsIsoglclassProfessionalLiabilityLawyer>();
        }

        public DbSet<TempPolicyTransactionsLocationsBuilding> GetTempPolicyTransactionsLocationsBuilding()
        {
            return _universalBdxContext.Set<TempPolicyTransactionsLocationsBuilding>();
        }
        public DbSet<TempPolicyTransactionsApimIsyCl> GetTempPolicyTransactionsApimIsyCls()
        {
            return _universalBdxContext.Set<TempPolicyTransactionsApimIsyCl>();
        }
        public List<string> GetProfessionalLiabilitiesContractRefs(int contractYear, int companyId)
        {
            var contractRefs = (from PT in _universalBdxContext.Set<TempPolicyTransaction>()
                                join PC in _universalBdxContext.Set<TempPolicyTransactionsContract>()
                                    on PT.TempPremiumsId equals PC.TempPremiumsId
                                join PL in _universalBdxContext.Set<TempPolicyTransactionsLocation>()
                                    on PT.TempPremiumsId equals PL.TempPremiumsId
                                join law in _universalBdxContext.Set<TempPolicyTransactionsLocationsIsoglclassProfessionalLiabilityLawyer>()
                                    on PL.TempLocationsId equals law.TempLocationsId
                                where PT.CorrectedBy == null && (PT.IgnoreRecord == false || PT.IgnoreRecord == null)
                                        && PC.ContractYear == contractYear
                                        && PC.CompanyId == companyId
                                orderby PC.ContractRef
                                select PC.ContractRef).Distinct().ToList();
            return contractRefs;
        }

        public List<string> GetTransportaionContractRefs(int contractYear, int companyId)
        {
            var contractRefs = (from PT in _universalBdxContext.Set<TempPolicyTransaction>()
                                join PC in _universalBdxContext.Set<TempPolicyTransactionsContract>()
                                   on PT.TempPremiumsId equals PC.TempPremiumsId
                                join TPT in _universalBdxContext.Set<TempPolicyTransactionsTransportation>()
                                    on PT.TempPremiumsId equals TPT.TempPremiumsId
                                join PL in _universalBdxContext.Set<TempPolicyTransactionsLocation>()
                                    on PT.TempPremiumsId equals PL.TempPremiumsId
                                where PT.TempPremiumsId == PC.TempPremiumsId && PT.CorrectedBy == null && (PT.IgnoreRecord == false || PT.IgnoreRecord == null)
                                        && PC.ContractYear == contractYear
                                        && PC.CompanyId == companyId
                                orderby PC.ContractRef
                                select PC.ContractRef.ToLower()).Distinct().ToList();
            return contractRefs;
        }

        public List<string> GetCommercialPackageAndHomeownersOrPersonalLinesContractRefs(int contractYear, int companyId)
        {
            var contractRefs = (from PT in _universalBdxContext.Set<TempPolicyTransaction>()
                                join PC in _universalBdxContext.Set<TempPolicyTransactionsContract>()
                                  on PT.TempPremiumsId equals PC.TempPremiumsId
                                join PL in _universalBdxContext.Set<TempPolicyTransactionsLocation>()
                                  on PT.TempPremiumsId equals PL.TempPremiumsId
                                where PT.TempPremiumsId == PC.TempPremiumsId && PT.CorrectedBy == null && (PT.IgnoreRecord == false || PT.IgnoreRecord == null)
                                        && PC.ContractYear == contractYear
                                        && PC.CompanyId == companyId
                                orderby PC.ContractRef
                                select PC.ContractRef.ToLower()).Distinct().ToList();
            return contractRefs;
        }

        public bool IsTransportationPolicy(PolicyRiskRequest riskRequest)
        {
            var contractRefs = (from PT in _universalBdxContext.Set<TempPolicyTransaction>()
                                join PC in _universalBdxContext.Set<TempPolicyTransactionsContract>()
                                   on PT.TempPremiumsId equals PC.TempPremiumsId
                                join TPT in _universalBdxContext.Set<TempPolicyTransactionsTransportation>()
                                    on PT.TempPremiumsId equals TPT.TempPremiumsId                               
                                where PT.TempPremiumsId == PC.TempPremiumsId && PT.CorrectedBy == null && (PT.IgnoreRecord == false || PT.IgnoreRecord == null)
                                       && PC.ContractYear == riskRequest.ContractYear
                                       && PC.CompanyId == riskRequest.CompanyId
                                       && PT.PolicyNo == riskRequest.PolicyNumber
                                orderby PC.ContractRef
                                select PC.ContractRef.ToLower()).Distinct().ToList();

            return contractRefs.Any();
        }

        public bool IsCommercialPackageAndHomeownersOrPersonalLinesPolicy(PolicyRiskRequest riskRequest)
        {

            var contractRefs = (from PT in _universalBdxContext.Set<TempPolicyTransaction>()
                                join PC in _universalBdxContext.Set<TempPolicyTransactionsContract>()
                                  on PT.TempPremiumsId equals PC.TempPremiumsId
                                join PL in _universalBdxContext.Set<TempPolicyTransactionsLocation>()
                                  on PT.TempPremiumsId equals PL.TempPremiumsId
                                where PT.TempPremiumsId == PC.TempPremiumsId && PT.CorrectedBy == null && (PT.IgnoreRecord == false || PT.IgnoreRecord == null)
                                        && PC.ContractYear == riskRequest.ContractYear
                                        && PC.CompanyId == riskRequest.CompanyId
                                        && PT.PolicyNo == riskRequest.PolicyNumber
                                orderby PC.ContractRef
                                select PC.ContractRef.ToLower()).Distinct().ToList();

            return contractRefs.Any();
        }
        public bool IsProfessionalLiabilityPolicy(PolicyRiskRequest riskRequest)
        {
            var contractRefs = (from PT in _universalBdxContext.Set<TempPolicyTransaction>()
                                join PC in _universalBdxContext.Set<TempPolicyTransactionsContract>()
                                    on PT.TempPremiumsId equals PC.TempPremiumsId
                                join PL in _universalBdxContext.Set<TempPolicyTransactionsLocation>()
                                    on PT.TempPremiumsId equals PL.TempPremiumsId
                                join law in _universalBdxContext.Set<TempPolicyTransactionsLocationsIsoglclassProfessionalLiabilityLawyer>()
                                    on PL.TempLocationsId equals law.TempLocationsId
                                where PT.CorrectedBy == null && (PT.IgnoreRecord == false || PT.IgnoreRecord == null)
                                        && PC.ContractYear == riskRequest.ContractYear
                                        && PC.CompanyId == riskRequest.CompanyId
                                        && PT.PolicyNo == riskRequest.PolicyNumber
                                orderby PC.ContractRef
                                select PC.ContractRef.ToLower()).Distinct().ToList();

            return contractRefs.Any();
        }
    }
}
