﻿using Microsoft.EntityFrameworkCore;
using Models;
using Repositories.Entities;
using System.Collections.Generic;

namespace Repositories.Interfaces
{
    public interface IUniversalBDXRepository
    {
        public DbSet<TempPolicyTransaction> GetTempPolicyTransactions();
        public DbSet<TempPolicyTransactionsLocationsBuildingsIsoglclass> GetTempPolicyTransactionsLocationsBuildingsIsoglclass();
        public DbSet<TempPolicyTransactionsIsoglclass> GetTempPolicyTransactionsIsoglclass();
        public DbSet<TempPolicyTransactionsLocation> GetTempPolicyTransactionsLocations();
        public DbSet<TempPolicyTransactionsLocationsBuilding> GetTempPolicyTransactionsLocationsBuilding();
        public DbSet<TempPolicyTransactionsContract> GetTempPolicyTransactionsContracts();
        public DbSet<TempPolicyTransactionsApimIsyCl> GetTempPolicyTransactionsApimIsyCls();
        #region Professional Liability
        public DbSet<TempPolicyTransactionsLocationsIsoglclassProfessionalLiabilityLawyer> GetTempPolicyTransactionsLocationsIsoglclassProfessionalLiabilityLawyers();
        public DbSet<TempPolicyTransactionsProfessionalLiabilityAttorney> GetTempPolicyTransactionsProfessionalLiabilityAttorneys();
        public DbSet<TempPolicyTransactionsProfessionalLiabilityClientIndustry> GetTempPolicyTransactionsProfessionalLiabilityClientIndustries();
        public DbSet<TempPolicyTransactionsProfessionalLiabilityContinuingLegalEducation> GetTempPolicyTransactionsProfessionalLiabilityContinuingLegalEducations();
        public DbSet<TempPolicyTransactionsProfessionalLiabilityLitigationHistory> GetTempPolicyTransactionsProfessionalLiabilityLitigationHistories();
        public DbSet<TempPolicyTransactionsProfessionalLiabilityLoyaltyCredit> GetTempPolicyTransactionsProfessionalLiabilityLoyaltyCredits();

        #endregion

        #region Transportaion
        public DbSet<TempPolicyTransactionsTransportationVehicleDetail> GetTempPolicyTransactionsTransportationVehicleDetails();
        public DbSet<TempPolicyTransactionsTransportationApdacvunitBanding> GetTempPolicyTransactionsTransportationAPDACVUnitBanding();
        public DbSet<TempPolicyTransactionsTransportation> GetTempPolicyTransactionsTransportation();
        public DbSet<TempPolicyTransactionsLocationsTransportation> GetTempPolicyTransactionsLocationsTransportation();
        public DbSet<TempPolicyTransactionsTransportationTrailerDetail> GetTempPolicyTransactionsTransportationTrailerDetails();
        public DbSet<TempPolicyTransactionsTransportationCargoCommodity> GetTempPolicyTransactionsTransportationCargoCommodities();
        public DbSet<TempPolicyTransactionsTransportationApdcommodity> GetTempPolicyTransactionsTransportationApdcommodities();
        public DbSet<TempPolicyTransactionsTransportationApdacvunitBanding> GetTempPolicyTransactionsTransportationApdacvunitBanding();
        public DbSet<Agent> GetAgents();

        #endregion
        #region Get contractRef's based upon line of business
        public List<string> GetProfessionalLiabilitiesContractRefs(int contractYear, int companyId);
        public List<string> GetTransportaionContractRefs(int contractYear, int companyId);
        public List<string> GetCommercialPackageAndHomeownersOrPersonalLinesContractRefs(int contractYear, int companyId);
        public bool IsProfessionalLiabilityPolicy(PolicyRiskRequest riskRequest);
        public bool IsTransportationPolicy(PolicyRiskRequest riskRequest);
        public bool IsCommercialPackageAndHomeownersOrPersonalLinesPolicy(PolicyRiskRequest riskRequest);
        #endregion
    }
}
