﻿using Repositories.Entities;

namespace Repositories.CompositeEntities
{
    public class TempRiskResponse
    {
        public TempPolicyTransaction TempPolicyTransactions { get; set; }
        public TempPolicyTransactionsContract TempPolicyTransContract { get; set; }      
        public TempPolicyTransactionsTransportation TempPolicyTransactionsTransportation { get; set; }
    }
}
