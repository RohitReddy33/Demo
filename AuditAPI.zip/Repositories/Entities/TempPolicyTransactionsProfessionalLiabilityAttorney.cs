﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class TempPolicyTransactionsProfessionalLiabilityAttorney
    {
        public long Id { get; set; }
        public long TempPremiumsId { get; set; }
        public int AttorneyHoursId { get; set; }
        public int Attorneys { get; set; }

        public virtual ProfessionalLiabilityAttorneyHour AttorneyHours { get; set; }
        public virtual TempPolicyTransaction TempPremiums { get; set; }
    }
}
