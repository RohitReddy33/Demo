﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class TempPolicyTransactionsTransportationApdcommodity
    {
        public long TempTransportationApdcommodityId { get; set; }
        public long TempTransportationId { get; set; }
        public string ApdcommodityScheme { get; set; }
        public int? ApdcommodityType { get; set; }

        public virtual TempPolicyTransactionsTransportation TempTransportation { get; set; }
    }
}
