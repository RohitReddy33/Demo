﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class TempPolicyTransactionsTransportationTrailerDetail
    {
        public long TempTransportationTrailerDetailsId { get; set; }
        public long TempTransportationId { get; set; }
        public string TypeOfTrailer { get; set; }
        public string Vin { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public decimal? Year { get; set; }
        public decimal? Acv { get; set; }
        public bool? NonOwnedTrailer { get; set; }

        public virtual TempPolicyTransactionsTransportation TempTransportation { get; set; }
    }
}
