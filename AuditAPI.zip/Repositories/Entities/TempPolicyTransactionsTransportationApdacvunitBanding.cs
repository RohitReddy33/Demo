﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class TempPolicyTransactionsTransportationApdacvunitBanding
    {
        public long? TempTransportationId { get; set; }
        public decimal? BandFrom { get; set; }
        public decimal? BandTo { get; set; }
        public short? UnitCount { get; set; }
        public int TempApdacvunitBandingId { get; set; }
        public decimal? Tivfgu { get; set; }
        public decimal? Aopdeductible { get; set; }

        public virtual TempPolicyTransactionsTransportation TempTransportation { get; set; }
    }
}
