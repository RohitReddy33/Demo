﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class ProfessionalLiabilityContinuingLegalEducation
    {
        public ProfessionalLiabilityContinuingLegalEducation()
        {
            TempPolicyTransactionsProfessionalLiabilityContinuingLegalEducations = new HashSet<TempPolicyTransactionsProfessionalLiabilityContinuingLegalEducation>();
        }

        public int ContinuingLegalEducationId { get; set; }
        public string ContinuingLegalEducation { get; set; }
        public decimal ModificationFactor { get; set; }
        public string VersionNo { get; set; }
        public DateTime VersionRelease { get; set; }

        public virtual ICollection<TempPolicyTransactionsProfessionalLiabilityContinuingLegalEducation> TempPolicyTransactionsProfessionalLiabilityContinuingLegalEducations { get; set; }
    }
}
