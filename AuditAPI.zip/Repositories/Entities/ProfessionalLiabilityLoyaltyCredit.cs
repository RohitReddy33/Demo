﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class ProfessionalLiabilityLoyaltyCredit
    {
        public ProfessionalLiabilityLoyaltyCredit()
        {
            TempPolicyTransactionsProfessionalLiabilityLoyaltyCredits = new HashSet<TempPolicyTransactionsProfessionalLiabilityLoyaltyCredit>();
        }

        public int LoyaltyCreditId { get; set; }
        public string LoyaltyCredit { get; set; }
        public decimal ModificationFactor { get; set; }
        public string VersionNo { get; set; }
        public DateTime VersionRelease { get; set; }

        public virtual ICollection<TempPolicyTransactionsProfessionalLiabilityLoyaltyCredit> TempPolicyTransactionsProfessionalLiabilityLoyaltyCredits { get; set; }
    }
}
