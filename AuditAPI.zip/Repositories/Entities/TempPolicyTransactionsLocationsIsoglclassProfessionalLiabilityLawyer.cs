﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class TempPolicyTransactionsLocationsIsoglclassProfessionalLiabilityLawyer
    {
        public long Id { get; set; }
        public long? TempLocationsId { get; set; }
        public string Isoglclass { get; set; }
        public DateTime? CoverageEffectiveDate { get; set; }
        public DateTime? CoverageExpirationDate { get; set; }
        public long? AreaOfPracticeId { get; set; }
        public int AreaOfPracticePercentage { get; set; }
        public int ExposureRatingBasis { get; set; }
        public int? Exposure { get; set; }
        public double? Rate { get; set; }
        public int? RatingId { get; set; }
        public decimal? TermPremium { get; set; }
        public decimal? Premium { get; set; }
        public decimal? Limit { get; set; }
        public decimal? Deductible { get; set; }
        public string TerritoriesCode { get; set; }
        public int? CoverageCode { get; set; }
        public string SubCoverageCode { get; set; }
        public double? ScheduledRateModificationFactor { get; set; }
        public double RateModificationFactor { get; set; }
        public double RateDepartureLcm { get; set; }
        public decimal? FirmRevenue { get; set; }
        public decimal? AverageCaseSize { get; set; }
        public decimal? MaximumCaseSize { get; set; }
        public int? NumberCasesPerYear { get; set; }
        public int? FirmAttorneyExperience { get; set; }
        public int? FirmAverageRate { get; set; }
        public int? StateHourlyRate { get; set; }
        public string AnnualStatementLob { get; set; }
        public string Cspsubline { get; set; }
        public DateTime? RetroActiveDate { get; set; }
        public DateTime? ExtendedReportingPeriodDate { get; set; }
        public string DeleteCode { get; set; }
        public bool? WithinDefenseLimit { get; set; }
        public decimal? DefenseCostLimit { get; set; }
        public decimal? DefenseCostDeductible { get; set; }
        public decimal? PolicyAggregateLimit { get; set; }
        public int? RatableEmployees { get; set; }
        public int? TotalEmployees { get; set; }
        public int? Premises { get; set; }
        public int? FormCode { get; set; }
        public string TerrorismCoverageCode { get; set; }
        public int? RateGroup { get; set; }
        public string PolicyTypeCode { get; set; }

        public virtual TempPolicyTransactionsLocation TempLocations { get; set; }
    }
}
