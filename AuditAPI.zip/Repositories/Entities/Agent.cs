﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class Agent
    {
        public int CompanyId { get; set; }
        public string CompanyName { get; set; }
        public string UniqueAgentReference { get; set; }
        public string GlobalClientCode { get; set; }
        public string Amigxlsagent { get; set; }
        public string AmigagentNo { get; set; }
        public string Glukxlsagent { get; set; }
        public int? GlukclientId { get; set; }
        public string Notes { get; set; }
        public string PolicyPrefix { get; set; }
        public string OverLimitEscalationEmailAddresses { get; set; }
        public string DocucorpStatus { get; set; }
        public bool? DocucorpPdfoptionEnabled { get; set; }
        public byte[] AgentLogo { get; set; }
        public string AgentLogoContentType { get; set; }
        public string AgentLogoFileName { get; set; }
        public byte[] DefaultAvatar { get; set; }
        public string DefaultAvatarContentType { get; set; }
        public string DefaultAvatarFileName { get; set; }
        public bool? SendAutomaticEmails { get; set; }
        public bool? AmigliveDocucorp { get; set; }
        public bool? WstriggersEmailSubmissionReport { get; set; }
        public DateTime? WstriggersEmailSubmissionReportSendUpToDate { get; set; }
        public bool? IsTempTablesTesting { get; set; }
        public string ShortName { get; set; }
        public bool? IsTestAgent { get; set; }
        public int? IsTestAgentOf { get; set; }
        public string RoofShapeScheme { get; set; }
        public string RoofConstructionScheme { get; set; }
        public bool? IsClaimsTpa { get; set; }
        public string TpalegacyXlsoffice { get; set; }
        public bool? Bcaimintegration { get; set; }
        public bool? Bcalisintegration { get; set; }
        public string ManagementSystem { get; set; }
        public bool? FormSetIdreversalProcessing { get; set; }
        public bool? ClaimsLookupContractFromPolicy { get; set; }
        public string Amspremiums { get; set; }
        public string Amsclaims { get; set; }
        public bool? RtdcloneOpenNotReportedAllowed { get; set; }
        public bool? IsLondonBroker { get; set; }
    }
}
