﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class TempPolicyTransactionsTransportationCargoCommodity
    {
        public long TempTransportationCargoCommodityId { get; set; }
        public long TempTransportationId { get; set; }
        public string CargoCommodityScheme { get; set; }
        public int? CargoCommodityType { get; set; }
        public decimal? CargoCommodityPercentage { get; set; }

        public virtual TempPolicyTransactionsTransportation TempTransportation { get; set; }
    }
}
