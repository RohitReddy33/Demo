﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class NatureOfTrade
    {
        public NatureOfTrade()
        {
            TempPolicyTransactionsLocationsTransportations = new HashSet<TempPolicyTransactionsLocationsTransportation>();
            TempPolicyTransactionsTransportations = new HashSet<TempPolicyTransactionsTransportation>();
        }

        public int NatureOfTrade1 { get; set; }
        public string Description { get; set; }

        public virtual ICollection<TempPolicyTransactionsLocationsTransportation> TempPolicyTransactionsLocationsTransportations { get; set; }
        public virtual ICollection<TempPolicyTransactionsTransportation> TempPolicyTransactionsTransportations { get; set; }
    }
}
