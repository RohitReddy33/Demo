﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class TempPolicyTransactionsProfessionalLiabilityClientIndustry
    {
        public long Id { get; set; }
        public long TempPremiumsId { get; set; }
        public int ClientIndustryId { get; set; }
        public decimal ModificationFactor { get; set; }
        public string ModificationFactorBasis { get; set; }

        public virtual ProfessionalLiabilityClientIndustry ClientIndustry { get; set; }
        public virtual TempPolicyTransaction TempPremiums { get; set; }
    }
}
