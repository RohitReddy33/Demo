﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class TempPolicyTransactionsProfessionalLiabilityLitigationHistory
    {
        public long Id { get; set; }
        public long TempPremiumsId { get; set; }
        public int LitigationHistoryId { get; set; }
        public decimal ModificationFactor { get; set; }

        public virtual ProfessionalLiabilityLitigationHistory LitigationHistory { get; set; }
        public virtual TempPolicyTransaction TempPremiums { get; set; }
    }
}
