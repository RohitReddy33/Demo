﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class TempPolicyTransactionsProfessionalLiabilityContinuingLegalEducation
    {
        public long Id { get; set; }
        public long TempPremiumsId { get; set; }
        public int ContinuingLegalEducationId { get; set; }
        public decimal ModificationFactor { get; set; }

        public virtual ProfessionalLiabilityContinuingLegalEducation ContinuingLegalEducation { get; set; }
        public virtual TempPolicyTransaction TempPremiums { get; set; }
    }
}
