﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class ProfessionalLiabilityLitigationHistory
    {
        public ProfessionalLiabilityLitigationHistory()
        {
            TempPolicyTransactionsProfessionalLiabilityLitigationHistories = new HashSet<TempPolicyTransactionsProfessionalLiabilityLitigationHistory>();
        }

        public int LitigationHistoryId { get; set; }
        public string LitigationHistory { get; set; }
        public decimal ModificationFactor { get; set; }
        public string VersionNo { get; set; }
        public DateTime VersionRelease { get; set; }

        public virtual ICollection<TempPolicyTransactionsProfessionalLiabilityLitigationHistory> TempPolicyTransactionsProfessionalLiabilityLitigationHistories { get; set; }
    }
}
