﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class TempPolicyTransactionsApimIsyCl
    {
        public long Id { get; set; }
        public long TempPremiumsId { get; set; }
        public DateTime DateCreated { get; set; }
        public string TransactionReasonCode { get; set; }
        public string CancelMethod { get; set; }
        public string PolicyTypeCode { get; set; }

        public virtual TempPolicyTransaction TempPremiums { get; set; }
    }
}
