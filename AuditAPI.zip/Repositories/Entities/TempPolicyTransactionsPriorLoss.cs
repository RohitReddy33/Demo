﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class TempPolicyTransactionsPriorLoss
    {
        public int TempPriorLossId { get; set; }
        public long? TempPremiumsId { get; set; }
        public DateTime? DateOfLoss { get; set; }
        public string CauseOfLoss { get; set; }
        public string ClaimStatus { get; set; }
        public decimal? TotalIncurred { get; set; }

        public virtual TempPolicyTransaction TempPremiums { get; set; }
    }
}
