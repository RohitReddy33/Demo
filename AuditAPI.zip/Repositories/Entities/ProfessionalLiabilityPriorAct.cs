﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class ProfessionalLiabilityPriorAct
    {
        public int PriorActsId { get; set; }
        public string PriorActs { get; set; }
        public decimal? ModificationFactor { get; set; }
        public string VersionNo { get; set; }
        public DateTime VersionRelease { get; set; }
    }
}
