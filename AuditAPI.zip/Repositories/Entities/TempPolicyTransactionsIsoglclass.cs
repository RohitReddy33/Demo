﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class TempPolicyTransactionsIsoglclass
    {
        public long TempPremiumsId { get; set; }
        public string Isoglclass { get; set; }
        public long Id { get; set; }
        public string Description { get; set; }
        public string PremiumBasis { get; set; }
        public decimal? PremiumBasisValue { get; set; }
        public double? RateProductsCompletedOperations { get; set; }
        public double? RateAllOther { get; set; }
        public decimal? ProductsCompletedOperationsPremium { get; set; }
        public decimal? AllOther { get; set; }
        public bool? AppliesAllLocations { get; set; }
        public string TerritoriesCode { get; set; }
        public string SubCoverageCode { get; set; }

        public virtual TempPolicyTransaction TempPremiums { get; set; }
    }
}
