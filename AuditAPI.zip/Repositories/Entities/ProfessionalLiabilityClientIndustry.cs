﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class ProfessionalLiabilityClientIndustry
    {
        public ProfessionalLiabilityClientIndustry()
        {
            TempPolicyTransactionsProfessionalLiabilityClientIndustries = new HashSet<TempPolicyTransactionsProfessionalLiabilityClientIndustry>();
        }

        public int ClientIndustryId { get; set; }
        public string ClientIndustry { get; set; }
        public decimal ModificationFactorLow { get; set; }
        public decimal ModificationFactorMedium { get; set; }
        public decimal ModificationFactorHigh { get; set; }
        public string VersionNo { get; set; }
        public DateTime VersionRelease { get; set; }

        public virtual ICollection<TempPolicyTransactionsProfessionalLiabilityClientIndustry> TempPolicyTransactionsProfessionalLiabilityClientIndustries { get; set; }
    }
}
