﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class TempPolicyTransactionsDocucorpIncludedForm
    {
        public int Id { get; set; }
        public long TempPremiumsId { get; set; }
        public string FormName { get; set; }
        public string EditionDate { get; set; }
        public string Description { get; set; }
        public string Version { get; set; }

        public virtual TempPolicyTransaction TempPremiums { get; set; }
    }
}
