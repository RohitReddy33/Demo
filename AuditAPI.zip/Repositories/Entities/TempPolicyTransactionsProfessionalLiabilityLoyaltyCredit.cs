﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class TempPolicyTransactionsProfessionalLiabilityLoyaltyCredit
    {
        public long Id { get; set; }
        public long TempPremiumsId { get; set; }
        public int LoyaltyCreditId { get; set; }
        public decimal ModificationFactor { get; set; }

        public virtual ProfessionalLiabilityLoyaltyCredit LoyaltyCredit { get; set; }
        public virtual TempPolicyTransaction TempPremiums { get; set; }
    }
}
