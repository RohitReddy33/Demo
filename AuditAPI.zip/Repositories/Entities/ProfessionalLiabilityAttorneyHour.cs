﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class ProfessionalLiabilityAttorneyHour
    {
        public ProfessionalLiabilityAttorneyHour()
        {
            TempPolicyTransactionsProfessionalLiabilityAttorneys = new HashSet<TempPolicyTransactionsProfessionalLiabilityAttorney>();
        }

        public int AttorneyHoursId { get; set; }
        public string AttorneyHours { get; set; }
        public decimal? ModificationFactor { get; set; }
        public string VersionNo { get; set; }
        public DateTime VersionRelease { get; set; }
        public string LineOfBusiness { get; set; }

        public virtual ICollection<TempPolicyTransactionsProfessionalLiabilityAttorney> TempPolicyTransactionsProfessionalLiabilityAttorneys { get; set; }
    }
}
