﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Repositories.Entities
{
    public partial class TypeOfCarrier
    {
        public TypeOfCarrier()
        {
            TempPolicyTransactionsLocationsTransportations = new HashSet<TempPolicyTransactionsLocationsTransportation>();
            TempPolicyTransactionsTransportations = new HashSet<TempPolicyTransactionsTransportation>();
        }

        public int TypeOfCarrier1 { get; set; }
        public string Description { get; set; }

        public virtual ICollection<TempPolicyTransactionsLocationsTransportation> TempPolicyTransactionsLocationsTransportations { get; set; }
        public virtual ICollection<TempPolicyTransactionsTransportation> TempPolicyTransactionsTransportations { get; set; }
    }
}
