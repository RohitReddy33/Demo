﻿using Microsoft.EntityFrameworkCore;
using Repositories.Entities;

#nullable disable

namespace Repositories.DBContext
{
    public partial class UniversalBdxContext : DbContext
    {
        public UniversalBdxContext()
        {
        }

        public UniversalBdxContext(DbContextOptions<UniversalBdxContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Agent> Agents { get; set; }
        public virtual DbSet<LogImportedFile> LogImportedFiles { get; set; }
        public virtual DbSet<LogImportedFilesW> LogImportedFilesWs { get; set; }
        public virtual DbSet<NatureOfLocation> NatureOfLocations { get; set; }
        public virtual DbSet<NatureOfTrade> NatureOfTrades { get; set; }
        public virtual DbSet<ProfessionalLiabilityAttorneyHour> ProfessionalLiabilityAttorneyHours { get; set; }
        public virtual DbSet<ProfessionalLiabilityClientIndustry> ProfessionalLiabilityClientIndustries { get; set; }
        public virtual DbSet<ProfessionalLiabilityContinuingLegalEducation> ProfessionalLiabilityContinuingLegalEducations { get; set; }
        public virtual DbSet<ProfessionalLiabilityLitigationHistory> ProfessionalLiabilityLitigationHistories { get; set; }
        public virtual DbSet<ProfessionalLiabilityLoyaltyCredit> ProfessionalLiabilityLoyaltyCredits { get; set; }
        public virtual DbSet<ProfessionalLiabilityPriorAct> ProfessionalLiabilityPriorActs { get; set; }
        public virtual DbSet<TempPolicyTransaction> TempPolicyTransactions { get; set; }
        public virtual DbSet<TempPolicyTransactionsApimIsyCl> TempPolicyTransactionsApimIsyCls { get; set; }
        public virtual DbSet<TempPolicyTransactionsContract> TempPolicyTransactionsContracts { get; set; }
        public virtual DbSet<TempPolicyTransactionsDocucorpIncludedForm> TempPolicyTransactionsDocucorpIncludedForms { get; set; }
        public virtual DbSet<TempPolicyTransactionsIsoglclass> TempPolicyTransactionsIsoglclasses { get; set; }
        public virtual DbSet<TempPolicyTransactionsLocation> TempPolicyTransactionsLocations { get; set; }
        public virtual DbSet<TempPolicyTransactionsLocationsBuilding> TempPolicyTransactionsLocationsBuildings { get; set; }
        public virtual DbSet<TempPolicyTransactionsLocationsBuildingsIsoglclass> TempPolicyTransactionsLocationsBuildingsIsoglclasses { get; set; }
        public virtual DbSet<TempPolicyTransactionsLocationsIsoglclass> TempPolicyTransactionsLocationsIsoglclasses { get; set; }
        public virtual DbSet<TempPolicyTransactionsLocationsIsoglclassProfessionalLiabilityLawyer> TempPolicyTransactionsLocationsIsoglclassProfessionalLiabilityLawyers { get; set; }
        public virtual DbSet<TempPolicyTransactionsLocationsTransportation> TempPolicyTransactionsLocationsTransportations { get; set; }
        public virtual DbSet<TempPolicyTransactionsPriorLoss> TempPolicyTransactionsPriorLosses { get; set; }
        public virtual DbSet<TempPolicyTransactionsProfessionalLiabilityAttorney> TempPolicyTransactionsProfessionalLiabilityAttorneys { get; set; }
        public virtual DbSet<TempPolicyTransactionsProfessionalLiabilityClientIndustry> TempPolicyTransactionsProfessionalLiabilityClientIndustries { get; set; }
        public virtual DbSet<TempPolicyTransactionsProfessionalLiabilityContinuingLegalEducation> TempPolicyTransactionsProfessionalLiabilityContinuingLegalEducations { get; set; }
        public virtual DbSet<TempPolicyTransactionsProfessionalLiabilityLitigationHistory> TempPolicyTransactionsProfessionalLiabilityLitigationHistories { get; set; }
        public virtual DbSet<TempPolicyTransactionsProfessionalLiabilityLoyaltyCredit> TempPolicyTransactionsProfessionalLiabilityLoyaltyCredits { get; set; }
        public virtual DbSet<TempPolicyTransactionsTransportation> TempPolicyTransactionsTransportations { get; set; }
        public virtual DbSet<TempPolicyTransactionsTransportationApdacvunitBanding> TempPolicyTransactionsTransportationApdacvunitBandings { get; set; }
        public virtual DbSet<TempPolicyTransactionsTransportationApdcommodity> TempPolicyTransactionsTransportationApdcommodities { get; set; }
        public virtual DbSet<TempPolicyTransactionsTransportationCargoCommodity> TempPolicyTransactionsTransportationCargoCommodities { get; set; }
        public virtual DbSet<TempPolicyTransactionsTransportationTrailerDetail> TempPolicyTransactionsTransportationTrailerDetails { get; set; }
        public virtual DbSet<TempPolicyTransactionsTransportationVehicleDetail> TempPolicyTransactionsTransportationVehicleDetails { get; set; }
        public virtual DbSet<TypeOfCarrier> TypeOfCarriers { get; set; }
        public virtual DbSet<TypeOfLiability> TypeOfLiabilities { get; set; }
        public virtual DbSet<TypeOfUnit> TypeOfUnits { get; set; }
        public virtual DbSet<TypeOfVehicle> TypeOfVehicles { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("name=UniversalDatabaseConnection", x => x.UseNetTopologySuite());
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "Latin1_General_CI_AS");

            modelBuilder.Entity<Agent>(entity =>
            {
                entity.HasKey(e => e.CompanyId)
                    .HasName("PK_Company");

                entity.HasIndex(e => e.CompanyId, "IX_Agents")
                    .IsUnique();

                entity.HasIndex(e => e.CompanyId, "ix_Agents_CompanyID_Includes")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.CompanyId, e.IsTestAgent }, "ix_Agents_CompanyID_IsTestAgent")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.UniqueAgentReference, e.CompanyId }, "ix_Agents_UniqueAgentReference_CompanyID")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.UniqueAgentReference, e.CompanyId, e.CompanyName }, "ix_Agents_UniqueAgentReference_CompanyID_CompanyName_Includes")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.UniqueAgentReference, "ix_Agents_UniqueAgentReference_Includes")
                    .HasFillFactor((byte)100);

                entity.Property(e => e.CompanyId)
                    .ValueGeneratedNever()
                    .HasColumnName("CompanyID");

                entity.Property(e => e.AgentLogo).HasColumnType("image");

                entity.Property(e => e.AgentLogoContentType)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AgentLogoFileName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.AmigagentNo)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("AMIGAgentNo");

                entity.Property(e => e.AmigliveDocucorp).HasColumnName("AMIGLiveDocucorp");

                entity.Property(e => e.Amigxlsagent)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("AMIGXLSAgent");

                entity.Property(e => e.Amsclaims)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("AMSClaims");

                entity.Property(e => e.Amspremiums)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("AMSPremiums");

                entity.Property(e => e.Bcaimintegration)
                    .HasColumnName("BCAIMIntegration")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Bcalisintegration)
                    .HasColumnName("BCALISIntegration")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.CompanyName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DefaultAvatar).HasColumnType("image");

                entity.Property(e => e.DefaultAvatarContentType)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DefaultAvatarFileName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpPdfoptionEnabled)
                    .HasColumnName("DocucorpPDFOptionEnabled")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.DocucorpStatus)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.FormSetIdreversalProcessing)
                    .HasColumnName("FormSetIDReversalProcessing")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.GlobalClientCode)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.GlukclientId).HasColumnName("GLUKClientID");

                entity.Property(e => e.Glukxlsagent)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("GLUKXLSAgent");

                entity.Property(e => e.IsClaimsTpa)
                    .HasColumnName("IsClaimsTPA")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IsTestAgent).HasDefaultValueSql("((0))");

                entity.Property(e => e.ManagementSystem)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Notes).IsUnicode(false);

                entity.Property(e => e.OverLimitEscalationEmailAddresses).IsUnicode(false);

                entity.Property(e => e.PolicyPrefix)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.RoofConstructionScheme)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.RoofShapeScheme)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.RtdcloneOpenNotReportedAllowed).HasColumnName("RTDCloneOpenNotReportedAllowed");

                entity.Property(e => e.SendAutomaticEmails).HasDefaultValueSql("((0))");

                entity.Property(e => e.ShortName)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.TpalegacyXlsoffice)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("TPALegacyXLSOffice")
                    .IsFixedLength(true);

                entity.Property(e => e.UniqueAgentReference)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.WstriggersEmailSubmissionReport)
                    .HasColumnName("WSTriggersEmailSubmissionReport")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.WstriggersEmailSubmissionReportSendUpToDate)
                    .HasColumnType("datetime")
                    .HasColumnName("WSTriggersEmailSubmissionReportSendUpToDate");
            });

            modelBuilder.Entity<LogImportedFile>(entity =>
            {
                entity.HasKey(e => new { e.ImportFilename, e.DuplicateFileSeq, e.UniqueAgentReference })
                    .IsClustered(false);

                entity.HasIndex(e => new { e.DateImported, e.DateCheckPremiumsRun, e.DateCheckLocationsRun, e.DateCheckClaimsRun, e.DatePostImportEnd }, "IX_DateImported_DateCheckPremiumsRun_DateCheckLocationsRun_DateCheckClaimsRun_DatePostImportEnd_Includes")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.ImportFilename, e.DuplicateFileSeq }, "IX_LogImportedFiles")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => e.DateAgentAdvised, "IX_LogImportedFiles_DateAgentAdvised")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TpauniqueAgentReference, e.DateAgentAdvised, e.DateImported, e.UniqueAgentReference, e.DuplicateFileSeq, e.ImportFilename }, "ix_LogImportedFiles_TPAUniqueAgentReference_DateAgentAdvised_DateImported_UniqueAgentReference_DuplicateFileSeq_ImportFilename")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.UniqueAgentReference, e.DateAgentAdvised, e.DateImported }, "ix_LogImportedFiles_UniqueAgentReference_DateAgentAdvised_DateImported")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.UniqueAgentReference, e.DateImported, e.DateAgentAdvised }, "ix_LogImportedFiles_UniqueAgentReference_DateImported_DateAgentAdvised")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.UniqueAgentReference, e.ImportFilename, e.DuplicateFileSeq, e.DateAgentAdvised, e.DateImported }, "ix_LogImportedFiles_UniqueAgentReference_ImportFilename_DuplicateFileSeq_DateAgentAdvised_DateImported")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.WsticketId, e.DuplicateFileSeq, e.ImportFilename, e.UniqueAgentReference }, "ix_LogImportedFiles_WSTicketID_DuplicateFileSeq_ImportFilename_UniqueAgentReference")
                    .HasFillFactor((byte)90);

                entity.HasIndex(e => new { e.WsticketId, e.ImportFilename, e.UniqueAgentReference, e.DuplicateFileSeq }, "ix_LogImportedFiles_WSTicketID_ImportFilename_UniqueAgentReference_DuplicateFileSeq")
                    .HasFillFactor((byte)80);

                entity.Property(e => e.ImportFilename)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UniqueAgentReference)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.Contract)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.DateAgentAdvised).HasColumnType("datetime");

                entity.Property(e => e.DateCheckClaimsRun).HasColumnType("datetime");

                entity.Property(e => e.DateCheckLocationsRun).HasColumnType("datetime");

                entity.Property(e => e.DateCheckPremiumsRun).HasColumnType("datetime");

                entity.Property(e => e.DateCorrectionDetectorLocationsRun).HasColumnType("datetime");

                entity.Property(e => e.DateCorrectionDetectorPremiumsRun).HasColumnType("datetime");

                entity.Property(e => e.DateImported).HasColumnType("datetime");

                entity.Property(e => e.DatePostImportEnd).HasColumnType("datetime");

                entity.Property(e => e.DatePostImportStart).HasColumnType("datetime");

                entity.Property(e => e.FileTypeId).HasColumnName("FileTypeID");

                entity.Property(e => e.GlukenteredDateFrom)
                    .HasColumnType("date")
                    .HasColumnName("GLUKEnteredDateFrom");

                entity.Property(e => e.GlukenteredDateTo)
                    .HasColumnType("date")
                    .HasColumnName("GLUKEnteredDateTo");

                entity.Property(e => e.ImportFileDate).HasColumnType("datetime");

                entity.Property(e => e.PickedUpFrom)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.PostImportProcessingTimeMillisecond).HasComputedColumnSql("(datediff(millisecond,[DatePostImportStart],[DatePostImportEnd]))", false);

                entity.Property(e => e.SavedTo)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Section)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.TpauniqueAgentReference)
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("TPAUniqueAgentReference");

                entity.Property(e => e.WsticketId).HasColumnName("WSTicketID");

                entity.HasOne(d => d.Wsticket)
                    .WithMany(p => p.LogImportedFiles)
                    .HasForeignKey(d => d.WsticketId)
                    .OnDelete(DeleteBehavior.SetNull)
                    .HasConstraintName("FK_LogImportedFiles_LogImportedFilesWS");
            });

            modelBuilder.Entity<LogImportedFilesW>(entity =>
            {
                entity.HasKey(e => e.WsticketId)
                    .IsClustered(false);

                entity.ToTable("LogImportedFilesWS");

                entity.HasIndex(e => new { e.FileStatus, e.FileSaved }, "IX_LogImportedFilesWS_FileStatus_FileSaved")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => e.ClientFileName, "ix_LogImportedFilesWS_ClientFileName")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.ClientFileName, e.UniqueAgentReference }, "ix_LogImportedFilesWS_ClientFileName_UniqueAgentReference")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TicketRequestDate, e.WsticketId }, "ix_LogImportedFilesWS_TicketRequestDate_WSTicketID")
                    .HasFillFactor((byte)80);

                entity.Property(e => e.WsticketId)
                    .ValueGeneratedNever()
                    .HasColumnName("WSTicketID");

                entity.Property(e => e.ClientFileName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.FileContents).HasColumnType("image");

                entity.Property(e => e.FileSavedDate).HasColumnType("datetime");

                entity.Property(e => e.PreXsltfileName)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("PreXSLTFileName");

                entity.Property(e => e.ProcessingLog).IsUnicode(false);

                entity.Property(e => e.ProcessingLogClient).IsUnicode(false);

                entity.Property(e => e.ProcessingStartDate).HasColumnType("datetime");

                entity.Property(e => e.ProcessingTimeMillisecond).HasComputedColumnSql("(datediff(millisecond,[TicketRequestDate],[TicketEndProcessingDate]))", false);

                entity.Property(e => e.TicketEndProcessingDate).HasColumnType("datetime");

                entity.Property(e => e.TicketRequestDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UniqueAgentReference)
                    .IsRequired()
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.Username)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.XsltfallBackTransformationUsed).HasColumnName("XSLTFallBackTransformationUsed");
            });

            modelBuilder.Entity<NatureOfLocation>(entity =>
            {
                entity.HasKey(e => e.NatureOfLocations);

                entity.Property(e => e.NatureOfLocations).ValueGeneratedNever();

                entity.Property(e => e.Description)
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<NatureOfTrade>(entity =>
            {
                entity.HasKey(e => e.NatureOfTrade1);

                entity.ToTable("NatureOfTrade");

                entity.Property(e => e.NatureOfTrade1)
                    .ValueGeneratedNever()
                    .HasColumnName("NatureOfTrade");

                entity.Property(e => e.Description)
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ProfessionalLiabilityAttorneyHour>(entity =>
            {
                entity.HasKey(e => e.AttorneyHoursId)
                    .HasName("PK__Professi__DB53B743F0016843");

                entity.ToTable("ProfessionalLiability_AttorneyHours");

                entity.Property(e => e.AttorneyHoursId)
                    .ValueGeneratedNever()
                    .HasColumnName("AttorneyHoursID");

                entity.Property(e => e.AttorneyHours)
                    .IsRequired()
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.LineOfBusiness)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.ModificationFactor).HasColumnType("decimal(9, 3)");

                entity.Property(e => e.VersionNo)
                    .IsRequired()
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('V.01.00')");

                entity.Property(e => e.VersionRelease)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<ProfessionalLiabilityClientIndustry>(entity =>
            {
                entity.HasKey(e => e.ClientIndustryId)
                    .HasName("PK__Professi__778DAF7BFC917D4B");

                entity.ToTable("ProfessionalLiability_ClientIndustry");

                entity.Property(e => e.ClientIndustryId).HasColumnName("ClientIndustryID");

                entity.Property(e => e.ClientIndustry)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ModificationFactorHigh)
                    .HasColumnType("decimal(9, 3)")
                    .HasColumnName("ModificationFactor_High");

                entity.Property(e => e.ModificationFactorLow)
                    .HasColumnType("decimal(9, 3)")
                    .HasColumnName("ModificationFactor_Low");

                entity.Property(e => e.ModificationFactorMedium)
                    .HasColumnType("decimal(9, 3)")
                    .HasColumnName("ModificationFactor_Medium");

                entity.Property(e => e.VersionNo)
                    .IsRequired()
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('V.01.00')");

                entity.Property(e => e.VersionRelease)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<ProfessionalLiabilityContinuingLegalEducation>(entity =>
            {
                entity.HasKey(e => e.ContinuingLegalEducationId)
                    .HasName("PK__Professi__E0511C38A7A4BFA0");

                entity.ToTable("ProfessionalLiability_ContinuingLegalEducation");

                entity.Property(e => e.ContinuingLegalEducationId).HasColumnName("ContinuingLegalEducationID");

                entity.Property(e => e.ContinuingLegalEducation)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ModificationFactor).HasColumnType("decimal(9, 3)");

                entity.Property(e => e.VersionNo)
                    .IsRequired()
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('V.01.00')");

                entity.Property(e => e.VersionRelease)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<ProfessionalLiabilityLitigationHistory>(entity =>
            {
                entity.HasKey(e => e.LitigationHistoryId)
                    .HasName("PK__Professi__43D7AEC60734DB2E");

                entity.ToTable("ProfessionalLiability_LitigationHistory");

                entity.Property(e => e.LitigationHistoryId).HasColumnName("LitigationHistoryID");

                entity.Property(e => e.LitigationHistory)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ModificationFactor).HasColumnType("decimal(9, 3)");

                entity.Property(e => e.VersionNo)
                    .IsRequired()
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('V.01.00')");

                entity.Property(e => e.VersionRelease)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<ProfessionalLiabilityLoyaltyCredit>(entity =>
            {
                entity.HasKey(e => e.LoyaltyCreditId)
                    .HasName("PK__Professi__E94ECD6AA9C93E0D");

                entity.ToTable("ProfessionalLiability_LoyaltyCredit");

                entity.Property(e => e.LoyaltyCreditId).HasColumnName("LoyaltyCreditID");

                entity.Property(e => e.LoyaltyCredit)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.ModificationFactor).HasColumnType("decimal(9, 3)");

                entity.Property(e => e.VersionNo)
                    .IsRequired()
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('V.01.00')");

                entity.Property(e => e.VersionRelease)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<ProfessionalLiabilityPriorAct>(entity =>
            {
                entity.HasKey(e => e.PriorActsId)
                    .HasName("PK__Professi__1C4D36102DB3B39F");

                entity.ToTable("ProfessionalLiability_PriorActs");

                entity.Property(e => e.PriorActsId)
                    .ValueGeneratedNever()
                    .HasColumnName("PriorActsID");

                entity.Property(e => e.ModificationFactor).HasColumnType("decimal(9, 3)");

                entity.Property(e => e.PriorActs)
                    .IsRequired()
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.VersionNo)
                    .IsRequired()
                    .HasMaxLength(8)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('V.01.00')");

                entity.Property(e => e.VersionRelease)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");
            });

            modelBuilder.Entity<TempPolicyTransaction>(entity =>
            {
                entity.HasKey(e => e.TempPremiumsId)
                    .HasName("PK_TempPremiumsTransactions");

                entity.HasIndex(e => new { e.CorrectedBy, e.Rms17completeDate, e.CompanyId, e.TransactionType }, "IX_CorrectedBy_RMS17CompleteDate_CompanyID_TransactionType_Includes");

                entity.HasIndex(e => new { e.CorrectedBy, e.RmssubmitDate, e.RmsgeoCompleteDate, e.TransactionType, e.PolicyNo, e.RmsgeoSubmitDate }, "IX_CorrectedBy_RMSSubmitDate_RMSGeoCompleteDate_TransactionType_PolicyNo_RMSGeoSubmitDate")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.MrX, e.MrY, e.TransactionType, e.InsuredStreet, e.InsuredZipCode, e.QuoteType }, "IX_MR_X_MR_Y_TransactionType_InsuredStreet_InsuredZipCode_QuoteType_Includes")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.Rms17completeDate, e.CompanyId, e.TransactionType, e.PolicyNo, e.Rms17submitDate }, "IX_RMS17CompleteDate_CompanyID_TransactionType_PolicyNo_RMS17SubmitDate_Includes")
                    .HasFillFactor((byte)90);

                entity.HasIndex(e => new { e.Rms17submitDate, e.Rms17geoCompleteDate, e.CompanyId, e.TransactionType, e.PolicyNo, e.Rms17geoSubmitDate }, "IX_RMS17SubmitDate_RMS17GeoCompleteDate_CompanyID_TransactionType_PolicyNo_RMS17GeoSubmitDate")
                    .HasFillFactor((byte)90);

                entity.HasIndex(e => e.UniqueAgentReference, "ixTempPolicyTransactions_UniqueAgentReference")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.CorrectedBy, e.RmscompleteDate, e.PolicyNo, e.RmssubmitDate, e.TransactionType }, "ix_CorrectedBy_RMSCompleteDatePolicyNo_RMSSubmitDate_TransactionType")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => e.CompanyId, "ix_TempPolicyTransactions_CompanyID")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.CompanyId, e.CorrectedBy, e.AccountingEffectiveDate, e.TempPremiumsId }, "ix_TempPolicyTransactions_CompanyID_CorrectedBy_AccountingEffectiveDate_TempPremiumsID")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.CompanyId, e.InsuredEntityId }, "ix_TempPolicyTransactions_CompanyID_InsuredEntityID");

                entity.HasIndex(e => new { e.CompanyId, e.TempPremiumsId, e.PolicyNo, e.TransactionType }, "ix_TempPolicyTransactions_CompanyID_TempPremiumsID_PolicyNo_TransactionType");

                entity.HasIndex(e => new { e.CompanyId, e.TempPremiumsId, e.UniqueAgentReference }, "ix_TempPolicyTransactions_CompanyID_TempPremiumsID_UniqueAgentReference_Includes");

                entity.HasIndex(e => new { e.CompanyId, e.UniqueAgentReference }, "ix_TempPolicyTransactions_CompanyID_UniqueAgentReference_Includes");

                entity.HasIndex(e => e.CorrectedBy, "ix_TempPolicyTransactions_CorrectedBy");

                entity.HasIndex(e => new { e.CorrectedBy, e.IgnoreRecord, e.ImportFilename }, "ix_TempPolicyTransactions_CorrectedBy_IgnoreRecord_ImportFilename")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.CorrectedBy, e.PolicyNo, e.TempPremiumsId, e.TransactionType, e.CompanyId }, "ix_TempPolicyTransactions_CorrectedBy_PolicyNo_TempPremiumsID_TransactionType_CompanyID_Includes")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.CorrectedBy, e.QuoteType, e.TransactionType, e.TotalPropertyLimit, e.RmsgeoSubmitDate, e.RmsgeoCompleteDate }, "ix_TempPolicyTransactions_CorrectedBy_QuoteType_TransactionType_TotalPropertyLimit_RMSGeoSubmitDate_RMSGeoCompleteDate_includes")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.CorrectedBy, e.RmscompleteDate, e.CompanyId, e.TransactionType }, "ix_TempPolicyTransactions_CorrectedBy_RMSCompleteDate_CompanyID_TransactionType_includes")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.CorrectedBy, e.TempPremiumsId, e.Corrects }, "ix_TempPolicyTransactions_CorrectedBy_TempPremiumsID_Corrects")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => e.Corrects, "ix_TempPolicyTransactions_Corrects");

                entity.HasIndex(e => e.FormSetId, "ix_TempPolicyTransactions_FormSetID")
                    .HasFillFactor((byte)90);

                entity.HasIndex(e => new { e.GoogleX, e.GoogleY, e.InsuredStreet }, "ix_TempPolicyTransactions_GeoGoogle")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.MrX, e.TransactionType, e.MrY, e.TempPremiumsId }, "ix_TempPolicyTransactions_GeoMR")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.GlobalEndorsementId, e.GlobalPolicyId, e.CompanyId, e.AccountingEffectiveDate, e.TempPremiumsId }, "ix_TempPolicyTransactions_GlobalEndorsementID_GlobalPolicyID_CompanyID_AccountingEffectiveDate_TempPremiumsID")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => e.ImportFilename, "ix_TempPolicyTransactions_ImportFilename")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.ImportFilename, e.TempPremiumsId }, "ix_TempPolicyTransactions_ImportFilename_TempPremiumsID_Includes")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.MrY, e.MrX, e.TransactionType, e.TempPremiumsId, e.CompanyId, e.InsuredCity, e.InsuredCounty, e.InsuredState, e.InsuredZipCode, e.InsuredCountryScheme, e.InsuredCountryCode }, "ix_TempPolicyTransactions_MR_Y_MR_X_TransactionType_TempPremiumsID_CompanyID_InsuredCity_InsuredCounty_InsuredState_InsuredZipCo");

                entity.HasIndex(e => new { e.MoveToLiveSeqNo, e.PolicyNo, e.CompanyId, e.TempPremiumsId }, "ix_TempPolicyTransactions_MoveToLiveSeqNo_PolicyNo_CompanyID_TempPremiumsID_Includes")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.CompanyId, e.ParentRui }, "ix_TempPolicyTransactions_ParentRUI")
                    .HasFillFactor((byte)90);

                entity.HasIndex(e => new { e.PolicyNo, e.CompanyId, e.MoveToLiveSeqNo, e.BordYear, e.BordMonth, e.TempPremiumsId }, "ix_TempPolicyTransactions_PolicyNo_CompanyID_MoveToLiveSeqNo_BordYear_BordMonth_TempPremiumsID")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.PolicyNo, e.CompanyId, e.TempPremiumsId }, "ix_TempPolicyTransactions_PolicyNo_CompanyID_TempPremiumsID_Includes")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.PolicyNo, e.TempPremiumsId, e.CorrectedBy, e.IgnoreRecord, e.DuplicateRecord, e.MoveToLiveSeqNo, e.CompanyId }, "ix_TempPolicyTransactions_PolicyNo_TempPremiumsID_CorrectedBy_IgnoreRecord_DuplicateRecord_MoveToLiveSeqNo_CompanyID_Includes")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.PolicyNo, e.TempPremiumsId, e.TransactionType, e.IgnoreRecord, e.DuplicateRecord, e.CorrectedBy }, "ix_TempPolicyTransactions_PolicyNo_TempPremiumsID_TransactionType_IgnoreRecord_DuplicateRecord_CorrectedBy")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.PolicyNo, e.TransactionType, e.TempPremiumsId }, "ix_TempPolicyTransactions_PolicyNo_TransactionType_TempPremiumsID")
                    .HasFillFactor((byte)90);

                entity.HasIndex(e => new { e.PolicyNo, e.TransactionType, e.TempPremiumsId, e.EffectiveDate }, "ix_TempPolicyTransactions_PolicyNo_TransactionType_TempPremiumsID_EffectiveDate")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.RmscompleteDate, e.CompanyId, e.TransactionType, e.PolicyNo, e.RmssubmitDate }, "ix_TempPolicyTransactions_RMSCompleteDate_CompanyID_TransactionType_PolicyNo_RMSSubmitDate")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.RmsgeoCompleteDate, e.CompanyId, e.TransactionType, e.PolicyNo, e.RmsgeoSubmitDate }, "ix_TempPolicyTransactions_RMSGeoCompleteDate_CompanyID_TransactionType_PolicyNo_RMSGeoSubmitDate")
                    .HasFillFactor((byte)90);

                entity.HasIndex(e => new { e.TempPremiumsId, e.CompanyId, e.ContractRef, e.TransactionType, e.EffectiveDate }, "ix_TempPolicyTransactions_TempPremiumsID_CompanyID_ContractRef_TransactionType_EffectiveDate");

                entity.HasIndex(e => new { e.TempPremiumsId, e.CompanyId, e.InsuredEntityId, e.TransactionType }, "ix_TempPolicyTransactions_TempPremiumsID_CompanyID_InsuredEntityID_TransactionType");

                entity.HasIndex(e => new { e.TempPremiumsId, e.CompanyId, e.TransactionType }, "ix_TempPolicyTransactions_TempPremiumsID_CompanyID_TransactionType")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TempPremiumsId, e.CorrectedBy, e.TransactionType, e.IsTestData, e.InHouseHold, e.RecordError, e.IgnoreRecord, e.CompanyId, e.ImportFilename, e.RmscompleteDate }, "ix_TempPolicyTransactions_TempPremiumsID_CorrectedBy_TransactionType_IsTestData_InHouseHold_RecordError_IgnoreRecord_CompanyID_I")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TempPremiumsId, e.EffectiveDate, e.AccountingEffectiveDate, e.BordMonth, e.CorrectedBy, e.BordYear, e.CompanyId }, "ix_TempPolicyTransactions_TempPremiumsID_EffectiveDate_AccountingEffectiveDate_BordMonth_CorrectedBy_BordYear_CompanyID_Includes")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TempPremiumsId, e.ImportFilename, e.DuplicateFileSeq, e.UniqueAgentReference }, "ix_TempPolicyTransactions_TempPremiumsID_ImportFilename_DuplicateFileSeq_UniqueAgentReference");

                entity.HasIndex(e => new { e.TempPremiumsId, e.PolicyNo }, "ix_TempPolicyTransactions_TempPremiumsID_PolicyNo")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TempPremiumsId, e.PolicyNo, e.CompanyId, e.TransactionType }, "ix_TempPolicyTransactions_TempPremiumsID_PolicyNo_CompanyID_TransactionType");

                entity.HasIndex(e => new { e.TempPremiumsId, e.PolicyNo, e.TransactionType }, "ix_TempPolicyTransactions_TempPremiumsID_PolicyNo_TransactionType");

                entity.HasIndex(e => new { e.TempPremiumsId, e.TransactionType }, "ix_TempPolicyTransactions_TempPremiumsID_TransactionType")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TransactionType, e.GlobalPolicyId, e.CompanyId, e.AccountingEffectiveDate, e.InHouseHold, e.TempPremiumsId }, "ix_TempPolicyTransactions_TransactionType_GlobalPolicyID_CompanyID_AccountingEffectiveDate_InHouseHold_TempPremiumsID_Includes")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TransactionType, e.GlobalPolicyId, e.CompanyId, e.AccountingEffectiveDate, e.TempPremiumsId }, "ix_TempPolicyTransactions_TransactionType_GlobalPolicyID_CompanyID_AccountingEffectiveDate_TempPremiumsID")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TransactionType, e.InsuredZipCode, e.CompanyId, e.TempPremiumsId, e.PolicyNo, e.InsuredName, e.EffectiveDate, e.ExpirationDate }, "ix_TempPolicyTransactions_TransactionType_InsuredZipCode_CompanyID_TempPremiumsID_PolicyNo_InsuredName_EffectiveDate_ExpirationD")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TransactionType, e.ParentRui, e.EngineQuoteEnquiryId, e.CompanyId, e.InsuredEntityId }, "ix_TempPolicyTransactions_TransactionType_ParentRUI_EngineQuoteEnquiryID_CompanyID_InsuredEntityID")
                    .HasFillFactor((byte)90);

                entity.HasIndex(e => new { e.TransactionType, e.QuoteType, e.CorrectedBy, e.DateImported, e.RecordError, e.TempPremiumsId, e.CompanyId, e.SubCompanyId }, "ix_TempPolicyTransactions_TransactionType_QuoteType_CorrectedBy_DateImported_RecordError_TempPremiumsID_CompanyID_SubCompanyID_I")
                    .HasFillFactor((byte)90);

                entity.HasIndex(e => new { e.TransactionType, e.RmscompleteDate, e.RmssubmitDate, e.RmsgeoCompleteDate, e.CompanyId, e.TempPremiumsId, e.PolicyNo, e.InsuredName, e.RmsgeoSubmitDate, e.UserCreated }, "ix_TempPolicyTransactions_TransactionType_RMSCompleteDate_RMSSubmitDate_RMSGeoCompleteDate_CompanyID_TempPremiumsID_PolicyNo_Ins")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TransactionType, e.TempPremiumsId, e.CompanyId, e.ImportFilename, e.DuplicateFileSeq, e.UniqueAgentReference }, "ix_TempPolicyTransactions_TransactionType_TempPremiumsID_CompanyID_ImportFilename_DuplicateFileSeq_UniqueAgentReference");

                entity.HasIndex(e => new { e.TransactionType, e.CompanyId, e.InsuredEntityId, e.EngineQuoteEnquiryId }, "ix_TempPolicyTransactions_Transactiontype_CompanyID_InsuredEntityID_EngineQuoteEnquiryID");

                entity.Property(e => e.TempPremiumsId).HasColumnName("TempPremiumsID");

                entity.Property(e => e.AccountCurrentSignedOff).HasColumnType("datetime");

                entity.Property(e => e.AccountingEffectiveDate).HasColumnType("datetime");

                entity.Property(e => e.AdditionalNamedInsured)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.AllOther).HasColumnType("money");

                entity.Property(e => e.AmigclassOfBusinessCode)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("AMIGClassOfBusinessCode");

                entity.Property(e => e.AmigcontractAsplitPercentage).HasColumnName("AMIGContractASplitPercentage");

                entity.Property(e => e.AmigcontractBsplitPercentage).HasColumnName("AMIGContractBSplitPercentage");

                entity.Property(e => e.AnimalLiablityCoverage).HasColumnType("money");

                entity.Property(e => e.Aopdeductible)
                    .HasColumnType("money")
                    .HasColumnName("AOPDeductible");

                entity.Property(e => e.AttachmentPoint).HasColumnType("money");

                entity.Property(e => e.Bccommission)
                    .HasColumnType("money")
                    .HasColumnName("BCCommission");

                entity.Property(e => e.BccustomErrorMessage)
                    .IsUnicode(false)
                    .HasColumnName("BCCustomErrorMessage");

                entity.Property(e => e.BodilyInjuryByAccidentLimit).HasColumnType("money");

                entity.Property(e => e.BodilyInjuryByDiseaseAggregateLimit).HasColumnType("money");

                entity.Property(e => e.BodilyInjuryByDiseaseEachEmployeeLimit).HasColumnType("money");

                entity.Property(e => e.BordereauType)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.BusinessArea)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CalcEquipmentBreakDownPremium).HasColumnType("money");

                entity.Property(e => e.CalcHomeSystemsProtectionPremium).HasColumnType("money");

                entity.Property(e => e.CalcIdentityTheftRecoveryPremium).HasColumnType("money");

                entity.Property(e => e.CalcServiceLinePremium).HasColumnType("money");

                entity.Property(e => e.Catdeductible)
                    .HasColumnType("money")
                    .HasColumnName("CATDeductible");

                entity.Property(e => e.CdmatchPercentage).HasColumnName("CDMatchPercentage");

                entity.Property(e => e.CedingCoNameRetailAgent)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.CertificateNumber)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.ChangeDescription).IsUnicode(false);

                entity.Property(e => e.CheckOnly).HasDefaultValueSql("((0))");

                entity.Property(e => e.CoInsurancePercentage).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.Commission).HasColumnType("money");

                entity.Property(e => e.CompanyId).HasColumnName("CompanyID");

                entity.Property(e => e.CompanyNumber)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.ConstructionCode)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ConstructionCodeScheme)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ContractRef)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.ContractShare).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.CoverageForm).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.CrimeDeductible).HasColumnType("money");

                entity.Property(e => e.CrimeLimit).HasColumnType("money");

                entity.Property(e => e.CrimePremium).HasColumnType("money");

                entity.Property(e => e.CrimeRate).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.CyberLiabilityLimit).HasColumnType("money");

                entity.Property(e => e.CyberLiabilityPremium).HasColumnType("money");

                entity.Property(e => e.DateCreated)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DateErrorChecksFirstRun).HasColumnType("datetime");

                entity.Property(e => e.DateErrorChecksLastRunEnd).HasColumnType("datetime");

                entity.Property(e => e.DateErrorChecksLastRunStart).HasColumnType("datetime");

                entity.Property(e => e.DateImported)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.DateOfLastLoss).HasColumnType("date");

                entity.Property(e => e.DateUpdated).HasColumnType("datetime");

                entity.Property(e => e.DocEndRevisedPropLimit)
                    .HasColumnType("money")
                    .HasColumnName("DocEND_RevisedPropLimit");

                entity.Property(e => e.DocEndTotalLiability)
                    .HasColumnType("money")
                    .HasColumnName("DocEND_TotalLiability");

                entity.Property(e => e.DocEndTotalProperty)
                    .HasColumnType("money")
                    .HasColumnName("DocEND_TotalProperty");

                entity.Property(e => e.DocEndTotalTerror)
                    .HasColumnType("money")
                    .HasColumnName("DocEND_TotalTerror");

                entity.Property(e => e.DocucorpAgentAddr)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpAgentCity)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpAgentName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpAgentState)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpAgentZip)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpAgentZipPlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpDamagePremRented)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("DOCUCORP_DAMAGE_PREM_RENTED");

                entity.Property(e => e.DocucorpMedExpenseLmt)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("DOCUCORP_MED_EXPENSE_LMT");

                entity.Property(e => e.DocucorpPersonalAndAdvertising)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("DOCUCORP_PERSONAL_AND_ADVERTISING");

                entity.Property(e => e.DocucorpProductCompletedOper)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("DOCUCORP_PRODUCT_COMPLETED_OPER");

                entity.Property(e => e.DocucorpTransCode)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.DqicoreScore)
                    .HasColumnType("decimal(6, 4)")
                    .HasColumnName("DQICoreScore");

                entity.Property(e => e.DqiquakeScore)
                    .HasColumnType("decimal(6, 4)")
                    .HasColumnName("DQIQuakeScore");

                entity.Property(e => e.DqiwindScore)
                    .HasColumnType("decimal(6, 4)")
                    .HasColumnName("DQIWindScore");

                entity.Property(e => e.DuplicateFileSeq).HasDefaultValueSql("((0))");

                entity.Property(e => e.DuplicateRecord).HasDefaultValueSql("((0))");

                entity.Property(e => e.EffectiveDate).HasColumnType("datetime");

                entity.Property(e => e.Ellimit)
                    .HasColumnType("money")
                    .HasColumnName("ELLimit");

                entity.Property(e => e.Elpremium)
                    .HasColumnType("money")
                    .HasColumnName("ELPremium");

                entity.Property(e => e.EndorsementNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EngineQuoteEnquiryId)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("EngineQuoteEnquiryID");

                entity.Property(e => e.EqappendagesandOrnamentation).HasColumnName("EQAppendagesandOrnamentation");

                entity.Property(e => e.EqbaseIsolation).HasColumnName("EQBaseIsolation");

                entity.Property(e => e.EqcladdingType).HasColumnName("EQCladdingType");

                entity.Property(e => e.EqconstructionQuality).HasColumnName("EQConstructionQuality");

                entity.Property(e => e.EqcrippleWalls).HasColumnName("EQCrippleWalls");

                entity.Property(e => e.EqengineeredFoundation).HasColumnName("EQEngineeredFoundation");

                entity.Property(e => e.EqequipmentSupportMaintenance).HasColumnName("EQEquipmentSupportMaintenance");

                entity.Property(e => e.EqframeBolted).HasColumnName("EQFrameBolted");

                entity.Property(e => e.EqmechanicalandElectricalEquipmentEarthquakeBracing).HasColumnName("EQMechanicalandElectricalEquipmentEarthquakeBracing");

                entity.Property(e => e.EqplanIrregularity).HasColumnName("EQPlanIrregularity");

                entity.Property(e => e.Eqpounding).HasColumnName("EQPounding");

                entity.Property(e => e.EqshortColumnCondition).HasColumnName("EQShortColumnCondition");

                entity.Property(e => e.EqsoftStory).HasColumnName("EQSoftStory");

                entity.Property(e => e.EqsprinklerLeakageCoverageFlag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("EQSprinklerLeakageCoverageFlag");

                entity.Property(e => e.EqsprinklerLeakageSusceptibility).HasColumnName("EQSprinklerLeakageSusceptibility");

                entity.Property(e => e.EqsprinklerType).HasColumnName("EQSprinklerType");

                entity.Property(e => e.EqstructuralUpgrade).HasColumnName("EQStructuralUpgrade");

                entity.Property(e => e.EqtiltUpRetrofit).HasColumnName("EQTiltUpRetrofit");

                entity.Property(e => e.EquipmentBreakdown)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.EquipmentBreakdownPremium).HasColumnType("money");

                entity.Property(e => e.EqunreinforcedMasonryPartitionsorChimneys).HasColumnName("EQUnreinforcedMasonryPartitionsorChimneys");

                entity.Property(e => e.EqunreinforcedMasonryRetrofit).HasColumnName("EQUnreinforcedMasonryRetrofit");

                entity.Property(e => e.EqverticalIrregularity).HasColumnName("EQVerticalIrregularity");

                entity.Property(e => e.ExpirationDate).HasColumnType("datetime");

                entity.Property(e => e.ExpiringPolicyNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ExtendedLiabilityRentedLocationsFamilies)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ExtendedLiabilityToRentedLocationsAmount).HasColumnType("money");

                entity.Property(e => e.FirstFloorHeightAboveGround).HasColumnType("decimal(3, 1)");

                entity.Property(e => e.FlfoundationType).HasColumnName("FLFoundationType");

                entity.Property(e => e.FloodDeductible).HasColumnType("money");

                entity.Property(e => e.FloodLimit).HasColumnType("money");

                entity.Property(e => e.FloodZone)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.ForDebugRequestPricingEngineVersion)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FormSetId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("FormSetID");

                entity.Property(e => e.FullTermEndorsementPremium).HasColumnType("money");

                entity.Property(e => e.GlaggregateLimit)
                    .HasColumnType("money")
                    .HasColumnName("GLAggregateLimit");

                entity.Property(e => e.GlobalEndorsementId).HasColumnName("GlobalEndorsementID");

                entity.Property(e => e.GlobalPolicyId).HasColumnName("GlobalPolicyID");

                entity.Property(e => e.GlukbppLimit)
                    .HasColumnType("money")
                    .HasColumnName("GLUKBppLimit");

                entity.Property(e => e.GlukbrokasureTransactionNumber).HasColumnName("GLUKBrokasureTransactionNumber");

                entity.Property(e => e.GlukbusinessIncome)
                    .HasColumnType("money")
                    .HasColumnName("GLUKBusinessIncome");

                entity.Property(e => e.Glukcpllimit)
                    .HasColumnType("money")
                    .HasColumnName("GLUKCPLLimit");

                entity.Property(e => e.Glukcplpremium)
                    .HasColumnType("money")
                    .HasColumnName("GLUKCPLPremium");

                entity.Property(e => e.GlukdistanceFromSaltWater)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("GLUKDistanceFromSaltWater");

                entity.Property(e => e.GlukfireDeductible)
                    .HasColumnType("money")
                    .HasColumnName("GLUKFireDeductible");

                entity.Property(e => e.GlukfireIncluded)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("GLUKFireIncluded")
                    .IsFixedLength(true);

                entity.Property(e => e.GlukfloodIncluded)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("GLUKFloodIncluded")
                    .IsFixedLength(true);

                entity.Property(e => e.GlukhailDeductible)
                    .HasColumnType("money")
                    .HasColumnName("GLUKHailDeductible");

                entity.Property(e => e.GlukhailIncluded)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("GLUKHailIncluded")
                    .IsFixedLength(true);

                entity.Property(e => e.GlukinHouseEndorsementNumber).HasColumnName("GLUKInHouseEndorsementNumber");

                entity.Property(e => e.GlukpaymentBasis)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("GLUKPaymentBasis")
                    .IsFixedLength(true);

                entity.Property(e => e.GlukquakeIncluded)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("GLUKQuakeIncluded")
                    .IsFixedLength(true);

                entity.Property(e => e.GluksltbrokerId).HasColumnName("GLUKSLTBrokerID");

                entity.Property(e => e.GlukspareText)
                    .IsUnicode(false)
                    .HasColumnName("GLUKSpareText");

                entity.Property(e => e.Glukwcapremium)
                    .HasColumnType("money")
                    .HasColumnName("GLUKWCAPremium");

                entity.Property(e => e.GlukwindIncluded)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("GLUKWindIncluded")
                    .IsFixedLength(true);

                entity.Property(e => e.GlukwindstormDeductible)
                    .HasColumnType("money")
                    .HasColumnName("GLUKWindstormDeductible");

                entity.Property(e => e.GlukzonePerilsId).HasColumnName("GLUKZonePerilsID");

                entity.Property(e => e.GoogleElevation).HasColumnName("GOOGLE_Elevation");

                entity.Property(e => e.GoogleElevationResolution).HasColumnName("GOOGLE_Elevation_Resolution");

                entity.Property(e => e.GoogleGeoCodeDate)
                    .HasColumnType("datetime")
                    .HasColumnName("GOOGLE_GeoCodeDate");

                entity.Property(e => e.GoogleLocationType)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("GOOGLE_LOCATION_TYPE");

                entity.Property(e => e.GoogleX).HasColumnName("GOOGLE_X");

                entity.Property(e => e.GoogleY).HasColumnName("GOOGLE_Y");

                entity.Property(e => e.GrossPremium).HasColumnType("money");

                entity.Property(e => e.HeatingLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.HereonPercentage).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.HistoricTiv1yearPrior)
                    .HasColumnType("money")
                    .HasColumnName("HistoricTIV1YearPrior");

                entity.Property(e => e.HistoricTiv2yearPrior)
                    .HasColumnType("money")
                    .HasColumnName("HistoricTIV2YearPrior");

                entity.Property(e => e.HistoricTiv3yearPrior)
                    .HasColumnType("money")
                    .HasColumnName("HistoricTIV3YearPrior");

                entity.Property(e => e.HoldError).HasDefaultValueSql("((0))");

                entity.Property(e => e.HomeSystemsProtectionPremium).HasColumnType("money");

                entity.Property(e => e.IdentityTheftRecovery)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.IdentityTheftRecoveryPremium).HasColumnType("money");

                entity.Property(e => e.IgnoreRecord).HasDefaultValueSql("((0))");

                entity.Property(e => e.ImportFilename)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Impremium)
                    .HasColumnType("money")
                    .HasColumnName("IMPremium");

                entity.Property(e => e.ImpremiumPolicyWide)
                    .HasColumnType("money")
                    .HasColumnName("IMPremiumPolicyWide");

                entity.Property(e => e.InHomeBusinessCoverageBusinessName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.InHomeBusinessCoverageGrossReceipts).HasColumnType("money");

                entity.Property(e => e.InHomeBusinessCoverageTypeOfBusiness)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.InHouseHold).HasDefaultValueSql("((0))");

                entity.Property(e => e.IncludedForms).IsUnicode(false);

                entity.Property(e => e.InlandMarineFloodLimitPolicyWide).HasColumnType("money");

                entity.Property(e => e.InlandMarineLimit).HasColumnType("money");

                entity.Property(e => e.InlandMarineLimitPolicyWide).HasColumnType("money");

                entity.Property(e => e.InlandMarineQuakeLimitPolicyWide).HasColumnType("money");

                entity.Property(e => e.InlandMarineWindLimitPolicyWide).HasColumnType("money");

                entity.Property(e => e.InsuredCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCountryCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCountryScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCounty)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredDoingBusinessAs)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredEntityId)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("InsuredEntityID");

                entity.Property(e => e.InsuredEntityType)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.InsuredName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredStreet)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredZipCodePlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.InvoiceNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.IsTestData).HasDefaultValueSql("((0))");

                entity.Property(e => e.IsocurrencyCode)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("ISOCurrencyCode");

                entity.Property(e => e.Isoglclass)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("ISOGLClass");

                entity.Property(e => e.IsopropertyCode)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("ISOPropertyCode");

                entity.Property(e => e.LiabilityDeductible).HasColumnType("money");

                entity.Property(e => e.LiabilityLimit).HasColumnType("money");

                entity.Property(e => e.LiabilityPremium).HasColumnType("money");

                entity.Property(e => e.LimitBuildingCoverageA).HasColumnType("money");

                entity.Property(e => e.LimitBusinessInterruptionCoverageD).HasColumnType("money");

                entity.Property(e => e.LimitContentsCoverageC).HasColumnType("money");

                entity.Property(e => e.LimitCoverageE).HasColumnType("money");

                entity.Property(e => e.LimitFirearms).HasColumnType("money");

                entity.Property(e => e.LimitJewellry).HasColumnType("money");

                entity.Property(e => e.LimitMoneyBanknotes).HasColumnType("money");

                entity.Property(e => e.LimitOtherCoverageB).HasColumnType("money");

                entity.Property(e => e.LimitPortableElectronicDevices).HasColumnType("money");

                entity.Property(e => e.LimitResidenceBurglary).HasColumnType("money");

                entity.Property(e => e.LimitSecurities).HasColumnType("money");

                entity.Property(e => e.LimitSilverware).HasColumnType("money");

                entity.Property(e => e.LossAssessmentCoverage).HasColumnType("money");

                entity.Property(e => e.MailingCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MailingCountryCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.MailingCountryScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.MailingCounty)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MailingState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.MailingStreet)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.MailingZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.MailingZipCodePlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ManualCheckedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ManualCheckedDate).HasColumnType("datetime");

                entity.Property(e => e.ManualCheckedNotes).IsUnicode(false);

                entity.Property(e => e.MedicalExpensesLimit).HasColumnType("money");

                entity.Property(e => e.MgaquoteId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("MGAQuoteID");

                entity.Property(e => e.MgaquoteVersion)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("MGAQuoteVersion");

                entity.Property(e => e.MgasubmissionId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("MGASubmissionID");

                entity.Property(e => e.MigrationOldSystemId).HasColumnName("MigrationOldSystemID");

                entity.Property(e => e.MinFloodDeductible).HasColumnType("money");

                entity.Property(e => e.MinHailHurricaneDeductible).HasColumnType("money");

                entity.Property(e => e.MinNamedStormDeductible).HasColumnType("money");

                entity.Property(e => e.MinQuakeDeductible).HasColumnType("money");

                entity.Property(e => e.MinimumCrimeAdjustmentPremium).HasColumnType("money");

                entity.Property(e => e.MinimumPropertyAdjustmentPremium).HasColumnType("money");

                entity.Property(e => e.MiscProfessionalLiabilityLimit).HasColumnType("money");

                entity.Property(e => e.MiscProfessionalLiabilityPremium).HasColumnType("money");

                entity.Property(e => e.ModifierMarketPriceAdjustment).HasColumnType("decimal(5, 4)");

                entity.Property(e => e.ModifierUnderwriterPriceAdjustment).HasColumnType("decimal(10, 8)");

                entity.Property(e => e.MrAdditionalElevation).HasColumnName("MR_Additional_ELEVATION");

                entity.Property(e => e.MrAdditionalPopulation).HasColumnName("MR_Additional_POPULATION");

                entity.Property(e => e.MrCity)
                    .HasMaxLength(150)
                    .HasColumnName("MR_CITY");

                entity.Property(e => e.MrCoordind).HasColumnName("MR_COORDIND");

                entity.Property(e => e.MrCrestaHighresId)
                    .HasMaxLength(150)
                    .HasColumnName("MR_CRESTA_HIGHRES_ID");

                entity.Property(e => e.MrCrestaHighresName)
                    .HasMaxLength(150)
                    .HasColumnName("MR_CRESTA_HIGHRES_NAME");

                entity.Property(e => e.MrCrestaLowresId)
                    .HasMaxLength(150)
                    .HasColumnName("MR_CRESTA_LOWRES_ID");

                entity.Property(e => e.MrCrestaLowresName)
                    .HasMaxLength(150)
                    .HasColumnName("MR_CRESTA_LOWRES_NAME");

                entity.Property(e => e.MrCrestaid)
                    .HasMaxLength(255)
                    .HasColumnName("MR_CRESTAID");

                entity.Property(e => e.MrCrestaname)
                    .HasMaxLength(255)
                    .HasColumnName("MR_CRESTANAME");

                entity.Property(e => e.MrDistanceToCoast).HasColumnName("MR_DISTANCE_TO_COAST");

                entity.Property(e => e.MrDistanceToFault).HasColumnName("MR_DISTANCE_TO_FAULT");

                entity.Property(e => e.MrErrAdditional)
                    .HasMaxLength(150)
                    .HasColumnName("MR_ERR_Additional");

                entity.Property(e => e.MrErrCresta)
                    .HasMaxLength(255)
                    .HasColumnName("MR_ERR_CRESTA");

                entity.Property(e => e.MrErrCrestaHighres)
                    .HasMaxLength(150)
                    .HasColumnName("MR_ERR_CRESTA_HIGHRES");

                entity.Property(e => e.MrErrCrestaLowres)
                    .HasMaxLength(150)
                    .HasColumnName("MR_ERR_CRESTA_LOWRES");

                entity.Property(e => e.MrErrGcd)
                    .HasMaxLength(255)
                    .HasColumnName("MR_ERR_GCD");

                entity.Property(e => e.MrErrHazard)
                    .HasMaxLength(255)
                    .HasColumnName("MR_ERR_Hazard");

                entity.Property(e => e.MrErrRiverflood).HasColumnName("MR_ERR_RIVERFLOOD");

                entity.Property(e => e.MrGeoCodeDate)
                    .HasColumnType("datetime")
                    .HasColumnName("MR_GeoCodeDate");

                entity.Property(e => e.MrGeozoneType)
                    .HasMaxLength(150)
                    .HasColumnName("MR_GEOZONE_TYPE");

                entity.Property(e => e.MrHazardEarthquake).HasColumnName("MR_Hazard_EARTHQUAKE");

                entity.Property(e => e.MrHazardExtratropicalstorm).HasColumnName("MR_Hazard_EXTRATROPICALSTORM");

                entity.Property(e => e.MrHazardFlashflood).HasColumnName("MR_Hazard_FLASHFLOOD");

                entity.Property(e => e.MrHazardHailstorm).HasColumnName("MR_Hazard_HAILSTORM");

                entity.Property(e => e.MrHazardLightning).HasColumnName("MR_Hazard_LIGHTNING");

                entity.Property(e => e.MrHazardStormsurge).HasColumnName("MR_Hazard_STORMSURGE");

                entity.Property(e => e.MrHazardTcyclone).HasColumnName("MR_Hazard_TCYCLONE");

                entity.Property(e => e.MrHazardTornado).HasColumnName("MR_Hazard_TORNADO");

                entity.Property(e => e.MrHazardTropicalcyclone).HasColumnName("MR_Hazard_TROPICALCYCLONE");

                entity.Property(e => e.MrHazardTsunami).HasColumnName("MR_Hazard_TSUNAMI");

                entity.Property(e => e.MrHazardVolcano).HasColumnName("MR_Hazard_VOLCANO");

                entity.Property(e => e.MrHazardWildfire).HasColumnName("MR_Hazard_WILDFIRE");

                entity.Property(e => e.MrHazardWstorm).HasColumnName("MR_Hazard_WSTORM");

                entity.Property(e => e.MrHnr)
                    .HasMaxLength(150)
                    .HasColumnName("MR_HNR");

                entity.Property(e => e.MrIso3)
                    .HasMaxLength(150)
                    .HasColumnName("MR_ISO3");

                entity.Property(e => e.MrQualind).HasColumnName("MR_QUALIND");

                entity.Property(e => e.MrRiskIndex).HasColumnName("MR_RiskIndex");

                entity.Property(e => e.MrRiskIndexEq).HasColumnName("MR_RiskIndexEq");

                entity.Property(e => e.MrRiskIndexFl).HasColumnName("MR_RiskIndexFl");

                entity.Property(e => e.MrRiskIndexSt).HasColumnName("MR_RiskIndexST");

                entity.Property(e => e.MrRiskScore).HasColumnName("MR_RiskScore");

                entity.Property(e => e.MrRiskScoreEq).HasColumnName("MR_RiskScoreEq");

                entity.Property(e => e.MrRiskScoreFl).HasColumnName("MR_RiskScoreFl");

                entity.Property(e => e.MrRiskScoreSt).HasColumnName("MR_RiskScoreST");

                entity.Property(e => e.MrRiverfloodRiverflood).HasColumnName("MR_RIVERFLOOD_RIVERFLOOD");

                entity.Property(e => e.MrSoil).HasColumnName("MR_SOIL");

                entity.Property(e => e.MrStr)
                    .HasMaxLength(150)
                    .HasColumnName("MR_STR");

                entity.Property(e => e.MrX).HasColumnName("MR_X");

                entity.Property(e => e.MrY).HasColumnName("MR_Y");

                entity.Property(e => e.MrZip)
                    .HasMaxLength(150)
                    .HasColumnName("MR_ZIP");

                entity.Property(e => e.Naic)
                    .HasMaxLength(11)
                    .IsUnicode(false)
                    .HasColumnName("NAIC");

                entity.Property(e => e.NetPremium).HasColumnType("money");

                entity.Property(e => e.Notes).IsUnicode(false);

                entity.Property(e => e.OccupancyCode)
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.OccupancyScheme)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.OrderId).HasColumnName("OrderID");

                entity.Property(e => e.OriginalAccountingEffectiveDate).HasColumnType("datetime");

                entity.Property(e => e.ParentRui)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("ParentRUI");

                entity.Property(e => e.Payable)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.Pdfattachment)
                    .HasColumnType("image")
                    .HasColumnName("PDFAttachment");

                entity.Property(e => e.PdfattachmentFileName)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("PDFAttachmentFileName");

                entity.Property(e => e.PersonalAccidentPremium).HasColumnType("money");

                entity.Property(e => e.PersonalInjuryCoverage).HasColumnType("money");

                entity.Property(e => e.PlacementType).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.PlcommercialIndicator)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("PLCommercialIndicator");

                entity.Property(e => e.Pllimit)
                    .HasColumnType("money")
                    .HasColumnName("PLLimit");

                entity.Property(e => e.Plpremium)
                    .HasColumnType("money")
                    .HasColumnName("PLPremium");

                entity.Property(e => e.PlumbingLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.PolicyFee).HasColumnType("money");

                entity.Property(e => e.PolicyNo)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PolicyProcessorSystemName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.PremiumBasis)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.PremiumBasisValue).HasColumnType("money");

                entity.Property(e => e.PricingEngineId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("PricingEngineID");

                entity.Property(e => e.ProductsCompletedOperationsPremium).HasColumnType("money");

                entity.Property(e => e.PropertyLimit).HasColumnType("money");

                entity.Property(e => e.PropertyLimitB).HasColumnType("money");

                entity.Property(e => e.PropertyPremium).HasColumnType("money");

                entity.Property(e => e.PropertyPremiumB).HasColumnType("money");

                entity.Property(e => e.ProtectionClass)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Protections)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.QuakeDeductible).HasColumnType("money");

                entity.Property(e => e.QuakeLimit).HasColumnType("money");

                entity.Property(e => e.Rate).HasColumnType("decimal(12, 8)");

                entity.Property(e => e.RateAllOther).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.RateProductsCompletedOperations).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.RatingSessionId)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("RatingSessionID");

                entity.Property(e => e.RecordError).HasDefaultValueSql("((1))");

                entity.Property(e => e.RetroActiveDate).HasColumnType("datetime");

                entity.Property(e => e.Rms17completeDate)
                    .HasColumnType("datetime")
                    .HasColumnName("RMS17CompleteDate");

                entity.Property(e => e.Rms17geoCompleteDate)
                    .HasColumnType("datetime")
                    .HasColumnName("RMS17GeoCompleteDate");

                entity.Property(e => e.Rms17geoSubmitDate)
                    .HasColumnType("datetime")
                    .HasColumnName("RMS17GeoSubmitDate");

                entity.Property(e => e.Rms17pickupDate)
                    .HasColumnType("datetime")
                    .HasColumnName("RMS17PickupDate");

                entity.Property(e => e.Rms17submitDate)
                    .HasColumnType("datetime")
                    .HasColumnName("RMS17SubmitDate");

                entity.Property(e => e.RmscompleteDate)
                    .HasColumnType("datetime")
                    .HasColumnName("RMSCompleteDate");

                entity.Property(e => e.RmsgeoCompleteDate)
                    .HasColumnType("datetime")
                    .HasColumnName("RMSGeoCompleteDate");

                entity.Property(e => e.RmsgeoSubmitDate)
                    .HasColumnType("datetime")
                    .HasColumnName("RMSGeoSubmitDate");

                entity.Property(e => e.RmspickupDate)
                    .HasColumnType("datetime")
                    .HasColumnName("RMSPickupDate");

                entity.Property(e => e.RmsproductVersion)
                    .HasMaxLength(15)
                    .IsUnicode(false)
                    .HasColumnName("RMSProductVersion");

                entity.Property(e => e.RmspurePremiumQuake)
                    .HasColumnType("money")
                    .HasColumnName("RMSPurePremiumQuake");

                entity.Property(e => e.RmspurePremiumScs)
                    .HasColumnType("money")
                    .HasColumnName("RMSPurePremiumSCS");

                entity.Property(e => e.RmspurePremiumWind)
                    .HasColumnType("money")
                    .HasColumnName("RMSPurePremiumWind");

                entity.Property(e => e.RmspurePremiumWinterStorm)
                    .HasColumnType("money")
                    .HasColumnName("RMSPurePremiumWinterStorm");

                entity.Property(e => e.RmsrunDate)
                    .HasColumnType("datetime")
                    .HasColumnName("RMSRunDate");

                entity.Property(e => e.RmssubmitDate)
                    .HasColumnType("datetime")
                    .HasColumnName("RMSSubmitDate");

                entity.Property(e => e.RolledBackBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RolledBackDate).HasColumnType("datetime");

                entity.Property(e => e.RoofConstructionCode).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.RoofConstructionScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.RoofLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.RoofShapeCode).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.RoofShapeScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.SectionNumber)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.ServiceLinePremium).HasColumnType("money");

                entity.Property(e => e.SizeofLayer).HasColumnType("money");

                entity.Property(e => e.SltbrokerAddress)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("SLTBrokerAddress");

                entity.Property(e => e.SltbrokerName)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("SLTBrokerName");

                entity.Property(e => e.SltbrokerNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("SLTBrokerNumber");

                entity.Property(e => e.Sltstate)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("SLTState");

                entity.Property(e => e.SpreadSheetRatersCompleteDate).HasColumnType("datetime");

                entity.Property(e => e.Squarefootage).HasColumnType("decimal(7, 0)");

                entity.Property(e => e.StructuresRentedOffPremisesCoverage)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.StructuresRentedOnPremisesCoverage)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SubCompanyId).HasColumnName("SubCompanyID");

                entity.Property(e => e.SubCoverageCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerCity)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerCounty)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerState)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerStreet)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerZipCode)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerZipCodePlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.SurplusLinesTransactionNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SurveyFees).HasColumnType("money");

                entity.Property(e => e.TaxFilingState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.TerritoriesCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TerrorismPremium).HasColumnType("money");

                entity.Property(e => e.Tivfgu)
                    .HasColumnType("money")
                    .HasColumnName("TIVFGU");

                entity.Property(e => e.TotalInsurancePremiumTax).HasColumnType("money");

                entity.Property(e => e.TotalPropertyLimit).HasColumnType("money");

                entity.Property(e => e.TotalPropertyPremium).HasColumnType("money");

                entity.Property(e => e.TransactionType)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Triprapremium)
                    .HasColumnType("money")
                    .HasColumnName("TRIPRAPremium");

                entity.Property(e => e.UnderwriterApprovedNotes).IsUnicode(false);

                entity.Property(e => e.UnderwriterName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.UnderwriterPremiumOffer).HasColumnType("money");

                entity.Property(e => e.UniqueAgentReference)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.UserCreated)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasDefaultValueSql("(right(suser_sname(),len(suser_sname())-charindex('\\',suser_sname())))");

                entity.Property(e => e.UserModified)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserUpdated)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.WindHailHurricaneDeductible).HasColumnType("money");

                entity.Property(e => e.WindHailHurricaneDeductibleNamedStorm).HasColumnType("money");

                entity.Property(e => e.WindLimit).HasColumnType("money");

                entity.Property(e => e.WiringLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.Xlsoffice)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("XLSOffice")
                    .IsFixedLength(true);

                entity.Property(e => e.YearBuilt).HasColumnType("decimal(4, 0)");

                entity.HasOne(d => d.LogImportedFile)
                    .WithMany(p => p.TempPolicyTransactions)
                    .HasForeignKey(d => new { d.ImportFilename, d.DuplicateFileSeq, d.UniqueAgentReference })
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("FK_TempPolicyTransactions_LogImportedFiles");
            });

            modelBuilder.Entity<TempPolicyTransactionsApimIsyCl>(entity =>
            {
                entity.ToTable("TempPolicyTransactions_APIM_ISyCL");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CancelMethod).HasMaxLength(255);

                entity.Property(e => e.DateCreated)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.PolicyTypeCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TempPremiumsId).HasColumnName("TempPremiumsID");

                entity.Property(e => e.TransactionReasonCode).HasMaxLength(255);

                entity.HasOne(d => d.TempPremiums)
                    .WithMany(p => p.TempPolicyTransactionsApimIsyCls)
                    .HasForeignKey(d => d.TempPremiumsId)
                    .HasConstraintName("FK__TempPolic__TempP__7514A227");
            });

            modelBuilder.Entity<TempPolicyTransactionsContract>(entity =>
            {
                entity.HasKey(e => new { e.TempPremiumsId, e.CompanyId, e.BusinessArea, e.ContractRef, e.ContractYear })
                    .HasName("PK_TempPolicyTransactions_Contracts_ID");

                entity.ToTable("TempPolicyTransactions_Contracts");

                entity.HasIndex(e => new { e.CompanyId, e.BusinessArea, e.ContractRef, e.ContractYear }, "IX_CompanyID_BusinessArea_ContractRef_ContractYear_Includes")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => e.Id, "IX_ID")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TempPremiumsId, e.ContractRef }, "IX_TempPolicyTransactions_Contracts_TempPremiumsID_ContractRef")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.ContractYear, e.ContractRef, e.CompanyId, e.TempPremiumsId }, "ix_TempPolicyTransactions_ContractYear_Contracts_ContractRef_CompanyID_TempPremiumsID");

                entity.HasIndex(e => new { e.BusinessArea, e.CompanyId }, "ix_TempPolicyTransactions_Contracts_BusinessArea_CompanyID_Includes");

                entity.HasIndex(e => new { e.BusinessArea, e.ContractRef, e.ContractYear, e.CompanyId, e.TempPremiumsId }, "ix_TempPolicyTransactions_Contracts_BusinessArea_ContractRef_ContractYear_CompanyID_TempPremiumsID_Includes");

                entity.HasIndex(e => e.BusinessArea, "ix_TempPolicyTransactions_Contracts_BusinessArea_Includes")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.ContractRef, e.CompanyId, e.TempPremiumsId }, "ix_TempPolicyTransactions_Contracts_ContractRef_CompanyID_TempPremiumsID");

                entity.HasIndex(e => e.TempPremiumsId, "ix_TempPolicyTransactions_Contracts_TempPremiumsID");

                entity.HasIndex(e => new { e.TempPremiumsId, e.BusinessArea }, "ix_TempPolicyTransactions_Contracts_TempPremiumsID_BusinessArea")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TempPremiumsId, e.CompanyId, e.BusinessArea }, "ix_TempPolicyTransactions_Contracts_TempPremiumsID_CompanyID_BusinessArea_Includes");

                entity.HasIndex(e => new { e.TempPremiumsId, e.ContractRef, e.ContractYear, e.CompanyId, e.BusinessArea }, "ix_TempPolicyTransactions_Contracts_TempPremiumsID_ContractRef_ContractYear_CompanyID_BusinessArea_Includes")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TempPremiumsId, e.Id }, "ix_TempPolicyTransactions_Contracts_TempPremiumsID_ID_Includes")
                    .HasFillFactor((byte)80);

                entity.Property(e => e.TempPremiumsId).HasColumnName("TempPremiumsID");

                entity.Property(e => e.CompanyId).HasColumnName("CompanyID");

                entity.Property(e => e.BusinessArea)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ContractRef)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.Bccommission)
                    .HasColumnType("money")
                    .HasColumnName("BCCommission");

                entity.Property(e => e.BccommissionPercentage)
                    .HasColumnType("decimal(6, 3)")
                    .HasColumnName("BCCommissionPercentage");

                entity.Property(e => e.Commission).HasColumnType("money");

                entity.Property(e => e.CommissionPercentage).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.ContractShare).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.EquipmentBreakdownShare).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.GrossPremium).HasColumnType("money");

                entity.Property(e => e.Id)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("ID");

                entity.Property(e => e.Idold).HasColumnName("IDold");

                entity.Property(e => e.LiabilityShare).HasColumnType("decimal(6, 3)");

                entity.HasOne(d => d.TempPremiums)
                    .WithMany(p => p.TempPolicyTransactionsContracts)
                    .HasForeignKey(d => d.TempPremiumsId)
                    .HasConstraintName("FK_TempPolicyTransactions_Contracts_TempPolicyTransactions");
            });

            modelBuilder.Entity<TempPolicyTransactionsDocucorpIncludedForm>(entity =>
            {
                entity.ToTable("TempPolicyTransactions_DocucorpIncludedForms");

                entity.HasIndex(e => e.TempPremiumsId, "ix_TempPolicyTransactions_DocucorpIncludedForms_TempPremiumsID")
                    .HasFillFactor((byte)80);

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Description)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.EditionDate)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.FormName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.TempPremiumsId).HasColumnName("TempPremiumsID");

                entity.Property(e => e.Version)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.HasOne(d => d.TempPremiums)
                    .WithMany(p => p.TempPolicyTransactionsDocucorpIncludedForms)
                    .HasForeignKey(d => d.TempPremiumsId)
                    .HasConstraintName("FK_TempPolicyTransactions_DocucorpIncludedForms_TempPolicyTransactions");
            });

            modelBuilder.Entity<TempPolicyTransactionsIsoglclass>(entity =>
            {
                entity.ToTable("TempPolicyTransactions_ISOGLClass");

                entity.HasIndex(e => new { e.TempPremiumsId, e.Id }, "ix_TempPolicyTransactions_ISOGLClass_TempPremiumsID_ID_Includes")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TempPremiumsId, e.Isoglclass }, "ix_TempPolicyTransactions_ISOGLClass_TempPremiumsID_ISOGLClass_Includes")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => e.TempPremiumsId, "ix_TempPolicyTransactions_ISOGLClass_TempPremiumsID_Includes")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.TempPremiumsId, e.PremiumBasis }, "ix_TempPolicyTransactions_ISOGLClass_TempPremiumsID_PremiumBasis")
                    .HasFillFactor((byte)80);

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.AllOther).HasColumnType("money");

                entity.Property(e => e.AppliesAllLocations).HasDefaultValueSql("((0))");

                entity.Property(e => e.Description).IsUnicode(false);

                entity.Property(e => e.Isoglclass)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("ISOGLClass");

                entity.Property(e => e.PremiumBasis)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.PremiumBasisValue).HasColumnType("money");

                entity.Property(e => e.ProductsCompletedOperationsPremium).HasColumnType("money");

                entity.Property(e => e.SubCoverageCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TempPremiumsId).HasColumnName("TempPremiumsID");

                entity.Property(e => e.TerritoriesCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.HasOne(d => d.TempPremiums)
                    .WithMany(p => p.TempPolicyTransactionsIsoglclasses)
                    .HasForeignKey(d => d.TempPremiumsId)
                    .HasConstraintName("FK_TempPremiumsTransactionsISOGLClass_TempPremiumsTransactions");
            });

            modelBuilder.Entity<TempPolicyTransactionsLocation>(entity =>
            {
                entity.HasKey(e => e.TempLocationsId)
                    .HasName("PK_TempPremiumsTransactionsLocations");

                entity.ToTable("TempPolicyTransactions_Locations");

                entity.HasIndex(e => new { e.MrX, e.MrY, e.InsuredStreet, e.InsuredZipCode }, "IX_MR_X_MR_Y_InsuredStreet_InsuredZipCode")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.GoogleY, e.GoogleX, e.InsuredStreet }, "ix_TempPolicyTransactions_Locations_GeoGoogle")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.MrX, e.MrY, e.TempPremiumsId }, "ix_TempPolicyTransactions_Locations_GeoMR")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.LocationNumber, e.TempLocationsId, e.CorrectedBy, e.LocationTransactionType, e.IgnoreRecord, e.TempPremiumsId }, "ix_TempPolicyTransactions_Locations_LocationNumber_TempLocationsID_CorrectedBy_LocationTransactionType_IgnoreRecord_TempPremiums")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.RmshazardGeoLookupDate, e.TempPremiumsId, e.TempLocationsId }, "ix_TempPolicyTransactions_Locations_RMSHazardGeoLookupDate_TempPremiumsID_TempLocationsID")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TempLocationsId, e.TempPremiumsId, e.LiabilityLimit }, "ix_TempPolicyTransactions_Locations_TempLocationsID_TempPremiumsID_LiabilityLimit_Includes")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => e.TempPremiumsId, "ix_TempPolicyTransactions_Locations_TempPremiumsID");

                entity.HasIndex(e => new { e.TempPremiumsId, e.BuildingNumber }, "ix_TempPolicyTransactions_Locations_TempPremiumsID_BuildingNumber")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TempPremiumsId, e.DocucorpFloodIncluded }, "ix_TempPolicyTransactions_Locations_TempPremiumsID_DocucorpFloodIncluded")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TempPremiumsId, e.DocucorpQuakeIncluded }, "ix_TempPolicyTransactions_Locations_TempPremiumsID_DocucorpQuakeIncluded")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TempPremiumsId, e.DocucorpWindIncluded }, "ix_TempPolicyTransactions_Locations_TempPremiumsID_DocucorpWindIncluded")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TempPremiumsId, e.LocationNumber, e.InsuredStreet, e.InsuredCity, e.InsuredCounty, e.InsuredState, e.InsuredZipCode, e.TotalPropertyLimit }, "ix_TempPolicyTransactions_Locations_TempPremiumsID_LocationNumber_InsuredStreet_InsuredCity_InsuredCounty_InsuredState_InsuredZi")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TempPremiumsId, e.TempLocationsId, e.Corrects }, "ix_TempPolicyTransactions_Locations_TempPremiumsID_TempLocationsID_Corrects_Includes")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TempPremiumsId, e.TempLocationsId }, "ix_TempPolicyTransactions_Locations_TempPremiumsID_TempLocationsID_Includes");

                entity.HasIndex(e => new { e.TempPremiumsId, e.TempLocationsId, e.LiabilityLimit }, "ix_TempPolicyTransactions_Locations_TempPremiumsID_TempLocationsID_LiabilityLimit")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TempPremiumsId, e.TotalPropertyLimit }, "ix_TempPolicyTransactions_Locations_TempPremiumsID_TotalPropertyLimit_Includes")
                    .HasFillFactor((byte)80);

                entity.Property(e => e.TempLocationsId).HasColumnName("TempLocationsID");

                entity.Property(e => e.AllOther).HasColumnType("money");

                entity.Property(e => e.AlternateHeatSourceCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.AmigclassOfBusinessCode)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("AMIGClassOfBusinessCode");

                entity.Property(e => e.Aopdeductible)
                    .HasColumnType("money")
                    .HasColumnName("AOPDeductible");

                entity.Property(e => e.BalboaBankCertNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.BalboaBankName)
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.BalboaGrossAdjustedPremium).HasColumnType("money");

                entity.Property(e => e.BalboaGrossPaidPremium).HasColumnType("money");

                entity.Property(e => e.BalboaGrossReturnPremium).HasColumnType("money");

                entity.Property(e => e.BalboaTier)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BasementType)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.BccustomErrorMessage)
                    .IsUnicode(false)
                    .HasColumnName("BCCustomErrorMessage");

                entity.Property(e => e.BordereauType)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.BuildingCoverageAvaluationBasis)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("BuildingCoverageAValuationBasis")
                    .IsFixedLength(true);

                entity.Property(e => e.BuildingNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CalcEquipmentBreakDownPremium).HasColumnType("money");

                entity.Property(e => e.CalcHomeSystemsProtectionPremium).HasColumnType("money");

                entity.Property(e => e.CalcServiceLinePremium).HasColumnType("money");

                entity.Property(e => e.Catdeductible)
                    .HasColumnType("money")
                    .HasColumnName("CATDeductible");

                entity.Property(e => e.CdmatchPercentage).HasColumnName("CDMatchPercentage");

                entity.Property(e => e.CoInsurancePercentage).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.ConstructionCode)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ConstructionCodeScheme)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ContentsCoverageCvaluationBasis)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("ContentsCoverageCValuationBasis")
                    .IsFixedLength(true);

                entity.Property(e => e.CrimeDeductible).HasColumnType("money");

                entity.Property(e => e.CrimeLimit).HasColumnType("money");

                entity.Property(e => e.CrimePremium).HasColumnType("money");

                entity.Property(e => e.CrimeRate).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.DateCreated).HasColumnType("datetime");

                entity.Property(e => e.DateErrorChecksFirstRun).HasColumnType("datetime");

                entity.Property(e => e.DateErrorChecksLastRunEnd).HasColumnType("datetime");

                entity.Property(e => e.DateErrorChecksLastRunStart).HasColumnType("datetime");

                entity.Property(e => e.DateImported).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.DateUpdated).HasColumnType("datetime");

                entity.Property(e => e.DocEndRevisedPropLimit)
                    .HasColumnType("money")
                    .HasColumnName("DocEND_RevisedPropLimit");

                entity.Property(e => e.DocEndTotalLiability)
                    .HasColumnType("money")
                    .HasColumnName("DocEND_TotalLiability");

                entity.Property(e => e.DocEndTotalProperty)
                    .HasColumnType("money")
                    .HasColumnName("DocEND_TotalProperty");

                entity.Property(e => e.DocEndTotalTerror)
                    .HasColumnType("money")
                    .HasColumnName("DocEND_TotalTerror");

                entity.Property(e => e.DocucorpTransCode)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.DqicoreScore)
                    .HasColumnType("decimal(6, 4)")
                    .HasColumnName("DQICoreScore");

                entity.Property(e => e.DqiquakeScore)
                    .HasColumnType("decimal(6, 4)")
                    .HasColumnName("DQIQuakeScore");

                entity.Property(e => e.DqiwindScore)
                    .HasColumnType("decimal(6, 4)")
                    .HasColumnName("DQIWindScore");

                entity.Property(e => e.Ellimit)
                    .HasColumnType("money")
                    .HasColumnName("ELLimit");

                entity.Property(e => e.Elpremium)
                    .HasColumnType("money")
                    .HasColumnName("ELPremium");

                entity.Property(e => e.EqappendagesandOrnamentation).HasColumnName("EQAppendagesandOrnamentation");

                entity.Property(e => e.EqbaseIsolation).HasColumnName("EQBaseIsolation");

                entity.Property(e => e.EqcladdingType).HasColumnName("EQCladdingType");

                entity.Property(e => e.EqconstructionQuality).HasColumnName("EQConstructionQuality");

                entity.Property(e => e.EqcrippleWalls).HasColumnName("EQCrippleWalls");

                entity.Property(e => e.EqengineeredFoundation).HasColumnName("EQEngineeredFoundation");

                entity.Property(e => e.EqequipmentSupportMaintenance).HasColumnName("EQEquipmentSupportMaintenance");

                entity.Property(e => e.EqframeBolted).HasColumnName("EQFrameBolted");

                entity.Property(e => e.EqmechanicalandElectricalEquipmentEarthquakeBracing).HasColumnName("EQMechanicalandElectricalEquipmentEarthquakeBracing");

                entity.Property(e => e.EqplanIrregularity).HasColumnName("EQPlanIrregularity");

                entity.Property(e => e.Eqpounding).HasColumnName("EQPounding");

                entity.Property(e => e.EqshortColumnCondition).HasColumnName("EQShortColumnCondition");

                entity.Property(e => e.EqsoftStory).HasColumnName("EQSoftStory");

                entity.Property(e => e.EqsprinklerLeakageCoverageFlag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("EQSprinklerLeakageCoverageFlag");

                entity.Property(e => e.EqsprinklerLeakageSusceptibility).HasColumnName("EQSprinklerLeakageSusceptibility");

                entity.Property(e => e.EqsprinklerType).HasColumnName("EQSprinklerType");

                entity.Property(e => e.EqstructuralUpgrade).HasColumnName("EQStructuralUpgrade");

                entity.Property(e => e.EqtiltUpRetrofit).HasColumnName("EQTiltUpRetrofit");

                entity.Property(e => e.EquipmentBreakdown)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.EquipmentBreakdownPremium).HasColumnType("money");

                entity.Property(e => e.EqunreinforcedMasonryPartitionsorChimneys).HasColumnName("EQUnreinforcedMasonryPartitionsorChimneys");

                entity.Property(e => e.EqunreinforcedMasonryRetrofit).HasColumnName("EQUnreinforcedMasonryRetrofit");

                entity.Property(e => e.EqverticalIrregularity).HasColumnName("EQVerticalIrregularity");

                entity.Property(e => e.ExtendedReplacementCostCoverage).HasColumnType("money");

                entity.Property(e => e.ExteriorPaintUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.FirstFloorHeightAboveGround).HasColumnType("decimal(3, 1)");

                entity.Property(e => e.FlfoundationType).HasColumnName("FLFoundationType");

                entity.Property(e => e.FloodDeductible).HasColumnType("money");

                entity.Property(e => e.FloodLimit).HasColumnType("money");

                entity.Property(e => e.FloodZone)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.GlaggregateLimit)
                    .HasColumnType("money")
                    .HasColumnName("GLAggregateLimit");

                entity.Property(e => e.Glukbideductible)
                    .HasColumnType("money")
                    .HasColumnName("GLUKBIDeductible");

                entity.Property(e => e.GlukbppLimit)
                    .HasColumnType("money")
                    .HasColumnName("GLUKBppLimit");

                entity.Property(e => e.GlukbuildingDeductible)
                    .HasColumnType("money")
                    .HasColumnName("GLUKBuildingDeductible");

                entity.Property(e => e.GlukbuildingsLimit)
                    .HasColumnType("money")
                    .HasColumnName("GLUKBuildingsLimit");

                entity.Property(e => e.GlukbusinessIncome)
                    .HasColumnType("money")
                    .HasColumnName("GLUKBusinessIncome");

                entity.Property(e => e.GlukcontentsDeductible)
                    .HasColumnType("money")
                    .HasColumnName("GLUKContentsDeductible");

                entity.Property(e => e.GlukdeductibleScheme)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("GLUKDeductibleScheme")
                    .IsFixedLength(true);

                entity.Property(e => e.GlukdistanceFromSaltWater)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("GLUKDistanceFromSaltWater");

                entity.Property(e => e.GlukfireDeductible)
                    .HasColumnType("money")
                    .HasColumnName("GLUKFireDeductible");

                entity.Property(e => e.GlukfireIncluded)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("GLUKFireIncluded")
                    .IsFixedLength(true);

                entity.Property(e => e.GlukfloodIncluded)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("GLUKFloodIncluded")
                    .IsFixedLength(true);

                entity.Property(e => e.GlukhailDeductible)
                    .HasColumnType("money")
                    .HasColumnName("GLUKHailDeductible");

                entity.Property(e => e.GlukhailIncluded)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("GLUKHailIncluded")
                    .IsFixedLength(true);

                entity.Property(e => e.GlukquakeIncluded)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("GLUKQuakeIncluded")
                    .IsFixedLength(true);

                entity.Property(e => e.GluksltbrokerAddress)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("GLUKSLTBrokerAddress");

                entity.Property(e => e.GluksltbrokerId).HasColumnName("GLUKSLTBrokerID");

                entity.Property(e => e.GluksltbrokerName)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("GLUKSLTBrokerName");

                entity.Property(e => e.GluksltbrokerState)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("GLUKSLTBrokerState")
                    .IsFixedLength(true);

                entity.Property(e => e.GluksltbrokerTaxNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("GLUKSLTBrokerTaxNumber");

                entity.Property(e => e.GlukwindIncluded)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("GLUKWindIncluded")
                    .IsFixedLength(true);

                entity.Property(e => e.GlukwindstormDeductible)
                    .HasColumnType("money")
                    .HasColumnName("GLUKWindstormDeductible");

                entity.Property(e => e.GlukzonePerilsId).HasColumnName("GLUKZonePerilsID");

                entity.Property(e => e.GoogleElevation).HasColumnName("GOOGLE_Elevation");

                entity.Property(e => e.GoogleElevationResolution).HasColumnName("GOOGLE_Elevation_Resolution");

                entity.Property(e => e.GoogleGeoCodeDate)
                    .HasColumnType("datetime")
                    .HasColumnName("GOOGLE_GeoCodeDate");

                entity.Property(e => e.GoogleLocationType)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("GOOGLE_LOCATION_TYPE");

                entity.Property(e => e.GoogleX).HasColumnName("GOOGLE_X");

                entity.Property(e => e.GoogleY).HasColumnName("GOOGLE_Y");

                entity.Property(e => e.GrossPremium).HasColumnType("money");

                entity.Property(e => e.HeatingLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.HomeSystemsProtection)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.HomeSystemsProtectionPremium).HasColumnType("money");

                entity.Property(e => e.Impremium)
                    .HasColumnType("money")
                    .HasColumnName("IMPremium");

                entity.Property(e => e.InlandMarineLimit).HasColumnType("money");

                entity.Property(e => e.InsuredCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCountryCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCountryScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCounty)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredStreet)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredZipCodePlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.Isoglclass)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("ISOGLClass");

                entity.Property(e => e.IsopropertyCode)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("ISOPropertyCode");

                entity.Property(e => e.LiabilityDeductible).HasColumnType("money");

                entity.Property(e => e.LiabilityLimit).HasColumnType("money");

                entity.Property(e => e.LiabilityPremium).HasColumnType("money");

                entity.Property(e => e.LimitBuildingCoverageA).HasColumnType("money");

                entity.Property(e => e.LimitBusinessInterruptionCoverageD).HasColumnType("money");

                entity.Property(e => e.LimitContentsCoverageC).HasColumnType("money");

                entity.Property(e => e.LimitCoverageE).HasColumnType("money");

                entity.Property(e => e.LimitOtherCoverageB).HasColumnType("money");

                entity.Property(e => e.LimitResidenceBurglary).HasColumnType("money");

                entity.Property(e => e.LocationNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LocationTransactionType)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.MgadistanceToCoastMiles).HasColumnName("MGADistanceToCoastMiles");

                entity.Property(e => e.Mgalatitude).HasColumnName("MGALatitude");

                entity.Property(e => e.Mgalongitude).HasColumnName("MGALongitude");

                entity.Property(e => e.MoldSublimitCoverage).HasColumnType("money");

                entity.Property(e => e.MrAdditionalElevation).HasColumnName("MR_Additional_ELEVATION");

                entity.Property(e => e.MrAdditionalPopulation).HasColumnName("MR_Additional_POPULATION");

                entity.Property(e => e.MrCity)
                    .HasMaxLength(150)
                    .HasColumnName("MR_CITY");

                entity.Property(e => e.MrCoordind).HasColumnName("MR_COORDIND");

                entity.Property(e => e.MrCrestaHighresId)
                    .HasMaxLength(150)
                    .HasColumnName("MR_CRESTA_HIGHRES_ID");

                entity.Property(e => e.MrCrestaHighresName)
                    .HasMaxLength(150)
                    .HasColumnName("MR_CRESTA_HIGHRES_NAME");

                entity.Property(e => e.MrCrestaLowresId)
                    .HasMaxLength(150)
                    .HasColumnName("MR_CRESTA_LOWRES_ID");

                entity.Property(e => e.MrCrestaLowresName)
                    .HasMaxLength(150)
                    .HasColumnName("MR_CRESTA_LOWRES_NAME");

                entity.Property(e => e.MrCrestaid)
                    .HasMaxLength(255)
                    .HasColumnName("MR_CRESTAID");

                entity.Property(e => e.MrCrestaname)
                    .HasMaxLength(255)
                    .HasColumnName("MR_CRESTANAME");

                entity.Property(e => e.MrDistanceToCoast).HasColumnName("MR_DISTANCE_TO_COAST");

                entity.Property(e => e.MrDistanceToFault).HasColumnName("MR_DISTANCE_TO_FAULT");

                entity.Property(e => e.MrErrAdditional)
                    .HasMaxLength(150)
                    .HasColumnName("MR_ERR_Additional");

                entity.Property(e => e.MrErrCresta)
                    .HasMaxLength(255)
                    .HasColumnName("MR_ERR_CRESTA");

                entity.Property(e => e.MrErrCrestaHighres)
                    .HasMaxLength(150)
                    .HasColumnName("MR_ERR_CRESTA_HIGHRES");

                entity.Property(e => e.MrErrCrestaLowres)
                    .HasMaxLength(150)
                    .HasColumnName("MR_ERR_CRESTA_LOWRES");

                entity.Property(e => e.MrErrGcd)
                    .HasMaxLength(255)
                    .HasColumnName("MR_ERR_GCD");

                entity.Property(e => e.MrErrHazard)
                    .HasMaxLength(255)
                    .HasColumnName("MR_ERR_Hazard");

                entity.Property(e => e.MrErrRiverflood).HasColumnName("MR_ERR_RIVERFLOOD");

                entity.Property(e => e.MrGeoCodeDate)
                    .HasColumnType("datetime")
                    .HasColumnName("MR_GeoCodeDate");

                entity.Property(e => e.MrGeozoneType)
                    .HasMaxLength(150)
                    .HasColumnName("MR_GEOZONE_TYPE");

                entity.Property(e => e.MrHazardEarthquake).HasColumnName("MR_Hazard_EARTHQUAKE");

                entity.Property(e => e.MrHazardExtratropicalstorm).HasColumnName("MR_Hazard_EXTRATROPICALSTORM");

                entity.Property(e => e.MrHazardFlashflood).HasColumnName("MR_Hazard_FLASHFLOOD");

                entity.Property(e => e.MrHazardHailstorm).HasColumnName("MR_Hazard_HAILSTORM");

                entity.Property(e => e.MrHazardLightning).HasColumnName("MR_Hazard_LIGHTNING");

                entity.Property(e => e.MrHazardStormsurge).HasColumnName("MR_Hazard_STORMSURGE");

                entity.Property(e => e.MrHazardTcyclone).HasColumnName("MR_Hazard_TCYCLONE");

                entity.Property(e => e.MrHazardTornado).HasColumnName("MR_Hazard_TORNADO");

                entity.Property(e => e.MrHazardTropicalcyclone).HasColumnName("MR_Hazard_TROPICALCYCLONE");

                entity.Property(e => e.MrHazardTsunami).HasColumnName("MR_Hazard_TSUNAMI");

                entity.Property(e => e.MrHazardVolcano).HasColumnName("MR_Hazard_VOLCANO");

                entity.Property(e => e.MrHazardWildfire).HasColumnName("MR_Hazard_WILDFIRE");

                entity.Property(e => e.MrHazardWstorm).HasColumnName("MR_Hazard_WSTORM");

                entity.Property(e => e.MrHnr)
                    .HasMaxLength(150)
                    .HasColumnName("MR_HNR");

                entity.Property(e => e.MrIso3)
                    .HasMaxLength(150)
                    .HasColumnName("MR_ISO3");

                entity.Property(e => e.MrQualind).HasColumnName("MR_QUALIND");

                entity.Property(e => e.MrRiskIndex).HasColumnName("MR_RiskIndex");

                entity.Property(e => e.MrRiskIndexEq).HasColumnName("MR_RiskIndexEq");

                entity.Property(e => e.MrRiskIndexFl).HasColumnName("MR_RiskIndexFl");

                entity.Property(e => e.MrRiskIndexSt).HasColumnName("MR_RiskIndexST");

                entity.Property(e => e.MrRiskScore).HasColumnName("MR_RiskScore");

                entity.Property(e => e.MrRiskScoreEq).HasColumnName("MR_RiskScoreEq");

                entity.Property(e => e.MrRiskScoreFl).HasColumnName("MR_RiskScoreFl");

                entity.Property(e => e.MrRiskScoreSt).HasColumnName("MR_RiskScoreST");

                entity.Property(e => e.MrRiverfloodRiverflood).HasColumnName("MR_RIVERFLOOD_RIVERFLOOD");

                entity.Property(e => e.MrSoil).HasColumnName("MR_SOIL");

                entity.Property(e => e.MrStr)
                    .HasMaxLength(150)
                    .HasColumnName("MR_STR");

                entity.Property(e => e.MrX).HasColumnName("MR_X");

                entity.Property(e => e.MrY).HasColumnName("MR_Y");

                entity.Property(e => e.MrZip)
                    .HasMaxLength(150)
                    .HasColumnName("MR_ZIP");

                entity.Property(e => e.Notes).IsUnicode(false);

                entity.Property(e => e.OccupancyCode)
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.OccupancyScheme)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OpeningProtectionTypesCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.OpeningProtectionsCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.OrdinanceOrLawCoverage).HasColumnType("money");

                entity.Property(e => e.PersonalAccidentPremium).HasColumnType("money");

                entity.Property(e => e.Pllimit)
                    .HasColumnType("money")
                    .HasColumnName("PLLimit");

                entity.Property(e => e.Plpremium)
                    .HasColumnType("money")
                    .HasColumnName("PLPremium");

                entity.Property(e => e.PlumbingLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.PremiumBasis)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.PremiumBasisValue).HasColumnType("money");

                entity.Property(e => e.PrimaryFlood)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.PrimaryHeatSourceCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.ProductsCompletedOperationsPremium).HasColumnType("money");

                entity.Property(e => e.PropertyLimit).HasColumnType("money");

                entity.Property(e => e.PropertyLimitB).HasColumnType("money");

                entity.Property(e => e.PropertyPremium).HasColumnType("money");

                entity.Property(e => e.PropertyPremiumB).HasColumnType("money");

                entity.Property(e => e.ProtectionClass)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Protections)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.QuakeDeductible).HasColumnType("money");

                entity.Property(e => e.QuakeLimit).HasColumnType("money");

                entity.Property(e => e.Rate).HasColumnType("decimal(12, 8)");

                entity.Property(e => e.RateAllOther).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.RateProductsCompletedOperations).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.RentalTerm)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.Rmsbasefloodelevation).HasColumnName("RMSBASEFLOODELEVATION");

                entity.Property(e => e.Rmsbizone).HasColumnName("RMSBIZONE");

                entity.Property(e => e.Rmsbuildingelevation).HasColumnName("RMSBUILDINGELEVATION");

                entity.Property(e => e.RmsfloodElevation).HasColumnName("RMSFloodELEVATION");

                entity.Property(e => e.RmsfloodFloodway)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("RMSFloodFLOODWAY")
                    .IsFixedLength(true);

                entity.Property(e => e.RmsfloodFlzone)
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasColumnName("RMSFloodFLZONE")
                    .IsFixedLength(true);

                entity.Property(e => e.RmsgeoResolutionCode).HasColumnName("RMSGeoResolutionCode");

                entity.Property(e => e.RmshazardGeoLookupDate)
                    .HasColumnType("datetime")
                    .HasColumnName("RMSHazardGeoLookupDate");

                entity.Property(e => e.RmsnfipRate).HasColumnName("RMSNFIP_RATE");

                entity.Property(e => e.Rmsnfipyear).HasColumnName("RMSNFIPYEAR");

                entity.Property(e => e.RmsquakeBizone).HasColumnName("RMSQuakeBIZONE");

                entity.Property(e => e.RmsquakeLandslide).HasColumnName("RMSQuakeLANDSLIDE");

                entity.Property(e => e.RmsquakeLiquefact).HasColumnName("RMSQuakeLIQUEFACT");

                entity.Property(e => e.RmsquakeSoilperiod).HasColumnName("RMSQuakeSOILPERIOD");

                entity.Property(e => e.RmsquakeSoilthickness).HasColumnName("RMSQuakeSOILTHICKNESS");

                entity.Property(e => e.RmsquakeSoiltype).HasColumnName("RMSQuakeSOILTYPE");

                entity.Property(e => e.Rmsspecialfloodhazardarea)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("RMSSPECIALFLOODHAZARDAREA")
                    .IsFixedLength(true);

                entity.Property(e => e.Rmswfaccess).HasColumnName("RMSWFACCESS");

                entity.Property(e => e.Rmswfareadesc).HasColumnName("RMSWFAREADESC");

                entity.Property(e => e.Rmswfhazard).HasColumnName("RMSWFHAZARD");

                entity.Property(e => e.Rmswflochist).HasColumnName("RMSWFLOCHIST");

                entity.Property(e => e.Rmswfnearhist).HasColumnName("RMSWFNEARHIST");

                entity.Property(e => e.Rmswfspeccond)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("RMSWFSPECCOND");

                entity.Property(e => e.Rmswfsurffuel)
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .HasColumnName("RMSWFSURFFUEL");

                entity.Property(e => e.Rmswfsuscept).HasColumnName("RMSWFSUSCEPT");

                entity.Property(e => e.Rmswfthreat).HasColumnName("RMSWFTHREAT");

                entity.Property(e => e.RmswindDistcoast).HasColumnName("RMSWindDISTCOAST");

                entity.Property(e => e.RmswindElevation).HasColumnName("RMSWindELEVATION");

                entity.Property(e => e.RmswindManrough).HasColumnName("RMSWindMANROUGH");

                entity.Property(e => e.RmswindNatrough).HasColumnName("RMSWindNATROUGH");

                entity.Property(e => e.Rmswindpool).HasColumnName("RMSWINDPOOL");

                entity.Property(e => e.RoofAnchorCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.RoofConstructionCode).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.RoofConstructionScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.RoofCoverageValuationBasis)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.RoofLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.RoofShapeCode).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.RoofShapeScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.RoofSheathingCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.ScreenedEnclosureCoverage).HasColumnType("money");

                entity.Property(e => e.ServiceLine)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.ServiceLinePremium).HasColumnType("money");

                entity.Property(e => e.SinkholeCoverage).HasColumnType("money");

                entity.Property(e => e.SltbrokerAddress)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("SLTBrokerAddress");

                entity.Property(e => e.SltbrokerName)
                    .HasMaxLength(255)
                    .IsUnicode(false)
                    .HasColumnName("SLTBrokerName");

                entity.Property(e => e.SltbrokerNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("SLTBrokerNumber");

                entity.Property(e => e.Sltstate)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("SLTState");

                entity.Property(e => e.Squarefootage).HasColumnType("decimal(7, 0)");

                entity.Property(e => e.SubCoverageCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TaxFilingState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.TempPremiumsId).HasColumnName("TempPremiumsID");

                entity.Property(e => e.TerritoriesCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TerrorismPremium).HasColumnType("money");

                entity.Property(e => e.Tivfgu)
                    .HasColumnType("money")
                    .HasColumnName("TIVFGU");

                entity.Property(e => e.TotalPropertyLimit).HasColumnType("money");

                entity.Property(e => e.TotalPropertyPremium).HasColumnType("money");

                entity.Property(e => e.Triprapremium)
                    .HasColumnType("money")
                    .HasColumnName("TRIPRAPremium");

                entity.Property(e => e.TypeOfHeatingUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfPlumbingUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfRoofingUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfWiringUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.UserCreated)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserModified)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserUpdated)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.WaterSewageBackupCoverage).HasColumnType("money");

                entity.Property(e => e.WindHailHurricaneDeductible).HasColumnType("money");

                entity.Property(e => e.WindHailHurricaneDeductibleNamedStorm).HasColumnType("money");

                entity.Property(e => e.WindLimit).HasColumnType("money");

                entity.Property(e => e.WiringLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.YearBuilt).HasColumnType("decimal(4, 0)");

                entity.HasOne(d => d.TempPremiums)
                    .WithMany(p => p.TempPolicyTransactionsLocations)
                    .HasForeignKey(d => d.TempPremiumsId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("FK_TempPremiumsTransactionsLocations_TempPremiumsTransactions");
            });

            modelBuilder.Entity<TempPolicyTransactionsLocationsBuilding>(entity =>
            {
                entity.HasKey(e => e.TempBuildingsId);

                entity.ToTable("TempPolicyTransactions_Locations_Buildings");

                entity.HasIndex(e => e.TempLocationsId, "IX_TempPolicyTransactions_Locations_Buildings_TempLocationsID")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.GoogleY, e.GoogleX, e.InsuredStreet }, "ix_TempPolicyTransactions_Locations_Buildings_GeoGoogle")
                    .HasFillFactor((byte)90);

                entity.HasIndex(e => new { e.TempLocationsId, e.TempBuildingsId }, "ix_TempPolicyTransactions_Locations_Buildings_TempLocationsID_TempBuildingsID_Includes");

                entity.Property(e => e.TempBuildingsId).HasColumnName("TempBuildingsID");

                entity.Property(e => e.AlternateHeatSourceCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Aopdeductible)
                    .HasColumnType("money")
                    .HasColumnName("AOPDeductible");

                entity.Property(e => e.BasementType)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.BccustomErrorMessage)
                    .IsUnicode(false)
                    .HasColumnName("BCCustomErrorMessage");

                entity.Property(e => e.BuildingCoverageAvaluationBasis)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("BuildingCoverageAValuationBasis")
                    .IsFixedLength(true);

                entity.Property(e => e.BuildingNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CalcEquipmentBreakDownPremium).HasColumnType("money");

                entity.Property(e => e.CalcHomeSystemsProtectionPremium).HasColumnType("money");

                entity.Property(e => e.CalcServiceLinePremium).HasColumnType("money");

                entity.Property(e => e.Catdeductible)
                    .HasColumnType("money")
                    .HasColumnName("CATDeductible");

                entity.Property(e => e.CdmatchPercentage).HasColumnName("CDMatchPercentage");

                entity.Property(e => e.ConstructionCode)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ConstructionCodeScheme)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ContentsCoverageCvaluationBasis)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("ContentsCoverageCValuationBasis")
                    .IsFixedLength(true);

                entity.Property(e => e.CoverageBvaluationBasis)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("CoverageBValuationBasis")
                    .IsFixedLength(true);

                entity.Property(e => e.CrimeDeductible).HasColumnType("money");

                entity.Property(e => e.CrimeLimit).HasColumnType("money");

                entity.Property(e => e.CrimePremium).HasColumnType("money");

                entity.Property(e => e.CrimeRate).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.DateErrorChecksFirstRun).HasColumnType("datetime");

                entity.Property(e => e.DateErrorChecksLastRunEnd).HasColumnType("datetime");

                entity.Property(e => e.DateErrorChecksLastRunStart).HasColumnType("datetime");

                entity.Property(e => e.DateImported).HasColumnType("datetime");

                entity.Property(e => e.DateUpdated).HasColumnType("datetime");

                entity.Property(e => e.DqicoreScore)
                    .HasColumnType("decimal(6, 4)")
                    .HasColumnName("DQICoreScore");

                entity.Property(e => e.DqiquakeScore)
                    .HasColumnType("decimal(6, 4)")
                    .HasColumnName("DQIQuakeScore");

                entity.Property(e => e.DqiwindScore)
                    .HasColumnType("decimal(6, 4)")
                    .HasColumnName("DQIWindScore");

                entity.Property(e => e.DwellingType)
                    .HasMaxLength(12)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.EqappendagesandOrnamentation).HasColumnName("EQAppendagesandOrnamentation");

                entity.Property(e => e.EqbaseIsolation).HasColumnName("EQBaseIsolation");

                entity.Property(e => e.EqcladdingType).HasColumnName("EQCladdingType");

                entity.Property(e => e.EqconstructionQuality).HasColumnName("EQConstructionQuality");

                entity.Property(e => e.EqcrippleWalls).HasColumnName("EQCrippleWalls");

                entity.Property(e => e.EqengineeredFoundation).HasColumnName("EQEngineeredFoundation");

                entity.Property(e => e.EqequipmentSupportMaintenance).HasColumnName("EQEquipmentSupportMaintenance");

                entity.Property(e => e.EqframeBolted).HasColumnName("EQFrameBolted");

                entity.Property(e => e.EqmechanicalandElectricalEquipmentEarthquakeBracing).HasColumnName("EQMechanicalandElectricalEquipmentEarthquakeBracing");

                entity.Property(e => e.EqplanIrregularity).HasColumnName("EQPlanIrregularity");

                entity.Property(e => e.Eqpounding).HasColumnName("EQPounding");

                entity.Property(e => e.EqshortColumnCondition).HasColumnName("EQShortColumnCondition");

                entity.Property(e => e.EqsoftStory).HasColumnName("EQSoftStory");

                entity.Property(e => e.EqsprinklerLeakageCoverageFlag)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .HasColumnName("EQSprinklerLeakageCoverageFlag");

                entity.Property(e => e.EqsprinklerLeakageSusceptibility).HasColumnName("EQSprinklerLeakageSusceptibility");

                entity.Property(e => e.EqsprinklerType).HasColumnName("EQSprinklerType");

                entity.Property(e => e.EqstructuralUpgrade).HasColumnName("EQStructuralUpgrade");

                entity.Property(e => e.EqtiltUpRetrofit).HasColumnName("EQTiltUpRetrofit");

                entity.Property(e => e.EquipmentBreakdown)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.EquipmentBreakdownPremium).HasColumnType("money");

                entity.Property(e => e.EqunreinforcedMasonryPartitionsorChimneys).HasColumnName("EQUnreinforcedMasonryPartitionsorChimneys");

                entity.Property(e => e.EqunreinforcedMasonryRetrofit).HasColumnName("EQUnreinforcedMasonryRetrofit");

                entity.Property(e => e.EqverticalIrregularity).HasColumnName("EQVerticalIrregularity");

                entity.Property(e => e.ExtendedReplacementCostCoverage).HasColumnType("money");

                entity.Property(e => e.FirstFloorHeightAboveGround).HasColumnType("decimal(3, 1)");

                entity.Property(e => e.FlfoundationType).HasColumnName("FLFoundationType");

                entity.Property(e => e.FloodDeductible).HasColumnType("money");

                entity.Property(e => e.FloodLimit).HasColumnType("money");

                entity.Property(e => e.FloodZone)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.GoogleElevation).HasColumnName("GOOGLE_Elevation");

                entity.Property(e => e.GoogleElevationResolution).HasColumnName("GOOGLE_Elevation_Resolution");

                entity.Property(e => e.GoogleGeoCodeDate)
                    .HasColumnType("datetime")
                    .HasColumnName("GOOGLE_GeoCodeDate");

                entity.Property(e => e.GoogleLocationType)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("GOOGLE_LOCATION_TYPE");

                entity.Property(e => e.GoogleX).HasColumnName("GOOGLE_X");

                entity.Property(e => e.GoogleY).HasColumnName("GOOGLE_Y");

                entity.Property(e => e.GrossPremium).HasColumnType("money");

                entity.Property(e => e.HeatingLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.HomeSystemsProtection)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.HomeSystemsProtectionPremium).HasColumnType("money");

                entity.Property(e => e.Impremium)
                    .HasColumnType("money")
                    .HasColumnName("IMPremium");

                entity.Property(e => e.InlandMarineLimit).HasColumnType("money");

                entity.Property(e => e.InsuredCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCountryCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCountryScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCounty)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredStreet)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredZipCodePlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.IsopropertyCode)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("ISOPropertyCode");

                entity.Property(e => e.LimitAboveGroundTanks).HasColumnType("money");

                entity.Property(e => e.LimitAttachedSigns).HasColumnType("money");

                entity.Property(e => e.LimitBuildingCoverageA).HasColumnType("money");

                entity.Property(e => e.LimitBusinessInterruptionCoverageD).HasColumnType("money");

                entity.Property(e => e.LimitCanopies).HasColumnType("money");

                entity.Property(e => e.LimitContentsCoverageC).HasColumnType("money");

                entity.Property(e => e.LimitCoverageE).HasColumnType("money");

                entity.Property(e => e.LimitDetachedSigns).HasColumnType("money");

                entity.Property(e => e.LimitFence).HasColumnType("money");

                entity.Property(e => e.LimitFixturesPlaygroundEquipment).HasColumnType("money");

                entity.Property(e => e.LimitLightPoles).HasColumnType("money");

                entity.Property(e => e.LimitOtherCoverageB).HasColumnType("money");

                entity.Property(e => e.LimitOutdoorTreesandShrubs).HasColumnType("money");

                entity.Property(e => e.LimitPoolsJacuzziesSpas).HasColumnType("money");

                entity.Property(e => e.LimitPumps).HasColumnType("money");

                entity.Property(e => e.LimitResidenceBurglary).HasColumnType("money");

                entity.Property(e => e.LimitTenantGlass).HasColumnType("money");

                entity.Property(e => e.MgadistanceToCoastMiles).HasColumnName("MGADistanceToCoastMiles");

                entity.Property(e => e.Mgalatitude).HasColumnName("MGALatitude");

                entity.Property(e => e.Mgalongitude).HasColumnName("MGALongitude");

                entity.Property(e => e.MoldSublimitCoverage).HasColumnType("money");

                entity.Property(e => e.MrAdditionalElevation).HasColumnName("MR_Additional_ELEVATION");

                entity.Property(e => e.MrAdditionalPopulation).HasColumnName("MR_Additional_POPULATION");

                entity.Property(e => e.MrCity)
                    .HasMaxLength(150)
                    .HasColumnName("MR_CITY");

                entity.Property(e => e.MrCoordind).HasColumnName("MR_COORDIND");

                entity.Property(e => e.MrCrestaHighresId)
                    .HasMaxLength(150)
                    .HasColumnName("MR_CRESTA_HIGHRES_ID");

                entity.Property(e => e.MrCrestaHighresName)
                    .HasMaxLength(150)
                    .HasColumnName("MR_CRESTA_HIGHRES_NAME");

                entity.Property(e => e.MrCrestaLowresId)
                    .HasMaxLength(150)
                    .HasColumnName("MR_CRESTA_LOWRES_ID");

                entity.Property(e => e.MrCrestaLowresName)
                    .HasMaxLength(150)
                    .HasColumnName("MR_CRESTA_LOWRES_NAME");

                entity.Property(e => e.MrCrestaid)
                    .HasMaxLength(255)
                    .HasColumnName("MR_CRESTAID");

                entity.Property(e => e.MrCrestaname)
                    .HasMaxLength(255)
                    .HasColumnName("MR_CRESTANAME");

                entity.Property(e => e.MrDistanceToCoast).HasColumnName("MR_DISTANCE_TO_COAST");

                entity.Property(e => e.MrDistanceToFault).HasColumnName("MR_DISTANCE_TO_FAULT");

                entity.Property(e => e.MrErrAdditional)
                    .HasMaxLength(150)
                    .HasColumnName("MR_ERR_Additional");

                entity.Property(e => e.MrErrCresta)
                    .HasMaxLength(255)
                    .HasColumnName("MR_ERR_CRESTA");

                entity.Property(e => e.MrErrCrestaHighres)
                    .HasMaxLength(150)
                    .HasColumnName("MR_ERR_CRESTA_HIGHRES");

                entity.Property(e => e.MrErrCrestaLowres)
                    .HasMaxLength(150)
                    .HasColumnName("MR_ERR_CRESTA_LOWRES");

                entity.Property(e => e.MrErrGcd)
                    .HasMaxLength(255)
                    .HasColumnName("MR_ERR_GCD");

                entity.Property(e => e.MrErrHazard)
                    .HasMaxLength(255)
                    .HasColumnName("MR_ERR_Hazard");

                entity.Property(e => e.MrErrRiverflood).HasColumnName("MR_ERR_RIVERFLOOD");

                entity.Property(e => e.MrGeoCodeDate)
                    .HasColumnType("datetime")
                    .HasColumnName("MR_GeoCodeDate");

                entity.Property(e => e.MrGeozoneType)
                    .HasMaxLength(150)
                    .HasColumnName("MR_GEOZONE_TYPE");

                entity.Property(e => e.MrHazardEarthquake).HasColumnName("MR_Hazard_EARTHQUAKE");

                entity.Property(e => e.MrHazardExtratropicalstorm).HasColumnName("MR_Hazard_EXTRATROPICALSTORM");

                entity.Property(e => e.MrHazardFlashflood).HasColumnName("MR_Hazard_FLASHFLOOD");

                entity.Property(e => e.MrHazardHailstorm).HasColumnName("MR_Hazard_HAILSTORM");

                entity.Property(e => e.MrHazardLightning).HasColumnName("MR_Hazard_LIGHTNING");

                entity.Property(e => e.MrHazardStormsurge).HasColumnName("MR_Hazard_STORMSURGE");

                entity.Property(e => e.MrHazardTcyclone).HasColumnName("MR_Hazard_TCYCLONE");

                entity.Property(e => e.MrHazardTornado).HasColumnName("MR_Hazard_TORNADO");

                entity.Property(e => e.MrHazardTropicalcyclone).HasColumnName("MR_Hazard_TROPICALCYCLONE");

                entity.Property(e => e.MrHazardTsunami).HasColumnName("MR_Hazard_TSUNAMI");

                entity.Property(e => e.MrHazardVolcano).HasColumnName("MR_Hazard_VOLCANO");

                entity.Property(e => e.MrHazardWildfire).HasColumnName("MR_Hazard_WILDFIRE");

                entity.Property(e => e.MrHazardWstorm).HasColumnName("MR_Hazard_WSTORM");

                entity.Property(e => e.MrHnr)
                    .HasMaxLength(150)
                    .HasColumnName("MR_HNR");

                entity.Property(e => e.MrIso3)
                    .HasMaxLength(150)
                    .HasColumnName("MR_ISO3");

                entity.Property(e => e.MrQualind).HasColumnName("MR_QUALIND");

                entity.Property(e => e.MrRiskIndex).HasColumnName("MR_RiskIndex");

                entity.Property(e => e.MrRiskIndexEq).HasColumnName("MR_RiskIndexEq");

                entity.Property(e => e.MrRiskIndexFl).HasColumnName("MR_RiskIndexFl");

                entity.Property(e => e.MrRiskIndexSt).HasColumnName("MR_RiskIndexST");

                entity.Property(e => e.MrRiskScore).HasColumnName("MR_RiskScore");

                entity.Property(e => e.MrRiskScoreEq).HasColumnName("MR_RiskScoreEq");

                entity.Property(e => e.MrRiskScoreFl).HasColumnName("MR_RiskScoreFl");

                entity.Property(e => e.MrRiskScoreSt).HasColumnName("MR_RiskScoreST");

                entity.Property(e => e.MrRiverfloodRiverflood).HasColumnName("MR_RIVERFLOOD_RIVERFLOOD");

                entity.Property(e => e.MrSoil).HasColumnName("MR_SOIL");

                entity.Property(e => e.MrStr)
                    .HasMaxLength(150)
                    .HasColumnName("MR_STR");

                entity.Property(e => e.MrX).HasColumnName("MR_X");

                entity.Property(e => e.MrY).HasColumnName("MR_Y");

                entity.Property(e => e.MrZip)
                    .HasMaxLength(150)
                    .HasColumnName("MR_ZIP");

                entity.Property(e => e.Notes).IsUnicode(false);

                entity.Property(e => e.OccupancyCode)
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.OccupancyScheme)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OpeningProtectionTypesCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.OpeningProtectionsCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.OrdinanceOrLawCoverage).HasColumnType("money");

                entity.Property(e => e.OrdinanceOrLawCoverageA).HasColumnType("money");

                entity.Property(e => e.OrdinanceOrLawCoverageB).HasColumnType("money");

                entity.Property(e => e.OrdinanceOrLawCoverageBccombined)
                    .HasColumnType("money")
                    .HasColumnName("OrdinanceOrLawCoverageBCCombined");

                entity.Property(e => e.OrdinanceOrLawCoverageC).HasColumnType("money");

                entity.Property(e => e.PlumbingLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.PrimaryFlood)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.PrimaryHeatSourceCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.PropertyLimit).HasColumnType("money");

                entity.Property(e => e.PropertyLimitB).HasColumnType("money");

                entity.Property(e => e.PropertyPremium).HasColumnType("money");

                entity.Property(e => e.PropertyPremiumB).HasColumnType("money");

                entity.Property(e => e.ProtectionClass)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Protections)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.QuakeDeductible).HasColumnType("money");

                entity.Property(e => e.QuakeLimit).HasColumnType("money");

                entity.Property(e => e.Rate).HasColumnType("decimal(12, 8)");

                entity.Property(e => e.RentalTerm)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.RoofAnchorCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.RoofConstructionCode).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.RoofConstructionScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.RoofCoverageValuationBasis)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.RoofLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.RoofShapeCode).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.RoofShapeScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.RoofSheathingCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.ScreenedEnclosureCoverage).HasColumnType("money");

                entity.Property(e => e.ServiceLine)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.ServiceLinePremium).HasColumnType("money");

                entity.Property(e => e.SinkholeCoverage).HasColumnType("money");

                entity.Property(e => e.Squarefootage).HasColumnType("decimal(7, 0)");

                entity.Property(e => e.TempLocationsId).HasColumnName("TempLocationsID");

                entity.Property(e => e.TerrorismPremium).HasColumnType("money");

                entity.Property(e => e.Tivfgu)
                    .HasColumnType("money")
                    .HasColumnName("TIVFGU");

                entity.Property(e => e.TotalPropertyLimit).HasColumnType("money");

                entity.Property(e => e.TotalPropertyPremium).HasColumnType("money");

                entity.Property(e => e.Triprapremium)
                    .HasColumnType("money")
                    .HasColumnName("TRIPRAPremium");

                entity.Property(e => e.TypeOfHeatingUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfPlumbingUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfRoofingUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfWiringUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.UserUpdated)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.WaterSewageBackupCoverage).HasColumnType("money");

                entity.Property(e => e.WindHailHurricaneDeductible).HasColumnType("money");

                entity.Property(e => e.WindHailHurricaneDeductibleNamedStorm).HasColumnType("money");

                entity.Property(e => e.WindLimit).HasColumnType("money");

                entity.Property(e => e.WiringLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.YearBuilt).HasColumnType("decimal(4, 0)");

                entity.HasOne(d => d.TempLocations)
                    .WithMany(p => p.TempPolicyTransactionsLocationsBuildings)
                    .HasForeignKey(d => d.TempLocationsId)
                    .HasConstraintName("FK_TempPolicyTransactions_Locations_Buildings_TempPolicyTransactions_Locations");
            });

            modelBuilder.Entity<TempPolicyTransactionsLocationsBuildingsIsoglclass>(entity =>
            {
                entity.ToTable("TempPolicyTransactions_Locations_Buildings_ISOGLClass");

                entity.HasIndex(e => e.TempBuildingsId, "ix_TempPolicyTransactions_Locations_Buildings_ISOGLClass_FK");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.AllOther).HasColumnType("money");

                entity.Property(e => e.Description).IsUnicode(false);

                entity.Property(e => e.Isoglclass)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("ISOGLClass");

                entity.Property(e => e.PremiumBasis)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.PremiumBasisValue).HasColumnType("money");

                entity.Property(e => e.ProductsCompletedOperationsPremium).HasColumnType("money");

                entity.Property(e => e.SubCoverageCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TempBuildingsId).HasColumnName("TempBuildingsID");

                entity.Property(e => e.TerritoriesCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.HasOne(d => d.TempBuildings)
                    .WithMany(p => p.TempPolicyTransactionsLocationsBuildingsIsoglclasses)
                    .HasForeignKey(d => d.TempBuildingsId)
                    .HasConstraintName("FK_TempPremiumsTransactionsLocationsBuildingsISOGLClass_TempPremiumsTransactionsLocationsBuildings");
            });

            modelBuilder.Entity<TempPolicyTransactionsLocationsIsoglclass>(entity =>
            {
                entity.ToTable("TempPolicyTransactions_Locations_ISOGLClass");

                entity.HasIndex(e => new { e.TempLocationsId, e.Isoglclass }, "ix_TempPolicyTransactions_Locations_ISOGLClass_TempLocationsID_ISOGLClass")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => e.TempLocationsId, "ix_TempPolicyTransactions_Locations_ISOGLClass_TempLocationsID_Includes")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.TempLocationsId, e.PremiumBasis }, "ix_TempPolicyTransactions_Locations_ISOGLClass_TempLocationsID_PremiumBasis")
                    .HasFillFactor((byte)80);

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.AllOther).HasColumnType("money");

                entity.Property(e => e.Description).IsUnicode(false);

                entity.Property(e => e.Isoglclass)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("ISOGLClass");

                entity.Property(e => e.PremiumBasis)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.PremiumBasisValue).HasColumnType("money");

                entity.Property(e => e.ProductsCompletedOperationsPremium).HasColumnType("money");

                entity.Property(e => e.SubCoverageCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TempLocationsId).HasColumnName("TempLocationsID");

                entity.Property(e => e.TerritoriesCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.HasOne(d => d.TempLocations)
                    .WithMany(p => p.TempPolicyTransactionsLocationsIsoglclasses)
                    .HasForeignKey(d => d.TempLocationsId)
                    .HasConstraintName("FK_TempPremiumsTransactionsLocationsISOGLClass_TempPremiumsTransactionsLocations");
            });

            modelBuilder.Entity<TempPolicyTransactionsLocationsIsoglclassProfessionalLiabilityLawyer>(entity =>
            {
                entity.ToTable("TempPolicyTransactions_Locations_ISOGLClass_ProfessionalLiability_Lawyers");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.AnnualStatementLob)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("AnnualStatementLOB")
                    .HasDefaultValueSql("('172')");

                entity.Property(e => e.AreaOfPracticeId).HasColumnName("AreaOfPracticeID");

                entity.Property(e => e.AreaOfPracticePercentage).HasDefaultValueSql("((1000))");

                entity.Property(e => e.AverageCaseSize).HasColumnType("money");

                entity.Property(e => e.CoverageEffectiveDate).HasColumnType("datetime");

                entity.Property(e => e.CoverageExpirationDate).HasColumnType("datetime");

                entity.Property(e => e.Cspsubline)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasColumnName("CSPSubline")
                    .HasDefaultValueSql("('317')");

                entity.Property(e => e.Deductible).HasColumnType("money");

                entity.Property(e => e.DefenseCostDeductible).HasColumnType("money");

                entity.Property(e => e.DefenseCostLimit).HasColumnType("money");

                entity.Property(e => e.DeleteCode)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.ExposureRatingBasis).HasDefaultValueSql("((75))");

                entity.Property(e => e.ExtendedReportingPeriodDate).HasColumnType("datetime");

                entity.Property(e => e.FirmRevenue).HasColumnType("money");

                entity.Property(e => e.FormCode).HasDefaultValueSql("((101))");

                entity.Property(e => e.Isoglclass)
                    .HasMaxLength(5)
                    .IsUnicode(false)
                    .HasColumnName("ISOGLClass");

                entity.Property(e => e.Limit).HasColumnType("money");

                entity.Property(e => e.MaximumCaseSize).HasColumnType("money");

                entity.Property(e => e.PolicyAggregateLimit).HasColumnType("money");

                entity.Property(e => e.PolicyTypeCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Premium).HasColumnType("money");

                entity.Property(e => e.RateDepartureLcm)
                    .HasColumnName("RateDepartureLCM")
                    .HasDefaultValueSql("((100))");

                entity.Property(e => e.RateModificationFactor).HasDefaultValueSql("((100))");

                entity.Property(e => e.RatingId).HasColumnName("RatingID");

                entity.Property(e => e.RetroActiveDate).HasColumnType("datetime");

                entity.Property(e => e.SubCoverageCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TempLocationsId).HasColumnName("TempLocationsID");

                entity.Property(e => e.TermPremium).HasColumnType("money");

                entity.Property(e => e.TerritoriesCode)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('999')");

                entity.Property(e => e.TerrorismCoverageCode)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.HasOne(d => d.TempLocations)
                    .WithMany(p => p.TempPolicyTransactionsLocationsIsoglclassProfessionalLiabilityLawyers)
                    .HasForeignKey(d => d.TempLocationsId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("FK__TempPolic__TempL__4A7F49DD");
            });

            modelBuilder.Entity<TempPolicyTransactionsLocationsTransportation>(entity =>
            {
                entity.HasKey(e => e.TempLocationsTransportationId)
                    .HasName("PK_TempPolicyTransactions_Locations_Transportation_1");

                entity.ToTable("TempPolicyTransactions_Locations_Transportation");

                entity.Property(e => e.TempLocationsTransportationId).HasColumnName("TempLocationsTransportationID");

                entity.Property(e => e.AnyOneCombination).HasColumnType("money");

                entity.Property(e => e.AnyOneLoss).HasColumnType("money");

                entity.Property(e => e.AnyOneUnit).HasColumnType("money");

                entity.Property(e => e.Apdcommodities).HasColumnName("APDCommodities");

                entity.Property(e => e.AvgValueInAterminal)
                    .HasColumnType("money")
                    .HasColumnName("AvgValueInATerminal");

                entity.Property(e => e.AvgValuePerShipment).HasColumnType("money");

                entity.Property(e => e.AvgValuePerUnit).HasColumnType("money");

                entity.Property(e => e.Dotnumber)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("DOTNumber");

                entity.Property(e => e.FullTermEndorsementPremium).HasColumnType("money");

                entity.Property(e => e.Mcnumber)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("MCNumber");

                entity.Property(e => e.OnHookLimit).HasColumnType("money");

                entity.Property(e => e.TempLocationsId).HasColumnName("TempLocationsID");

                entity.Property(e => e.Tivfgu)
                    .HasColumnType("money")
                    .HasColumnName("TIVFGU");

                entity.Property(e => e.TotalValueAtAnyOneTerminal).HasColumnType("money");

                entity.Property(e => e.TransportationType)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfVehicle)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.HasOne(d => d.NatureOfLocationsNavigation)
                    .WithMany(p => p.TempPolicyTransactionsLocationsTransportations)
                    .HasForeignKey(d => d.NatureOfLocations)
                    .HasConstraintName("FK_TempPolicyTransactions_Locations_Transportation_NatureOfLocations");

                entity.HasOne(d => d.NatureOfTradeNavigation)
                    .WithMany(p => p.TempPolicyTransactionsLocationsTransportations)
                    .HasForeignKey(d => d.NatureOfTrade)
                    .HasConstraintName("FK_TempPolicyTransactions_Locations_Transportation_NatureOfTrade");

                entity.HasOne(d => d.TempLocations)
                    .WithMany(p => p.TempPolicyTransactionsLocationsTransportations)
                    .HasForeignKey(d => d.TempLocationsId)
                    .HasConstraintName("FK_TempPolicyTransactions_Locations_Transportation_TempPolicyTransactions_Locations");

                entity.HasOne(d => d.TypeOfCarrierNavigation)
                    .WithMany(p => p.TempPolicyTransactionsLocationsTransportations)
                    .HasForeignKey(d => d.TypeOfCarrier)
                    .HasConstraintName("FK_TempPolicyTransactions_Locations_Transportation_TypeOfCarrier");

                entity.HasOne(d => d.TypeOfLiabilityNavigation)
                    .WithMany(p => p.TempPolicyTransactionsLocationsTransportations)
                    .HasForeignKey(d => d.TypeOfLiability)
                    .HasConstraintName("FK_TempPolicyTransactions_Locations_Transportation_TypeOfLiability");

                entity.HasOne(d => d.TypeOfUnitsNavigation)
                    .WithMany(p => p.TempPolicyTransactionsLocationsTransportations)
                    .HasForeignKey(d => d.TypeOfUnits)
                    .HasConstraintName("FK_TempPolicyTransactions_Locations_Transportation_TypeOfUnits");

                entity.HasOne(d => d.TypeOfVehicleNavigation)
                    .WithMany(p => p.TempPolicyTransactionsLocationsTransportations)
                    .HasForeignKey(d => d.TypeOfVehicle)
                    .HasConstraintName("FK_TempPolicyTransactions_Locations_Transportation_TypeOfVehicle");
            });

            modelBuilder.Entity<TempPolicyTransactionsPriorLoss>(entity =>
            {
                entity.HasKey(e => e.TempPriorLossId);

                entity.ToTable("TempPolicyTransactions_PriorLosses");

                entity.HasIndex(e => e.TempPremiumsId, "IX_TempPolicyTransactions_PriorLosses_TempPremiumsID");

                entity.Property(e => e.TempPriorLossId).HasColumnName("TempPriorLossID");

                entity.Property(e => e.CauseOfLoss)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimStatus)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.DateOfLoss).HasColumnType("datetime");

                entity.Property(e => e.TempPremiumsId).HasColumnName("TempPremiumsID");

                entity.Property(e => e.TotalIncurred).HasColumnType("money");

                entity.HasOne(d => d.TempPremiums)
                    .WithMany(p => p.TempPolicyTransactionsPriorLosses)
                    .HasForeignKey(d => d.TempPremiumsId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("FK_TempPolicyTransactions_PriorLosses_TempPolicyTransactions");
            });

            modelBuilder.Entity<TempPolicyTransactionsProfessionalLiabilityAttorney>(entity =>
            {
                entity.ToTable("TempPolicyTransactions_ProfessionalLiability_Attorneys");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.AttorneyHoursId).HasColumnName("AttorneyHoursID");

                entity.Property(e => e.TempPremiumsId).HasColumnName("TempPremiumsID");

                entity.HasOne(d => d.AttorneyHours)
                    .WithMany(p => p.TempPolicyTransactionsProfessionalLiabilityAttorneys)
                    .HasForeignKey(d => d.AttorneyHoursId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_AttornyHoursID");

                entity.HasOne(d => d.TempPremiums)
                    .WithMany(p => p.TempPolicyTransactionsProfessionalLiabilityAttorneys)
                    .HasForeignKey(d => d.TempPremiumsId)
                    .HasConstraintName("fk_TempPolicyTransactions_Attorneys");
            });

            modelBuilder.Entity<TempPolicyTransactionsProfessionalLiabilityClientIndustry>(entity =>
            {
                entity.ToTable("TempPolicyTransactions_ProfessionalLiability_ClientIndustry");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ClientIndustryId).HasColumnName("ClientIndustryID");

                entity.Property(e => e.ModificationFactor)
                    .HasColumnType("decimal(9, 3)")
                    .HasDefaultValueSql("((1.00))");

                entity.Property(e => e.ModificationFactorBasis)
                    .IsRequired()
                    .HasMaxLength(25)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('Adhoc')");

                entity.Property(e => e.TempPremiumsId).HasColumnName("TempPremiumsID");

                entity.HasOne(d => d.ClientIndustry)
                    .WithMany(p => p.TempPolicyTransactionsProfessionalLiabilityClientIndustries)
                    .HasForeignKey(d => d.ClientIndustryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_TempPolicyTransactions_ClientIndustry");

                entity.HasOne(d => d.TempPremiums)
                    .WithMany(p => p.TempPolicyTransactionsProfessionalLiabilityClientIndustries)
                    .HasForeignKey(d => d.TempPremiumsId)
                    .HasConstraintName("FK__TempPolic__TempP__4D5BB688");
            });

            modelBuilder.Entity<TempPolicyTransactionsProfessionalLiabilityContinuingLegalEducation>(entity =>
            {
                entity.ToTable("TempPolicyTransactions_ProfessionalLiability_ContinuingLegalEducation");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ContinuingLegalEducationId).HasColumnName("ContinuingLegalEducationID");

                entity.Property(e => e.ModificationFactor).HasColumnType("decimal(9, 3)");

                entity.Property(e => e.TempPremiumsId).HasColumnName("TempPremiumsID");

                entity.HasOne(d => d.ContinuingLegalEducation)
                    .WithMany(p => p.TempPolicyTransactionsProfessionalLiabilityContinuingLegalEducations)
                    .HasForeignKey(d => d.ContinuingLegalEducationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_TempPolicyTransactions_ContinuingLegalEducation");

                entity.HasOne(d => d.TempPremiums)
                    .WithMany(p => p.TempPolicyTransactionsProfessionalLiabilityContinuingLegalEducations)
                    .HasForeignKey(d => d.TempPremiumsId)
                    .HasConstraintName("FK__TempPolic__TempP__4F43FEFA");
            });

            modelBuilder.Entity<TempPolicyTransactionsProfessionalLiabilityLitigationHistory>(entity =>
            {
                entity.ToTable("TempPolicyTransactions_ProfessionalLiability_LitigationHistory");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.LitigationHistoryId).HasColumnName("LitigationHistoryID");

                entity.Property(e => e.ModificationFactor).HasColumnType("decimal(9, 3)");

                entity.Property(e => e.TempPremiumsId).HasColumnName("TempPremiumsID");

                entity.HasOne(d => d.LitigationHistory)
                    .WithMany(p => p.TempPolicyTransactionsProfessionalLiabilityLitigationHistories)
                    .HasForeignKey(d => d.LitigationHistoryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_TempPolicyTransactions_LitigationHistory");

                entity.HasOne(d => d.TempPremiums)
                    .WithMany(p => p.TempPolicyTransactionsProfessionalLiabilityLitigationHistories)
                    .HasForeignKey(d => d.TempPremiumsId)
                    .HasConstraintName("FK__TempPolic__TempP__512C476C");
            });

            modelBuilder.Entity<TempPolicyTransactionsProfessionalLiabilityLoyaltyCredit>(entity =>
            {
                entity.ToTable("TempPolicyTransactions_ProfessionalLiability_LoyaltyCredit");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.LoyaltyCreditId).HasColumnName("LoyaltyCreditID");

                entity.Property(e => e.ModificationFactor).HasColumnType("decimal(9, 3)");

                entity.Property(e => e.TempPremiumsId).HasColumnName("TempPremiumsID");

                entity.HasOne(d => d.LoyaltyCredit)
                    .WithMany(p => p.TempPolicyTransactionsProfessionalLiabilityLoyaltyCredits)
                    .HasForeignKey(d => d.LoyaltyCreditId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fk_TempPolicyTransactions_LoyaltyCredit");

                entity.HasOne(d => d.TempPremiums)
                    .WithMany(p => p.TempPolicyTransactionsProfessionalLiabilityLoyaltyCredits)
                    .HasForeignKey(d => d.TempPremiumsId)
                    .HasConstraintName("FK__TempPolic__TempP__53148FDE");
            });

            modelBuilder.Entity<TempPolicyTransactionsTransportation>(entity =>
            {
                entity.HasKey(e => e.TempTransportationId)
                    .HasName("PK_TempPolicyTransactions_Transportation_1");

                entity.ToTable("TempPolicyTransactions_Transportation");

                entity.HasIndex(e => e.TempPremiumsId, "ix_TempPolicyTransactions_Transportation_TempPremiumsID")
                    .HasFillFactor((byte)80);

                entity.Property(e => e.TempTransportationId).HasColumnName("TempTransportationID");

                entity.Property(e => e.AnyOneCombination).HasColumnType("money");

                entity.Property(e => e.AnyOneLoss).HasColumnType("money");

                entity.Property(e => e.AnyOneUnit).HasColumnType("money");

                entity.Property(e => e.Apdcommodities).HasColumnName("APDCommodities");

                entity.Property(e => e.AvgValueInAterminal)
                    .HasColumnType("money")
                    .HasColumnName("AvgValueInATerminal");

                entity.Property(e => e.AvgValuePerShipment).HasColumnType("money");

                entity.Property(e => e.AvgValuePerUnit).HasColumnType("money");

                entity.Property(e => e.ChainsTarpsLimit).HasColumnType("money");

                entity.Property(e => e.Dotnumber)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("DOTNumber");

                entity.Property(e => e.ElectronicEquipmentLimit).HasColumnType("money");

                entity.Property(e => e.FullTermEndorsementPremium).HasColumnType("money");

                entity.Property(e => e.HighestValuedPowerUnit).HasColumnType("money");

                entity.Property(e => e.HighestValuedTrailer).HasColumnType("money");

                entity.Property(e => e.HiredVehicleAnnualCostOfRentals).HasColumnType("money");

                entity.Property(e => e.HiredVehicleLimit).HasColumnType("money");

                entity.Property(e => e.HiredVehicleRentedAdditionalUnitsFrequency)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Mcnumber)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("MCNumber");

                entity.Property(e => e.OnHookLimit).HasColumnType("money");

                entity.Property(e => e.PollutantCleanUpLimit).HasColumnType("money");

                entity.Property(e => e.TempPremiumsId).HasColumnName("TempPremiumsID");

                entity.Property(e => e.TempReplacementAutoLimit).HasColumnType("money");

                entity.Property(e => e.Tivfgu)
                    .HasColumnType("money")
                    .HasColumnName("TIVFGU");

                entity.Property(e => e.TotalValueAtAnyOneTerminal).HasColumnType("money");

                entity.Property(e => e.TotalWrittenOffOnEndorsement).HasColumnType("money");

                entity.Property(e => e.TowingStorageDebrisRemovalLimit).HasColumnType("money");

                entity.Property(e => e.TrailerInterchangeDeductible).HasColumnType("money");

                entity.Property(e => e.TrailerInterchangeLimit).HasColumnType("money");

                entity.Property(e => e.TrailerInterchangePremium).HasColumnType("money");

                entity.Property(e => e.TransportationType)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfVehicle)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.HasOne(d => d.NatureOfLocationsNavigation)
                    .WithMany(p => p.TempPolicyTransactionsTransportations)
                    .HasForeignKey(d => d.NatureOfLocations)
                    .HasConstraintName("FK_TempPolicyTransactions_Transportation_NatureOfLocations");

                entity.HasOne(d => d.NatureOfTradeNavigation)
                    .WithMany(p => p.TempPolicyTransactionsTransportations)
                    .HasForeignKey(d => d.NatureOfTrade)
                    .HasConstraintName("FK_TempPolicyTransactions_Transportation_NatureOfTrade");

                entity.HasOne(d => d.TempPremiums)
                    .WithMany(p => p.TempPolicyTransactionsTransportations)
                    .HasForeignKey(d => d.TempPremiumsId)
                    .HasConstraintName("FK_TempPolicyTransactions_Transportation_TempPolicyTransactions");

                entity.HasOne(d => d.TypeOfCarrierNavigation)
                    .WithMany(p => p.TempPolicyTransactionsTransportations)
                    .HasForeignKey(d => d.TypeOfCarrier)
                    .HasConstraintName("FK_TempPolicyTransactions_Transportation_TypeOfCarrier");

                entity.HasOne(d => d.TypeOfLiabilityNavigation)
                    .WithMany(p => p.TempPolicyTransactionsTransportations)
                    .HasForeignKey(d => d.TypeOfLiability)
                    .HasConstraintName("FK_TempPolicyTransactions_Transportation_TypeOfLiability");

                entity.HasOne(d => d.TypeOfUnitsNavigation)
                    .WithMany(p => p.TempPolicyTransactionsTransportations)
                    .HasForeignKey(d => d.TypeOfUnits)
                    .HasConstraintName("FK_TempPolicyTransactions_Transportation_TypeOfUnits");

                entity.HasOne(d => d.TypeOfVehicleNavigation)
                    .WithMany(p => p.TempPolicyTransactionsTransportations)
                    .HasForeignKey(d => d.TypeOfVehicle)
                    .HasConstraintName("FK_TempPolicyTransactions_Transportation_TypeOfVehicle");
            });

            modelBuilder.Entity<TempPolicyTransactionsTransportationApdacvunitBanding>(entity =>
            {
                entity.HasKey(e => e.TempApdacvunitBandingId);

                entity.ToTable("TempPolicyTransactions_Transportation_APDACVUnitBanding");

                entity.HasIndex(e => e.TempTransportationId, "ix_TempPolicyTransactions_Transportation_APDACVUnitBanding_TempTransportationID");

                entity.Property(e => e.TempApdacvunitBandingId).HasColumnName("TempAPDACVUnitBandingID");

                entity.Property(e => e.Aopdeductible)
                    .HasColumnType("money")
                    .HasColumnName("AOPDeductible");

                entity.Property(e => e.BandFrom).HasColumnType("money");

                entity.Property(e => e.BandTo).HasColumnType("money");

                entity.Property(e => e.TempTransportationId).HasColumnName("TempTransportationID");

                entity.Property(e => e.Tivfgu)
                    .HasColumnType("money")
                    .HasColumnName("TIVFGU");

                entity.HasOne(d => d.TempTransportation)
                    .WithMany(p => p.TempPolicyTransactionsTransportationApdacvunitBandings)
                    .HasForeignKey(d => d.TempTransportationId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("FK_TempPolicyTransactions_Transportation_APDACVUnitBanding_TempPolicyTransactions_Transportation");
            });

            modelBuilder.Entity<TempPolicyTransactionsTransportationApdcommodity>(entity =>
            {
                entity.HasKey(e => e.TempTransportationApdcommodityId)
                    .HasName("PK_TempPolicyTransactions_Transportation_APDCommodity");

                entity.ToTable("TempPolicyTransactions_Transportation_APDCommodities");

                entity.HasIndex(e => e.TempTransportationId, "IX_NonClusteredIndex-TempTransportationID")
                    .HasFillFactor((byte)80);

                entity.Property(e => e.TempTransportationApdcommodityId).HasColumnName("TempTransportationAPDCommodityID");

                entity.Property(e => e.ApdcommodityScheme)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("APDCommodityScheme");

                entity.Property(e => e.ApdcommodityType).HasColumnName("APDCommodityType");

                entity.Property(e => e.TempTransportationId).HasColumnName("TempTransportationID");

                entity.HasOne(d => d.TempTransportation)
                    .WithMany(p => p.TempPolicyTransactionsTransportationApdcommodities)
                    .HasForeignKey(d => d.TempTransportationId)
                    .HasConstraintName("FK_TempPolicyTransactions_Transportation_APDCommodities_TempPolicyTransactions_Transportation");
            });

            modelBuilder.Entity<TempPolicyTransactionsTransportationCargoCommodity>(entity =>
            {
                entity.HasKey(e => e.TempTransportationCargoCommodityId)
                    .HasName("PK_TempPolicyTransactions_Transportation_CargoCommodity");

                entity.ToTable("TempPolicyTransactions_Transportation_CargoCommodities");

                entity.HasIndex(e => e.TempTransportationId, "IX_NonClusteredIndex-TempTransportationID")
                    .HasFillFactor((byte)80);

                entity.Property(e => e.TempTransportationCargoCommodityId).HasColumnName("TempTransportationCargoCommodityID");

                entity.Property(e => e.CargoCommodityPercentage).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.CargoCommodityScheme)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TempTransportationId).HasColumnName("TempTransportationID");

                entity.HasOne(d => d.TempTransportation)
                    .WithMany(p => p.TempPolicyTransactionsTransportationCargoCommodities)
                    .HasForeignKey(d => d.TempTransportationId)
                    .HasConstraintName("FK_TempPolicyTransactions_Transportation_CargoCommodities_TempPolicyTransactions_Transportation");
            });

            modelBuilder.Entity<TempPolicyTransactionsTransportationTrailerDetail>(entity =>
            {
                entity.HasKey(e => e.TempTransportationTrailerDetailsId);

                entity.ToTable("TempPolicyTransactions_Transportation_TrailerDetails");

                entity.HasIndex(e => e.TempTransportationId, "IX_NnClusteredIndex-TempTransportationID")
                    .HasFillFactor((byte)80);

                entity.Property(e => e.TempTransportationTrailerDetailsId).HasColumnName("TempTransportationTrailerDetailsID");

                entity.Property(e => e.Acv)
                    .HasColumnType("money")
                    .HasColumnName("ACV");

                entity.Property(e => e.Make)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Model)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TempTransportationId).HasColumnName("TempTransportationID");

                entity.Property(e => e.TypeOfTrailer)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Vin)
                    .HasMaxLength(17)
                    .IsUnicode(false)
                    .HasColumnName("VIN");

                entity.Property(e => e.Year).HasColumnType("decimal(4, 0)");

                entity.HasOne(d => d.TempTransportation)
                    .WithMany(p => p.TempPolicyTransactionsTransportationTrailerDetails)
                    .HasForeignKey(d => d.TempTransportationId)
                    .HasConstraintName("FK_TempPolicyTransactions_Transportation_TrailerDetails_TempPolicyTransactions_Transportation");
            });

            modelBuilder.Entity<TempPolicyTransactionsTransportationVehicleDetail>(entity =>
            {
                entity.HasKey(e => e.TempTransportationVehicleDetailsId);

                entity.ToTable("TempPolicyTransactions_Transportation_VehicleDetails");

                entity.HasIndex(e => e.TempTransportationId, "IX_NonClusteredIndex-TempTransportationID")
                    .HasFillFactor((byte)80);

                entity.Property(e => e.TempTransportationVehicleDetailsId).HasColumnName("TempTransportationVehicleDetailsID");

                entity.Property(e => e.Acv)
                    .HasColumnType("money")
                    .HasColumnName("ACV");

                entity.Property(e => e.Make)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Model)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TempTransportationId).HasColumnName("TempTransportationID");

                entity.Property(e => e.TypeOfVehicle)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Vin)
                    .HasMaxLength(17)
                    .IsUnicode(false)
                    .HasColumnName("VIN");

                entity.Property(e => e.Year).HasColumnType("decimal(4, 0)");

                entity.HasOne(d => d.TempTransportation)
                    .WithMany(p => p.TempPolicyTransactionsTransportationVehicleDetails)
                    .HasForeignKey(d => d.TempTransportationId)
                    .HasConstraintName("FK_TempPolicyTransactions_Transportation_VehicleDetails_TempPolicyTransactions_Transportation");
            });

            modelBuilder.Entity<TypeOfCarrier>(entity =>
            {
                entity.HasKey(e => e.TypeOfCarrier1);

                entity.ToTable("TypeOfCarrier");

                entity.Property(e => e.TypeOfCarrier1)
                    .ValueGeneratedNever()
                    .HasColumnName("TypeOfCarrier");

                entity.Property(e => e.Description)
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TypeOfLiability>(entity =>
            {
                entity.HasKey(e => e.TypeOfLiability1);

                entity.ToTable("TypeOfLiability");

                entity.Property(e => e.TypeOfLiability1)
                    .ValueGeneratedNever()
                    .HasColumnName("TypeOfLiability");

                entity.Property(e => e.Description)
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TypeOfUnit>(entity =>
            {
                entity.HasKey(e => e.TypeOfUnits);

                entity.Property(e => e.TypeOfUnits).ValueGeneratedNever();

                entity.Property(e => e.Description)
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TypeOfVehicle>(entity =>
            {
                entity.HasKey(e => e.TypeOfVehicle1);

                entity.ToTable("TypeOfVehicle");

                entity.Property(e => e.TypeOfVehicle1)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .HasColumnName("TypeOfVehicle");

                entity.Property(e => e.Description)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Notes).IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
