using AuditApi.Controllers;
using AuditApi.Shared.Helper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Model;
using Models;
using Moq;
using Newtonsoft.Json;
using Repositories.Interfaces;
using Services.Interfaces;
using System;
using System.IO;
using System.Threading.Tasks;

namespace AuditAPIUnitTests
{
    [TestClass]
    public class TransactionAuditControllerUnitTests : TestDataHelper
    {
        private TransactionAuditController _transactionAuditController;
        private Mock<ITransactionsAuditService> _transactionAuditApiService;
        private Mock<IUniversalBDXRepository> _universalBDXRepository;
        [TestInitialize]
        public void Setup()
        {
            var logger = new Mock<ILogger<TransactionAuditController>>();
            var _authorizationHelper = new Mock<IAuthorizationHelper>();
                _authorizationHelper.Setup(m => m.IsServiceInternallyCalled()).Returns(true);
            var configuration = new Mock<IConfiguration>();
                configuration.Setup(c => c["ClientCompanyId"]).Returns("49");

            _transactionAuditApiService = new Mock<ITransactionsAuditService>();
            _transactionAuditController = new TransactionAuditController(logger.Object, _transactionAuditApiService.Object, _authorizationHelper.Object, configuration.Object);
            _universalBDXRepository = new Mock<IUniversalBDXRepository>();

            var tempPolicyTransactions = GetTempPolicyTransaction();
            var tempPolicyTransactionsIsoglClasses = GetTempPolicyTransactionsIsoglclasses();
            var tempPolicyTransactionsContracts = GetTempPolicyTransactionsContracts();
            _universalBDXRepository.Setup(r => r.GetTempPolicyTransactions()).Returns(GetDbSet(tempPolicyTransactions));
            _universalBDXRepository.Setup(r => r.GetTempPolicyTransactionsIsoglclass()).Returns(GetDbSet(tempPolicyTransactionsIsoglClasses));
            _universalBDXRepository.Setup(r => r.GetTempPolicyTransactionsContracts()).Returns(GetDbSet(tempPolicyTransactionsContracts));
        }

        [TestMethod]
        public async Task Should_Return_Policy_Data_For_Given_Policy_Number()
        {
            var policyRiskRequest = new PolicyRiskRequest() { CompanyId = 192, ContractRef = "3400", ContractYear = 2021, PolicyNumber = "GLS00016617A/21" };
            var policyResponseJson = File.ReadAllText(@".\PolicySearchResponse.json");
            var policyRiskResponse = JsonConvert.DeserializeObject<RiskResponse>(policyResponseJson);

            _transactionAuditApiService.Setup(s => s.GetPolicyTransactions(It.IsAny<PolicyRiskRequest>())).Returns(policyRiskResponse);
            var policyTransactions = await _transactionAuditController.GetPolicyTransactions(policyRiskRequest);
            Assert.IsNotNull(policyTransactions.Result);
            Assert.IsInstanceOfType(policyTransactions, typeof(ActionResult<RiskResponse>));
        }

        [TestMethod]
        public async Task Should_Return_Policy_Data_For_Given_AccountingPeriod()
        {
            var monthlySearchRequest = new MonthlyRiskRequest() { CompanyId = 192, ContractRef = "3400", ContractYear = 2021, AccountingEffectiveDate = Convert.ToDateTime("2021-10-30") };
            var policyResponseJson = File.ReadAllText(@".\PolicySearchResponse.json");
            var policyRiskResponse = JsonConvert.DeserializeObject<RiskResponse>(policyResponseJson);

            _transactionAuditApiService.Setup(s => s.GetMonthlyTransactions(It.IsAny<MonthlyRiskRequest>())).Returns(policyRiskResponse);
            var monthlyPolicyTransactions = await _transactionAuditController.GetMonthlyTransactions(monthlySearchRequest);
            Assert.IsInstanceOfType(monthlyPolicyTransactions, typeof(ActionResult<RiskResponse>));

        }
    }
}
