﻿using Microsoft.EntityFrameworkCore;
using Moq;
using Repositories.Entities;
using Repositories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AuditAPIUnitTests
{
    public class TestDataHelper
    {
        protected Mock<IUniversalBDXRepository> _repository;
        public TestDataHelper()
        {
            _repository = new Mock<IUniversalBDXRepository>();
        }
        protected static List<TempPolicyTransaction> GetTempPolicyTransaction()
        {
            return new List<TempPolicyTransaction>()
            {
                new TempPolicyTransaction(){ CompanyId = 192 ,TempPremiumsId = 3377261,InsuredName ="SUSAN DIERKER", PolicyNo ="GLS00016617A/21", TransactionType = "END" , ImportFilename = "GP_AMFED_A3168_17Jun18P.xlsx" ,
                        RecordError = true , HoldError = true , OverrideError = true , AccountingEffectiveDate = Convert.ToDateTime("2021-10-30") , ManualChecked = false,
                        DuplicateRecord = false, IgnoreRecord = false, IsTestData = false , GrossPremium = 0, InHouseHold = true, WindLimit = 334000, CorrectedBy = null,
                        TempPolicyTransactionsPriorLosses = new List<TempPolicyTransactionsPriorLoss>{ new TempPolicyTransactionsPriorLoss { TempPremiumsId = 3377261 } } ,
                        TempPolicyTransactionsContracts = new List<TempPolicyTransactionsContract> { new TempPolicyTransactionsContract { TempPremiumsId = 3377261 } },
                        TempPolicyTransactionsDocucorpIncludedForms = new List<TempPolicyTransactionsDocucorpIncludedForm>(),
                       
                },

                new TempPolicyTransaction(){ CompanyId = 192 ,TempPremiumsId = 3377262,InsuredName ="SUSAN DIERKER", PolicyNo ="GLSP12009516", TransactionType = "END" , ImportFilename = "GP_AMFED_A3168_17Jun18P.xlsx" ,
                    RecordError = true , HoldError = true , OverrideError = true ,AccountingEffectiveDate = Convert.ToDateTime("2021-10-30") , ManualChecked = false,
                    DuplicateRecord = false, IgnoreRecord = false, IsTestData = false , GrossPremium = 0, InHouseHold = true, WindLimit = 334000, CorrectedBy = null},

                new TempPolicyTransaction(){ CompanyId = 192 ,TempPremiumsId = 3652025,InsuredName ="SUSAN DIERKER", PolicyNo ="GLSP12000716", TransactionType = "END" , ImportFilename = "GP_AMFED_A3168_17Jun18P.xlsx" ,
                        RecordError = true , HoldError = true , OverrideError = true ,AccountingEffectiveDate = Convert.ToDateTime("2020-1-2") , ManualChecked = false,
                        DuplicateRecord = false, IgnoreRecord = false, IsTestData = false , GrossPremium = 0, InHouseHold = true, WindLimit = 334000, CorrectedBy = null},

                new TempPolicyTransaction(){CompanyId = 21 , TempPremiumsId = 813885, TransactionType = "END" , PdfattachmentFileName = "LOVULLOTEST_GLSP12000516_NEW-GLSP12000516-32249_120418_124518.PDF",
                     Pdfattachment = Encoding.ASCII.GetBytes("LOVULLOTEST_GLSP12000516_NEW-GLSP12000516-32249_120418_124518.PDF"),
                     RecordError = false , HoldError = false , OverrideError = true , ManualChecked = false,AccountingEffectiveDate = Convert.ToDateTime("2020-1-29"),
                     DuplicateRecord = false, IgnoreRecord = false, IsTestData = true , GrossPremium = 2000 , InHouseHold = false , WindLimit = 134000, CorrectedBy = null},
                new TempPolicyTransaction(){CompanyId = 6355 , TempPremiumsId = 780480, TransactionType = "END" , ImportFilename = "GP_JJBackFillTest_A3168_18OCT18P.XLSX",
                        RecordError = false , HoldError = false , OverrideError = true , ManualChecked = false,AccountingEffectiveDate = Convert.ToDateTime("2020-1-29"),
                        DuplicateRecord = false, IgnoreRecord = false, IsTestData = true , GrossPremium = 2000 , InHouseHold = false , WindLimit = 134000, CorrectedBy = null},

                new TempPolicyTransaction(){ CompanyId = 8192 ,TempPremiumsId = 780513,  OverrideError = true , TransactionType = "END" , ImportFilename = "LP_RIVINGTONTEST_A9700_18APR18P.xlsx" ,
                        RecordError = false , HoldError = false , AccountingEffectiveDate = Convert.ToDateTime("2020-1-28"), ManualChecked = false,
                        DuplicateRecord = false, IgnoreRecord = false, IsTestData = false , GrossPremium = 2000 , InHouseHold = false , WindLimit = 33000, CorrectedBy = null},

                new TempPolicyTransaction(){ CompanyId = 24 ,TempPremiumsId = 780501, InsuredName ="SUSAN DIERKER", PolicyNo ="GLSP12000516", TransactionType = "END" , ImportFilename = "GP_AMFED_A3168_17Jun18P.xlsx" ,
                        RecordError = true , HoldError = true , OverrideError = true ,AccountingEffectiveDate = Convert.ToDateTime("2020-1-2") , ManualChecked = false,
                        DuplicateRecord = false, IgnoreRecord = false, IsTestData = false , GrossPremium = 0, InHouseHold = true, WindLimit = 334000},

                new TempPolicyTransaction(){ CompanyId = 24 ,TempPremiumsId = 780502,InsuredName ="RALPH HALL", PolicyNo ="GLSP12000512", TransactionType = "CAN" , ImportFilename = "GP_AMFED_A3168_16Jun18P.xlsx" ,
                        RecordError = true , HoldError = true , OverrideError = false , AccountingEffectiveDate = Convert.ToDateTime("2020-1-28") , ManualChecked = false,
                        DuplicateRecord = false, IgnoreRecord = false, IsTestData = false , GrossPremium = 0 , InHouseHold = true, WindLimit = 34000, CorrectedBy = null},

                new TempPolicyTransaction(){ CompanyId = 192 ,TempPremiumsId = 780503, TransactionType = "NEW" , ImportFilename = "GP_BLISSGLEN_A3135_20Apr20P.xlsx" ,RecordError = false ,
                        HoldError = false , OverrideError = false ,AccountingEffectiveDate = Convert.ToDateTime("2020-2-15") , ManualChecked = false,
                        DuplicateRecord = false, IgnoreRecord = false, IsTestData = false, GrossPremium = 0 , InHouseHold = false , WindLimit = 134000},

                new TempPolicyTransaction(){ CompanyId = 192 ,TempPremiumsId = 780504, TransactionType = "NEW" , ImportFilename = "GP_BLISSGLEN_A3136_21Apr20P.xlsx" ,RecordError = false ,
                        HoldError = false , OverrideError = true , AccountingEffectiveDate = Convert.ToDateTime("2020-2-17") , ManualChecked = false,
                        DuplicateRecord = false, IgnoreRecord = false, IsTestData = false, GrossPremium = 0 , InHouseHold = false, WindLimit = 434000},

                new TempPolicyTransaction(){ CompanyId = 192 ,TempPremiumsId = 780505, TransactionType = "ENQ" , ImportFilename = "GP_BLISSGLEN_A3136_23Apr20P.xlsx" ,RecordError = false ,
                        HoldError = true , OverrideError = false , AccountingEffectiveDate = Convert.ToDateTime("2020-2-16"), ManualChecked = false,
                        DuplicateRecord = false, IgnoreRecord = false, IsTestData = false, GrossPremium = 0, InHouseHold = false, WindLimit = 534000},

                new TempPolicyTransaction(){ CompanyId = 192 , TempPremiumsId = 780506, TransactionType = "QTE" , ImportFilename = "GP_BLISSGLEN_A3136_22Apr20P.xlsx" ,RecordError = true ,
                        HoldError = false ,OverrideError = false , AccountingEffectiveDate = Convert.ToDateTime("2020-2-18") , ManualChecked = false,
                        DuplicateRecord = false , IgnoreRecord = false, IsTestData = false, GrossPremium = 0, InHouseHold = false ,WindLimit = 0},

                new TempPolicyTransaction(){CompanyId = 192, TempPremiumsId = 780568, PolicyNo ="E17100509261201", TransactionType = "CAN" , AccountingEffectiveDate = Convert.ToDateTime("2020-11-29"),
                        InsuredName ="RODNEY  BROWN", NumberofBuildings = 1, NumberofLocations = 1 , RecordError = true , HoldError = true, ManualChecked = true,
                        BusinessArea="GLUK", ContractRef="TEST CONTRACT REF", ContractPeriod = 2018, ImportFilename = "GP_BLISSGLEN_A3136_22Apr20P.xlsx",WindLimit = 0,
                        OverrideError = false ,DuplicateRecord = false ,IgnoreRecord = false , IsTestData = false ,GrossPremium = 10000, InHouseHold = false},

                new TempPolicyTransaction(){CompanyId = 192, TempPremiumsId = 780569,  PolicyNo ="USG1003308/20",TransactionType = "END" , AccountingEffectiveDate = Convert.ToDateTime("2020-11-29"),
                        InsuredName ="JESSIE M  MILLER", NumberofBuildings = 1, NumberofLocations = 1,RecordError = true , HoldError = false, WindLimit = 334000,
                        BusinessArea="GLUK", ContractRef="TEST CONTRACT REF", ContractPeriod =2019, ImportFilename = "GP_BLISSGLEN_A3136_22Apr20P.xlsx" ,  ManualChecked = true,
                        OverrideError = false , DuplicateRecord = false, IgnoreRecord = false, IsTestData = false ,GrossPremium = 0, InHouseHold = false},

                new TempPolicyTransaction(){TempPremiumsId = 780570, CompanyId = 192, PolicyNo="UKP62024",TransactionType = "NEW" ,AccountingEffectiveDate = Convert.ToDateTime("2020-11-29"),
                        InsuredName ="STEPHANIE ROLLEY", NumberofBuildings = 1, NumberofLocations = 1,RecordError = false , HoldError = false, OverrideError = false,
                        ManualChecked = true,DuplicateRecord = false,IgnoreRecord = false, IsTestData = false,GrossPremium = 0, InHouseHold = false, WindLimit = 134000,
                        BusinessArea="GLUK", ContractRef="TEST CONTRACT REF", ContractPeriod = 2020, ImportFilename = "GP_BLISSGLEN_A3136_22Apr20P.xlsx" },

                new TempPolicyTransaction(){TempPremiumsId = 780480, CompanyId = 192, PolicyNo="UKP62025",TransactionType = "NEW" ,AccountingEffectiveDate = Convert.ToDateTime("2020-11-29"),
                        InsuredName ="STEPHANIE ROLLEY TEST", NumberofBuildings = 1, NumberofLocations = 1,RecordError = false , HoldError = true, OverrideError = false,
                        ManualChecked = false, DuplicateRecord = false, IgnoreRecord = false, IsTestData = false,GrossPremium = 0, InHouseHold = false, WindLimit = 34000,
                        BusinessArea="GLUK", ContractRef="TEST CONTRACT REFERENCE", ContractPeriod = 2020, ImportFilename = "GP_BLISSGLEN_A3136_25Apr20P.xlsx" },

                new TempPolicyTransaction(){ TempPremiumsId = 780481, CompanyId = 192, PolicyNo="UKP62025",TransactionType = "NEW" ,AccountingEffectiveDate = Convert.ToDateTime("2020-11-29"),
                        InsuredName ="STEPHANIE ROLLEY TEST", NumberofBuildings = 1, NumberofLocations = 1,RecordError = false , HoldError = true, OverrideError = false,
                        ManualChecked = false, DuplicateRecord = false, IgnoreRecord = true,  IsTestData = false, GrossPremium = 0, InHouseHold = false, WindLimit = 4000,
                        BusinessArea="GLUK", ContractRef="TEST CONTRACT REFERENCE", ContractPeriod = 2020, ImportFilename = "GP_BLISSGLEN_A3136_25Apr20P.xlsx" },

                new TempPolicyTransaction(){TempPremiumsId = 780482 , CompanyId = 192, PolicyNo="UKP62026",TransactionType = "NEW" ,AccountingEffectiveDate = Convert.ToDateTime("2020-11-29"),
                        InsuredName ="STEPHANIE ROLLEY TEST", NumberofBuildings = 1, NumberofLocations = 1,RecordError = false , HoldError = true, OverrideError = false,
                        ManualChecked = false, DuplicateRecord = true, IgnoreRecord = true, IsTestData = false, GrossPremium = 0, InHouseHold = false, WindLimit = 134000,
                        BusinessArea="GLUK", ContractRef="TEST CONTRACT REFERENCE", ContractPeriod = 2020, ImportFilename = "GP_BLISSGLEN_A3136_25Apr20P.xlsx" },

            };
        }

        protected static List<TempPolicyTransactionsLocation> GetTempPolicyTransactionsLocations()
        {
            return new List<TempPolicyTransactionsLocation>() {
                   new TempPolicyTransactionsLocation(){ TempLocationsId = 777249, TempPremiumsId = 813885},
                   new TempPolicyTransactionsLocation(){TempPremiumsId = 780480, TempLocationsId = 777249},
                     new TempPolicyTransactionsLocation(){TempPremiumsId = 3377261, TempLocationsId = 777260},
                };
        }

        protected static List<TempPolicyTransactionsIsoglclass> GetTempPolicyTransactionsIsoglclasses()
        {
            return new List<TempPolicyTransactionsIsoglclass>() {
                   new TempPolicyTransactionsIsoglclass(){ TempPremiumsId = 782157 , Isoglclass="60010", Id=9254, PremiumBasis="T"},
                   new TempPolicyTransactionsIsoglclass(){ TempPremiumsId = 3377261 , Isoglclass="60010", Id=15456, PremiumBasis="U", Description = "Vacant Builidngs - not factories - Other than Not-For-Profit"},
            };
        }

        protected static List<TempPolicyTransactionsApimIsyCl> GetTempPolicyTransactionsApimIsyCls()
        {
            return new List<TempPolicyTransactionsApimIsyCl>()
            {
                new TempPolicyTransactionsApimIsyCl(){ TempPremiumsId = 3377261 },
                new TempPolicyTransactionsApimIsyCl(){ TempPremiumsId = 782157 }
            };
        }
        protected static List<Agent> GetAgents()
        {
            return new List<Agent>()
            {
                new Agent(){ CompanyId = 192, CompanyName = "Johnson & Johnson Inc." },
                new Agent(){ CompanyId = 49, CompanyName = "Bell & Clements Limited" }
            };
        }

        protected static List<TempPolicyTransactionsContract> GetTempPolicyTransactionsContracts()
        {
            return new List<TempPolicyTransactionsContract>()
            {
                new TempPolicyTransactionsContract(){ CompanyId = 192, ContractRef = "3400", ContractYear = 2021, TempPremiumsId = 3377261},
                new TempPolicyTransactionsContract(){ CompanyId = 192, ContractRef = "3400", ContractYear = 2020, TempPremiumsId = 3377262},
                new TempPolicyTransactionsContract(){ CompanyId = 192, ContractRef = "3401", ContractYear = 2021, TempPremiumsId = 3377263},
                new TempPolicyTransactionsContract(){ CompanyId = 192, ContractRef = "3903", ContractYear = 2021, TempPremiumsId = 3377264},
                new TempPolicyTransactionsContract(){ CompanyId = 192, ContractRef = "3183", ContractYear = 2021, TempPremiumsId = 3377265},
                new TempPolicyTransactionsContract(){ CompanyId = 192, ContractRef = "3175", ContractYear = 2021, TempPremiumsId = 3377266},
                new TempPolicyTransactionsContract(){ CompanyId = 192, ContractRef = "3105", ContractYear = 2021, TempPremiumsId = 3377267}
            };
        }
        protected static List<TempPolicyTransactionsLocation> GetTempolicyTransactionsLocations()
        {
            return new List<TempPolicyTransactionsLocation>()
            {
                new TempPolicyTransactionsLocation(){TempPremiumsId =3377261 , TempLocationsId = 123456}
            };

        }
        public DbSet<T> GetDbSet<T>(List<T> sourceList) where T : class
        {
            var queryable = sourceList.AsQueryable();

            var dbSet = new Mock<DbSet<T>>();
            dbSet.As<IQueryable<T>>().Setup(m => m.Provider).Returns(queryable.Provider);
            dbSet.As<IQueryable<T>>().Setup(m => m.Expression).Returns(queryable.Expression);
            dbSet.As<IQueryable<T>>().Setup(m => m.ElementType).Returns(queryable.ElementType);
            dbSet.As<IQueryable<T>>().Setup(m => m.GetEnumerator()).Returns(queryable.GetEnumerator());
            dbSet.Setup(d => d.Add(It.IsAny<T>())).Callback<T>(sourceList.Add);
            return dbSet.Object;
        }
        protected static Mock<DbSet<T>> GetDbSet<T>(IQueryable<T> TestData) where T : class
        {
            var MockSet = new Mock<DbSet<T>>();
            MockSet.As<IAsyncEnumerable<T>>().Setup(x =>
            x.GetAsyncEnumerator(default)).Returns(new TestAsyncEnumerator<T>(TestData.GetEnumerator()));
            MockSet.As<IQueryable<T>>().Setup(x => x.Provider).Returns(new EntityAsyncQueryProvider<T>(TestData.Provider));
            MockSet.As<IQueryable<T>>().Setup(x => x.Expression).Returns(TestData.Expression);
            MockSet.As<IQueryable<T>>().Setup(x => x.ElementType).Returns(TestData.ElementType);
            MockSet.As<IQueryable<T>>().Setup(x => x.GetEnumerator()).Returns(TestData.GetEnumerator());
            return MockSet;
        }
    }
}

