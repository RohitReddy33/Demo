﻿using Newtonsoft.Json;
using System;

namespace Models
{
    public partial class ProfessionalLiabilityClassLawyer
    {
        [JsonProperty("isoglClassCode")]
        public string IsoglClassCode { get; set; }

        [JsonProperty("coverageEffectiveDate")]
        public DateTime? CoverageEffectiveDate { get; set; }

        [JsonProperty("coverageExpiryDate")]
        public DateTime? CoverageExpiryDate { get; set; }

        [JsonProperty("areaOfPracticeID")]
        public long? AreaOfPracticeId { get; set; }

        [JsonProperty("areaOfPracticePercentage")]
        public int AreaOfPracticePercentage { get; set; }

        [JsonProperty("exposureRatingBasis")]
        public int ExposureRatingBasis { get; set; }

        [JsonProperty("exposure")]
        public int? Exposure { get; set; }

        [JsonProperty("rate")]
        public double Rate { get; set; }

        [JsonProperty("ratingID")]
        public int? RatingId { get; set; }

        [JsonProperty("termPremium")]
        public decimal? TermPremium { get; set; }

        [JsonProperty("premiumAmount")]
        public decimal? PremiumAmount { get; set; }

        [JsonProperty("limitAmount")]
        public decimal? LimitAmount { get; set; }

        [JsonProperty("deductibleAmount")]
        public decimal? DeductibleAmount { get; set; }

        [JsonProperty("territoriesCode")]
        public string TerritoriesCode { get; set; }

        [JsonProperty("coverageCode")]
        public int? CoverageCode { get; set; }

        [JsonProperty("subCoverageCode")]
        public string SubCoverageCode { get; set; }

        [JsonProperty("scheduledRateModificationFactor")]
        public double ScheduledRateModificationFactor { get; set; }

        [JsonProperty("rateModificationFactor")]
        public double RateModificationFactor { get; set; }

        [JsonProperty("rateDepartureLCM")]
        public double RateDepartureLcm { get; set; }

        [JsonProperty("firmRevenue")]
        public decimal? FirmRevenue { get; set; }

        [JsonProperty("averageCaseSize")]
        public decimal? AverageCaseSize { get; set; }

        [JsonProperty("maximumCaseSize")]
        public decimal? MaximumCaseSize { get; set; }

        [JsonProperty("numberCasesPerYear")]
        public int? NumberCasesPerYear { get; set; }

        [JsonProperty("firmAttorneyExperience")]
        public int? FirmAttorneyExperience { get; set; }

        [JsonProperty("firmAverageRate")]
        public int? FirmAverageRate { get; set; }

        [JsonProperty("stateHourlyRate")]
        public int? StateHourlyRate { get; set; }

        [JsonProperty("annualStatementLOB")]
        public string AnnualStatementLob { get; set; }

        [JsonProperty("cspSubline")]
        public string CspSubline { get; set; }

        [JsonProperty("retroActiveDate")]
        public DateTime? RetroActiveDate { get; set; }

        [JsonProperty("extendedReportingPeriodDate")]
        public DateTime? ExtendedReportingPeriodDate { get; set; }

        [JsonProperty("deleteCode")]
        public string DeleteCode { get; set; }

        [JsonProperty("withinDefenseLimit")]
        public bool WithinDefenseLimit { get; set; }

        [JsonProperty("defenseCostLimit")]
        public decimal DefenseCostLimit { get; set; }

        [JsonProperty("defenseCostDeductible")]
        public decimal DefenseCostDeductible { get; set; }

        [JsonProperty("policyAggregateLimit")]
        public decimal? PolicyAggregateLimit { get; set; }

        [JsonProperty("ratableEmployees")]
        public int? RatableEmployees { get; set; }

        [JsonProperty("totalEmployees")]
        public int? TotalEmployees { get; set; }

        [JsonProperty("premises")]
        public int? Premises { get; set; }

        [JsonProperty("formCode")]
        public int? FormCode { get; set; }

        [JsonProperty("terrorismCoverageCode")]
        public string TerrorismCoverageCode { get; set; }

        [JsonProperty("rateGroup")]
        public int? RateGroup { get; set; }

        [JsonProperty("policyTypeCode")]
        public string PolicyTypeCode { get; set; }
    }
}
