﻿using Newtonsoft.Json;

namespace Models
{
 
    public class ProfessionalLiabilityClientIndustryModel
    {
        [JsonProperty("clientIndustryId")]
        public int ClientIndustryId { get; set; }

        [JsonProperty("modificationFactor")]
        public decimal ModificationFactor { get; set; }

        [JsonProperty("modificationFactorBasis")]
        public string ModificationFactorBasis { get; set; }
    }
}
