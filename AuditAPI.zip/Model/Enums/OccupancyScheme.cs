﻿namespace Models.Enums
{
    public enum OccupancyScheme
    {
        AIR,
        ATC,
        GLUK,
        ISOPROP,
        OWN,
        ISOGL,
    }
}
