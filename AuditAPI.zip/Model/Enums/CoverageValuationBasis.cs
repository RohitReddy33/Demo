﻿namespace Models.Enums
{
    public enum CoverageValuationBasis
    {
        RCV,
        ACV,
        FRC,
    }
}
