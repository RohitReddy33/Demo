﻿namespace Models.Enums
{
    public enum TypeOfVehicle
    {
        [System.Xml.Serialization.XmlEnumAttribute("1")]
        Item1,

        [System.Xml.Serialization.XmlEnumAttribute("1a")]
        Item1a,


        [System.Xml.Serialization.XmlEnumAttribute("1b")]
        Item1b,


        [System.Xml.Serialization.XmlEnumAttribute("1c")]
        Item1c,


        [System.Xml.Serialization.XmlEnumAttribute("1d")]
        Item1d,


        [System.Xml.Serialization.XmlEnumAttribute("1e")]
        Item1e,


        [System.Xml.Serialization.XmlEnumAttribute("2")]
        Item2,


        [System.Xml.Serialization.XmlEnumAttribute("3")]
        Item3,


        [System.Xml.Serialization.XmlEnumAttribute("3a")]
        Item3a,


        [System.Xml.Serialization.XmlEnumAttribute("3b")]
        Item3b,


        [System.Xml.Serialization.XmlEnumAttribute("3c")]
        Item3c,


        [System.Xml.Serialization.XmlEnumAttribute("4")]
        Item4,


        [System.Xml.Serialization.XmlEnumAttribute("4a")]
        Item4a,


        [System.Xml.Serialization.XmlEnumAttribute("4b")]
        Item4b,
    }
}
