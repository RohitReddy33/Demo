﻿namespace Models.Enums
{
    public enum TypeOfBusiness
    {
        OFFICE,
        TEACHER,
        SALES,
        OTHER,
    }
}
