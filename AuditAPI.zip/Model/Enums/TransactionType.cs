﻿namespace Models.Enums
{
    public enum TransactionType
    {
        ENQ,
        QTE,
        NEW,
        END,
        CAN,
        REI,
        EXT,
        RIV,
        BND
    };
}
