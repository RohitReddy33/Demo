﻿namespace Models.Enums
{
    public enum RentalTerm
    {
        NONE,
        ANNUAL,
        MONTHLY,
        WEEKLY,
        LESSTHANWEEK,
    }
}
