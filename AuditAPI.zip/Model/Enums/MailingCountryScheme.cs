﻿namespace Models.Enums
{
    public enum MailingCountryScheme
    {
        ISO2A,
        ISO3A,
        ISO3N,
        FIPS,
    }
}
