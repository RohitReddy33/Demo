﻿namespace Models.Enums
{
    public enum CancelMethod
    {
        F,
        P,
        S
    };
}

