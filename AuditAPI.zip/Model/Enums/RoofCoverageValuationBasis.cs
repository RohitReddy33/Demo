﻿namespace Models.Enums
{
    public enum RoofCoverageValuationBasis
    {
        RCV,
        ACV,
        FRC,
        EXC,
    }
}
