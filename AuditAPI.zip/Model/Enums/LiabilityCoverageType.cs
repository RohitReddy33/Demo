﻿namespace Models.Enums
{
    public enum LiabilityCoverageType
    {
        EL,
        MiscProfessionalLiability,
        CyberLiability,
        MedicalExpenses,
        ProductsCompletedOperations,
        OtherGL,
        Liability,
        PLLiability,
        AnimalLiability,
        PersonalAdvertisingInjury,
        SpecialLiabilites,
        ExtendedLiability,
        PremisesOperations,
        FireDamage,
        GeneralAggregate,
        EachOccurrence
    }
}
