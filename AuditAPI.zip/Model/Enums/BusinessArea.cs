﻿namespace Models.Enums
{
    public enum BusinessArea
    {
        AMIG,
        GLUK,
        LLoyds,
        Lloyds,
        UK,
        PESLIC,
    }
}
