﻿namespace Models.Enums
{
    public enum ConstructionScheme
    {
        AIR,
        AMIG,
        ATC,
        GLUK,
        ISOFIRE,
        MCHINE,
        OWN,
        RMS,
        TUSCANO,
    }
}
