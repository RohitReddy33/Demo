﻿namespace Models.Enums
{
    public enum TypeOfUpdate
    {
        FULL,
        PARTIAL,
    }
}
