﻿namespace Models.Enums
{
    public enum UtilityType
    {
        Wiring,
        Heating,
        Plumbing,
        Roof,
    }
}
