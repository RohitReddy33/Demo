﻿namespace Models.Enums
{
    public enum CountryScheme
    {
        ISO2A,
        ISO3A,
        ISO3N,
        FIPS,
    }
}
