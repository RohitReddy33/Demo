﻿namespace Models.Enums
{
    public enum StructuresRentedOffPremisesCoverage
    {
        INCLUDED,
        EXCLUDED,
    }

}
