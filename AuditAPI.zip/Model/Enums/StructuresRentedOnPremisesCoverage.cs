﻿namespace Models.Enums
{
    public enum StructuresRentedOnPremisesCoverage
    {
        INCLUDED,
        EXCLUDED,
    }
}
