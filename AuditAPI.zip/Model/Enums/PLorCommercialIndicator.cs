﻿namespace Models.Enums
{
    public enum PLorCommercialIndicator
    {
        PL,
        CL,
    }
}
