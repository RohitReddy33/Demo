﻿using Newtonsoft.Json.Converters;
using System.Text.Json.Serialization;

namespace Models.Enums
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum TransportationCoverageType
    {
        TempReplacementAuto,
        PollutantCleanUp,
        TowingStorageDebrisRemoval,
        ChainsTarps,
        DebrisRemoval,
        EarnedFreight,
        MiscEquip,
        FurtherDamagePreventionExpense,
        OnHook,
        TrailerInterchange,
        HiredVehicle,
        AnyOneLoss,
        AnyOneUnit,
    }
}
