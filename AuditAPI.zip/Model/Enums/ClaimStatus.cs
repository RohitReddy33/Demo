﻿namespace Models.Enums
{
    public enum ClaimStatus
    {
        O,
        C,
    }
}
