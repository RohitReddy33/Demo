﻿using Models.Enums;
using Newtonsoft.Json;

namespace Models
{
   public class TransportationCoverage:Coverage
    {
        [JsonProperty("transportationCoverageType")]
        public string TransportationCoverageType { get; set; }
    }
}
