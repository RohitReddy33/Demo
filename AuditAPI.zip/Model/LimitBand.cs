﻿using Newtonsoft.Json;

namespace Models
{
    public class LimitBand
    {
        [JsonProperty("from")]
        public decimal? From { get; set; }

        [JsonProperty("to")]
        public decimal? To { get; set; }

        [JsonProperty("unitCount")]
        public short? UnitCount { get; set; }

        [JsonProperty("deductibleAmount")]
        public decimal? DeductibleAmount { get; set; }
    }
}
