﻿using Newtonsoft.Json;

namespace Models
{
    public class InHomeDayCareCoverage
    {
        [JsonProperty("numberOfChildren")]
        public int NumberOfChildren { get; set; }

        [JsonProperty("dayCareLocatedInDwelling")]
        public bool DayCareLocatedInDwelling { get; set; }
    }
}
