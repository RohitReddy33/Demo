﻿using System.Collections.Generic;

namespace Models
{
    public class ValidationResult
    {
        public string Key { get; set; }
        public List<string> ErrorMessages { get; set; }
    }
}
