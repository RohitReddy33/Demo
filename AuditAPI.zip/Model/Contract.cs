﻿using Models.Enums;
using Newtonsoft.Json;

namespace Models
{
    public partial class Contract
    {
        [JsonProperty("sectionNo")]
        public string SectionNo { get; set; }
        
        [JsonProperty("contract")]
        public string ContractRef { get; set; }

        [JsonProperty("contractPeriod")]
        public int ContractPeriod { get; set; }

        [JsonProperty("commission")]
        public decimal? Commission { get; set; }

        [JsonProperty("contractPercentage")]
        public decimal? ContractPercentage { get; set; }

        [JsonProperty("liabilityPercentage")]
        public decimal? LiabilityPercentage { get; set; }

        [JsonProperty("equipmentBreakdownPercentage")]
        public decimal? EquipmentBreakdownPercentage { get; set; }
    }

}
