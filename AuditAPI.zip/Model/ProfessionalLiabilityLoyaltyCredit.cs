﻿using Newtonsoft.Json;

namespace Models
{
    public class ProfessionalLiabilityLoyaltyCreditModel
    {
        [JsonProperty("loyaltyCreditId")]
        public int LoyaltyCreditId { get; set; }

        [JsonProperty("modificationFactor")]
        public decimal ModificationFactor { get; set; }
    }
}
