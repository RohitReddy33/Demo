﻿using Models.Enums;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace Models
{
    public partial class BuildingRecord
    {
      
        [JsonProperty("buildingNumber")]
        public string BuildingNumber { get; set; }

        [JsonProperty("insuredStreet")]
        public string InsuredStreet { get; set; }

        [JsonProperty("insuredCity")]
        public string InsuredCity { get; set; }

        [JsonProperty("insuredCounty")]
        public string InsuredCounty { get; set; }

        [JsonProperty("insuredState")]
        public string InsuredState { get; set; }

        [JsonProperty("insuredZipCode")]
        public string InsuredZipCode { get; set; }

        [JsonProperty("insuredZipCodePlusFour")]
        public string InsuredZipCodePlusFour { get; set; }

        [JsonProperty("countryScheme")]
        public string CountryScheme { get; set; }

        [JsonProperty("coverageIsVandalismMischief")]
        public bool? CoverageIsVandalismMischief { get; set; }

        [JsonProperty("country")]
        public string Country { get; set; }

        [JsonProperty("occupancyScheme")]
        public string OccupancyScheme { get; set; }

        [JsonProperty("occupancyCode")]
        public string OccupancyCode { get; set; }

        [JsonProperty("dwellingType")]
        public string DwellingType { get; set; }

        [JsonProperty("buildingCharacteristics")]
        public BuildingCharacteristics BuildingCharacteristics { get; set; }

        [JsonProperty("propertyCoverages")]
        public List<PropertyCoverage> PropertyCoverages { get; set; }

        [JsonProperty("liabilityClasses")]
        public List<LiabilityClass> LiabilityClasses { get; set; }
    }
}
