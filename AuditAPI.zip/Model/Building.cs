﻿namespace Models
{
    public class Building
    {
        public string BuildingNumber { get; set; }
        public string InsuredStreet { get; set; }
        public string InsuredCity { get; set; }
        public string InsuredState { get; set; }
        public string InsuredZipCode { get; set; }
        public string Country { get; set; }
        public decimal? YearBuilt { get; set; }
        public int? NumberofStories { get; set; }
        public decimal? Squarefootage { get; set; }
        public string FloodZone { get; set; }
        public string RoofConstructionScheme { get; set; }
        public decimal? RoofConstructionCode { get; set; }
        public string RoofShapeScheme { get; set; }
        public decimal? RoofShapeCode { get; set; }
        public decimal? RoofLastUpdated { get; set; }
        public decimal? WiringLastUpdated { get; set; }
        public decimal? PlumbingLastUpdated { get; set; }
        public decimal? HeatingLastUpdated { get; set; }
        public string InsuredCounty { get; set; }
        public string InsuredCountryScheme { get; set; }
        public string InsuredCountryCode { get; set; }
        public decimal? GrossPremium { get; set; }
        public decimal? TotalPropertyPremium { get; set; }
        public decimal? TotalPropertyLimit { get; set; }
        public decimal? PropertyPremium { get; set; }
        public decimal? PropertyLimit { get; set; }
        public decimal? PropertyPremiumB { get; set; }
        public decimal? PropertyLimitB { get; set; }
        public decimal? LimitBuildingCoverageA { get; set; }
        public decimal? LimitContentsCoverageC { get; set; }
        public decimal? LimitBusinessInterruptionCoverageD { get; set; }
        public decimal? LimitOtherCoverageB { get; set; }
        public decimal? LimitCoverageE { get; set; }
        public decimal? Rate { get; set; }
        public decimal? Aopdeductible { get; set; }
        public decimal? WindLimit { get; set; }
        public decimal? WindHailHurricaneDeductible { get; set; }
        public decimal? Catdeductible { get; set; }
        public decimal? QuakeLimit { get; set; }
        public decimal? QuakeDeductible { get; set; }
        public decimal? FloodLimit { get; set; }
        public decimal? FloodDeductible { get; set; }
        public decimal? Impremium { get; set; }
        public decimal? InlandMarineLimit { get; set; }
        public decimal? CrimeLimit { get; set; }
        public decimal? CrimePremium { get; set; }
        public decimal? CrimeDeductible { get; set; }
        public int? CrimeInsuranceAgreement { get; set; }
        public decimal? CrimeRate { get; set; }
        public string EquipmentBreakdown { get; set; }
        public decimal? EquipmentBreakdownPremium { get; set; }
        public decimal? TerrorismPremium { get; set; }
        public decimal? Triprapremium { get; set; }
        public decimal? Tivfgu { get; set; }
        public double? CdmatchPercentage { get; set; }
    }
}
