﻿using Models.Enums;
using Newtonsoft.Json;
using System;

namespace Models
{
    public class PriorLoss
    {
        [JsonProperty("dateOfLoss")]
        public DateTime? DateOfLoss { get; set; }

        [JsonProperty("causeOfLoss")]
        public string CauseOfLoss { get; set; }

        [JsonProperty("claimStatus")]
        public string ClaimStatus { get; set; }

        [JsonProperty("totalIncurred")]
        public decimal? TotalIncurred { get; set; }
    }

}
