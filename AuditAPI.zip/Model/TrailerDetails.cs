﻿using Newtonsoft.Json;

namespace Models
{
    public partial class TrailerDetails
    {
        [JsonProperty("typeOfTrailer")]
        public string TypeOfTrailer { get; set; }

        [JsonProperty("vin")]
        public string Vin { get; set; }

        [JsonProperty("make")]
        public string Make { get; set; }

        [JsonProperty("model")]
        public string Model { get; set; }

        [JsonProperty("year")]
        public int Year { get; set; }

        [JsonProperty("acv")]
        public decimal? Acv { get; set; }

        [JsonProperty("nonOwnedTrailer")]
        public bool? NonOwnedTrailer { get; set; }
    }
}
