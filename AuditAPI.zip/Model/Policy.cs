﻿using System;
using System.Collections.Generic;

namespace Models
{
    public class Policy
    {
        public string RecordUniqueIdentifier { get; set; }
        public string PolicyNumber { get; set; }
        public string EndorsementNumber { get; set; }
        public decimal? ContractShare { get; set; }
        public decimal? LiabilityShare { get; set; }
        public decimal? EquipmentBreakdownShare { get; set; }
        public string TransactionType { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public DateTime? AccountingEffectiveDate { get; set; }
        public decimal? PropertyPremium { get; set; }
        public decimal? LiabilityPremium { get; set; }
        public decimal? EquipmentBreakdownPremium { get; set; }
        public decimal? GrossPremium { get; set; }
        public decimal? Commission { get; set; }
        public decimal? NetPremium { get; set; }
        public string InvoiceNumber { get; set; }
        public List<Location> Locations { get; set; }
        public List<Transportation> Transportations { get; set; }

    }
}
