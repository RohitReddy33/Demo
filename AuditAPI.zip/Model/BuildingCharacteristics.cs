﻿using Models.Enums;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace Models
{
    public partial class BuildingCharacteristics
    {

        [JsonProperty("isMobileHome")]
        public bool? IsMobileHome { get; set; }

        [JsonProperty("isVacant")]
        public bool? IsVacant { get; set; }

        [JsonProperty("isBuildersRisk")]
        public bool? IsBuildersRisk { get; set; }

        [JsonProperty("hasConcreteBasement")]
        public bool? HasConcreteBasement { get; set; }

        [JsonProperty("hasMortaredBlockFoundation")]
        public bool? HasMortaredBlockFoundation { get; set; }

        [JsonProperty("hasStiltsOverWater")]
        public bool? HasStiltsOverWater { get; set; }

        [JsonProperty("firstFloorHeightAboveGround")]
        public decimal? FirstFloorHeightAboveGround { get; set; }

        [JsonProperty("flFoundationType")]
        public int? FlFoundationType { get; set; }

        [JsonProperty("mgaLatitude")]
        public double? MgaLatitude { get; set; }

        [JsonProperty("mgaLongitude")]
        public double? MgaLongitude { get; set; }

        [JsonProperty("mgaDistanceToCoastMiles")]
        public double? MgaDistanceToCoastMiles { get; set; }

        [JsonProperty("isoPropertyCode")]
        public string IsoPropertyCode { get; set; }

        [JsonProperty("constructionScheme")]
        public string ConstructionScheme { get; set; }

        [JsonProperty("constructionCode")]
        public string ConstructionCode { get; set; }

        [JsonProperty("rentalTerm")]
        public string RentalTerm { get; set; }

        [JsonProperty("protectionClass")]
        public string ProtectionClass { get; set; }

        [JsonProperty("protections")]
        public string Protections { get; set; }

        [JsonProperty("centralFireProtection")]
        public bool? CentralFireProtection { get; set; }

        [JsonProperty("centralBurglarProtection")]
        public bool? CentralBurglarProtection { get; set; }

        [JsonProperty("localFireProtection")]
        public bool? LocalFireProtection { get; set; }

        [JsonProperty("localBurglarProtection")]
        public bool? LocalBurglarProtection { get; set; }

        [JsonProperty("policeStationBurglarAlarmProtection")]
        public bool? PoliceStationBurglarAlarmProtection { get; set; }

        [JsonProperty("fireStationAlarmProtection")]
        public bool? FireStationAlarmProtection { get; set; }

        [JsonProperty("smokeDetectorsProtection")]
        public bool? SmokeDetectorsProtection { get; set; }

        [JsonProperty("sprinklersProtection")]
        public bool? SprinklersProtection { get; set; }

        [JsonProperty("waterShutOffValveProtection")]
        public bool? WaterShutOffValveProtection { get; set; }

        [JsonProperty("waterShutOffWithAlarmProtection")]
        public bool? WaterShutOffWithAlarmProtection { get; set; }

        [JsonProperty("gatedCommunityProtection")]
        public bool? GatedCommunityProtection { get; set; }

        [JsonProperty("stormShuttersProtection")]
        public bool? StormShuttersProtection { get; set; }

        [JsonProperty("impactResistantGlassProtection")]
        public bool? ImpactResistantGlassProtection { get; set; }

        [JsonProperty("fireExtinguisherProtection")]
        public bool? FireExtinguisherProtection { get; set; }

        [JsonProperty("ansulProtection")]
        public bool? AnsulProtection { get; set; }

        [JsonProperty("openingProtectionsCode")]
        public string OpeningProtectionsCode { get; set; }

        [JsonProperty("openingProtectionTypesCode")]
        public string OpeningProtectionTypesCode { get; set; }

        [JsonProperty("yearBuilt")]
        public decimal? YearBuilt { get; set; }

        [JsonProperty("numberOfStories")]
        public int? NumberOfStories { get; set; }

        [JsonProperty("squareFootage")]
        public decimal? SquareFootage { get; set; }

        [JsonProperty("floodZone")]
        public string FloodZone { get; set; }

        [JsonProperty("roofConstruction")]
        public string RoofConstruction { get; set; }

        [JsonProperty("roofConstructionCode")]
        public decimal? RoofConstructionCode { get; set; }

        [JsonProperty("roofShowsSignsOfDeterioration")]
        public bool? RoofShowsSignsOfDeterioration { get; set; }

        [JsonProperty("shapeOfRoof")]
        public decimal? ShapeOfRoof { get; set; }

        [JsonProperty("utilityUpdates")]
        public List<UtilityUpdate> UtilityUpdates { get; set; }

        [JsonProperty("roofAnchorCode")]
        public string RoofAnchorCode { get; set; }

        [JsonProperty("roofSheathingCode")]
        public string RoofSheathingCode { get; set; }

        [JsonProperty("primaryHeatSourceCode")]
        public string PrimaryHeatSourceCode { get; set; }

        [JsonProperty("alternateHeatSourceCode")]
        public string AlternateHeatSourceCode { get; set; }

        [JsonProperty("basementType")]
        public string BasementType { get; set; }

        [JsonProperty("grossPremium")]
        public decimal? GrossPremium { get; set; }

        [JsonProperty("crimeInsuranceAct")]
        public int? CrimeInsuranceAct { get; set; }

        [JsonProperty("equipmentBreakdown")]
        public string EquipmentBreakdown { get; set; }

        [JsonProperty("homeSystemsProtection")]
        public string HomeSystemsProtection { get; set; }

        [JsonProperty("serviceLine")]
        public string ServiceLine { get; set; }

        [JsonProperty("totalInsuredValueFromtheGroundUp")]
        public decimal? TotalInsuredValueFromtheGroundUp { get; set; }

        [JsonProperty("roofCoverage")]
        public bool? RoofCoverage { get; set; }

        [JsonProperty("roofCoverageValuationBasis")]
        public string RoofCoverageValuationBasis { get; set; }

        [JsonProperty("numberOfAcres")]
        public double? NumberOfAcres { get; set; }

        [JsonProperty("townHouse")]
        public bool? TownHouse { get; set; }

        [JsonProperty("forSale")]
        public bool? ForSale { get; set; }

        [JsonProperty("historicRegistry")]
        public bool? HistoricRegistry { get; set; }

        [JsonProperty("newPurchase")]
        public bool? NewPurchase { get; set; }

        [JsonProperty("eqBaseIsolation")]
        public int? EqBaseIsolation { get; set; }

        [JsonProperty("eqCladdingType")]
        public int? EqCladdingType { get; set; }

        [JsonProperty("eqConstructionQuality")]
        public int? EqConstructionQuality { get; set; }

        [JsonProperty("eqEquipmentSupportMaintenance")]
        public int? EqEquipmentSupportMaintenance { get; set; }

        [JsonProperty("eqEngineeredFoundation")]
        public int? EqEngineeredFoundation { get; set; }

        [JsonProperty("eqSprinklerLeakageSusceptibility")]
        public int? EqSprinklerLeakageSusceptibility { get; set; }

        [JsonProperty("eqFrameBolted")]
        public int? EqFrameBolted { get; set; }

        [JsonProperty("eqUnreinforcedMasonryPartitionsorChimneys")]
        public int? EqUnreinforcedMasonryPartitionsorChimneys { get; set; }

        [JsonProperty("eqMechanicalandElectricalEquipmentEarthquakeBracing")]
        public int? EqMechanicalandElectricalEquipmentEarthquakeBracing { get; set; }

        [JsonProperty("eqAppendagesandOrnamentation")]
        public int? EqAppendagesandOrnamentation { get; set; }

        [JsonProperty("eqVerticalIrregularity")]
        public int? EqVerticalIrregularity { get; set; }

        [JsonProperty("eqPounding")]
        public int? EqPounding { get; set; }

        [JsonProperty("eqPlanIrregularity")]
        public int? EqPlanIrregularity { get; set; }

        [JsonProperty("eqShortColumnCondition")]
        public int? EqShortColumnCondition { get; set; }

        [JsonProperty("eqSprinklerType")]
        public int? EqSprinklerType { get; set; }

        [JsonProperty("eqSoftStory")]
        public int? EqSoftStory { get; set; }

        [JsonProperty("eqStructuralUpgrade")]
        public int? EqStructuralUpgrade { get; set; }

        [JsonProperty("eqTiltUpRetrofit")]
        public int? EqTiltUpRetrofit { get; set; }

        [JsonProperty("eqUnreinforcedMasonryRetrofit")]
        public int? EqUnreinforcedMasonryRetrofit { get; set; }

        [JsonProperty("eqCrippleWalls")]
        public int? EqCrippleWalls { get; set; }

        [JsonProperty("eqSprinklerLeakageCoverageFlag")]
        public string EqSprinklerLeakageCoverageFlag { get; set; }

        [JsonProperty("hasTrampoline")]
        public bool? HasTrampoline { get; set; }

        [JsonProperty("hasSwimmingPool")]
        public bool? HasSwimmingPool { get; set; }

        [JsonProperty("hasSolarPanels")]
        public bool? HasSolarPanels { get; set; }

        [JsonProperty("hasMultipleRoofingLayers")]
        public bool? HasMultipleRoofingLayers { get; set; }

        [JsonProperty("dwellingType")]
        public string DwellingType { get; set; }
    }
}
