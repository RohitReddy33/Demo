﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Models
{
    public class Location
    {
        public int LocationNumber { get; set; }
        public List<Building> Buildings { get; set; }     
    }
}
