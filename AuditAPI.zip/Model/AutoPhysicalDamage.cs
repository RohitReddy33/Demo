﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Models
{
    public class AutoPhysicalDamage
    {
       
        [JsonProperty("anyOneCombination")]
        public decimal? AnyOneCombination { get; set; }

        [JsonProperty("apdCommodities")]
        public List<ApdCommodity> ApdCommodities { get; set; }

        [JsonProperty("avgValueInATerminal")]
        public decimal? AvgValueInATerminal { get; set; }

        [JsonProperty("dotNumber")]
        public string DotNumber { get; set; }

        [JsonProperty("premiumAmount")]
        public decimal? PremiumAmount { get; set; }

        [JsonProperty("mcNumber")]
        public string McNumber { get; set; }

        [JsonProperty("noOfUnits")]
        public int? NoOfUnits { get; set; }

        [JsonProperty("radiusOfUse")]
        public double? RadiusOfUse { get; set; }

        [JsonProperty("totalActualCashValueOfScheduledItems")]
        public int? TotalActualCashValueOfScheduledItems { get; set; }

        [JsonProperty("yearsInBusiness")]
        public int? YearsInBusiness { get; set; }

        [JsonProperty("vehicles")]
        public List<VehicleDetails> Vehicles { get; set; }

        [JsonProperty("trailers")]
        public List<TrailerDetails> Trailers { get; set; }

        [JsonProperty("CargoCommodity")]
        public List<CargoCommodity> CargoCommodity { get; set; }

        [JsonProperty("limitAmount")]
        public decimal? LimitAmount { get; set; }

        [JsonProperty("yearofOldestPowerUnit")]
        public int? YearofOldestPowerUnit { get; set; }

        [JsonProperty("highestValuedPowerUnit")]
        public decimal? HighestValuedPowerUnit { get; set; }

        [JsonProperty("highestValuedTrailer")]
        public decimal? HighestValuedTrailer { get; set; }

        [JsonProperty("apdacvUnitBanding")]
        public List<LimitBand> ApdacvUnitBanding { get; set; }

        [JsonProperty("trailerInterchange")]
        public TrailerInterchange TrailerInterchange { get; set; }

        [JsonProperty("hiredVehicle")]
        public HiredVehicle HiredVehicle { get; set; }

        [JsonProperty("driversOutsideCriteria")]
        public bool? DriversOutsideCriteria { get; set; }

        [JsonProperty("transportationCoverages")]
        public List<TransportationCoverage> TransportationCoverages { get; set; }

        [JsonProperty("totalWrittenOffOnEndorsement")]
        public decimal? TotalWrittenOffOnEndorsement { get; set; }
    }
}
