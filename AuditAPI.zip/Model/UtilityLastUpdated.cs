﻿using Models.Enums;
using Newtonsoft.Json;

namespace Models
{
    public partial class UtilityLastUpdated
    {
        [JsonProperty("utilityType")]
        public UtilityType UtilityType { get; set; }

        [JsonProperty("year")]
        public int Year { get; set; }

        [JsonProperty("typeOfUpdate")]
        public TypeOfUpdate TypeOfUpdate { get; set; }
    }
}
