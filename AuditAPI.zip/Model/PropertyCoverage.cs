﻿using Models.Enums;
using Newtonsoft.Json;

namespace Models
{
    public partial class PropertyCoverage: Coverage
    {
        [JsonProperty("propertyCoverageType")]
        public string PropertyCoverageType { get; set; }

        [JsonProperty("coverageValuationBasis")]
        public string CoverageValuationBasis { get; set; }

    }
}
