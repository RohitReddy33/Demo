﻿using Models.Validators;
using System;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace Models
{
    [DataContract]
    public class MonthlyRiskRequest
    {
        [DataMember]
        [DataType(DataType.Date)]
        [CustomDateValidator(ErrorMessage = "Please give valid accounting effective date.")]
        public DateTime? AccountingEffectiveDate { get; set; }

        [DataMember]
        [Required(AllowEmptyStrings = false, ErrorMessage = "Please give valid contract reference.")]
        public string ContractRef { get; set; }

        [DataMember]
        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Please give valid contract year.")]
        public int ContractYear { get; set; }

        [JsonIgnore]
        public int CompanyId { get; set; }
       

    }
}
