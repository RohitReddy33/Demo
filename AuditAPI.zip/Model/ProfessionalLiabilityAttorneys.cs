﻿using Newtonsoft.Json;

namespace Models
{
    public class ProfessionalLiabilityAttorneys
    {
        [JsonProperty("attorneyHoursID")]
        public int AttorneyHoursId { get; set; }

        [JsonProperty("attorneys")]
        public int Attorneys { get; set; }
    }
}
