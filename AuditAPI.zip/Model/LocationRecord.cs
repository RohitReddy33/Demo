﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Models
{
    public class LocationRecord
    {
        [JsonProperty("locationNumber")]
        public int LocationNumber { get; set; }

        [JsonProperty("buildings")]
        public List<BuildingRecord> Buildings { get; set; }

        [JsonProperty("liabilityClasses")]
        public List<LiabilityClass> LiabilityClasses { get; set; }

        [JsonProperty("professionalLiabilityClassLawyers")]
        public List<ProfessionalLiabilityClassLawyer> ProfessionalLiabilityClassLawyers { get; set; }

        [JsonProperty("taxesFeesAndSurcharges")]
        public List<TaxFeeAndSurcharge> TaxesFeesAndSurcharges { get; set; }

        [JsonProperty("dealersOpenLot")]
        public PolicyRecord DealersOpenLot { get; set; }

        [JsonProperty("premiumAmount")]
        public decimal? PremiumAmount { get; set; }

        [JsonProperty("elPremiumExcIPT")]
        public double? ElPremiumExcIpt { get; set; }

        [JsonProperty("plPremiumExcIPT")]
        public double? PlPremiumExcIpt { get; set; }

        [JsonProperty("limitAmount")]
        public double? LimitAmount { get; set; }
    }

}
