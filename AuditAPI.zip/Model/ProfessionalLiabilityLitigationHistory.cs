﻿using Newtonsoft.Json;

namespace Models
{
    public class ProfessionalLiabilityLitigationHistoryModel
    {
        [JsonProperty("litigationHistoryId")]
        public int LitigationHistoryId { get; set; }

        [JsonProperty("modificationFactor")]
        public decimal ModificationFactor { get; set; }
    }

}
