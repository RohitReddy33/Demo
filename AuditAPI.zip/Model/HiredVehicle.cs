﻿using Newtonsoft.Json;

namespace Models
{
    public partial class HiredVehicle
    {
        [JsonProperty("limitAmount")]
        public decimal? LimitAmount { get; set; }

        [JsonProperty("isReplacementOfScheduledUnit")]
        public bool? IsReplacementOfScheduledUnit { get; set; }

        [JsonProperty("rentedAdditionalUnitsFrequency")]
        public string RentedAdditionalUnitsFrequency { get; set; }

        [JsonProperty("noOfConcurrentUnitsRented")]
        public int? NoOfConcurrentUnitsRented { get; set; }

        [JsonProperty("annualCostOfRentals")]
        public decimal? AnnualCostOfRentals { get; set; }
    }
}
