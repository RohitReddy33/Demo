﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Models
{
    public class DealersOpenLot
    {
        [JsonProperty("avgNoOfUnits")]
        public int? AvgNoOfUnits { get; set; }

        [JsonProperty("avgValuePerUnit")]
        public decimal? AvgValuePerUnit { get; set; }

        [JsonProperty("maxValuePerUnit")]
        public decimal? MaxValuePerUnit { get; set; }

        [JsonProperty("maxNoOfUnits")]
        public int? MaxNoOfUnits { get; set; }

        [JsonProperty("natureOfLocations")]
        public int? NatureOfLocations { get; set; }

        [JsonProperty("typeOfUnits")]
        public int? TypeOfUnits { get; set; }

        [JsonProperty("yearsInBusiness")]
        public int? YearsInBusiness { get; set; }

        [JsonProperty("radiusOfUse")]
        public int? RadiusOfUse { get; set; }

        [JsonProperty("anyOneUnit")]
        public decimal? AnyOneUnit { get; set; }

        [JsonProperty("transportationCoverages")]
        public List<TransportationCoverage> TransportationCoverages { get; set; }
    }
}
