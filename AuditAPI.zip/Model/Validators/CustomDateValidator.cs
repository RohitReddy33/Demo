﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Models.Validators
{
    public class CustomDateValidator : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            if (value == null)
                return false;

            Type t = value.GetType();
            if (t.Equals(typeof(DateTime?)))
            {
                if (DateTime.TryParse(value.ToString(), out DateTime Temp) == false)
                    return false;
            }            
            return true;
        }       
    }
}
