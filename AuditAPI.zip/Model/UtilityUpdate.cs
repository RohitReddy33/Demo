﻿using Newtonsoft.Json;

namespace Models
{
    public class UtilityUpdate
    {
        [JsonProperty("utilityType")]
        public string UtilityType { get; set; }
        
        [JsonProperty("year")]
        public decimal? Year { get; set; }

        [JsonProperty("avgValuePerShipment")]
        public string TypeOfUpdate { get; set; }
    }
}
