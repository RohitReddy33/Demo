﻿using Newtonsoft.Json;

namespace Models
{
    public partial class TrailerInterchange
    {
        [JsonProperty("limitAmount")]
        public decimal? LimitAmount { get; set; }

        [JsonProperty("estimatedTrailerDays")]
        public int? EstimatedTrailerDays { get; set; }

        [JsonProperty("noOfPowerUnits")]
        public int? NoOfPowerUnits { get; set; }

        [JsonProperty("deductibleAmount")]
        public decimal? DeductibleAmount { get; set; }

        [JsonProperty("premiumAmount")]
        public decimal? PremiumAmount { get; set; }
    }
}
