﻿using Newtonsoft.Json;

namespace Models
{
    public class ProfessionalLiabilityContinuingLegalEducationModel
    {

        [JsonProperty("continuingLegalEducationId")]
        public int ContinuingLegalEducationId { get; set; }

        [JsonProperty("modificationFactor")]
        public decimal ModificationFactor { get; set; }
    }
}
