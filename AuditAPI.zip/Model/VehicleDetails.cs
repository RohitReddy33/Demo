﻿using Models.Enums;
using Newtonsoft.Json;

namespace Models
{
    public partial class VehicleDetails
    {
        [JsonProperty("type")]
        public string[] Type { get; set; }

        [JsonProperty("typeOfVehicle")]
        public string TypeOfVehicle { get; set; }

        [JsonProperty("vin")]
        public string Vin { get; set; }

        [JsonProperty("make")]
        public string Make { get; set; }

        [JsonProperty("model")]
        public string Model { get; set; }

        [JsonProperty("year")]
        public decimal? Year { get; set; }

        [JsonProperty("acv")]
        public decimal? Acv { get; set; }
    }
}
