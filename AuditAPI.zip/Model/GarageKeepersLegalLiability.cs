﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Models
{
    public class GarageKeepersLegalLiability
    {
        [JsonProperty("avgNoOfUnits")]
        public int? AvgNoOfUnits { get; set; }

        [JsonProperty("avgValuePerUnit")]
        public decimal? AvgValuePerUnit { get; set; }

        [JsonProperty("premiumAmount")]
        public decimal? PremiumAmount { get; set; }

        [JsonProperty("maxNoOfUnits")]
        public int? MaxNoOfUnits { get; set; }

        [JsonProperty("natureOfLocations")]
        public int? NatureOfLocations { get; set; }

        [JsonProperty("natureOfTrade")]
        public int? NatureOfTrade { get; set; }

        [JsonProperty("noOfWreckerTowingUnits")]
        public int? NoOfWreckerTowingUnits { get; set; }

        [JsonProperty("limitAmount")]
        public decimal? LimitAmount { get; set; }

        [JsonProperty("typeOfLiability")]
        public int? TypeOfLiability { get; set; }

        [JsonProperty("yearsInBusiness")]
        public int? YearsInBusiness { get; set; }

        [JsonProperty("transportationCoverages")]
        public List<TransportationCoverage> TransportationCoverages { get; set; }
    }
}
