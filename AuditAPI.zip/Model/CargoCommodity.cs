﻿using Newtonsoft.Json;

namespace Models
{
    public partial class CargoCommodity
    {
        [JsonProperty("cargoCommodityScheme")]
        public string CargoCommodityScheme { get; set; }

        [JsonProperty("cargoCommodityType")]
        public int? CargoCommodityType { get; set; }

        [JsonProperty("cargoCommodityPercentage")]
        public decimal? CargoCommodityPercentage { get; set; }
    }
}
