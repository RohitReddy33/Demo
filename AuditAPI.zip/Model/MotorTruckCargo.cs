﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Models
{
    public partial class MotorTruckCargo
    {
        [JsonProperty("avgValuePerShipment")]
        public decimal? AvgValuePerShipment { get; set; }

        [JsonProperty("cargoCommodities")]
        public List<CargoCommodity> CargoCommodities { get; set; }

        [JsonProperty("dotNumber")]
        public string DotNumber { get; set; }

        [JsonProperty("premiumAmount")]
        public decimal? PremiumAmount { get; set; }

        [JsonProperty("mcNumber")]
        public string McNumber { get; set; }

        [JsonProperty("noOfUnits")]
        public int? NoOfUnits { get; set; }

        [JsonProperty("radiusOfUse")]
        public int? RadiusOfUse { get; set; }

        [JsonProperty("totalValueAtAnyOneTerminal")]
        public decimal? TotalValueAtAnyOneTerminal { get; set; }

        [JsonProperty("typeOfCarrier")]
        public int? TypeOfCarrier { get; set; }

        [JsonProperty("yearsInBusiness")]
        public int YearsInBusiness { get; set; }

        [JsonProperty("vehicles")]
        public List<VehicleDetails> Vehicles { get; set; }

        [JsonProperty("limitAmount")]
        public decimal? LimitAmount { get; set; }

        [JsonProperty("transportationCoverages")]
        public List<TransportationCoverage> TransportationCoverages { get; set; }

        [JsonProperty("driversOutsideCriteria")]
        public bool? DriversOutsideCriteria { get; set; }

        [JsonProperty("anyOneLoss")]
        public decimal? AnyOneLoss { get; set; }

        [JsonProperty("anyOneUnit")]
        public decimal? AnyOneUnit { get; set; }

        [JsonProperty("trailerInterchange")]
        public TrailerInterchange TrailerInterchange { get; set; }

        [JsonProperty("totalWrittenOffOnEndorsement")]
        public decimal? TotalWrittenOffOnEndorsement { get; set; }
    }
}
