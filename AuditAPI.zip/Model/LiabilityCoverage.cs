﻿using Models.Enums;
using Newtonsoft.Json;

namespace Models
{
    public partial class LiabilityCoverage
    {
      
        [JsonProperty("premiumAmount")]
        public decimal? PremiumAmount { get; set; }

        [JsonProperty("limitAmount")]
        public decimal? LimitAmount { get; set; }

        [JsonProperty("deductibleAmount")]
        public decimal? DeductibleAmount { get; set; }

        [JsonProperty("rate")]
        public decimal? Rate { get; set; }

        [JsonProperty("coverageForm")]
        public decimal? CoverageForm { get; set; }

        [JsonProperty("transportationCoverageType", NullValueHandling = NullValueHandling.Ignore)]
        public string TransportationCoverageType { get; set; }

        [JsonProperty("liabilityCoverageType", NullValueHandling = NullValueHandling.Ignore)]
        public string LiabilityCoverageType { get; set; }

    }
}
