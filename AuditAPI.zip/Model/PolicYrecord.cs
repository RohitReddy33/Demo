﻿using Models.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace Models
{
    public class PolicyRecord
    {
        [JsonProperty("recordUniqueIdentifier")]
        public string RecordUniqueIdentifier { get; set; }

        [JsonProperty("ratingSessionID")]
        public string RatingSessionId { get; set; }

        [JsonProperty("parentRUI")]
        public string ParentRui { get; set; }

        [JsonProperty("pricingEngineID")]
        public string PricingEngineId { get; set; }

        [JsonProperty("pricingEngineQuoteEnquiryID")]
        public string PricingEngineQuoteEnquiryId { get; set; }

        [JsonProperty("insuredEntityID")]
        public string InsuredEntityId { get; set; }

        [JsonProperty("invoiceNumber")]
        public string InvoiceNumber { get; set; }

        [JsonProperty("accountingEffectiveDate")]
        public DateTime? AccountingEffectiveDate { get; set; }

        [JsonProperty("transactionType")]
        public string TransactionType { get; set; }
        //public TransactionType TransactionType { get; set; }
        [JsonProperty("cedingCoNameRetailAgent")]
        public string CedingCoNameRetailAgent { get; set; }
        [JsonProperty("transactionReasonCode")]
        public string TransactionReasonCode { get; set; }

        [JsonProperty("cancelMethod")]
        public string CancelMethod { get; set; }
        //public CancelMethod CancelMethod { get; set; }

        [JsonProperty("businessArea")]
        public string BusinessArea { get; set; }
        //public BusinessArea? BusinessArea { get; set; }

        [JsonProperty("subCompanyID")]
        public int? SubCompanyId { get; set; }

        [JsonProperty("insuredName")]
        public string InsuredName { get; set; }

        [JsonProperty("insuredDoingBusinessAs")]
        public string InsuredDoingBusinessAs { get; set; }

        [JsonProperty("additionalNamedInsured")]
        public string AdditionalNamedInsured { get; set; }

        [JsonProperty("certificateNumber")]
        public string CertificateNumber { get; set; }

        [JsonProperty("policyNumber")]
        public string PolicyNumber { get; set; }

        [JsonProperty("endorsementNumber")]
        public string EndorsementNumber { get; set; }

        [JsonProperty("expiringPolicyNumber")]
        public string ExpiringPolicyNumber { get; set; }

        [JsonProperty("pLorCommercialIndicator")]
        public string PLorCommercialIndicator { get; set; }
        //public PLorCommercialIndicator PLorCommercialIndicator { get; set; }

        [JsonProperty("coverageForm")]
        public decimal? CoverageForm { get; set; }

        [JsonProperty("placementType")]
        public decimal? PlacementType { get; set; }

        [JsonProperty("coInsurancePercentage")]
        public decimal? CoInsurancePercentage { get; set; }

        [JsonProperty("hereOnPercentage")]
        public decimal? HereOnPercentage { get; set; }

        [JsonProperty("cancellationCode")]
        public int? CancellationCode { get; set; }


        [JsonProperty("totalPropertyLimit")]
        public decimal TotalPropertyLimit { get; set; }

        [JsonProperty("effectiveDate")]
        public DateTime? EffectiveDate { get; set; }

        [JsonProperty("expiryDate")]
        public DateTime? ExpiryDate { get; set; }

        [JsonProperty("mailingStreet")]
        public string MailingStreet { get; set; }

        [JsonProperty("mailingCity")]
        public string MailingCity { get; set; }

        [JsonProperty("mailingCounty")]
        public string MailingCounty { get; set; }

        [JsonProperty("mailingState")]
        public string MailingState { get; set; }

        [JsonProperty("mailingZipCode")]
        public string MailingZipCode { get; set; }

        [JsonProperty("mailingZipCodePlusFour")]
        public string MailingZipCodePlusFour { get; set; }

        [JsonProperty("mailingCountryScheme")]
        public string MailingCountryScheme { get; set; }
        //public MailingCountryScheme? MailingCountryScheme { get; set; }

        [JsonProperty("mailingCountry")]
        public string MailingCountry { get; set; }

        [JsonProperty("grossPremium")]
        public decimal? GrossPremium { get; set; }

        [JsonProperty("netCommission")]
        public decimal? NetCommission { get; set; }

        [JsonProperty("netPremium")]
        public decimal? NetPremium { get; set; }

        [JsonProperty("payable")]
        public string Payable { get; set; }

        [JsonProperty("fullTermPremiumChange")]
        public decimal? FullTermPremiumChange { get; set; }

        [JsonProperty("minimumPropertyAdjustmentPremium")]
        public decimal? MinimumPropertyAdjustmentPremium { get; set; }

        [JsonProperty("minimumCrimeAdjustmentPremium")]
        public decimal? MinimumCrimeAdjustmentPremium { get; set; }

        [JsonProperty("minFloodDeductible")]
        public decimal? MinFloodDeductible { get; set; }

        [JsonProperty("crimeInsuranceAct")]
        public int? CrimeInsuranceAct { get; set; }

        [JsonProperty("identityTheftRecovery")]
        public string IdentityTheftRecovery { get; set; }

        [JsonProperty("totalInsuredValueFromtheGroundUp")]
        public decimal? TotalInsuredValueFromtheGroundUp { get; set; }

        [JsonProperty("attachmentPoint")]
        public decimal? AttachmentPoint { get; set; }

        [JsonProperty("sizeofLayer")]
        public string SizeofLayer { get; set; }

        [JsonProperty("glAggregateLimit")]
        public decimal? GlAggregateLimit { get; set; }

        [JsonProperty("liabilityClasses")]
        public List<LiabilityClass> LiabilityClasses { get; set; }

        [JsonProperty("surveyFees")]
        public decimal? SurveyFees { get; set; }

        [JsonProperty("sltBrokerNumber")]
        public string SltBrokerNumber { get; set; }

        [JsonProperty("sltBrokerName")]
        public string SltBrokerName { get; set; }

        [JsonProperty("sltBrokerAddress")]
        public string SltBrokerAddress { get; set; }

        [JsonProperty("sltState")]
        public string SltState { get; set; }

        [JsonProperty("surplusLinesTransactionNumber")]
        public string SurplusLinesTransactionNumber { get; set; }

        [JsonProperty("naic")]
        public string Naic { get; set; }

        [JsonProperty("cedingCompanyNameRetailAgent")]
        public string CedingCompanyNameRetailAgent { get; set; }

        [JsonProperty("locations")]
        public List<LocationRecord> Locations { get; set; }

        [JsonProperty("autoPhysicalDamage")]
        public AutoPhysicalDamage AutoPhysicalDamage { get; set; }

        [JsonProperty("dealersOpenLot")]
        public DealersOpenLot DealersOpenLot { get; set; }

        [JsonProperty("garageKeepersLegalLiability")]
        public GarageKeepersLegalLiability GarageKeepersLegalLiability { get; set; }

        [JsonProperty("motorTruckCargo")]
        public MotorTruckCargo MotorTruckCargo { get; set; }

        [JsonProperty("contracts")]
        public List<Contract> Contracts { get; set; }

        [JsonProperty("policyProcessorSystemName")]
        public string PolicyProcessorSystemName { get; set; }

        [JsonProperty("policyForm")]
        public List<PolicyFormDetail> PolicyForm { get; set; }

        [JsonProperty("underwriterName")]
        public string UnderwriterName { get; set; }

        [JsonProperty("insuredEntityType")]
        public string InsuredEntityType { get; set; }

        [JsonProperty("bankruptcy")]
        public bool? Bankruptcy { get; set; }

        [JsonProperty("foreclosure")]
        public bool? Foreclosure { get; set; }

        [JsonProperty("inHomeBusinessCoverage")]
        public InHomeBusinessCoverage InHomeBusinessCoverage { get; set; }

        [JsonProperty("inHomeDayCareCoverage")]
        public InHomeDayCareCoverage InHomeDayCareCoverage { get; set; }

        [JsonProperty("structuresRentedOnPremisesCoverage")]
        public string StructuresRentedOnPremisesCoverage { get; set; }
        //public StructuresRentedOnPremisesCoverage StructuresRentedOnPremisesCoverage { get; set; }

        [JsonProperty("structuresRentedOffPremisesCoverage")]
        public string StructuresRentedOffPremisesCoverage { get; set; }
        //public StructuresRentedOffPremisesCoverage StructuresRentedOffPremisesCoverage { get; set; }

        [JsonProperty("extendedLiabilityToRentedLocationsCoverage")]
        public bool? ExtendedLiabilityToRentedLocationsCoverage { get; set; }

        [JsonProperty("lapseInCoverage")]
        public bool? LapseInCoverage { get; set; }

        [JsonProperty("trampolineIsCovered")]
        public bool? TrampolineIsCovered { get; set; }

        [JsonProperty("swimmingPoolIsCovered")]
        public bool? SwimmingPoolIsCovered { get; set; }

        [JsonProperty("modifierMarketPriceAdjustment")]
        public decimal? ModifierMarketPriceAdjustment { get; set; }

        [JsonProperty("dateOfLastLoss")]
        public DateTime? DateOfLastLoss { get; set; }

        [JsonProperty("coverageIsVandalismMischief")]
        public bool? CoverageIsVandalismMischief { get; set; }

        [JsonProperty("modifierUnderwriterPriceAdjustment")]
        public bool? ModifierUnderwriterPriceAdjustment { get; set; }

        [JsonProperty("retroActiveDate")]
        public DateTime? RetroActiveDate { get; set; }

        [JsonProperty("priorLosses")]
        public List<PriorLoss> PriorLosses { get; set; }

        [JsonProperty("ProfessionalLiabilityClassLawyers")]
        public List<ProfessionalLiabilityClassLawyer> ProfessionalLiabilityClassLawyers { get; set; }

        [JsonProperty("professionalLiabilityAttorneys")]
        public List<ProfessionalLiabilityAttorneys> ProfessionalLiabilityAttorneys { get; set; }

        [JsonProperty("professionalLiabilityAttorneyPriorActs")]
        public List<ProfessionalLiabilityAttorneyPriorActs> ProfessionalLiabilityAttorneyPriorActs { get; set; }

        [JsonProperty("professionalLiabilityClientIndustry")]
        public List<ProfessionalLiabilityClientIndustryModel> ProfessionalLiabilityClientIndustry { get; set; }

        [JsonProperty("professionalLiabilityContinuingLegalEducation")]
        public List<ProfessionalLiabilityContinuingLegalEducationModel> ProfessionalLiabilityContinuingLegalEducation { get; set; }

        [JsonProperty("professionalLiabilityLitigationHistory")]
        public List<ProfessionalLiabilityLitigationHistoryModel> ProfessionalLiabilityLitigationHistory { get; set; }

        [JsonProperty("professionalLiabilityLoyaltyCredit")]
        public List<ProfessionalLiabilityLoyaltyCreditModel> ProfessionalLiabilityLoyaltyCredit { get; set; }

        [JsonProperty("policyTypeCode")]
        public string PolicyTypeCode { get; set; }

        [JsonProperty("historicTIV1YearPrior")]
        public decimal? HistoricTiv1YearPrior { get; set; }

        [JsonProperty("historicTIV2YearPrior")]
        public decimal? HistoricTiv2YearPrior { get; set; }

        [JsonProperty("historicTIV3YearPrior")]
        public decimal? HistoricTiv3YearPrior { get; set; }

        [JsonProperty("nonEnginePricing")]
        public bool? NonEnginePricing { get; set; }

        [JsonProperty("hasPriorCoverageWithNoLapse")]
        public bool? HasPriorCoverageWithNoLapse { get; set; }

        [JsonProperty("hasLapsedPriorCoverage")]
        public bool? HasLapsedPriorCoverage { get; set; }

        [JsonProperty("extendedLiabilityToRentedLocationsAmount")]
        public decimal? ExtendedLiabilityToRentedLocationsAmount { get; set; }

        [JsonProperty("extendedLiabilityRentedLocationsCount")]
        public int? ExtendedLiabilityRentedLocationsCount { get; set; }

        [JsonProperty("extendedLiabilityRentedLocationsFamilies")]
        public string ExtendedLiabilityRentedLocationsFamilies { get; set; }

        [JsonProperty("forDebugRequestPricingEngineVersion")]
        public string ForDebugRequestPricingEngineVersion { get; set; }

        [JsonProperty("policyFee")]
        public decimal? PolicyFee { get; set; }

        [JsonProperty("underwriterPremiumOffer")]
        public decimal? UnderwriterPremiumOffer { get; set; }

        [JsonProperty("agencyName")]
        public string AgencyName { get; set; }

        [JsonProperty("fileName")]
        public string FileName { get; set; }

        [JsonProperty("uploadDate")]
        public string UploadDate { get; set; }

        [JsonProperty("uploaderVersion")]
        public string UploaderVersion { get; set; }

        [JsonProperty("batchNumber")]
        public string BatchNumber { get; set; }

        #region Details from other tables
        
        
        public List<ApdCommodity> ApdCommodities { get; set; }
        public List<AutoPhysicalDamage> AutoPhysicalDamages { get; set; }
        #endregion
    }
}
