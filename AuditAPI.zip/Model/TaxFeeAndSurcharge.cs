﻿using Newtonsoft.Json;

namespace Models
{
    public partial class TaxFeeAndSurcharge
    {
        [JsonProperty("tfsType")]
        public string TfsType { get; set; }

        [JsonProperty("code")]
        public string Code { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("amount")]
        public decimal Amount { get; set; }
    }
}
