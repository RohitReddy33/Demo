﻿using Newtonsoft.Json;

namespace Models
{
    public partial class Coverage
    {
        [JsonProperty("premiumAmount")]
        public decimal? PremiumAmount { get; set; }

        [JsonProperty("limitAmount")]
        public decimal? LimitAmount { get; set; }

        [JsonProperty("deductibleAmount")]
        public decimal? DeductibleAmount { get; set; }

        [JsonProperty("rate")]
        public decimal? Rate { get; set; }

        [JsonProperty("coverageForm")]
        public decimal? CoverageForm { get; set; }
    }
}
