﻿using Newtonsoft.Json;

namespace Models
{
    public class PolicyFormDetail
    {
        [JsonProperty("formName")]
        public string FormName { get; set; }

        [JsonProperty("formEditionDate")]
        public string FormEditionDate { get; set; }

        [JsonProperty("formDescription")]
        public string FormDescription { get; set; }
    }
}
