﻿using Models;
using System.Collections.Generic;

namespace Model
{
    public class RiskResponse
    {
       // public List<Policy> Policies { get; set; }
        public List<PolicyRecord> PolicyRecord { get; set; }
    }
}
