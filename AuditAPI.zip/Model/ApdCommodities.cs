﻿using Models.Enums;
using Newtonsoft.Json;

namespace Models
{
    public partial class ApdCommodities
    {
        [JsonProperty("type")]
        public CancelMethod Type { get; set; }

        [JsonProperty("items")]
        public PolicyRecord Items { get; set; }
    }
}
