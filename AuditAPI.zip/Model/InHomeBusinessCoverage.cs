﻿using Models.Enums;
using Newtonsoft.Json;

namespace Models
{
    public class InHomeBusinessCoverage
    {
        [JsonProperty("typeOfBusiness")]
        public string TypeOfBusiness { get; set; }

        [JsonProperty("numberOfEmployees")]
        public int? NumberOfEmployees { get; set; }

        [JsonProperty("grossReceipts")]
        public decimal? GrossReceipts { get; set; }

        [JsonProperty("businessName")]
        public string BusinessName { get; set; }
    }
}
