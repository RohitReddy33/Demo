﻿using Newtonsoft.Json;

namespace Models
{
    public class ApdCommodity
    {
        [JsonProperty("apdCommodityScheme")]
        public string ApdCommodityScheme { get; set; }

        [JsonProperty("apdCommodityType")]
        public int? ApdCommodityType { get; set; }
    }
}
