﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Models
{
    public class LiabilityClass
    {
        [JsonProperty("isoglClassCode")]
        public string IsoglClassCode { get; set; }

        [JsonProperty("subCoverageCode")]
        public string SubCoverageCode { get; set; }

        [JsonProperty("premiumBasis")]
        public string PremiumBasis { get; set; }

        [JsonProperty("premiumBasisValue")]
        public decimal? PremiumBasisValue { get; set; }

        [JsonProperty("territoriesCode")]
        public string TerritoriesCode { get; set; }

        [JsonProperty("liabilityCoverages")]
        public List<LiabilityCoverage> LiabilityCoverages { get; set; }

        [JsonProperty("appliesAllLocations")]
        public bool? AppliesAllLocations { get; set; }
    }
}
