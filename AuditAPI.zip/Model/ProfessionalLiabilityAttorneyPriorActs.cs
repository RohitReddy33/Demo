﻿using Newtonsoft.Json;

namespace Models
{
    public class ProfessionalLiabilityAttorneyPriorActs
    {
        [JsonProperty("attorneyHoursID")]
        public int AttorneyHoursId { get; set; }

        [JsonProperty("attorneys")]
        public int Attorneys { get; set; }

        [JsonProperty("priorActsID")]
        public int PriorActsId { get; set; }
    }
}
