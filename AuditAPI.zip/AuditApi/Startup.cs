using AuditApi.Constants;
using AuditApi.Shared.Extensions;
using AuditApi.Shared.Helper;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Any;
using Microsoft.OpenApi.Interfaces;
using Microsoft.OpenApi.Models;
using Repositories;
using Repositories.DBContext;
using Repositories.Interfaces;
using Serilog;
using Serilog.Events;
using Serilog.Exceptions;
using Serilog.Sinks.Elasticsearch;
using Serilog.Sinks.SystemConsole.Themes;
using Services;
using Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Net;
using System.Reflection;
using System.Text.Json.Serialization;

namespace AuditApi
{
    public class Startup
    {
        private const string AllowSpecificOrigins = "AllowSpecificOrigins";
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            var elasticUri = Configuration["ElasticConfiguration:Uri"];
            var environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
            Log.Logger = new LoggerConfiguration()
                .Enrich.FromLogContext()
                .Enrich.WithMachineName()
                .Enrich.WithEnvironmentUserName()
                .Enrich.WithThreadId()
                .Enrich.WithProcessId()
                .Enrich.WithAssemblyName()
                .Enrich.WithExceptionStackTraceHash()
                .Enrich.WithExceptionDetails()
                .Enrich.WithProperty("Environment", environment)
                .WriteTo.Elasticsearch(new ElasticsearchSinkOptions(new Uri(elasticUri))
                {
                    AutoRegisterTemplate = true,
                    IndexFormat = "transaction-audit-api-2021.10",
                    ModifyConnectionSettings = (c) => c.GlobalHeaders(new NameValueCollection { { "Authorization", $"Basic {Configuration["ElasticConfiguration:Key"]}" } })
                })
                .WriteTo.Console(LogEventLevel.Information, theme: AnsiConsoleTheme.Literate)
                .CreateLogger();

            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.CustomSchemaIds(type => type.ToString());
                c.SwaggerDoc("v1", new OpenApiInfo
                {
                    Version = "v1",
                    Title = "Transaction Audit Api",
                    Description = "A Transaction Audit API",
                    Contact = new OpenApiContact
                    {
                        Name = "Software Engineering",
                        Email = "DevelopmentTeam@bellandclements.co.uk"
                    },
                    Extensions = new Dictionary<string, IOpenApiExtension>
                    {
                        {"x-logo", new OpenApiObject {
                                    {"url", new OpenApiString($"/images/b&c-logo-trans-v2.PNG")},
                                    {"altText", new OpenApiString("Bell & Clements")},
                                    {"style", new OpenApiString("padding: 20px")},
                                }
                        }
                    }
                });
                var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
                var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
                c.IncludeXmlComments(xmlPath);
            });
            services.AddSwaggerGenNewtonsoftSupport();
            services.AddDbContext<UniversalBdxContext>(options =>
            {
                options.UseChangeTrackingProxies(false);
                options.UseSqlServer(Configuration.GetConnectionString("UniversalDatabaseConnection"),
                        sqlServerOptions =>
                        {

                            sqlServerOptions.CommandTimeout(120);
                            sqlServerOptions.UseNetTopologySuite();
                        });
            });

            services.AddScoped<IUniversalBDXRepository, UniversalBDXRepository>();
            services.AddScoped<ITransactionsAuditService, TransactionsAuditService>();
            services.AddTransient<IHttpContextAccessor, HttpContextAccessor>();
            services.AddScoped<IAuthorizationHelper, AuthorizationHelper>();

            services.AddCors(options =>
            {
                options.AddPolicy(AllowSpecificOrigins,
                    builder =>
                    {
                        builder.WithOrigins(
                                //  "http://localhost:64571",// TODO - update for J&J Urls
                                ""
                                )
                            .AllowAnyHeader()
                            .AllowAnyMethod()
                            .AllowCredentials();
                    });
            });

            services.AddAuthentication("Bearer")
             .AddJwtBearer("Bearer", options =>
             {
                 options.Authority = Configuration.GetConnectionString("AuthenticationAuthority");
                 options.RequireHttpsMetadata = false;
                 options.Audience = "transactionauditapi";
             });

            services.AddAuthorization(options =>
            {
                options.AddPolicy(PolicyConstants.AuditApiClientIdPolicy, policy =>
                                        policy.RequireClaim("client_id", PolicyConstants.AuditApiClientIdPolicyValue));
            });

            services.AddControllers().AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
            });
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            
            if (env.IsDevelopment() || env.EnvironmentName.ToLower().Contains("internal") || env.EnvironmentName.ToLower().Contains("test"))
            {
                app.UseSwagger();
                app.UseReDoc(c =>
                {
                    c.DocumentTitle = "Transaction Audit API Documentation";
                    c.RoutePrefix = "";
                    c.SpecUrl = "swagger/v1/swagger.json";
                });
            }

            app.UseMessagePerformanceLoggerMiddleware();
            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseCors(AllowSpecificOrigins);
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseSerilogRequestLogging();
            app.UseStaticFiles();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

        }
    }
}
