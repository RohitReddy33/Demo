﻿using AuditApi.Constants;
using AuditApi.Shared.Helper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Model;
using Models;
using Serilog.Context;
using Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuditApi.Controllers
{
    [Route("api/transactions")]
    [ApiController]
    [Authorize]
    public class TransactionAuditController : ControllerBase
    {
        private readonly ILogger<TransactionAuditController> _logger;
        private readonly ITransactionsAuditService _transactionAuditService;
        private readonly IAuthorizationHelper _authorizationHelper;
        private IConfiguration _configuration;
        public TransactionAuditController(ILogger<TransactionAuditController> logger, ITransactionsAuditService transactionAuditService,
                                           IAuthorizationHelper authorizationHelper, IConfiguration configuration)
        {
            _logger = logger;
            _transactionAuditService = transactionAuditService;
            _authorizationHelper = authorizationHelper;
            _configuration = configuration;
        }

        [ApiExplorerSettings(IgnoreApi = true)]
        [HttpGet]
        [Route("Environment")]
        [AllowAnonymous]
        public ActionResult<string> GetEnvironment()
        {
            var environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
            return Ok(environment);
        }

        /// <summary>
        /// Get monthly risks
        /// </summary>
        /// <param name="riskRequest"></param>
        /// <returns></returns>
        [HttpPost("monthly-risk-data")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(RiskResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(List<Models.ValidationResult>), StatusCodes.Status400BadRequest)]
        [Authorize(Policy = PolicyConstants.AuditApiClientIdPolicy)]
        public async Task<ActionResult<RiskResponse>> GetMonthlyTransactions([FromBody] MonthlyRiskRequest riskRequest)
        {
            try
            {
                _logger.LogInformation("GetMonthlyData request received");
                using (LogContext.PushProperty("MonthlyTransactionsRequest", "MonthlyTransactions"))
                {
                    _logger.LogInformation($"{riskRequest.AccountingEffectiveDate}");
                    _logger.LogInformation($"{riskRequest.ContractRef}");
                    _logger.LogInformation($"{riskRequest.ContractYear}");
                }
                if (!_authorizationHelper.IsValidRequest())
                    return Forbid();

                var errors = ModelState.Where(x => x.Value.Errors.Count > 0).Select(x => new ValidationResult
                {
                    Key = x.Key,
                    ErrorMessages = x.Value.Errors.Select(y => y.ErrorMessage).ToList()
                }).ToList();

                if (!ModelState.IsValid)
                    return BadRequest(errors);

                riskRequest.CompanyId = Convert.ToInt16(_configuration["ClientCompanyId"]);
                var riskResponse = await Task.Run(() => _transactionAuditService.GetMonthlyTransactions(riskRequest));
                return Ok(riskResponse);
            }
            catch (Exception exception)
            {
                _logger.LogError("GetMonthlyTransactions", exception.ToString());
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        /// <summary>
        /// Get policy risks
        /// </summary>
        /// <param name="riskRequest"></param>
        /// <returns></returns>
        [HttpPost("policy-risk-data")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(RiskResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(List<Models.ValidationResult>), StatusCodes.Status400BadRequest)]
        [Authorize(Policy = PolicyConstants.AuditApiClientIdPolicy)]
        public async Task<ActionResult<RiskResponse>> GetPolicyTransactions([FromBody] PolicyRiskRequest riskRequest)
        {
            try
            {
                _logger.LogInformation("GetPolicy request received");
                using (LogContext.PushProperty("PolicyTransactionsRequest", "PolicyTransactions"))
                {
                    _logger.LogInformation($"{riskRequest.RecordUniqueIdentifier}");
                    _logger.LogInformation($"{riskRequest.PolicyNumber}");
                    _logger.LogInformation($"{riskRequest.ContractRef}");
                    _logger.LogInformation($"{riskRequest.ContractYear}");
                }
                if (!_authorizationHelper.IsValidRequest())
                    return Forbid();

                var errors = ModelState.Where(x => x.Value.Errors.Count > 0).Select(x => new ValidationResult
                {
                    Key = x.Key,
                    ErrorMessages = x.Value.Errors.Select(y => y.ErrorMessage).ToList()
                }).ToList();

                if (!ModelState.IsValid)
                    return BadRequest(errors);

                riskRequest.CompanyId = Convert.ToInt16(_configuration["ClientCompanyId"]);
                var riskResponse = await Task.Run(() => _transactionAuditService.GetPolicyTransactions(riskRequest));
                return Ok(riskResponse);
            }
            catch (Exception exception)
            {
                _logger.LogError("GetPolicyTransactions", exception.ToString());
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }

        /// <summary>
        /// Get policy risks
        /// </summary>
        /// <param name="riskRequest"></param>
        /// <returns></returns>
        [ApiExplorerSettings(IgnoreApi = true)]
        [HttpPost("policy-record-identifier-risk-data")]
        [Produces("application/json")]
        [ProducesResponseType(typeof(RiskResponse), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(List<Models.ValidationResult>), StatusCodes.Status400BadRequest)]
        [Authorize(Policy = PolicyConstants.AuditApiClientIdPolicy)]
        public async Task<ActionResult<RiskResponse>> GetPolicyTransactionsByFormSetId([FromBody] PolicyRiskRequest riskRequest)
        {
            try
            {
                _logger.LogInformation("GetPolicyTransactionsByFormSetId request received");

                using (LogContext.PushProperty("PolicyTransactionsByFormSetIdRequest", riskRequest.RecordUniqueIdentifier))
                {
                    _logger.LogInformation($"{riskRequest.PolicyNumber}");
                    _logger.LogInformation($"{riskRequest.ContractRef}");
                    _logger.LogInformation($"{riskRequest.ContractYear}");
                }
                if (!_authorizationHelper.IsValidRequest())
                    return Forbid();

                var errors = ModelState.Where(x => x.Value.Errors.Count > 0).Select(x => new ValidationResult
                {
                    Key = x.Key,
                    ErrorMessages = x.Value.Errors.Select(y => y.ErrorMessage).ToList()
                }).ToList();

                if (!ModelState.IsValid)
                    return BadRequest(errors);

                riskRequest.CompanyId = Convert.ToInt16(_configuration["ClientCompanyId"]);
                var riskResponse = await Task.Run(() => _transactionAuditService.GetPolicyTransactions(riskRequest));
                return Ok(riskResponse);
            }
            catch (Exception exception)
            {
                _logger.LogError("GetPolicyTransactionsByFormSetId", exception.ToString());
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
    }
}
