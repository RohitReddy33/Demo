﻿namespace AuditApi.Constants
{
    public class PolicyConstants
    {
        public const string AuditApiClientIdPolicy = "client_id";
        public const string AuditApiClientIdPolicyValue = "JOHNSON-transaction-audit-api";
    }
}
