﻿using Microsoft.AspNetCore.Builder;

namespace AuditApi.Shared.Extensions
{
    public static class MessagePerformanceLoggerExtensions
    {
        public static IApplicationBuilder UseMessagePerformanceLoggerMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<MessagePerformanceLoggerMiddleware>();
        }
    }
}
