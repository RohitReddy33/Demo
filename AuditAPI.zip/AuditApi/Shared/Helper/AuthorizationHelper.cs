﻿
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Services.Interfaces;
using System;
using System.Linq;

namespace AuditApi.Shared.Helper
{
    public class AuthorizationHelper : IAuthorizationHelper
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly string BCUsersCompanyId = "49";
        private readonly ITransactionsAuditService _transactionsAuditService;
        public IConfiguration Configuration { get; }
        public AuthorizationHelper(IHttpContextAccessor httpContextAccessor, IConfiguration configuration, ITransactionsAuditService transactionsAuditService)
        {
            _httpContextAccessor = httpContextAccessor;
            Configuration = configuration;
            _transactionsAuditService = transactionsAuditService;
        }
        public bool IsServiceInternallyCalled()
        {
            var User = _httpContextAccessor.HttpContext.User;
            if (User.Identity.IsAuthenticated && (User.Identity.AuthenticationType == "Negotiate") || User.Identity.AuthenticationType == "Windows"
                                                   || User.Identity.AuthenticationType == "NTLM")
                return true;

            if (BCUsersCompanyId == Configuration["ClientCompanyId"])
                return true;

            return false;
        }
        public bool IsValidRequest()
        {
            var User = _httpContextAccessor.HttpContext.User;
            var clientId = User.Claims.Where(c => c.Type == "client_id").FirstOrDefault();

            var companyId = _transactionsAuditService.GetAgentIdFromUniqueAgentReference(clientId.Value);
            if (companyId == Convert.ToInt16(Configuration["ClientCompanyId"]))
                return true;

            return false;
        }
    }
}
