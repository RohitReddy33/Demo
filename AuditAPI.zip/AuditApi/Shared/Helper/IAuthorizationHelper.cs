﻿namespace AuditApi.Shared.Helper
{
    public interface IAuthorizationHelper
    {
        public bool IsServiceInternallyCalled();
        public bool IsValidRequest();
    }
}
