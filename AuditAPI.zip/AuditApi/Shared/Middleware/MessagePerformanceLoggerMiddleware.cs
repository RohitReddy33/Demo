﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Serilog.Context;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace AuditApi.Shared
{
    public class MessagePerformanceLoggerMiddleware
    {
        private readonly RequestDelegate _request;
        private readonly ILogger _logger;

        public MessagePerformanceLoggerMiddleware(RequestDelegate request, ILogger<MessagePerformanceLoggerMiddleware> logger)
        {
            _request = request;
            _logger = logger;
        }

        public async Task Invoke(HttpContext context)
        {
            var watcher = Stopwatch.StartNew();

            var requestBody = await GetRequestBody(context.Request);

            var username = context.User.Identity.Name;
            if (context.Request.Headers.TryGetValue("username", out var usernames))
            {
                username = usernames.First();
            }

            string company = null;

            if (context.User.Identity.AuthenticationType == "Negotiate"
                || context.User.Identity.AuthenticationType == "Windows"
                || context.User.Identity.AuthenticationType == "NTLM")
            {
                company = "Bell & Clements Limited";
            }
            else if (context.User.Claims.Any(x => x.Type == "companyName"))
            {
                company = context.User.Claims.First(x => x.Type == "companyName").Value;
            }

            await _request.Invoke(context);

            watcher.Stop();
            var elapsedTimeMs = watcher.ElapsedMilliseconds.ToString();

            using (LogContext.PushProperty("RequestPath", context.Request.Path))
            using (LogContext.PushProperty("RequestElapsedTimeMS", double.Parse(elapsedTimeMs)))
            using (LogContext.PushProperty("RequestMethod", context.Request.Method))
            using (LogContext.PushProperty("RequestQueryString", context.Request.QueryString))
            using (LogContext.PushProperty("RequestBody", requestBody))
            using (LogContext.PushProperty("ResponseStatus", context.Response.StatusCode))
            using (LogContext.PushProperty("Username", username))
            using (LogContext.PushProperty("Company", company))
            {
                _logger.LogInformation($"{context.Request.Path} took {elapsedTimeMs} ms");
            }
        }

        private static async Task<string> GetRequestBody(HttpRequest request)
        {
            request.EnableBuffering();
            var body = await new StreamReader(request.Body).ReadToEndAsync();
            request.Body.Position = 0;
            return body;
        }
    }
}
