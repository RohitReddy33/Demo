﻿using Model;
using Models;
using System.Threading.Tasks;

namespace Services.Interfaces
{
    public interface ITransactionsAuditService
    {
        public int GetAgentIdFromUniqueAgentReference(string clientId);
        public RiskResponse GetMonthlyTransactions(MonthlyRiskRequest riskRequest);
        public RiskResponse GetPolicyTransactions(PolicyRiskRequest riskRequest);
    }
}
