﻿using Microsoft.EntityFrameworkCore;
using Model;
using Models;
using Repositories.Interfaces;
using Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Services
{
    public class TransactionsAuditService : ITransactionsAuditService
    {
        private readonly IUniversalBDXRepository _universalBDXRepository;
        public TransactionsAuditService(IUniversalBDXRepository universalBDXRepository)
        {
            _universalBDXRepository = universalBDXRepository;
        }
        public int GetAgentIdFromUniqueAgentReference(string clientId)
        {
            var uniqueAgentReference = clientId.Split('-').First();
            if (uniqueAgentReference == null)
                throw new Exception($"Unique Agent Reference can not be extracted from {clientId}");

            var agent = _universalBDXRepository.GetAgents().Where(a =>
                                            a.UniqueAgentReference.ToLower().Equals(uniqueAgentReference.ToLower())).FirstOrDefault();

            return agent.CompanyId;

        }
        public RiskResponse GetMonthlyTransactions(MonthlyRiskRequest riskRequest)
        {

            var isProfessionalLiabilityContractRef = _universalBDXRepository.GetProfessionalLiabilitiesContractRefs(riskRequest.ContractYear, riskRequest.CompanyId)
                                                                                                .Any(c => c.Equals(riskRequest.ContractRef));
            if (isProfessionalLiabilityContractRef)
                return GetProfessionalLiabilityRiskResponse(riskRequest.CompanyId, riskRequest.ContractRef, riskRequest.ContractYear, null, riskRequest.AccountingEffectiveDate.Value);

            var isTransportationContractRef = _universalBDXRepository.GetTransportaionContractRefs(riskRequest.ContractYear, riskRequest.CompanyId).Any(c => c.Equals(riskRequest.ContractRef));
            if (isTransportationContractRef)
                return GetTransportationRiskResponse(riskRequest.CompanyId, riskRequest.ContractRef, riskRequest.ContractYear, null, riskRequest.AccountingEffectiveDate.Value);

            var isHomeOwnersContractRef = _universalBDXRepository.GetCommercialPackageAndHomeownersOrPersonalLinesContractRefs(riskRequest.ContractYear, riskRequest.CompanyId)
                                                                                                .Any(c => c.Equals(riskRequest.ContractRef));
            if (isHomeOwnersContractRef)
                return GetCommercialPackageOrHomeOwnersOrPersonalLinesRiskResponse(riskRequest.CompanyId, riskRequest.ContractRef, riskRequest.ContractYear, null, riskRequest.AccountingEffectiveDate.Value);

            return null;
        }

        public RiskResponse GetPolicyTransactions(PolicyRiskRequest riskRequest)
        {
            var isProfessionalLiabilityPolicy = _universalBDXRepository.IsProfessionalLiabilityPolicy(riskRequest);
            if (isProfessionalLiabilityPolicy)
                return GetProfessionalLiabilityRiskResponse(riskRequest.CompanyId, riskRequest.ContractRef, riskRequest.ContractYear, riskRequest.PolicyNumber, default(DateTime), false, riskRequest.RecordUniqueIdentifier);

            var isTransportationPolicy = _universalBDXRepository.IsTransportationPolicy(riskRequest);
            if (isTransportationPolicy)
                return GetTransportationRiskResponse(riskRequest.CompanyId, riskRequest.ContractRef, riskRequest.ContractYear, riskRequest.PolicyNumber, default(DateTime), false, riskRequest.RecordUniqueIdentifier);

            var isCommercialPackageAndHomeownersOrPersonalLinesPolicy = _universalBDXRepository.IsCommercialPackageAndHomeownersOrPersonalLinesPolicy(riskRequest);
            if (isCommercialPackageAndHomeownersOrPersonalLinesPolicy)
                return GetCommercialPackageOrHomeOwnersOrPersonalLinesRiskResponse(riskRequest.CompanyId, riskRequest.ContractRef, riskRequest.ContractYear, riskRequest.PolicyNumber, default(DateTime), false, riskRequest.RecordUniqueIdentifier);

            return null;
        }

        private RiskResponse GetProfessionalLiabilityRiskResponse(int companyId, string contractRef, int contractYear, string policyNo, DateTime accountingEffectiveDate, bool IsMonthlyRiskData = true, string recordUniqueIdentifier = null)
        {
            var tempPolicyTransactions = (from policyTransaction in _universalBDXRepository.GetTempPolicyTransactions().Where(t => t.CompanyId == companyId)
                                                                            .Where(t => t.CorrectedBy == null && (t.IgnoreRecord != true))
                                          .Include(t => t.TempPolicyTransactionsIsoglclasses)
                                          .Include(t => t.TempPolicyTransactionsDocucorpIncludedForms)
                                          .Include(t => t.TempPolicyTransactionsApimIsyCls)
                                          .Include(t => t.TempPolicyTransactionsPriorLosses)
                                          .Include(t => t.TempPolicyTransactionsProfessionalLiabilityAttorneys)
                                          .Include(t => t.TempPolicyTransactionsProfessionalLiabilityClientIndustries)
                                          .Include(t => t.TempPolicyTransactionsProfessionalLiabilityContinuingLegalEducations)
                                          .Include(t => t.TempPolicyTransactionsProfessionalLiabilityLitigationHistories)
                                          .Include(t => t.TempPolicyTransactionsProfessionalLiabilityLoyaltyCredits) // TODO- INLCUDE TempPolicyTransactions_ProfessionalLiability_PriorActs ONCE TWO FK ISSUE IS FIXED IN DB                                       
                                          .Include(t => t.TempPolicyTransactionsLocations)
                                          .ThenInclude(l => l.TempPolicyTransactionsLocationsIsoglclasses)
                                           select policyTransaction);
            if (IsMonthlyRiskData)
            {
                tempPolicyTransactions = tempPolicyTransactions.Where(p => p.AccountingEffectiveDate.Value.Month == accountingEffectiveDate.Month);
                tempPolicyTransactions = tempPolicyTransactions.Where(p => p.AccountingEffectiveDate.Value.Year == accountingEffectiveDate.Year);
            }

            if (!IsMonthlyRiskData)
            {
                policyNo = policyNo.Trim();
                tempPolicyTransactions = tempPolicyTransactions.Where(p => p.PolicyNo.Equals(policyNo));
                if (!string.IsNullOrEmpty(recordUniqueIdentifier) && !string.IsNullOrWhiteSpace(recordUniqueIdentifier))
                {
                    recordUniqueIdentifier = recordUniqueIdentifier.Trim();
                    tempPolicyTransactions = tempPolicyTransactions.Where(p => p.FormSetId.Equals(recordUniqueIdentifier));
                }
            }

            var tempPolicyTransactionsContracts = _universalBDXRepository.GetTempPolicyTransactionsContracts()
                                                               .Where(c => c.CompanyId == companyId)
                                                               .Where(c => c.ContractYear == contractYear)
                                                               .Where(c => c.ContractRef.Equals(contractRef));

            if (tempPolicyTransactionsContracts == null || tempPolicyTransactionsContracts.Count() == 0 || tempPolicyTransactions == null || tempPolicyTransactions.Count() == 0)
                return new RiskResponse();

            var policyRecords = (from policyTransaction in tempPolicyTransactions
                                 join policyContract in tempPolicyTransactionsContracts
                                        on policyTransaction.TempPremiumsId equals policyContract.TempPremiumsId
                                 join policyLocation in _universalBDXRepository.GetTempPolicyTransactionsLocations()
                                        .Include(l => l.TempPolicyTransactionsLocationsIsoglclasses)
                                        .Include(l => l.TempPolicyTransactionsLocationsIsoglclassProfessionalLiabilityLawyers)
                                        on policyTransaction.TempPremiumsId equals policyLocation.TempPremiumsId
                                 #region Select only required columns
                                 select new
                                 {
                                     #region TempPolicyTrans columns
                                     policyTransaction.FormSetId,
                                     policyTransaction.RatingSessionId,
                                     policyTransaction.InsuredEntityId,
                                     policyTransaction.ParentRui,
                                     policyTransaction.PricingEngineId,
                                     policyTransaction.EngineQuoteEnquiryId,
                                     policyTransaction.InvoiceNumber,
                                     policyTransaction.AccountingEffectiveDate,
                                     policyTransaction.TransactionType,
                                     TransactionReasonCode = policyTransaction.TempPolicyTransactionsApimIsyCls.FirstOrDefault().TransactionReasonCode ?? null,
                                     policyTransaction.CancellationCode,
                                     policyTransaction.BusinessArea,
                                     policyTransaction.SubCompanyId,
                                     // policyTransaction.InsuredName, commented out due to data security risk
                                     policyTransaction.InsuredDoingBusinessAs,
                                     policyTransaction.AdditionalNamedInsured,
                                     policyTransaction.CertificateNumber,
                                     policyTransaction.PolicyNo,
                                     policyTransaction.EndorsementNumber,
                                     policyTransaction.ExpiringPolicyNumber,
                                     policyTransaction.PlcommercialIndicator,
                                     policyTransaction.CoverageForm,
                                     policyTransaction.PlacementType,
                                     policyTransaction.CoInsurancePercentage,
                                     policyTransaction.HereonPercentage,
                                     policyTransaction.EffectiveDate,
                                     policyTransaction.ExpirationDate,
                                     policyTransaction.MailingStreet,
                                     policyTransaction.MailingCity,
                                     policyTransaction.MailingCounty,
                                     policyTransaction.MailingState,
                                     policyTransaction.MailingZipCode,
                                     policyTransaction.MailingCountryScheme,
                                     policyTransaction.MailingZipCodePlusFour,
                                     policyTransaction.GrossPremium,
                                     policyTransaction.Commission,
                                     policyTransaction.Payable,
                                     policyTransaction.FullTermEndorsementPremium,
                                     policyTransaction.MinimumPropertyAdjustmentPremium,
                                     policyTransaction.MinimumCrimeAdjustmentPremium,
                                     policyTransaction.MinFloodDeductible,
                                     policyTransaction.CrimeInsuranceAgreement,
                                     policyTransaction.IdentityTheftRecovery,
                                     policyTransaction.Tivfgu,
                                     policyTransaction.AttachmentPoint,
                                     policyTransaction.GlaggregateLimit,
                                     policyTransaction.SurveyFees,
                                     policyTransaction.SltbrokerNumber,
                                     policyTransaction.SltbrokerName,
                                     policyTransaction.SltbrokerAddress,
                                     policyTransaction.Sltstate,
                                     policyTransaction.SurplusLinesTransactionNumber,
                                     policyTransaction.Naic,
                                     policyTransaction.CedingCoNameRetailAgent,
                                     policyTransaction.NetPremium,
                                     LiabilityClasses = new List<LiabilityClass>() {
                                                               new LiabilityClass
                                                               {
                                                                   LiabilityCoverages = new List<LiabilityCoverage> {
                                                                      policyTransaction.GlaggregateLimit.HasValue? new LiabilityCoverage{
                                                                          LiabilityCoverageType = "GeneralAggregate",
                                                                          LimitAmount = policyTransaction.GlaggregateLimit
                                                                    }:null,
                                                                      !string.IsNullOrEmpty(policyTransaction.DocucorpProductCompletedOper)? new LiabilityCoverage{
                                                                          LiabilityCoverageType = "ProductsCompletedOperations",
                                                                          LimitAmount = Convert.ToDecimal(policyTransaction.DocucorpProductCompletedOper)
                                                                    }:null,
                                                                        !string.IsNullOrEmpty(policyTransaction.DocucorpPersonalAndAdvertising)? new LiabilityCoverage{
                                                                          LiabilityCoverageType = "PersonalAdvertisingInjury",
                                                                          LimitAmount = Convert.ToDecimal(policyTransaction.DocucorpPersonalAndAdvertising)
                                                                    }:null,
                                                                        !string.IsNullOrEmpty( policyTransaction.DocucorpDamagePremRented)? new LiabilityCoverage{
                                                                          LiabilityCoverageType = "FireDamage",
                                                                          LimitAmount = Convert.ToDecimal(policyTransaction.DocucorpDamagePremRented)
                                                                    }:null,
                                                                        !string.IsNullOrEmpty( policyTransaction.DocucorpMedExpenseLmt)? new LiabilityCoverage{
                                                                          LiabilityCoverageType = "MedicalExpenses",
                                                                          LimitAmount = Convert.ToDecimal(policyTransaction.DocucorpMedExpenseLmt)
                                                                    }:null,
                                                                         policyTransaction.LiabilityLimit.HasValue? new LiabilityCoverage{
                                                                          LiabilityCoverageType = "EachOccurrence",
                                                                          LimitAmount = policyTransaction.LiabilityLimit
                                                                    }:null
                                                                   }
                                                               }},
                                     #endregion

                                     Contracts = policyTransaction.TempPolicyTransactionsContracts.Select(contract =>
                                                    new Contract
                                                    {
                                                        ContractRef = contract.ContractRef,
                                                        Commission = contract.CommissionPercentage,
                                                        ContractPercentage = contract.ContractShare,
                                                        ContractPeriod = contract.ContractYear,
                                                        EquipmentBreakdownPercentage = contract.EquipmentBreakdownShare,
                                                        LiabilityPercentage = contract.LiabilityShare,
                                                        SectionNo = string.IsNullOrEmpty(contract.ContractRef.Substring(4)) ? null : contract.ContractRef.Substring(4),
                                                    }).ToList(),
                                     policyTransaction.PolicyProcessorSystemName,
                                     PolicyForm = policyTransaction.TempPolicyTransactionsDocucorpIncludedForms.Any() ?
                                                        policyTransaction.TempPolicyTransactionsDocucorpIncludedForms.Select(df =>
                                                            new PolicyFormDetail
                                                            {
                                                                FormDescription = df.Description,
                                                                FormEditionDate = df.EditionDate,
                                                                FormName = df.FormName
                                                            }).ToList() : null,
                                     policyTransaction.UnderwriterName,
                                     policyTransaction.InsuredEntityType,
                                     policyTransaction.Bankruptcy,
                                     policyTransaction.Foreclosure,
                                     InHomeBusinessCoverage = new InHomeBusinessCoverage
                                     {
                                         BusinessName = policyTransaction.BusinessArea, // ASK for confirmation
                                         GrossReceipts = policyTransaction.GrossPremium, // ASK for confirmation
                                         NumberOfEmployees = policyTransaction.InHomeBusinessCoverageNoEmployees,
                                         TypeOfBusiness = policyTransaction.InHomeBusinessCoverageTypeOfBusiness
                                     },
                                     policyTransaction.StructuresRentedOffPremisesCoverage,
                                     policyTransaction.StructuresRentedOnPremisesCoverage,
                                     policyTransaction.ExtendedLiabilityToRentedLocationsCoverage,
                                     policyTransaction.LapseInCoverage,
                                     policyTransaction.TrampolineIsCovered,
                                     policyTransaction.SwimmingPoolIsCovered,
                                     policyTransaction.ModifierMarketPriceAdjustment,
                                     policyTransaction.DateOfLastLoss,
                                     policyTransaction.CoverageIsVandalismMischief,
                                     policyTransaction.RetroActiveDate,
                                     PriorLosses = policyTransaction.TempPolicyTransactionsPriorLosses.Any() ?
                                                        policyTransaction.TempPolicyTransactionsPriorLosses.Select(priorLoss =>
                                                            new PriorLoss
                                                            {
                                                                CauseOfLoss = priorLoss.CauseOfLoss,
                                                                ClaimStatus = priorLoss.ClaimStatus,
                                                                DateOfLoss = priorLoss.DateOfLoss,
                                                                TotalIncurred = priorLoss.TotalIncurred
                                                            }).ToList() : null,

                                     #region Locations & Buildings
                                     locations = policyTransaction.TempPolicyTransactionsLocations.Select(l =>
                                     new LocationRecord
                                     {
                                         LocationNumber = int.Parse(l.LocationNumber),
                                         LiabilityClasses = l.TempPolicyTransactionsLocationsIsoglclasses.Any() ?
                                                                l.TempPolicyTransactionsLocationsIsoglclasses.Select(iso =>
                                                                     new LiabilityClass
                                                                     {
                                                                         IsoglClassCode = iso.SubCoverageCode,
                                                                         LiabilityCoverages = new List<LiabilityCoverage>{
                                                                                          new LiabilityCoverage
                                                                                         {
                                                                                           CoverageForm=  policyTransaction.CoverageForm,
                                                                                           PremiumAmount=  policyTransaction.LiabilityPremium,
                                                                                           LimitAmount   =  policyTransaction.LiabilityLimit
                                                                                         }},
                                                                         PremiumBasis = l.PremiumBasis,
                                                                         PremiumBasisValue = l.PremiumBasisValue,
                                                                         TerritoriesCode = l.TerritoriesCode,
                                                                         SubCoverageCode = l.SubCoverageCode
                                                                     }).ToList() : null,
                                         Buildings = l.TempPolicyTransactionsLocationsBuildings.Any() ?
                                                      l.TempPolicyTransactionsLocationsBuildings.Select(building => new BuildingRecord
                                                      {
                                                          BuildingNumber = building.BuildingNumber,
                                                          InsuredStreet = building.InsuredStreet,
                                                          InsuredCity = building.InsuredCity,
                                                          InsuredState = building.InsuredState,
                                                          InsuredZipCode = building.InsuredZipCode,
                                                          Country = building.InsuredCounty,
                                                          InsuredZipCodePlusFour = building.InsuredZipCodePlusFour,
                                                          CountryScheme = building.InsuredCountryScheme,
                                                          CoverageIsVandalismMischief = building.CoverageIsVandalismMischief,
                                                          OccupancyScheme = building.OccupancyScheme,
                                                          OccupancyCode = building.OccupancyCode,
                                                          DwellingType = building.DwellingType,
                                                          LiabilityClasses = building.TempPolicyTransactionsLocationsBuildingsIsoglclasses.Any() ?
                                                                 building.TempPolicyTransactionsLocationsBuildingsIsoglclasses.Select(lc =>
                                                                     new LiabilityClass
                                                                     {
                                                                         IsoglClassCode = lc.Isoglclass,
                                                                         LiabilityCoverages = new List<LiabilityCoverage> {
                                                                         new LiabilityCoverage
                                                                         {
                                                                             CoverageForm = policyTransaction.CoverageForm,
                                                                             PremiumAmount =policyTransaction.LiabilityPremium,
                                                                             LimitAmount = policyTransaction.LiabilityLimit
                                                                         }},
                                                                         PremiumBasis = lc.PremiumBasis,
                                                                         PremiumBasisValue = lc.PremiumBasisValue,
                                                                         TerritoriesCode = lc.TerritoriesCode,
                                                                         SubCoverageCode = lc.SubCoverageCode
                                                                     }).ToList() : null,
                                                          BuildingCharacteristics = new BuildingCharacteristics
                                                          {
                                                              MgaDistanceToCoastMiles = building.MgadistanceToCoastMiles,
                                                              MgaLatitude = building.Mgalatitude,
                                                              MgaLongitude = building.Mgalongitude,
                                                              IsoPropertyCode = building.IsopropertyCode,
                                                              ConstructionScheme = building.ConstructionCodeScheme,
                                                              ConstructionCode = building.ConstructionCode,
                                                              RentalTerm = building.RentalTerm,
                                                              ProtectionClass = building.ProtectionClass,
                                                              Protections = building.Protections,
                                                              OpeningProtectionsCode = building.OpeningProtectionsCode,
                                                              OpeningProtectionTypesCode = building.OpeningProtectionTypesCode,
                                                              CentralBurglarProtection = building.CentralBurglarProtection,
                                                              CentralFireProtection = building.CentralFireProtection,
                                                              LocalBurglarProtection = building.LocalBurglarProtection,
                                                              LocalFireProtection = building.LocalFireProtection,
                                                              PoliceStationBurglarAlarmProtection = building.PoliceStationBurglarAlarmProtection,
                                                              FireExtinguisherProtection = building.FireExtinguisherProtection,
                                                              SmokeDetectorsProtection = building.SmokeDetectorsProtection,
                                                              SprinklersProtection = building.SprinklersProtection,
                                                              WaterShutOffValveProtection = building.WaterShutOffValveProtection,
                                                              WaterShutOffWithAlarmProtection = building.WaterShutOffWithAlarmProtection,
                                                              GatedCommunityProtection = building.GatedCommunityProtection,
                                                              StormShuttersProtection = building.StormShuttersProtection,
                                                              ImpactResistantGlassProtection = building.ImpactResistantGlassProtection,
                                                              FireStationAlarmProtection = building.FireStationAlarmProtection,
                                                              AnsulProtection = building.AnsulProtection,
                                                              YearBuilt = building.YearBuilt,
                                                              NumberOfAcres = building.NumberOfAcres,
                                                              NumberOfStories = building.NumberofStories,
                                                              SquareFootage = building.Squarefootage,
                                                              FloodZone = building.FloodZone,
                                                              RoofConstruction = Convert.ToString(building.RoofConstructionCode),
                                                              RoofShowsSignsOfDeterioration = building.RoofShowsSignsOfDeterioration,
                                                              ShapeOfRoof = building.RoofShapeCode,
                                                              RoofAnchorCode = building.RoofAnchorCode,
                                                              RoofSheathingCode = building.RoofSheathingCode,
                                                              PrimaryHeatSourceCode = building.PrimaryHeatSourceCode,
                                                              AlternateHeatSourceCode = building.AlternateHeatSourceCode,
                                                              BasementType = building.BasementType,
                                                              GrossPremium = building.GrossPremium,
                                                              CrimeInsuranceAct = building.CrimeInsuranceAgreement,
                                                              EquipmentBreakdown = building.EquipmentBreakdown,
                                                              HomeSystemsProtection = building.HomeSystemsProtection,
                                                              ServiceLine = building.ServiceLine,
                                                              TotalInsuredValueFromtheGroundUp = building.Tivfgu,
                                                              RoofCoverage = building.RoofCoverage,
                                                              RoofCoverageValuationBasis = building.RoofCoverageValuationBasis,
                                                              TownHouse = building.TownHouse,
                                                              ForSale = building.ForSale,
                                                              HistoricRegistry = building.HistoricRegistry,
                                                              NewPurchase = building.NewPurchase,
                                                              EqBaseIsolation = building.EqbaseIsolation,
                                                              EqCladdingType = building.EqbaseIsolation,
                                                              EqConstructionQuality = building.EqconstructionQuality,
                                                              EqEquipmentSupportMaintenance = building.EqequipmentSupportMaintenance,
                                                              EqEngineeredFoundation = building.EqengineeredFoundation,
                                                              EqSprinklerLeakageCoverageFlag = building.EqsprinklerLeakageCoverageFlag,
                                                              EqAppendagesandOrnamentation = building.EqappendagesandOrnamentation,
                                                              EqFrameBolted = building.EqframeBolted,
                                                              EqUnreinforcedMasonryPartitionsorChimneys = building.EqunreinforcedMasonryPartitionsorChimneys,
                                                              EqMechanicalandElectricalEquipmentEarthquakeBracing = building.EqmechanicalandElectricalEquipmentEarthquakeBracing,
                                                              EqVerticalIrregularity = building.EqverticalIrregularity,
                                                              EqPounding = building.Eqpounding,
                                                              EqPlanIrregularity = building.EqplanIrregularity,
                                                              EqShortColumnCondition = building.EqshortColumnCondition,
                                                              EqSprinklerLeakageSusceptibility = building.EqsprinklerLeakageSusceptibility,
                                                              EqSoftStory = building.EqsoftStory,
                                                              EqStructuralUpgrade = building.EqstructuralUpgrade,
                                                              EqTiltUpRetrofit = building.EqtiltUpRetrofit,
                                                              EqUnreinforcedMasonryRetrofit = building.EqunreinforcedMasonryRetrofit,
                                                              EqCrippleWalls = building.EqcrippleWalls,
                                                              HasTrampoline = building.HasTrampoline,
                                                              HasSwimmingPool = building.HasSwimmingPool,
                                                              HasSolarPanels = building.HasSolarPanels,
                                                              HasMultipleRoofingLayers = building.HasMultipleRoofingLayers,
                                                              DwellingType = building.DwellingType,
                                                              IsMobileHome = building.IsMobileHome,
                                                              IsVacant = building.IsVacant,
                                                              IsBuildersRisk = building.IsBuildersRisk,
                                                              HasConcreteBasement = building.HasConcreteBasement,
                                                              HasMortaredBlockFoundation = building.HasMortaredBlockFoundation,
                                                              HasStiltsOverWater = building.HasStiltsOverWater,
                                                              FirstFloorHeightAboveGround = building.FirstFloorHeightAboveGround,
                                                              FlFoundationType = building.FlfoundationType
                                                          }
                                                      }).ToList() : null
                                     }),
                                     #endregion

                                     #region Professional Liability
                                     professionalLiabilityClassLawyers = policyLocation.TempPolicyTransactionsLocationsIsoglclassProfessionalLiabilityLawyers.Select(p =>
                                                   new ProfessionalLiabilityClassLawyer
                                                   {
                                                       IsoglClassCode = p.Isoglclass,
                                                       CoverageEffectiveDate = p.CoverageEffectiveDate,
                                                       CoverageExpiryDate = p.CoverageExpirationDate,
                                                       AreaOfPracticeId = p.AreaOfPracticeId,
                                                       AreaOfPracticePercentage = p.AreaOfPracticePercentage,
                                                       RatingId = p.RatingId,
                                                       AnnualStatementLob = p.AnnualStatementLob,
                                                       AverageCaseSize = p.AverageCaseSize,
                                                       CoverageCode = p.CoverageCode,
                                                       CspSubline = p.Cspsubline,
                                                       DeductibleAmount = p.Deductible,
                                                       Exposure = p.Exposure,
                                                       ExposureRatingBasis = p.ExposureRatingBasis,
                                                       FirmAverageRate = p.FirmAverageRate,
                                                       FirmAttorneyExperience = p.FirmAttorneyExperience,
                                                       FirmRevenue = p.FirmRevenue,
                                                       LimitAmount = p.Limit,
                                                       PolicyAggregateLimit = p.PolicyAggregateLimit,
                                                       MaximumCaseSize = p.MaximumCaseSize,
                                                       NumberCasesPerYear = p.NumberCasesPerYear,
                                                       TermPremium = p.TermPremium,
                                                       PremiumAmount = p.Premium,
                                                       RateDepartureLcm = p.RateDepartureLcm,
                                                       RateModificationFactor = p.RateModificationFactor,
                                                       StateHourlyRate = p.StateHourlyRate,
                                                       SubCoverageCode = p.SubCoverageCode,
                                                       TerritoriesCode = p.TerritoriesCode,
                                                       RetroActiveDate = p.RetroActiveDate,
                                                       ExtendedReportingPeriodDate = p.ExtendedReportingPeriodDate

                                                   }).ToList(),
                                     ProfessionalLiabilityAttorneys = policyTransaction.TempPolicyTransactionsProfessionalLiabilityAttorneys.Any() ?
                                                                            policyTransaction.TempPolicyTransactionsProfessionalLiabilityAttorneys.Select(p =>
                                                                                 new ProfessionalLiabilityAttorneys
                                                                                 {
                                                                                     AttorneyHoursId = p.AttorneyHoursId,
                                                                                     Attorneys = p.Attorneys
                                                                                 }).ToList() : null,
                                     ProfessionalLiabilityClientIndustry = policyTransaction.TempPolicyTransactionsProfessionalLiabilityClientIndustries.Any() ?
                                                                                policyTransaction.TempPolicyTransactionsProfessionalLiabilityClientIndustries.Select(ci =>
                                                                                     new ProfessionalLiabilityClientIndustryModel
                                                                                     {
                                                                                         ClientIndustryId = ci.ClientIndustryId,
                                                                                         ModificationFactor = ci.ModificationFactor,
                                                                                         ModificationFactorBasis = ci.ModificationFactorBasis
                                                                                     }).ToList() : null,
                                     ProfessionalLiabilityContinuingLegalEducation = policyTransaction.TempPolicyTransactionsProfessionalLiabilityContinuingLegalEducations.Any() ?
                                                                                        policyTransaction.TempPolicyTransactionsProfessionalLiabilityContinuingLegalEducations.Select(le =>
                                                                                            new ProfessionalLiabilityContinuingLegalEducationModel
                                                                                            {
                                                                                                ContinuingLegalEducationId = le.ContinuingLegalEducationId,
                                                                                                ModificationFactor = le.ModificationFactor
                                                                                            }).ToList() : null,
                                     ProfessionalLiabilityLitigationHistory = policyTransaction.TempPolicyTransactionsProfessionalLiabilityLitigationHistories.Any() ?
                                                                                    policyTransaction.TempPolicyTransactionsProfessionalLiabilityLitigationHistories.Select(lh =>
                                                                                        new ProfessionalLiabilityLitigationHistoryModel
                                                                                        {
                                                                                            LitigationHistoryId = lh.LitigationHistoryId,
                                                                                            ModificationFactor = lh.ModificationFactor
                                                                                        }).ToList() : null,
                                     ProfessionalLiabilityLoyaltyCredit = policyTransaction.TempPolicyTransactionsProfessionalLiabilityLoyaltyCredits.Any() ?
                                                                                policyTransaction.TempPolicyTransactionsProfessionalLiabilityLoyaltyCredits.Select(lc =>
                                                                                    new ProfessionalLiabilityLoyaltyCreditModel
                                                                                    {
                                                                                        LoyaltyCreditId = lc.LoyaltyCreditId,
                                                                                        ModificationFactor = lc.ModificationFactor
                                                                                    }).ToList() : null,
                                     #endregion
                                     policyTransaction.HistoricTiv1yearPrior,
                                     policyTransaction.HistoricTiv2yearPrior,
                                     policyTransaction.HistoricTiv3yearPrior,
                                     policyTransaction.NonEnginePricing,
                                     policyTransaction.HasLapsedPriorCoverage,
                                     policyTransaction.HasPriorCoverageWithNoLapse
                                 })
            #endregion
                                      .AsEnumerable()
            #region Construct Policy Risk Response
                                      .Select(policyTransaction =>
                                      new PolicyRecord
                                      {
                                          #region   Policy level columns
                                          RecordUniqueIdentifier = policyTransaction.FormSetId,
                                          RatingSessionId = policyTransaction.RatingSessionId,
                                          InsuredEntityId = policyTransaction.InsuredEntityId,
                                          ParentRui = policyTransaction.ParentRui,
                                          PricingEngineId = policyTransaction.PricingEngineId,
                                          PricingEngineQuoteEnquiryId = policyTransaction.EngineQuoteEnquiryId,
                                          // AgencyName = agent == null ? null : agent.CompanyName,
                                          InvoiceNumber = policyTransaction.InvoiceNumber,
                                          AccountingEffectiveDate = policyTransaction.AccountingEffectiveDate.Value,
                                          TransactionType = policyTransaction.TransactionType,
                                          TransactionReasonCode = policyTransaction.TransactionReasonCode,
                                          CancellationCode = policyTransaction.CancellationCode,
                                          BusinessArea = policyTransaction.BusinessArea,
                                          SubCompanyId = policyTransaction.SubCompanyId,
                                          // InsuredName = policyTransaction.InsuredName,
                                          InsuredDoingBusinessAs = policyTransaction.InsuredDoingBusinessAs,
                                          AdditionalNamedInsured = policyTransaction.AdditionalNamedInsured,
                                          CertificateNumber = policyTransaction.CertificateNumber,
                                          PolicyNumber = policyTransaction.PolicyNo,
                                          EndorsementNumber = policyTransaction.EndorsementNumber,
                                          ExpiringPolicyNumber = policyTransaction.ExpiringPolicyNumber,
                                          PLorCommercialIndicator = policyTransaction.PlcommercialIndicator,
                                          CoverageForm = policyTransaction.CoverageForm,
                                          PlacementType = policyTransaction.PlacementType,
                                          CoInsurancePercentage = policyTransaction.CoInsurancePercentage,
                                          HereOnPercentage = policyTransaction.HereonPercentage,
                                          EffectiveDate = policyTransaction.EffectiveDate,
                                          ExpiryDate = policyTransaction.ExpirationDate,
                                          MailingStreet = policyTransaction.MailingStreet,
                                          MailingCity = policyTransaction.MailingCity,
                                          MailingCountry = "USA",
                                          MailingCounty = policyTransaction.MailingCounty,
                                          MailingState = policyTransaction.MailingState,
                                          MailingZipCode = policyTransaction.MailingZipCode,
                                          MailingCountryScheme = policyTransaction.MailingCountryScheme,
                                          MailingZipCodePlusFour = policyTransaction.MailingZipCodePlusFour,
                                          GrossPremium = policyTransaction.GrossPremium,
                                          NetCommission = policyTransaction.Commission,
                                          NetPremium = policyTransaction.NetPremium,
                                          Payable = policyTransaction.Payable,
                                          FullTermPremiumChange = policyTransaction.FullTermEndorsementPremium,
                                          MinimumPropertyAdjustmentPremium = policyTransaction.MinimumPropertyAdjustmentPremium,
                                          MinimumCrimeAdjustmentPremium = policyTransaction.MinimumCrimeAdjustmentPremium,
                                          MinFloodDeductible = policyTransaction.MinFloodDeductible,
                                          CrimeInsuranceAct = policyTransaction.CrimeInsuranceAgreement,
                                          IdentityTheftRecovery = policyTransaction.IdentityTheftRecovery,
                                          TotalInsuredValueFromtheGroundUp = policyTransaction.Tivfgu,
                                          AttachmentPoint = policyTransaction.AttachmentPoint,
                                          GlAggregateLimit = policyTransaction.GlaggregateLimit,
                                          LiabilityClasses = policyTransaction.LiabilityClasses,
                                          Contracts = policyTransaction.Contracts,
                                          PolicyProcessorSystemName = policyTransaction.PolicyProcessorSystemName,
                                          PolicyForm = policyTransaction.PolicyForm,
                                          UnderwriterName = policyTransaction.UnderwriterName,
                                          CedingCompanyNameRetailAgent = policyTransaction.CedingCoNameRetailAgent,
                                          InsuredEntityType = policyTransaction.InsuredEntityType,
                                          Bankruptcy = policyTransaction.Bankruptcy,
                                          Foreclosure = policyTransaction.Foreclosure,
                                          InHomeBusinessCoverage = policyTransaction.InHomeBusinessCoverage,
                                          StructuresRentedOffPremisesCoverage = policyTransaction.StructuresRentedOffPremisesCoverage,
                                          StructuresRentedOnPremisesCoverage = policyTransaction.StructuresRentedOnPremisesCoverage,
                                          ExtendedLiabilityToRentedLocationsCoverage = policyTransaction.ExtendedLiabilityToRentedLocationsCoverage,
                                          LapseInCoverage = policyTransaction.LapseInCoverage,
                                          TrampolineIsCovered = policyTransaction.TrampolineIsCovered,
                                          SwimmingPoolIsCovered = policyTransaction.SwimmingPoolIsCovered,
                                          ModifierMarketPriceAdjustment = policyTransaction.ModifierMarketPriceAdjustment,
                                          DateOfLastLoss = policyTransaction.DateOfLastLoss,
                                          CoverageIsVandalismMischief = policyTransaction.CoverageIsVandalismMischief,
                                          RetroActiveDate = policyTransaction.RetroActiveDate,
                                          PriorLosses = policyTransaction.PriorLosses,
                                          Naic = policyTransaction.Naic,
                                          CedingCoNameRetailAgent = policyTransaction.CedingCoNameRetailAgent,
                                          SltBrokerNumber = policyTransaction.SltbrokerNumber,
                                          SltBrokerName = policyTransaction.SltbrokerName,
                                          SltBrokerAddress = policyTransaction.SltbrokerAddress,
                                          SltState = policyTransaction.Sltstate,
                                          #endregion

                                          #region Locations & Buildings & Transaportation
                                          Locations = policyTransaction.locations.ToList(),
                                          #endregion

                                          #region Professional Liability
                                          ProfessionalLiabilityClassLawyers = policyTransaction.professionalLiabilityClassLawyers,
                                          ProfessionalLiabilityAttorneys = policyTransaction.ProfessionalLiabilityAttorneys,
                                          ProfessionalLiabilityClientIndustry = policyTransaction.ProfessionalLiabilityClientIndustry,
                                          ProfessionalLiabilityContinuingLegalEducation = policyTransaction.ProfessionalLiabilityContinuingLegalEducation,
                                          ProfessionalLiabilityLitigationHistory = policyTransaction.ProfessionalLiabilityLitigationHistory,
                                          ProfessionalLiabilityLoyaltyCredit = policyTransaction.ProfessionalLiabilityLoyaltyCredit,
                                          #endregion

                                          HistoricTiv1YearPrior = policyTransaction.HistoricTiv1yearPrior,
                                          HistoricTiv2YearPrior = policyTransaction.HistoricTiv2yearPrior,
                                          HistoricTiv3YearPrior = policyTransaction.HistoricTiv3yearPrior,
                                          NonEnginePricing = policyTransaction.NonEnginePricing,
                                          HasLapsedPriorCoverage = policyTransaction.HasLapsedPriorCoverage,
                                          HasPriorCoverageWithNoLapse = policyTransaction.HasPriorCoverageWithNoLapse
                                      }).ToList();
            #endregion

            return new RiskResponse { PolicyRecord = policyRecords };
        }
        private RiskResponse GetTransportationRiskResponse(int companyId, string contractRef, int contractYear, string policyNo, DateTime accountingEffectiveDate, bool IsMonthlyRiskData = true, string recordUniqueIdentifier = null)
        {
            contractRef = contractRef.Trim();
            var agent = _universalBDXRepository.GetAgents().Where(a => a.CompanyId == companyId).FirstOrDefault();
            var tempPolicyTransactions = (from policyTransaction in _universalBDXRepository.GetTempPolicyTransactions()
                                                                         .Where(t => t.CompanyId == companyId)
                                                                         .Where(t => t.CorrectedBy == null && (t.IgnoreRecord != true))
                                          .Include(t => t.TempPolicyTransactionsIsoglclasses)
                                          .Include(t => t.TempPolicyTransactionsDocucorpIncludedForms)
                                          .Include(t => t.TempPolicyTransactionsPriorLosses)
                                          .Include(t => t.TempPolicyTransactionsLocations)
                                          .ThenInclude(l => l.TempPolicyTransactionsLocationsIsoglclasses)
                                           select policyTransaction);
            if (IsMonthlyRiskData)
            {
                tempPolicyTransactions = tempPolicyTransactions.Where(p => p.AccountingEffectiveDate.Value.Month == accountingEffectiveDate.Month);
                tempPolicyTransactions = tempPolicyTransactions.Where(p => p.AccountingEffectiveDate.Value.Year == accountingEffectiveDate.Year);
            }

            if (!IsMonthlyRiskData)
            {
                policyNo = policyNo.Trim();
                tempPolicyTransactions = tempPolicyTransactions.Where(p => p.PolicyNo.Equals(policyNo));
                if (!string.IsNullOrEmpty(recordUniqueIdentifier) && !string.IsNullOrWhiteSpace(recordUniqueIdentifier))
                {
                    recordUniqueIdentifier = recordUniqueIdentifier.Trim();
                    tempPolicyTransactions = tempPolicyTransactions.Where(p => p.FormSetId.Equals(recordUniqueIdentifier));
                }
            }

            var tempPolicyTransactionsContracts = _universalBDXRepository.GetTempPolicyTransactionsContracts()
                                                               .Where(c => c.CompanyId == companyId)
                                                               .Where(c => c.ContractYear == contractYear)
                                                               .Where(c => c.ContractRef.Trim().ToLower().Equals(contractRef.Trim().ToLower()));

            if (tempPolicyTransactionsContracts == null || tempPolicyTransactionsContracts.Count() == 0 || tempPolicyTransactions == null || tempPolicyTransactions.Count() == 0)
                return new RiskResponse();

            var policyRecords = (from policyTransaction in tempPolicyTransactions
                                 join policyContract in tempPolicyTransactionsContracts
                                        on policyTransaction.TempPremiumsId equals policyContract.TempPremiumsId
                                 join policyTransportation in _universalBDXRepository.GetTempPolicyTransactionsTransportation()
                                                                .Include(t => t.TempPolicyTransactionsTransportationApdacvunitBandings)
                                                                .Include(t => t.TempPolicyTransactionsTransportationApdcommodities)
                                                                .Include(t => t.TempPolicyTransactionsTransportationCargoCommodities)
                                                                .Include(t => t.TempPolicyTransactionsTransportationTrailerDetails)
                                                                .Include(t => t.TempPolicyTransactionsTransportationVehicleDetails)
                                        on policyTransaction.TempPremiumsId equals policyTransportation.TempPremiumsId
                                 join policyLocation in _universalBDXRepository.GetTempPolicyTransactionsLocations()
                                        on policyTransaction.TempPremiumsId equals policyLocation.TempPremiumsId

                                 #region Select only required columns
                                 select new
                                 {
                                     #region TempPolicyTrans columns
                                     policyTransaction.FormSetId,
                                     policyTransaction.RatingSessionId,
                                     policyTransaction.InsuredEntityId,
                                     policyTransaction.ParentRui,
                                     policyTransaction.PricingEngineId,
                                     policyTransaction.EngineQuoteEnquiryId,
                                     policyTransaction.InvoiceNumber,
                                     policyTransaction.AccountingEffectiveDate,
                                     policyTransaction.TransactionType,
                                     policyTransaction.CancellationCode,
                                     policyTransaction.BusinessArea,
                                     policyTransaction.SubCompanyId,
                                     // policyTransaction.InsuredName,
                                     policyTransaction.InsuredDoingBusinessAs,
                                     policyTransaction.AdditionalNamedInsured,
                                     policyTransaction.CertificateNumber,
                                     policyTransaction.PolicyNo,
                                     policyTransaction.EndorsementNumber,
                                     policyTransaction.ExpiringPolicyNumber,
                                     policyTransaction.PlcommercialIndicator,
                                     policyTransaction.CoverageForm,
                                     policyTransaction.PlacementType,
                                     policyTransaction.CoInsurancePercentage,
                                     policyTransaction.HereonPercentage,
                                     policyTransaction.EffectiveDate,
                                     policyTransaction.ExpirationDate,
                                     policyTransaction.MailingStreet,
                                     policyTransaction.MailingCity,
                                     policyTransaction.MailingCounty,
                                     policyTransaction.MailingState,
                                     policyTransaction.MailingZipCode,
                                     policyTransaction.MailingCountryScheme,
                                     policyTransaction.MailingZipCodePlusFour,
                                     policyTransaction.GrossPremium,
                                     policyTransaction.Commission,
                                     policyTransaction.Payable,
                                     policyTransaction.FullTermEndorsementPremium,
                                     policyTransaction.MinimumPropertyAdjustmentPremium,
                                     policyTransaction.MinimumCrimeAdjustmentPremium,
                                     policyTransaction.MinFloodDeductible,
                                     policyTransaction.CrimeInsuranceAgreement,
                                     policyTransaction.IdentityTheftRecovery,
                                     policyTransaction.Tivfgu,
                                     policyTransaction.AttachmentPoint,
                                     policyTransaction.GlaggregateLimit,
                                     policyTransaction.SurveyFees,
                                     policyTransaction.SltbrokerNumber,
                                     policyTransaction.SltbrokerName,
                                     policyTransaction.SltbrokerAddress,
                                     policyTransaction.Sltstate,
                                     policyTransaction.SurplusLinesTransactionNumber,
                                     policyTransaction.Naic,
                                     policyTransaction.CedingCoNameRetailAgent,
                                     policyTransaction.NetPremium,
                                     policyTransaction.Rate,
                                     LiabilityClasses = new List<LiabilityClass>() {
                                                               new LiabilityClass
                                                               {
                                                                   LiabilityCoverages = new List<LiabilityCoverage> {
                                                                      policyTransaction.GlaggregateLimit.HasValue? new LiabilityCoverage{
                                                                          LiabilityCoverageType = "GeneralAggregate",
                                                                          LimitAmount = policyTransaction.GlaggregateLimit
                                                                    }:null,
                                                                      !string.IsNullOrEmpty(policyTransaction.DocucorpProductCompletedOper)? new LiabilityCoverage{
                                                                          LiabilityCoverageType = "ProductsCompletedOperations",
                                                                          LimitAmount = Convert.ToDecimal(policyTransaction.DocucorpProductCompletedOper)
                                                                    }:null,
                                                                        !string.IsNullOrEmpty(policyTransaction.DocucorpPersonalAndAdvertising)? new LiabilityCoverage{
                                                                          LiabilityCoverageType = "PersonalAdvertisingInjury",
                                                                          LimitAmount = Convert.ToDecimal(policyTransaction.DocucorpPersonalAndAdvertising)
                                                                    }:null,
                                                                        !string.IsNullOrEmpty( policyTransaction.DocucorpDamagePremRented)? new LiabilityCoverage{
                                                                          LiabilityCoverageType = "FireDamage",
                                                                          LimitAmount = Convert.ToDecimal(policyTransaction.DocucorpDamagePremRented)
                                                                    }:null,
                                                                        !string.IsNullOrEmpty( policyTransaction.DocucorpMedExpenseLmt)? new LiabilityCoverage{
                                                                          LiabilityCoverageType = "MedicalExpenses",
                                                                          LimitAmount = Convert.ToDecimal(policyTransaction.DocucorpMedExpenseLmt)
                                                                    }:null,
                                                                         policyTransaction.LiabilityLimit.HasValue? new LiabilityCoverage{
                                                                          LiabilityCoverageType = "EachOccurrence",
                                                                          LimitAmount = policyTransaction.LiabilityLimit
                                                                    }:null
                                                                   }
                                                               }},
                                     #endregion

                                     Contracts = policyTransaction.TempPolicyTransactionsContracts.Select(contract =>
                                                    new Contract
                                                    {
                                                        ContractRef = contract.ContractRef,
                                                        Commission = contract.CommissionPercentage,
                                                        ContractPercentage = contract.ContractShare,
                                                        ContractPeriod = contract.ContractYear,
                                                        EquipmentBreakdownPercentage = contract.EquipmentBreakdownShare,
                                                        LiabilityPercentage = contract.LiabilityShare,
                                                        SectionNo = string.IsNullOrEmpty(contract.ContractRef.Substring(4)) ? null : contract.ContractRef.Substring(4),
                                                    }).ToList(),
                                     policyTransaction.PolicyProcessorSystemName,
                                     PolicyForm = policyTransaction.TempPolicyTransactionsDocucorpIncludedForms.Any() ?
                                                        policyTransaction.TempPolicyTransactionsDocucorpIncludedForms.Select(df =>
                                                            new PolicyFormDetail
                                                            {
                                                                FormDescription = df.Description,
                                                                FormEditionDate = df.EditionDate,
                                                                FormName = df.FormName
                                                            }).ToList() : null,
                                     policyTransaction.UnderwriterName,
                                     policyTransaction.InsuredEntityType,
                                     policyTransaction.Bankruptcy,
                                     policyTransaction.Foreclosure,
                                     policyTransaction.StructuresRentedOffPremisesCoverage,
                                     policyTransaction.StructuresRentedOnPremisesCoverage,
                                     policyTransaction.ExtendedLiabilityToRentedLocationsCoverage,
                                     policyTransaction.LapseInCoverage,
                                     policyTransaction.TrampolineIsCovered,
                                     policyTransaction.SwimmingPoolIsCovered,
                                     policyTransaction.ModifierMarketPriceAdjustment,
                                     policyTransaction.DateOfLastLoss,
                                     policyTransaction.CoverageIsVandalismMischief,
                                     policyTransaction.RetroActiveDate,
                                     PriorLosses = policyTransaction.TempPolicyTransactionsPriorLosses.Any() ?
                                            policyTransaction.TempPolicyTransactionsPriorLosses.Select(priorLoss =>
                                                    new PriorLoss
                                                    {
                                                        CauseOfLoss = priorLoss.CauseOfLoss,
                                                        ClaimStatus = priorLoss.ClaimStatus,
                                                        DateOfLoss = priorLoss.DateOfLoss,
                                                        TotalIncurred = priorLoss.TotalIncurred
                                                    }).ToList() : null,
                                     #region Locations & Buildings
                                     locations = policyTransaction.TempPolicyTransactionsLocations.Select(l =>
                                     new LocationRecord
                                     {
                                         LocationNumber = int.Parse(l.LocationNumber),
                                         LiabilityClasses = l.TempPolicyTransactionsLocationsIsoglclasses.Any() ?
                                                             l.TempPolicyTransactionsLocationsIsoglclasses.Select(iso =>
                                                                     new LiabilityClass
                                                                     {
                                                                         IsoglClassCode = iso.SubCoverageCode,
                                                                         PremiumBasis = l.PremiumBasis,
                                                                         PremiumBasisValue = l.PremiumBasisValue,
                                                                         TerritoriesCode = l.TerritoriesCode,
                                                                         SubCoverageCode = l.SubCoverageCode,
                                                                         LiabilityCoverages = new List<LiabilityCoverage>{
                                                                                                  new LiabilityCoverage
                                                                                                     {
                                                                                                       CoverageForm =  policyTransaction.CoverageForm,
                                                                                                       PremiumAmount =  l.LiabilityPremium,
                                                                                                       LimitAmount   =  l.LiabilityLimit
                                                                                                     }}

                                                                     }).ToList() : null,
                                         Buildings =
                                                       l.TempPolicyTransactionsLocationsBuildings.Select(building => new BuildingRecord
                                                       {
                                                           BuildingNumber = building.BuildingNumber,
                                                           InsuredStreet = building.InsuredStreet,
                                                           InsuredCity = building.InsuredCity,
                                                           InsuredState = building.InsuredState,
                                                           InsuredZipCode = building.InsuredZipCode,
                                                           Country = building.InsuredCountryCode,
                                                           InsuredZipCodePlusFour = building.InsuredZipCodePlusFour,
                                                           CountryScheme = building.InsuredCountryScheme,
                                                           CoverageIsVandalismMischief = building.CoverageIsVandalismMischief,
                                                           OccupancyScheme = building.OccupancyScheme,
                                                           OccupancyCode = building.OccupancyCode,
                                                           DwellingType = building.DwellingType,
                                                           LiabilityClasses = building.TempPolicyTransactionsLocationsBuildingsIsoglclasses.Any() ?
                                                                               building.TempPolicyTransactionsLocationsBuildingsIsoglclasses.Select(lc =>
                                                                                   new LiabilityClass
                                                                                   {
                                                                                       IsoglClassCode = lc.Isoglclass,
                                                                                       LiabilityCoverages = new List<LiabilityCoverage> {
                                                                                                         new LiabilityCoverage
                                                                                                         {
                                                                                                             CoverageForm = policyTransaction.CoverageForm,
                                                                                                             PremiumAmount = policyTransaction.LiabilityPremium,
                                                                                                             LimitAmount = policyTransaction.LiabilityLimit
                                                                                                         }},
                                                                                       PremiumBasis = lc.PremiumBasis,
                                                                                       PremiumBasisValue = lc.PremiumBasisValue,
                                                                                       TerritoriesCode = lc.TerritoriesCode,
                                                                                       SubCoverageCode = lc.SubCoverageCode
                                                                                   }).ToList() : null,
                                                           BuildingCharacteristics = new BuildingCharacteristics
                                                           {
                                                               MgaDistanceToCoastMiles = building.MgadistanceToCoastMiles,
                                                               MgaLatitude = building.Mgalatitude,
                                                               MgaLongitude = building.Mgalongitude,
                                                               IsoPropertyCode = building.IsopropertyCode,
                                                               ConstructionScheme = building.ConstructionCodeScheme,
                                                               ConstructionCode = building.ConstructionCode,
                                                               RentalTerm = building.RentalTerm,
                                                               ProtectionClass = building.ProtectionClass,
                                                               Protections = building.Protections,
                                                               OpeningProtectionsCode = building.OpeningProtectionsCode,
                                                               OpeningProtectionTypesCode = building.OpeningProtectionTypesCode,
                                                               CentralBurglarProtection = building.CentralBurglarProtection,
                                                               CentralFireProtection = building.CentralFireProtection,
                                                               LocalBurglarProtection = building.LocalBurglarProtection,
                                                               LocalFireProtection = building.LocalFireProtection,
                                                               PoliceStationBurglarAlarmProtection = building.PoliceStationBurglarAlarmProtection,
                                                               FireExtinguisherProtection = building.FireExtinguisherProtection,
                                                               SmokeDetectorsProtection = building.SmokeDetectorsProtection,
                                                               SprinklersProtection = building.SprinklersProtection,
                                                               WaterShutOffValveProtection = building.WaterShutOffValveProtection,
                                                               WaterShutOffWithAlarmProtection = building.WaterShutOffWithAlarmProtection,
                                                               GatedCommunityProtection = building.GatedCommunityProtection,
                                                               StormShuttersProtection = building.StormShuttersProtection,
                                                               ImpactResistantGlassProtection = building.ImpactResistantGlassProtection,
                                                               FireStationAlarmProtection = building.FireStationAlarmProtection,
                                                               AnsulProtection = building.AnsulProtection,
                                                               YearBuilt = building.YearBuilt,
                                                               NumberOfAcres = building.NumberOfAcres,
                                                               NumberOfStories = building.NumberofStories,
                                                               SquareFootage = building.Squarefootage,
                                                               FloodZone = building.FloodZone,
                                                               RoofConstruction = Convert.ToString(building.RoofConstructionCode),
                                                               RoofShowsSignsOfDeterioration = building.RoofShowsSignsOfDeterioration,
                                                               ShapeOfRoof = building.RoofShapeCode,
                                                               RoofAnchorCode = building.RoofAnchorCode,
                                                               RoofSheathingCode = building.RoofSheathingCode,
                                                               PrimaryHeatSourceCode = building.PrimaryHeatSourceCode,
                                                               AlternateHeatSourceCode = building.AlternateHeatSourceCode,
                                                               BasementType = building.BasementType,
                                                               GrossPremium = building.GrossPremium,
                                                               CrimeInsuranceAct = building.CrimeInsuranceAgreement,
                                                               EquipmentBreakdown = building.EquipmentBreakdown,
                                                               HomeSystemsProtection = building.HomeSystemsProtection,
                                                               ServiceLine = building.ServiceLine,
                                                               TotalInsuredValueFromtheGroundUp = building.Tivfgu,
                                                               RoofCoverage = building.RoofCoverage,
                                                               RoofCoverageValuationBasis = building.RoofCoverageValuationBasis,
                                                               TownHouse = building.TownHouse,
                                                               ForSale = building.ForSale,
                                                               HistoricRegistry = building.HistoricRegistry,
                                                               NewPurchase = building.NewPurchase,
                                                               EqBaseIsolation = building.EqbaseIsolation,
                                                               EqCladdingType = building.EqbaseIsolation,
                                                               EqConstructionQuality = building.EqconstructionQuality,
                                                               EqEquipmentSupportMaintenance = building.EqequipmentSupportMaintenance,
                                                               EqEngineeredFoundation = building.EqengineeredFoundation,
                                                               EqSprinklerLeakageCoverageFlag = building.EqsprinklerLeakageCoverageFlag,
                                                               EqAppendagesandOrnamentation = building.EqappendagesandOrnamentation,
                                                               EqFrameBolted = building.EqframeBolted,
                                                               EqUnreinforcedMasonryPartitionsorChimneys = building.EqunreinforcedMasonryPartitionsorChimneys,
                                                               EqMechanicalandElectricalEquipmentEarthquakeBracing = building.EqmechanicalandElectricalEquipmentEarthquakeBracing,
                                                               EqVerticalIrregularity = building.EqverticalIrregularity,
                                                               EqPounding = building.Eqpounding,
                                                               EqPlanIrregularity = building.EqplanIrregularity,
                                                               EqShortColumnCondition = building.EqshortColumnCondition,
                                                               EqSprinklerLeakageSusceptibility = building.EqsprinklerLeakageSusceptibility,
                                                               EqSoftStory = building.EqsoftStory,
                                                               EqStructuralUpgrade = building.EqstructuralUpgrade,
                                                               EqTiltUpRetrofit = building.EqtiltUpRetrofit,
                                                               EqUnreinforcedMasonryRetrofit = building.EqunreinforcedMasonryRetrofit,
                                                               EqCrippleWalls = building.EqcrippleWalls,
                                                               HasTrampoline = building.HasTrampoline,
                                                               HasSwimmingPool = building.HasSwimmingPool,
                                                               HasSolarPanels = building.HasSolarPanels,
                                                               HasMultipleRoofingLayers = building.HasMultipleRoofingLayers,
                                                               DwellingType = building.DwellingType,
                                                               IsMobileHome = building.IsMobileHome,
                                                               IsVacant = building.IsVacant,
                                                               IsBuildersRisk = building.IsBuildersRisk,
                                                               HasConcreteBasement = building.HasConcreteBasement,
                                                               HasMortaredBlockFoundation = building.HasMortaredBlockFoundation,
                                                               HasStiltsOverWater = building.HasStiltsOverWater,
                                                               FirstFloorHeightAboveGround = building.FirstFloorHeightAboveGround,
                                                               FlFoundationType = building.FlfoundationType
                                                           },
                                                           PropertyCoverages = new List<PropertyCoverage>() {
                                                                                           policyTransaction.Aopdeductible.HasValue? new PropertyCoverage{
                                                                                                    PropertyCoverageType = "AOP",
                                                                                                    DeductibleAmount=policyTransaction.Aopdeductible,
                                                                                                    PremiumAmount = building.PropertyPremium
                                                                                           }:null,
                                                                                           policyTransaction.LimitBuildingCoverageA.HasValue? new PropertyCoverage{
                                                                                                    PropertyCoverageType="BuildingCoverageA",
                                                                                                    CoverageValuationBasis = building.BuildingCoverageAvaluationBasis?? l.BuildingCoverageAvaluationBasis,
                                                                                                    LimitAmount = policyTransaction.LimitBuildingCoverageA ,
                                                                                                    PremiumAmount = building.PropertyPremium
                                                                                           }:null,
                                                                                             policyTransaction.LimitOtherCoverageB.HasValue? new PropertyCoverage{
                                                                                                    PropertyCoverageType="LimitOtherCoverageB",
                                                                                                    CoverageValuationBasis = building.BuildingCoverageAvaluationBasis?? l.BuildingCoverageAvaluationBasis ,
                                                                                                    LimitAmount = policyTransaction.LimitOtherCoverageB ,
                                                                                                    PremiumAmount = building.PropertyPremium
                                                                                           }:null,
                                                                                              policyTransaction.QuakeDeductible.HasValue? new PropertyCoverage{
                                                                                                    PropertyCoverageType="Quake",
                                                                                                    LimitAmount = policyTransaction.QuakeLimit ,
                                                                                                    DeductibleAmount=   policyTransaction.QuakeDeductible,
                                                                                           }:null,
                                                                                               policyTransaction.WindLimit.HasValue? new PropertyCoverage{
                                                                                                    PropertyCoverageType = "Wind",
                                                                                                    LimitAmount = policyTransaction.WindLimit,

                                                                                           }:null,
                                                                                               policyTransaction.WindHailHurricaneDeductible.HasValue? new PropertyCoverage{
                                                                                                    PropertyCoverageType = "WindHailHurricane",
                                                                                                    DeductibleAmount=   policyTransaction.WindHailHurricaneDeductible,
                                                                                           }:null,
                                                                                               policyTransaction.PropertyPremium.HasValue? new PropertyCoverage{
                                                                                                    PropertyCoverageType = "Property",
                                                                                                    PremiumAmount =policyTransaction.TotalPropertyPremium,
                                                                                                    LimitAmount=policyTransaction.PropertyLimit,
                                                                                           }:null,
                                                                                       }
                                                       }).ToList()
                                     }),
                                     #endregion

                                     #region Transportation
                                     transportation = policyTransportation,
                                     policyTransaction.PropertyLimit,
                                     policyTransaction.PropertyPremium,
                                     policyTransaction.LiabilityPremium,
                                     policyTransaction.LiabilityLimit,
                                     #endregion

                                     policyTransaction.HistoricTiv1yearPrior,
                                     policyTransaction.HistoricTiv2yearPrior,
                                     policyTransaction.HistoricTiv3yearPrior,
                                     policyTransaction.NonEnginePricing,
                                     policyTransaction.HasLapsedPriorCoverage,
                                     policyTransaction.HasPriorCoverageWithNoLapse
                                 })
            #endregion
                                      .AsEnumerable()
            #region Construct Policy Risk Response
                                      .Select(policyTransaction =>
                                            new PolicyRecord
                                            {
                                                #region   Policy level columns
                                                RecordUniqueIdentifier = policyTransaction.FormSetId,
                                                RatingSessionId = policyTransaction.RatingSessionId,
                                                InsuredEntityId = policyTransaction.InsuredEntityId,
                                                ParentRui = policyTransaction.ParentRui,
                                                PricingEngineId = policyTransaction.PricingEngineId,
                                                PricingEngineQuoteEnquiryId = policyTransaction.EngineQuoteEnquiryId,
                                                AgencyName = agent == null ? null : agent.CompanyName,
                                                InvoiceNumber = policyTransaction.InvoiceNumber,
                                                AccountingEffectiveDate = policyTransaction.AccountingEffectiveDate,
                                                TransactionType = policyTransaction.TransactionType,
                                                CancellationCode = policyTransaction.CancellationCode,
                                                BusinessArea = policyTransaction.BusinessArea,
                                                SubCompanyId = policyTransaction.SubCompanyId,
                                                // InsuredName = policyTransaction.InsuredName,
                                                InsuredDoingBusinessAs = policyTransaction.InsuredDoingBusinessAs,
                                                AdditionalNamedInsured = policyTransaction.AdditionalNamedInsured,
                                                CertificateNumber = policyTransaction.CertificateNumber,
                                                PolicyNumber = policyTransaction.PolicyNo,
                                                EndorsementNumber = policyTransaction.EndorsementNumber,
                                                ExpiringPolicyNumber = policyTransaction.ExpiringPolicyNumber,
                                                PLorCommercialIndicator = policyTransaction.PlcommercialIndicator,
                                                CoverageForm = policyTransaction.CoverageForm,
                                                PlacementType = policyTransaction.PlacementType,
                                                CoInsurancePercentage = policyTransaction.CoInsurancePercentage,
                                                HereOnPercentage = policyTransaction.HereonPercentage,
                                                EffectiveDate = policyTransaction.EffectiveDate,
                                                ExpiryDate = policyTransaction.ExpirationDate,
                                                MailingStreet = policyTransaction.MailingStreet,
                                                MailingCity = policyTransaction.MailingCity,
                                                MailingCountry = "USA",
                                                MailingCounty = policyTransaction.MailingCounty,
                                                MailingState = policyTransaction.MailingState,
                                                MailingZipCode = policyTransaction.MailingZipCode,
                                                MailingCountryScheme = policyTransaction.MailingCountryScheme,
                                                MailingZipCodePlusFour = policyTransaction.MailingZipCodePlusFour,
                                                GrossPremium = policyTransaction.GrossPremium,
                                                NetCommission = policyTransaction.Commission,
                                                NetPremium = policyTransaction.NetPremium,
                                                Payable = policyTransaction.Payable,
                                                FullTermPremiumChange = policyTransaction.FullTermEndorsementPremium,
                                                MinimumPropertyAdjustmentPremium = policyTransaction.MinimumPropertyAdjustmentPremium,
                                                MinimumCrimeAdjustmentPremium = policyTransaction.MinimumCrimeAdjustmentPremium,
                                                MinFloodDeductible = policyTransaction.MinFloodDeductible,
                                                CrimeInsuranceAct = policyTransaction.CrimeInsuranceAgreement,
                                                IdentityTheftRecovery = policyTransaction.IdentityTheftRecovery,
                                                TotalInsuredValueFromtheGroundUp = policyTransaction.Tivfgu,
                                                AttachmentPoint = policyTransaction.AttachmentPoint,
                                                GlAggregateLimit = policyTransaction.GlaggregateLimit,
                                                LiabilityClasses = policyTransaction.LiabilityClasses.Any(l => l.LiabilityCoverages.Any(c => c != null)) ? policyTransaction.LiabilityClasses : null,
                                                Contracts = policyTransaction.Contracts,
                                                CedingCompanyNameRetailAgent = policyTransaction.CedingCoNameRetailAgent,
                                                PolicyProcessorSystemName = policyTransaction.PolicyProcessorSystemName,
                                                PolicyForm = policyTransaction.PolicyForm,
                                                UnderwriterName = policyTransaction.UnderwriterName,
                                                InsuredEntityType = policyTransaction.InsuredEntityType,
                                                Bankruptcy = policyTransaction.Bankruptcy,
                                                Foreclosure = policyTransaction.Foreclosure,
                                                StructuresRentedOffPremisesCoverage = policyTransaction.StructuresRentedOffPremisesCoverage,
                                                StructuresRentedOnPremisesCoverage = policyTransaction.StructuresRentedOnPremisesCoverage,
                                                ExtendedLiabilityToRentedLocationsCoverage = policyTransaction.ExtendedLiabilityToRentedLocationsCoverage,
                                                LapseInCoverage = policyTransaction.LapseInCoverage,
                                                TrampolineIsCovered = policyTransaction.TrampolineIsCovered,
                                                SwimmingPoolIsCovered = policyTransaction.SwimmingPoolIsCovered,
                                                ModifierMarketPriceAdjustment = policyTransaction.ModifierMarketPriceAdjustment,
                                                DateOfLastLoss = policyTransaction.DateOfLastLoss,
                                                CoverageIsVandalismMischief = policyTransaction.CoverageIsVandalismMischief,
                                                RetroActiveDate = policyTransaction.RetroActiveDate,
                                                PriorLosses = policyTransaction.PriorLosses,
                                                Naic = policyTransaction.Naic,
                                                SltBrokerAddress = policyTransaction.SltbrokerAddress,
                                                SltBrokerName = policyTransaction.SltbrokerName,
                                                SltBrokerNumber = policyTransaction.SltbrokerNumber,
                                                SltState = policyTransaction.Sltstate,
                                                SurplusLinesTransactionNumber = policyTransaction.SurplusLinesTransactionNumber,
                                                #endregion

                                                #region Locations & Buildings & Transaportation
                                                Locations = policyTransaction.locations.ToList(),
                                                AutoPhysicalDamage = policyTransaction.transportation != null && policyTransaction.transportation.TransportationType.ToUpper().Equals("APD") ?
                                                                 new AutoPhysicalDamage
                                                                 {
                                                                     AnyOneCombination = policyTransaction.transportation.AnyOneCombination,
                                                                     ApdacvUnitBanding = policyTransaction.transportation.TempPolicyTransactionsTransportationApdacvunitBandings.Any() ?
                                                                        policyTransaction.transportation.TempPolicyTransactionsTransportationApdacvunitBandings.Select(a =>
                                                                         new LimitBand
                                                                         {
                                                                             DeductibleAmount = a.Aopdeductible,
                                                                             From = a.BandFrom,
                                                                             To = a.BandTo,
                                                                             UnitCount = a.UnitCount
                                                                         }).ToList() : null,
                                                                     ApdCommodities = policyTransaction.transportation.TempPolicyTransactionsTransportationApdcommodities.Any() ?
                                                                                        policyTransaction.transportation.TempPolicyTransactionsTransportationApdcommodities.Select(a =>
                                                                                         new ApdCommodity
                                                                                         {
                                                                                             ApdCommodityScheme = a.ApdcommodityScheme,
                                                                                             ApdCommodityType = a.ApdcommodityType
                                                                                         }).ToList() : null,
                                                                     AvgValueInATerminal = policyTransaction.transportation.AvgValueInAterminal,
                                                                     CargoCommodity = policyTransaction.transportation.TempPolicyTransactionsTransportationCargoCommodities.Any() ?
                                                                                        policyTransaction.transportation.TempPolicyTransactionsTransportationCargoCommodities.Select(c =>
                                                                                         new CargoCommodity
                                                                                         {
                                                                                             CargoCommodityPercentage = c.CargoCommodityPercentage,
                                                                                             CargoCommodityScheme = c.CargoCommodityScheme,
                                                                                             CargoCommodityType = c.CargoCommodityType
                                                                                         }).ToList() : null,
                                                                     DotNumber = policyTransaction.transportation.Dotnumber,
                                                                     PremiumAmount = policyTransaction.PropertyPremium,
                                                                     McNumber = policyTransaction.transportation.Mcnumber,
                                                                     NoOfUnits = policyTransaction.transportation.NoOfUnits,
                                                                     RadiusOfUse = policyTransaction.transportation.RadiusOfUse,
                                                                     TotalActualCashValueOfScheduledItems = policyTransaction.transportation.TotalActualCashValueOfScheduledItems,
                                                                     YearsInBusiness = policyTransaction.transportation.YearsInBusiness,
                                                                     Vehicles = policyTransaction.transportation.TempPolicyTransactionsTransportationVehicleDetails.Any() ?
                                                                                policyTransaction.transportation.TempPolicyTransactionsTransportationVehicleDetails.Select(t =>
                                                                                     new VehicleDetails()
                                                                                     {
                                                                                         Acv = t.Acv,
                                                                                         Make = t.Make,
                                                                                         Model = t.Model,
                                                                                         Vin = t.Vin,
                                                                                         TypeOfVehicle = t.TypeOfVehicle,
                                                                                         Year = t.Year,

                                                                                     }).ToList() : null,
                                                                     Trailers = policyTransaction.transportation.TempPolicyTransactionsTransportationTrailerDetails.Any() ?
                                                                                policyTransaction.transportation.TempPolicyTransactionsTransportationTrailerDetails.Select(t =>
                                                                                      new TrailerDetails()
                                                                                      {
                                                                                          Acv = t.Acv,
                                                                                          Make = t.Make,
                                                                                          Model = t.Model,
                                                                                          NonOwnedTrailer = t.NonOwnedTrailer,
                                                                                          TypeOfTrailer = t.TypeOfTrailer,
                                                                                      }
                                                                                     ).ToList() : null,
                                                                     HighestValuedPowerUnit = policyTransaction.transportation.HighestValuedPowerUnit,
                                                                     HighestValuedTrailer = policyTransaction.transportation.HighestValuedTrailer,
                                                                     TrailerInterchange = new TrailerInterchange
                                                                     {
                                                                         DeductibleAmount = policyTransaction.transportation.TrailerInterchangeDeductible,
                                                                         EstimatedTrailerDays = policyTransaction.transportation.TrailerInterchangeEstTrailerDays,
                                                                         LimitAmount = policyTransaction.transportation.TrailerInterchangeLimit,
                                                                         NoOfPowerUnits = policyTransaction.transportation.TrailerInterchangeNoOfPowerUnits,
                                                                         PremiumAmount = policyTransaction.transportation.TrailerInterchangePremium
                                                                     },
                                                                     HiredVehicle = new HiredVehicle
                                                                     {
                                                                         AnnualCostOfRentals = policyTransaction.transportation.HiredVehicleAnnualCostOfRentals,
                                                                         LimitAmount = policyTransaction.transportation.HiredVehicleLimit,
                                                                         IsReplacementOfScheduledUnit = policyTransaction.transportation.HiredVehicleReplacementOfScheduledUnit,
                                                                         NoOfConcurrentUnitsRented = policyTransaction.transportation.HiredVehicleNoOfConcurrentUnitsRented,
                                                                         RentedAdditionalUnitsFrequency = policyTransaction.transportation.HiredVehicleRentedAdditionalUnitsFrequency
                                                                     },
                                                                     DriversOutsideCriteria = policyTransaction.transportation.DriversOutsideCriteria,
                                                                     TransportationCoverages = new List<TransportationCoverage>() {
                                                                                          policyTransaction.transportation.AnyOneLoss.HasValue ?
                                                                                                new TransportationCoverage {
                                                                                                        TransportationCoverageType = "AnyOneLoss",
                                                                                                        LimitAmount = policyTransaction.PropertyLimit,
                                                                                                        PremiumAmount = policyTransaction.PropertyPremium,
                                                                                                        Rate= policyTransaction.Rate
                                                                                                    }:null,
                                                                                          policyTransaction.transportation.AnyOneUnit.HasValue ?
                                                                                                new TransportationCoverage {
                                                                                                        TransportationCoverageType = "AnyOneUnit",
                                                                                                        LimitAmount = policyTransaction.transportation.AnyOneUnit
                                                                                                    }:null,
                                                                                          policyTransaction.transportation.TowingStorageDebrisRemovalLimit.HasValue ?
                                                                                                new TransportationCoverage {
                                                                                                        TransportationCoverageType = "TowingStorageDebrisRemoval",
                                                                                                        LimitAmount = policyTransaction.transportation.TowingStorageDebrisRemovalLimit
                                                                                                    }:null
                                                                                                },
                                                                     TotalWrittenOffOnEndorsement = policyTransaction.transportation.TotalWrittenOffOnEndorsement
                                                                 } : null,
                                                DealersOpenLot = policyTransaction.transportation != null && policyTransaction.transportation.TransportationType.ToUpper().Equals("DOL") ?
                                                                 new DealersOpenLot
                                                                 {
                                                                     AnyOneUnit = policyTransaction.transportation.AnyOneUnit,
                                                                     AvgNoOfUnits = policyTransaction.transportation.AvgNoOfUnits,
                                                                     AvgValuePerUnit = policyTransaction.transportation.AvgValuePerUnit,
                                                                     MaxNoOfUnits = policyTransaction.transportation.MaxNoOfUnits,
                                                                     MaxValuePerUnit = policyTransaction.transportation.MaxNoOfUnits,
                                                                     NatureOfLocations = policyTransaction.transportation.NatureOfLocations,
                                                                     RadiusOfUse = policyTransaction.transportation.RadiusOfUse,
                                                                     TransportationCoverages = new List<TransportationCoverage>() {
                                                                                          policyTransaction.transportation.AnyOneLoss.HasValue ?
                                                                                                new TransportationCoverage {
                                                                                                        TransportationCoverageType = "AnyOneLoss",
                                                                                                        LimitAmount = policyTransaction.PropertyLimit,
                                                                                                        PremiumAmount = policyTransaction.PropertyPremium
                                                                                                    }:null,
                                                                                          policyTransaction.transportation.AnyOneUnit.HasValue ?
                                                                                                new TransportationCoverage {
                                                                                                        TransportationCoverageType = "AnyOneUnit",
                                                                                                        LimitAmount = policyTransaction.transportation.AnyOneUnit
                                                                                                    }:null,
                                                                                          policyTransaction.transportation.AnyOneCombination.HasValue ?
                                                                                                new TransportationCoverage {
                                                                                                        TransportationCoverageType = "AnyOneCombination",
                                                                                                        LimitAmount = policyTransaction.transportation.AnyOneCombination
                                                                                                    }:null,
                                                                                          policyTransaction.transportation.TowingStorageDebrisRemovalLimit.HasValue ?
                                                                                                new TransportationCoverage {
                                                                                                        TransportationCoverageType = "DebrisRemoval",
                                                                                                        LimitAmount = policyTransaction.transportation.TowingStorageDebrisRemovalLimit
                                                                                                    }:null
                                                                                                },
                                                                     TypeOfUnits = policyTransaction.transportation.TypeOfUnits,
                                                                     YearsInBusiness = policyTransaction.transportation.YearsInBusiness
                                                                 } : null,
                                                GarageKeepersLegalLiability = policyTransaction.transportation != null && policyTransaction.transportation.TransportationType.ToUpper().Equals("GKL") ?
                                                                 new GarageKeepersLegalLiability
                                                                 {
                                                                     AvgNoOfUnits = policyTransaction.transportation.AvgNoOfUnits,
                                                                     AvgValuePerUnit = policyTransaction.transportation.AvgValuePerUnit,
                                                                     LimitAmount = policyTransaction.PropertyLimit, // ASK which column or its calc ?
                                                                     MaxNoOfUnits = policyTransaction.transportation.MaxNoOfUnits,
                                                                     YearsInBusiness = policyTransaction.transportation.YearsInBusiness,
                                                                     NatureOfLocations = policyTransaction.transportation.NatureOfLocations,
                                                                     NatureOfTrade = policyTransaction.transportation.NatureOfTrade,
                                                                     NoOfWreckerTowingUnits = policyTransaction.transportation.NoOfWreckerTowingUnits,
                                                                     PremiumAmount = policyTransaction.PropertyPremium,
                                                                     TransportationCoverages = new List<TransportationCoverage>() {
                                                                                          policyTransaction.transportation.AnyOneLoss.HasValue ?
                                                                                                new TransportationCoverage {
                                                                                                        TransportationCoverageType = "AnyOneLoss",
                                                                                                        LimitAmount = policyTransaction.PropertyLimit,
                                                                                                        PremiumAmount = policyTransaction.PropertyPremium
                                                                                                    }:null,
                                                                                          policyTransaction.transportation.AnyOneUnit.HasValue ?
                                                                                                new TransportationCoverage {
                                                                                                        TransportationCoverageType = "AnyOneUnit",
                                                                                                        LimitAmount = policyTransaction.transportation.AnyOneUnit
                                                                                                    }:null,
                                                                                          policyTransaction.transportation.AnyOneCombination.HasValue ?
                                                                                                new TransportationCoverage {
                                                                                                        TransportationCoverageType = "AnyOneCombination",
                                                                                                        LimitAmount = policyTransaction.transportation.AnyOneCombination
                                                                                                    }:null,
                                                                                          policyTransaction.transportation.TowingStorageDebrisRemovalLimit.HasValue ?
                                                                                                new TransportationCoverage {
                                                                                                        TransportationCoverageType = "DebrisRemoval",
                                                                                                        LimitAmount = policyTransaction.transportation.TowingStorageDebrisRemovalLimit
                                                                                                    }:null,
                                                                     },
                                                                     TypeOfLiability = policyTransaction.transportation.TypeOfLiability
                                                                 } : null,
                                                MotorTruckCargo = policyTransaction.transportation != null && policyTransaction.transportation.TransportationType.ToUpper().Equals("MTC") ?
                                                                 new MotorTruckCargo
                                                                 {
                                                                     AnyOneLoss = policyTransaction.transportation.AnyOneLoss,
                                                                     AnyOneUnit = policyTransaction.transportation.AnyOneUnit,
                                                                     AvgValuePerShipment = policyTransaction.transportation.AvgValuePerShipment,
                                                                     TransportationCoverages = new List<TransportationCoverage>() {
                                                                                          policyTransaction.transportation.AnyOneLoss.HasValue ?
                                                                                                new TransportationCoverage {
                                                                                                        TransportationCoverageType = "AnyOneLoss",
                                                                                                        LimitAmount = policyTransaction.PropertyLimit,
                                                                                                        PremiumAmount = policyTransaction.PropertyPremium
                                                                                                    }:null,
                                                                                          policyTransaction.transportation.AnyOneUnit.HasValue ?
                                                                                                new TransportationCoverage {
                                                                                                        TransportationCoverageType = "AnyOneUnit",
                                                                                                        LimitAmount = policyTransaction.transportation.AnyOneUnit
                                                                                                    }:null,
                                                                                          policyTransaction.transportation.AnyOneCombination.HasValue ?
                                                                                                new TransportationCoverage {
                                                                                                        TransportationCoverageType = "AnyOneCombination",
                                                                                                        LimitAmount = policyTransaction.transportation.AnyOneCombination
                                                                                                    }:null,
                                                                                          policyTransaction.transportation.TowingStorageDebrisRemovalLimit.HasValue ?
                                                                                                new TransportationCoverage {
                                                                                                        TransportationCoverageType = "DebrisRemoval",
                                                                                                        LimitAmount = policyTransaction.transportation.TowingStorageDebrisRemovalLimit
                                                                                                    }:null,
                                                                     },
                                                                     CargoCommodities = policyTransaction.transportation.TempPolicyTransactionsTransportationCargoCommodities.Any() ?
                                                                                policyTransaction.transportation.TempPolicyTransactionsTransportationCargoCommodities.Select(c =>
                                                                                 new CargoCommodity()
                                                                                 {
                                                                                     CargoCommodityPercentage = c.CargoCommodityPercentage,
                                                                                     CargoCommodityScheme = c.CargoCommodityScheme,
                                                                                     CargoCommodityType = c.CargoCommodityType
                                                                                 }).ToList() : null,
                                                                     DotNumber = policyTransaction.transportation.Dotnumber,
                                                                     DriversOutsideCriteria = policyTransaction.transportation.DriversOutsideCriteria,
                                                                     LimitAmount = policyTransaction.PropertyLimit, // ASK which column,
                                                                     McNumber = policyTransaction.transportation.Mcnumber,
                                                                     NoOfUnits = policyTransaction.transportation.NoOfUnits,
                                                                     PremiumAmount = policyTransaction.PropertyPremium,
                                                                     RadiusOfUse = policyTransaction.transportation.RadiusOfUse,
                                                                     TotalValueAtAnyOneTerminal = policyTransaction.transportation.TotalValueAtAnyOneTerminal,
                                                                     TotalWrittenOffOnEndorsement = policyTransaction.transportation.TotalWrittenOffOnEndorsement,
                                                                     TrailerInterchange = new TrailerInterchange
                                                                     {
                                                                         DeductibleAmount = policyTransaction.transportation.TrailerInterchangeDeductible,
                                                                         EstimatedTrailerDays = policyTransaction.transportation.TrailerInterchangeEstTrailerDays,
                                                                         LimitAmount = policyTransaction.transportation.TrailerInterchangePremium,
                                                                         NoOfPowerUnits = policyTransaction.transportation.TrailerInterchangeNoOfPowerUnits,
                                                                         PremiumAmount = policyTransaction.transportation.TrailerInterchangePremium
                                                                     }
                                                                 } : null,
                                                #endregion

                                                HistoricTiv1YearPrior = policyTransaction.HistoricTiv1yearPrior,
                                                HistoricTiv2YearPrior = policyTransaction.HistoricTiv2yearPrior,
                                                HistoricTiv3YearPrior = policyTransaction.HistoricTiv3yearPrior,
                                                NonEnginePricing = policyTransaction.NonEnginePricing,
                                                HasLapsedPriorCoverage = policyTransaction.HasLapsedPriorCoverage,
                                                HasPriorCoverageWithNoLapse = policyTransaction.HasPriorCoverageWithNoLapse
                                            }).ToList();
            #endregion

            return new RiskResponse { PolicyRecord = policyRecords };

        }
        private RiskResponse GetCommercialPackageOrHomeOwnersOrPersonalLinesRiskResponse(int companyId, string contractRef, int contractYear, string policyNo, DateTime accountingEffectiveDate, bool IsMonthlyRiskData = true, string recordUniqueIdentifier = null)
        {
            contractRef = contractRef.Trim();
            var agent = _universalBDXRepository.GetAgents().FirstOrDefault(a => a.CompanyId == companyId);
            var tempPolicyTransactions = (from policyTransaction in _universalBDXRepository.GetTempPolicyTransactions().Where(t => t.CompanyId == companyId)
                                             .Include(t => t.TempPolicyTransactionsIsoglclasses)
                                             .Include(t => t.TempPolicyTransactionsLocations)
                                             .ThenInclude(l => l.TempPolicyTransactionsLocationsBuildings)
                                             .Include(t => t.TempPolicyTransactionsDocucorpIncludedForms)
                                             .Include(t => t.TempPolicyTransactionsPriorLosses)
                                             .Where(l => l.CorrectedBy == null && (l.IgnoreRecord != true))
                                           select policyTransaction);

            if (IsMonthlyRiskData)
            {
                tempPolicyTransactions = tempPolicyTransactions.Where(p => p.AccountingEffectiveDate.Value.Month == accountingEffectiveDate.Month);
                tempPolicyTransactions = tempPolicyTransactions.Where(p => p.AccountingEffectiveDate.Value.Year == accountingEffectiveDate.Year);           
            }

            if (!IsMonthlyRiskData)
            {
                policyNo = policyNo.Trim();
                tempPolicyTransactions = tempPolicyTransactions.Where(p => p.PolicyNo.Equals(policyNo));
                if (!string.IsNullOrEmpty(recordUniqueIdentifier) && !string.IsNullOrWhiteSpace(recordUniqueIdentifier))
                {
                    recordUniqueIdentifier = recordUniqueIdentifier.Trim();
                    tempPolicyTransactions = tempPolicyTransactions.Where(p => p.FormSetId.Equals(recordUniqueIdentifier));
                }
            }

            var tempPolicyTransactionsContracts = _universalBDXRepository.GetTempPolicyTransactionsContracts()
                                                                .Where(c => c.CompanyId == companyId)
                                                                .Where(c => c.ContractYear == contractYear)
                                                                .Where(c => c.ContractRef.Equals(contractRef));

            if (tempPolicyTransactionsContracts == null || tempPolicyTransactionsContracts.Count() == 0 || tempPolicyTransactions == null || tempPolicyTransactions.Count() == 0)
                return new RiskResponse();

            var policyRecords = (from policyTransaction in tempPolicyTransactions
                                 join policyContract in tempPolicyTransactionsContracts
                                        on policyTransaction.TempPremiumsId equals policyContract.TempPremiumsId

                                 #region Select only required columns
                                 select new
                                 {
                                     #region TempPolicyTrans columns
                                     policyTransaction.FormSetId,
                                     policyTransaction.RatingSessionId,
                                     policyTransaction.InsuredEntityId,
                                     policyTransaction.ParentRui,
                                     policyTransaction.PricingEngineId,
                                     policyTransaction.EngineQuoteEnquiryId,
                                     policyTransaction.InvoiceNumber,
                                     policyTransaction.AccountingEffectiveDate,
                                     policyTransaction.TransactionType,
                                     policyTransaction.CancellationCode,
                                     policyTransaction.BusinessArea,
                                     policyTransaction.SubCompanyId,
                                     // policyTransaction.InsuredName, commented out to avoid exposing all information
                                     policyTransaction.InsuredDoingBusinessAs,
                                     policyTransaction.AdditionalNamedInsured,
                                     policyTransaction.CertificateNumber,
                                     policyTransaction.PolicyNo,
                                     policyTransaction.EndorsementNumber,
                                     policyTransaction.ExpiringPolicyNumber,
                                     policyTransaction.PlcommercialIndicator,
                                     policyTransaction.CoverageForm,
                                     policyTransaction.PlacementType,
                                     policyTransaction.CoInsurancePercentage,
                                     policyTransaction.HereonPercentage,
                                     policyTransaction.EffectiveDate,
                                     policyTransaction.ExpirationDate,
                                     policyTransaction.MailingStreet,
                                     policyTransaction.MailingCity,
                                     policyTransaction.MailingCounty,
                                     policyTransaction.MailingState,
                                     policyTransaction.MailingZipCode,
                                     policyTransaction.MailingCountryScheme,
                                     policyTransaction.MailingZipCodePlusFour,
                                     policyTransaction.GrossPremium,
                                     policyTransaction.Commission,
                                     policyTransaction.Payable,
                                     policyTransaction.FullTermEndorsementPremium,
                                     policyTransaction.MinimumPropertyAdjustmentPremium,
                                     policyTransaction.MinimumCrimeAdjustmentPremium,
                                     policyTransaction.MinFloodDeductible,
                                     policyTransaction.CrimeInsuranceAgreement,
                                     policyTransaction.IdentityTheftRecovery,
                                     policyTransaction.Tivfgu,
                                     policyTransaction.AttachmentPoint,
                                     policyTransaction.GlaggregateLimit,
                                     policyTransaction.SurveyFees,
                                     policyTransaction.SltbrokerNumber,
                                     policyTransaction.SltbrokerName,
                                     policyTransaction.SltbrokerAddress,
                                     policyTransaction.Sltstate,
                                     policyTransaction.SurplusLinesTransactionNumber,
                                     policyTransaction.Naic,
                                     policyTransaction.CedingCoNameRetailAgent,
                                     policyTransaction.NetPremium,
                                     LiabilityClasses = new List<LiabilityClass>() {
                                                               new LiabilityClass
                                                               {
                                                                   LiabilityCoverages = new List<LiabilityCoverage> {
                                                                      policyTransaction.GlaggregateLimit.HasValue? new LiabilityCoverage{
                                                                          LiabilityCoverageType = "GeneralAggregate",
                                                                          LimitAmount = policyTransaction.GlaggregateLimit
                                                                    }:null,
                                                                      !string.IsNullOrEmpty(policyTransaction.DocucorpProductCompletedOper)? new LiabilityCoverage{
                                                                          LiabilityCoverageType = "ProductsCompletedOperations",
                                                                          LimitAmount = Convert.ToDecimal(policyTransaction.DocucorpProductCompletedOper)
                                                                    }:null,
                                                                        !string.IsNullOrEmpty(policyTransaction.DocucorpPersonalAndAdvertising)? new LiabilityCoverage{
                                                                          LiabilityCoverageType = "PersonalAdvertisingInjury",
                                                                          LimitAmount = Convert.ToDecimal(policyTransaction.DocucorpPersonalAndAdvertising)
                                                                    }:null,
                                                                        !string.IsNullOrEmpty( policyTransaction.DocucorpDamagePremRented)? new LiabilityCoverage{
                                                                          LiabilityCoverageType = "FireDamage",
                                                                          LimitAmount = Convert.ToDecimal(policyTransaction.DocucorpDamagePremRented)
                                                                    }:null,
                                                                        !string.IsNullOrEmpty( policyTransaction.DocucorpMedExpenseLmt)? new LiabilityCoverage{
                                                                          LiabilityCoverageType = "MedicalExpenses",
                                                                          LimitAmount = Convert.ToDecimal(policyTransaction.DocucorpMedExpenseLmt)
                                                                    }:null,
                                                                         policyTransaction.LiabilityLimit.HasValue? new LiabilityCoverage{
                                                                          LiabilityCoverageType = "EachOccurrence",
                                                                          LimitAmount = policyTransaction.LiabilityLimit
                                                                    }:null
                                                                   }
                                                               }},
                                     #endregion

                                     Contracts = policyTransaction.TempPolicyTransactionsContracts.Where(c => c.TempPremiumsId == policyTransaction.TempPremiumsId)
                                                                                 .Select(contract => new Contract
                                                                                 {
                                                                                     ContractRef = contract.ContractRef,
                                                                                     Commission = contract.CommissionPercentage,
                                                                                     ContractPercentage = contract.ContractShare,
                                                                                     ContractPeriod = contract.ContractYear,
                                                                                     EquipmentBreakdownPercentage = contract.EquipmentBreakdownShare,
                                                                                     LiabilityPercentage = contract.LiabilityShare,
                                                                                     SectionNo = string.IsNullOrEmpty(contract.ContractRef.Substring(4)) ? null : contract.ContractRef.Substring(4),
                                                                                 }).ToList(),
                                     policyTransaction.PolicyProcessorSystemName,
                                     PolicyForm = policyTransaction.TempPolicyTransactionsDocucorpIncludedForms.Any() ?
                                                        policyTransaction.TempPolicyTransactionsDocucorpIncludedForms.Select(df =>
                                                                new PolicyFormDetail
                                                                {
                                                                    FormDescription = df.Description,
                                                                    FormEditionDate = df.EditionDate,
                                                                    FormName = df.FormName
                                                                }).ToList() : null,
                                     policyTransaction.UnderwriterName,
                                     policyTransaction.InsuredEntityType,
                                     policyTransaction.Bankruptcy,
                                     policyTransaction.Foreclosure,
                                     InHomeBusinessCoverage = new InHomeBusinessCoverage
                                     {
                                         BusinessName = policyTransaction.BusinessArea, // ASK for confirmation
                                         GrossReceipts = policyTransaction.GrossPremium, // ASK for confirmation
                                         NumberOfEmployees = policyTransaction.InHomeBusinessCoverageNoEmployees,
                                         TypeOfBusiness = policyTransaction.InHomeBusinessCoverageTypeOfBusiness
                                     },
                                     policyTransaction.StructuresRentedOffPremisesCoverage,
                                     policyTransaction.StructuresRentedOnPremisesCoverage,
                                     policyTransaction.ExtendedLiabilityToRentedLocationsCoverage,
                                     policyTransaction.LapseInCoverage,
                                     policyTransaction.TrampolineIsCovered,
                                     policyTransaction.SwimmingPoolIsCovered,
                                     policyTransaction.ModifierMarketPriceAdjustment,
                                     policyTransaction.DateOfLastLoss,
                                     policyTransaction.CoverageIsVandalismMischief,
                                     policyTransaction.RetroActiveDate,
                                     PriorLosses = policyTransaction.TempPolicyTransactionsPriorLosses.Any() ?
                                                    policyTransaction.TempPolicyTransactionsPriorLosses.Where(p => p.TempPremiumsId == policyTransaction.TempPremiumsId)
                                                            .Select(priorLoss =>
                                                                      new PriorLoss
                                                                      {
                                                                          CauseOfLoss = priorLoss.CauseOfLoss,
                                                                          ClaimStatus = priorLoss.ClaimStatus,
                                                                          DateOfLoss = priorLoss.DateOfLoss,
                                                                          TotalIncurred = priorLoss.TotalIncurred
                                                                      }).ToList() : null,
                                     #region Locations & Buildings
                                     locations = policyTransaction.TempPolicyTransactionsLocations
                                                        .Select(l =>
                                       new LocationRecord
                                       {
                                           LocationNumber = int.Parse(l.LocationNumber),
                                           LiabilityClasses = l.TempPolicyTransactionsLocationsIsoglclasses.Any() ?
                                                                   l.TempPolicyTransactionsLocationsIsoglclasses.Select(iso =>
                                                                   new LiabilityClass
                                                                   {
                                                                       IsoglClassCode = iso.SubCoverageCode,
                                                                       LiabilityCoverages = new List<LiabilityCoverage>{
                                                                              new LiabilityCoverage
                                                                                 {
                                                                                   CoverageForm=  policyTransaction.CoverageForm,
                                                                                   PremiumAmount=  policyTransaction.LiabilityPremium,
                                                                                   LimitAmount   =  policyTransaction.LiabilityLimit
                                                                                 }},
                                                                       PremiumBasis = l.PremiumBasis,
                                                                       PremiumBasisValue = l.PremiumBasisValue,
                                                                       TerritoriesCode = l.TerritoriesCode,
                                                                       SubCoverageCode = l.SubCoverageCode
                                                                   }).ToList() : null,
                                           Buildings =
                                                       l.TempPolicyTransactionsLocationsBuildings.Select(building => new BuildingRecord
                                                       {
                                                           BuildingNumber = building.BuildingNumber,
                                                           InsuredStreet = building.InsuredStreet,
                                                           InsuredCity = building.InsuredCity,
                                                           InsuredState = building.InsuredState,
                                                           InsuredZipCode = building.InsuredZipCode,
                                                           InsuredCounty = building.InsuredCounty,
                                                           Country = building.InsuredCountryCode,
                                                           InsuredZipCodePlusFour = building.InsuredZipCodePlusFour,
                                                           CountryScheme = building.InsuredCountryScheme,
                                                           CoverageIsVandalismMischief = building.CoverageIsVandalismMischief,
                                                           OccupancyScheme = building.OccupancyScheme,
                                                           OccupancyCode = building.OccupancyCode,
                                                           DwellingType = building.DwellingType,
                                                           LiabilityClasses =
                                                               building.TempPolicyTransactionsLocationsBuildingsIsoglclasses.Select(lc =>
                                                                   new LiabilityClass
                                                                   {
                                                                       IsoglClassCode = lc.Isoglclass,
                                                                       LiabilityCoverages = new List<LiabilityCoverage> {
                                                                           new LiabilityCoverage
                                                                           {
                                                                                 LiabilityCoverageType = "Liability",
                                                                                 LimitAmount = policyTransaction.LiabilityLimit,
                                                                                 PremiumAmount =policyTransaction.LiabilityPremium
                                                                           }
                                                                        },
                                                                       PremiumBasis = lc.PremiumBasis,
                                                                       PremiumBasisValue = lc.PremiumBasisValue,
                                                                       TerritoriesCode = lc.TerritoriesCode,
                                                                       SubCoverageCode = lc.SubCoverageCode
                                                                   }).ToList(),
                                                           BuildingCharacteristics = new BuildingCharacteristics
                                                           {
                                                               MgaDistanceToCoastMiles = building.MgadistanceToCoastMiles,
                                                               MgaLatitude = building.Mgalatitude,
                                                               MgaLongitude = building.Mgalongitude,
                                                               IsoPropertyCode = building.IsopropertyCode,
                                                               ConstructionScheme = building.ConstructionCodeScheme,
                                                               ConstructionCode = building.ConstructionCode,
                                                               RentalTerm = building.RentalTerm,
                                                               ProtectionClass = building.ProtectionClass,
                                                               Protections = building.Protections,
                                                               OpeningProtectionsCode = building.OpeningProtectionsCode,
                                                               OpeningProtectionTypesCode = building.OpeningProtectionTypesCode,
                                                               CentralBurglarProtection = building.CentralBurglarProtection,
                                                               CentralFireProtection = building.CentralFireProtection,
                                                               LocalBurglarProtection = building.LocalBurglarProtection,
                                                               LocalFireProtection = building.LocalFireProtection,
                                                               PoliceStationBurglarAlarmProtection = building.PoliceStationBurglarAlarmProtection,
                                                               FireExtinguisherProtection = building.FireExtinguisherProtection,
                                                               SmokeDetectorsProtection = building.SmokeDetectorsProtection,
                                                               SprinklersProtection = building.SprinklersProtection,
                                                               WaterShutOffValveProtection = building.WaterShutOffValveProtection,
                                                               WaterShutOffWithAlarmProtection = building.WaterShutOffWithAlarmProtection,
                                                               GatedCommunityProtection = building.GatedCommunityProtection,
                                                               StormShuttersProtection = building.StormShuttersProtection,
                                                               ImpactResistantGlassProtection = building.ImpactResistantGlassProtection,
                                                               FireStationAlarmProtection = building.FireStationAlarmProtection,
                                                               AnsulProtection = building.AnsulProtection,
                                                               YearBuilt = building.YearBuilt,
                                                               NumberOfAcres = building.NumberOfAcres,
                                                               NumberOfStories = building.NumberofStories,
                                                               SquareFootage = building.Squarefootage,
                                                               FloodZone = building.FloodZone,
                                                               RoofConstruction = Convert.ToString(building.RoofConstructionCode),
                                                               RoofShowsSignsOfDeterioration = building.RoofShowsSignsOfDeterioration,
                                                               ShapeOfRoof = building.RoofShapeCode,
                                                               RoofAnchorCode = building.RoofAnchorCode,
                                                               RoofSheathingCode = building.RoofSheathingCode,
                                                               PrimaryHeatSourceCode = building.PrimaryHeatSourceCode,
                                                               AlternateHeatSourceCode = building.AlternateHeatSourceCode,
                                                               BasementType = building.BasementType,
                                                               GrossPremium = building.GrossPremium,
                                                               CrimeInsuranceAct = building.CrimeInsuranceAgreement,
                                                               EquipmentBreakdown = building.EquipmentBreakdown,
                                                               HomeSystemsProtection = building.HomeSystemsProtection,
                                                               ServiceLine = building.ServiceLine,
                                                               TotalInsuredValueFromtheGroundUp = building.Tivfgu,
                                                               RoofCoverage = building.RoofCoverage,
                                                               RoofCoverageValuationBasis = building.RoofCoverageValuationBasis,
                                                               TownHouse = building.TownHouse,
                                                               ForSale = building.ForSale,
                                                               HistoricRegistry = building.HistoricRegistry,
                                                               NewPurchase = building.NewPurchase,
                                                               EqBaseIsolation = building.EqbaseIsolation,
                                                               EqCladdingType = building.EqbaseIsolation,
                                                               EqConstructionQuality = building.EqconstructionQuality,
                                                               EqEquipmentSupportMaintenance = building.EqequipmentSupportMaintenance,
                                                               EqEngineeredFoundation = building.EqengineeredFoundation,
                                                               EqSprinklerLeakageCoverageFlag = building.EqsprinklerLeakageCoverageFlag,
                                                               EqAppendagesandOrnamentation = building.EqappendagesandOrnamentation,
                                                               EqFrameBolted = building.EqframeBolted,
                                                               EqUnreinforcedMasonryPartitionsorChimneys = building.EqunreinforcedMasonryPartitionsorChimneys,
                                                               EqMechanicalandElectricalEquipmentEarthquakeBracing = building.EqmechanicalandElectricalEquipmentEarthquakeBracing,
                                                               EqVerticalIrregularity = building.EqverticalIrregularity,
                                                               EqPounding = building.Eqpounding,
                                                               EqPlanIrregularity = building.EqplanIrregularity,
                                                               EqShortColumnCondition = building.EqshortColumnCondition,
                                                               EqSprinklerLeakageSusceptibility = building.EqsprinklerLeakageSusceptibility,
                                                               EqSoftStory = building.EqsoftStory,
                                                               EqStructuralUpgrade = building.EqstructuralUpgrade,
                                                               EqTiltUpRetrofit = building.EqtiltUpRetrofit,
                                                               EqUnreinforcedMasonryRetrofit = building.EqunreinforcedMasonryRetrofit,
                                                               EqCrippleWalls = building.EqcrippleWalls,
                                                               HasTrampoline = building.HasTrampoline,
                                                               HasSwimmingPool = building.HasSwimmingPool,
                                                               HasSolarPanels = building.HasSolarPanels,
                                                               HasMultipleRoofingLayers = building.HasMultipleRoofingLayers,
                                                               DwellingType = building.DwellingType,
                                                               IsMobileHome = building.IsMobileHome,
                                                               IsVacant = building.IsVacant,
                                                               IsBuildersRisk = building.IsBuildersRisk,
                                                               HasConcreteBasement = building.HasConcreteBasement,
                                                               HasMortaredBlockFoundation = building.HasMortaredBlockFoundation,
                                                               HasStiltsOverWater = building.HasStiltsOverWater,
                                                               FirstFloorHeightAboveGround = building.FirstFloorHeightAboveGround,
                                                               FlFoundationType = building.FlfoundationType,
                                                               UtilityUpdates = new List<UtilityUpdate>() {
                                                                                       policyTransaction.RoofLastUpdated!=null ? new UtilityUpdate
                                                                                        {
                                                                                            Year = policyTransaction.RoofLastUpdated,
                                                                                            TypeOfUpdate = "FULL",
                                                                                            UtilityType = "Roof"
                                                                                        }: null,
                                                                                       policyTransaction.WiringLastUpdated !=null ?
                                                                                           new UtilityUpdate
                                                                                            {
                                                                                                Year = policyTransaction.WiringLastUpdated,
                                                                                                TypeOfUpdate = "FULL",
                                                                                                UtilityType = "Wiring"
                                                                                            }: null,
                                                                                        policyTransaction.PlumbingLastUpdated != null?
                                                                                            new UtilityUpdate
                                                                                            {
                                                                                                Year = policyTransaction.PlumbingLastUpdated,
                                                                                                TypeOfUpdate = "FULL",
                                                                                                UtilityType = "Plumbing"
                                                                                            }:null,
                                                                                        policyTransaction.HeatingLastUpdated!=null ?
                                                                                            new UtilityUpdate
                                                                                            {
                                                                                                Year = policyTransaction.HeatingLastUpdated,
                                                                                                TypeOfUpdate = "FULL",
                                                                                                UtilityType = "Heating"
                                                                                            }:null
                                                                                        }

                                                           },
                                                           PropertyCoverages = new List<PropertyCoverage>() {
                                                                                           policyTransaction.Aopdeductible.HasValue? new PropertyCoverage{
                                                                                                    PropertyCoverageType = "AOP",
                                                                                                    LimitAmount = policyTransaction.PropertyLimit,
                                                                                                    PremiumAmount = building.PropertyPremium
                                                                                           }:null,
                                                                                           policyTransaction.LimitBuildingCoverageA.HasValue? new PropertyCoverage{
                                                                                                    PropertyCoverageType="BuildingCoverageA",
                                                                                                    CoverageValuationBasis = building.BuildingCoverageAvaluationBasis?? l.BuildingCoverageAvaluationBasis ,
                                                                                                    LimitAmount = policyTransaction.LimitBuildingCoverageA ,
                                                                                                    PremiumAmount = building.PropertyPremium
                                                                                           }:null,
                                                                                             policyTransaction.LimitOtherCoverageB.HasValue? new PropertyCoverage{
                                                                                                    PropertyCoverageType="LimitOtherCoverageB",
                                                                                                    CoverageValuationBasis = building.BuildingCoverageAvaluationBasis?? l.BuildingCoverageAvaluationBasis ,
                                                                                                    LimitAmount = policyTransaction.LimitOtherCoverageB ,
                                                                                                    PremiumAmount = building.PropertyPremium
                                                                                           }:null,
                                                                                              policyTransaction.QuakeDeductible.HasValue? new PropertyCoverage{
                                                                                                    PropertyCoverageType="Quake",
                                                                                                    LimitAmount = policyTransaction.QuakeLimit ,
                                                                                                    DeductibleAmount=   policyTransaction.QuakeDeductible,
                                                                                           }:null,
                                                                                               policyTransaction.WindLimit.HasValue? new PropertyCoverage{
                                                                                                    PropertyCoverageType = "Wind",
                                                                                                    LimitAmount = policyTransaction.WindLimit,
                                                                                                    DeductibleAmount = policyTransaction.WindHailHurricaneDeductible

                                                                                           }:null,
                                                                                               policyTransaction.WindHailHurricaneDeductible.HasValue? new PropertyCoverage{
                                                                                                    PropertyCoverageType="WindHailHurricane",
                                                                                                    DeductibleAmount=   policyTransaction.WindHailHurricaneDeductible,
                                                                                                    LimitAmount = policyTransaction.PropertyLimit ,
                                                                                           }:null,
                                                                                       }
                                                       }).ToList()
                                       }),
                                     #endregion
                                     policyTransaction.HistoricTiv1yearPrior,
                                     policyTransaction.HistoricTiv2yearPrior,
                                     policyTransaction.HistoricTiv3yearPrior,
                                     policyTransaction.NonEnginePricing,
                                     policyTransaction.HasLapsedPriorCoverage,
                                     policyTransaction.HasPriorCoverageWithNoLapse
                                 })
            #endregion

            #region Construct Policy Risk Response
                                      .Select(policyTransaction =>
                                      new PolicyRecord
                                      {
                                          #region   Policy level columns
                                          RecordUniqueIdentifier = policyTransaction.FormSetId,
                                          RatingSessionId = policyTransaction.RatingSessionId,
                                          InsuredEntityId = policyTransaction.InsuredEntityId,
                                          ParentRui = policyTransaction.ParentRui,
                                          PricingEngineId = policyTransaction.PricingEngineId,
                                          PricingEngineQuoteEnquiryId = policyTransaction.EngineQuoteEnquiryId,
                                          AgencyName = agent.CompanyName ?? agent.CompanyName,
                                          InvoiceNumber = policyTransaction.InvoiceNumber,
                                          AccountingEffectiveDate = policyTransaction.AccountingEffectiveDate,
                                          TransactionType = policyTransaction.TransactionType,
                                          CancellationCode = policyTransaction.CancellationCode,
                                          BusinessArea = policyTransaction.BusinessArea,
                                          SubCompanyId = policyTransaction.SubCompanyId,
                                          //  InsuredName = policyTransaction.InsuredName,
                                          InsuredDoingBusinessAs = policyTransaction.InsuredDoingBusinessAs,
                                          AdditionalNamedInsured = policyTransaction.AdditionalNamedInsured,
                                          CertificateNumber = policyTransaction.CertificateNumber,
                                          PolicyNumber = policyTransaction.PolicyNo,
                                          EndorsementNumber = policyTransaction.EndorsementNumber,
                                          ExpiringPolicyNumber = policyTransaction.ExpiringPolicyNumber,
                                          PLorCommercialIndicator = policyTransaction.PlcommercialIndicator,
                                          CoverageForm = policyTransaction.CoverageForm,
                                          PlacementType = policyTransaction.PlacementType,
                                          CoInsurancePercentage = policyTransaction.CoInsurancePercentage,
                                          HereOnPercentage = policyTransaction.HereonPercentage,
                                          EffectiveDate = policyTransaction.EffectiveDate,
                                          ExpiryDate = policyTransaction.ExpirationDate,
                                          MailingStreet = policyTransaction.MailingStreet,
                                          MailingCity = policyTransaction.MailingCity,
                                          MailingCountry = "USA",
                                          MailingCounty = policyTransaction.MailingCounty,
                                          MailingState = policyTransaction.MailingState,
                                          MailingZipCode = policyTransaction.MailingZipCode,
                                          MailingCountryScheme = policyTransaction.MailingCountryScheme,
                                          MailingZipCodePlusFour = policyTransaction.MailingZipCodePlusFour,
                                          GrossPremium = policyTransaction.GrossPremium,
                                          NetPremium = policyTransaction.NetPremium,
                                          NetCommission = policyTransaction.Commission,
                                          Payable = policyTransaction.Payable,
                                          FullTermPremiumChange = policyTransaction.FullTermEndorsementPremium,
                                          MinimumPropertyAdjustmentPremium = policyTransaction.MinimumPropertyAdjustmentPremium,
                                          MinimumCrimeAdjustmentPremium = policyTransaction.MinimumCrimeAdjustmentPremium,
                                          MinFloodDeductible = policyTransaction.MinFloodDeductible,
                                          CrimeInsuranceAct = policyTransaction.CrimeInsuranceAgreement,
                                          IdentityTheftRecovery = policyTransaction.IdentityTheftRecovery,
                                          TotalInsuredValueFromtheGroundUp = policyTransaction.Tivfgu,
                                          AttachmentPoint = policyTransaction.AttachmentPoint,
                                          GlAggregateLimit = policyTransaction.GlaggregateLimit,
                                          //      LiabilityClasses = policyTransaction.LiabilityClasses,
                                          Contracts = policyTransaction.Contracts,
                                          PolicyProcessorSystemName = policyTransaction.PolicyProcessorSystemName,
                                          PolicyForm = policyTransaction.PolicyForm,
                                          UnderwriterName = policyTransaction.UnderwriterName,
                                          CedingCompanyNameRetailAgent = policyTransaction.CedingCoNameRetailAgent,
                                          InsuredEntityType = policyTransaction.InsuredEntityType,
                                          Bankruptcy = policyTransaction.Bankruptcy,
                                          Foreclosure = policyTransaction.Foreclosure,
                                          InHomeBusinessCoverage = policyTransaction.InHomeBusinessCoverage,
                                          StructuresRentedOffPremisesCoverage = policyTransaction.StructuresRentedOffPremisesCoverage,
                                          StructuresRentedOnPremisesCoverage = policyTransaction.StructuresRentedOnPremisesCoverage,
                                          ExtendedLiabilityToRentedLocationsCoverage = policyTransaction.ExtendedLiabilityToRentedLocationsCoverage,
                                          LapseInCoverage = policyTransaction.LapseInCoverage,
                                          TrampolineIsCovered = policyTransaction.TrampolineIsCovered,
                                          SwimmingPoolIsCovered = policyTransaction.SwimmingPoolIsCovered,
                                          ModifierMarketPriceAdjustment = policyTransaction.ModifierMarketPriceAdjustment,
                                          DateOfLastLoss = policyTransaction.DateOfLastLoss,
                                          CoverageIsVandalismMischief = policyTransaction.CoverageIsVandalismMischief,
                                          RetroActiveDate = policyTransaction.RetroActiveDate,
                                          PriorLosses = policyTransaction.PriorLosses,
                                          SltBrokerNumber = policyTransaction.SltbrokerNumber,
                                          SltBrokerName = policyTransaction.SltbrokerName,
                                          SltBrokerAddress = policyTransaction.SltbrokerAddress,
                                          SltState = policyTransaction.Sltstate,
                                          #endregion

                                          #region Locations & Buildings & Transaportation
                                          Locations = policyTransaction.locations.ToList(),
                                          #endregion                                          
                                          HistoricTiv1YearPrior = policyTransaction.HistoricTiv1yearPrior,
                                          HistoricTiv2YearPrior = policyTransaction.HistoricTiv2yearPrior,
                                          HistoricTiv3YearPrior = policyTransaction.HistoricTiv3yearPrior,
                                          NonEnginePricing = policyTransaction.NonEnginePricing,
                                          HasLapsedPriorCoverage = policyTransaction.HasLapsedPriorCoverage,
                                          HasPriorCoverageWithNoLapse = policyTransaction.HasPriorCoverageWithNoLapse
                                      }).ToList();
            #endregion

            return new RiskResponse { PolicyRecord = policyRecords };
        }

        private List<LiabilityClass> AddLiabilityClasses(decimal? glaggregateLimit, string docucorpProductCompletedOper, string docucorpPersonalAndAdvertising, string docucorpDamagePremRented,
                                                         string docucorpMedExpenseLmt, decimal? liabilityLimit)
        {
            var liabilityClass = new LiabilityClass();

            liabilityClass.LiabilityCoverages = new List<LiabilityCoverage>();
            if (glaggregateLimit.HasValue)
            {
                liabilityClass.LiabilityCoverages.Add(
                    new LiabilityCoverage
                    {
                        LiabilityCoverageType = "GeneralAggregate",
                        LimitAmount = glaggregateLimit
                    });
            }
            if (!string.IsNullOrEmpty(docucorpProductCompletedOper))
            {

                liabilityClass.LiabilityCoverages.Add(
                    new LiabilityCoverage
                    {
                        LiabilityCoverageType = "ProductsCompletedOperations",
                        LimitAmount = Convert.ToDecimal(docucorpProductCompletedOper)
                    });
            }
            if (!string.IsNullOrEmpty(docucorpPersonalAndAdvertising))
            {
                liabilityClass.LiabilityCoverages.Add(new LiabilityCoverage
                {
                    LiabilityCoverageType = "PersonalAdvertisingInjury",
                    LimitAmount = Convert.ToDecimal(docucorpPersonalAndAdvertising)
                });
            }
            if (!string.IsNullOrEmpty(docucorpDamagePremRented))
            {

                liabilityClass.LiabilityCoverages.Add(new LiabilityCoverage
                {
                    LiabilityCoverageType = "FireDamage",
                    LimitAmount = Convert.ToDecimal(docucorpDamagePremRented)
                });
            }

            if (!string.IsNullOrEmpty(docucorpMedExpenseLmt))
            {
                liabilityClass.LiabilityCoverages.Add(
                    new LiabilityCoverage
                    {
                        LiabilityCoverageType = "MedicalExpenses",
                        LimitAmount = Convert.ToDecimal(docucorpMedExpenseLmt)
                    });
            }
            if (liabilityLimit.HasValue)
            {
                liabilityClass.LiabilityCoverages.Add(
                    new LiabilityCoverage
                    {
                        LiabilityCoverageType = "EachOccurrence",
                        LimitAmount = liabilityLimit
                    });
            }
            return new List<LiabilityClass>() { liabilityClass };

        }
    }
}
