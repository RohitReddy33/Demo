

$sourceOrg = "http://bcdevtfs:8080/tfs/DefaultCollection"
$sourceProject = "WebServices"
$sourceRepo = "SSO"
$targetOrg = "https://dev.azure.com/NGanduri"
$targetProject = "Test-Project"
$targetRepo = "SSO"
$pat = "k25jaw35zc6czaog25oaitgbzo7ysxm3fo6berojckdpsff3xouq"

$tempDir = "C:\Users\Hemanth Kumar\Documents\temp"

git clone --mirror "$sourceOrg/$sourceProject/_git/$sourceRepo" "$tempDir\$sourceRepo" 

cd "$tempDir\$sourceRepo"

git remote add target "$targetOrg/$targetProject/_git/$targetRepo"

$targetPass = "quhq4jfdzundgavwomfptbnp4hfcxzmxz2zmx546mt7jqbalc2xa"
$base64AuthInfo = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes(":$($targetPass)"))

git push target --mirror
