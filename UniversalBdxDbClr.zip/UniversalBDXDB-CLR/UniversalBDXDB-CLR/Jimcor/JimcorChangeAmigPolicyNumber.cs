﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;
using System.Text.RegularExpressions;

public partial class UserDefinedFunctions
{
    [Microsoft.SqlServer.Server.SqlFunction]
    public static SqlString JimcorChangeAmigPolicyNumber(SqlString policyNumber)
    {
        if (policyNumber.IsNull) return null;
        Regex jimcorAmigPolicyMatch = new Regex("[A-Z]{3}-[0-9]{7}", RegexOptions.Compiled);
        if (jimcorAmigPolicyMatch.Match(policyNumber.Value).Value == policyNumber.Value)
        {
            policyNumber = policyNumber.Value.Replace("-", "");
            policyNumber = policyNumber.Value.Substring(1, policyNumber.Value.Length - 1) + policyNumber.Value.Substring(0,1);
        }
        return new SqlString(policyNumber.Value);
    }
};

