﻿using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RMSTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public class AddressToGeoCode
        {
            public string countryCode { get; set; }
            public string countryScheme { get; set; }
            public string admin1Code { get; set; }
            public string postalCode { get; set; }
            public string streetAddress { get; set; }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var client = new RestClient("https://api.rms.com/li");

            var request = new RestRequest("/geocode/latest", Method.POST);

            string access_token = "eyJraWQiOiJyc2EtcHJvZC1iZWxsLWNsZW1lbnRzLUJlSW5WMSIsInR5cCI6IkpXVCIsImFsZyI6IlJTMjU2In0.eyJwb29sX3RpZXIiOiJlbnRlcnByaXNlIiwicGVybWlzc2lvbnMiOlsiTEktUVVBTlRVTSJdLCJpc3MiOiJSTVMtTG9uZy1MaWZlLVRva2VuLUFQSSIsImNvZ25pdG86dXNlcm5hbWUiOiJiZWxsY2xlbWVudHNAYmVsbGNsZW1lbnRzLmNvbSIsImtleV9yZWdpb24iOiJldS13ZXN0LTEiLCJwb29sX2lkIjoiZXUtd2VzdC0yXzNpTHR6VkE1MiIsImV4cCI6MTYwMjM4Mjc4OSwiaWF0IjoxNTcwODI1MTg5LCJwbGFuX2lkIjoieUNDc1lIVEFHNTZtS0dHNzlueDdaNlczOXBpQVN3R2U0S29BZm1XNyJ9.Oe6u56scbzsOfgzlelsiNNRH3zYDpa8PBEQjavgenrNtsY5gD2BMxx8Qe5i-lvcrA4bPkHejJG-pNJOqLDCm0tl3qNHOeeq0r3pyVFIncukFuXJFDF_mZsptgEiFAtkdsa0gp5HHkI6TXZAkSoWb9V1O39-wPOPul8sxBNycyYh368r0pGnaUMnhqklzBAdl_dr9ZC70QjrxM6SiB9HNo19s9gYRFweV9RA1olGjOl0akG7nMZZxe8hrm-_IXyepSqONpXXZrGwiyi84stI4LqjKb9hbMdACezMR0cs7jvW9iX4a3bGhAkSDHhqdEFsmB_yFPfb7bh6WM0aJRIj6ZQ;";

            request.AddParameter("Authorization",
                    string.Format("Bearer " + access_token),
                                ParameterType.HttpHeader);

            AddressToGeoCode test = new AddressToGeoCode
            {
                countryCode = "US",
                countryScheme = "ISO2A",
                admin1Code = "CA",
                postalCode = "94560",
                streetAddress = "7575 GATEWAY BLVD"
            };

            request.AddJsonBody(test);

            var response = client.Execute(request);

            var content = response.Content;

            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                System.Windows.Forms.MessageBox.Show(content.ToString());
            }
            else
            {
                System.Windows.Forms.MessageBox.Show("Error");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            RMSAPIClass.RMSAPI test = new RMSAPIClass.RMSAPI();

            //MessageBox.Show(test.fl_risk_score("US", "ISO2A", "CA", "94560", "7575 GATEWAY BLVD"));

            MessageBox.Show(test.fl_risk_score("US", "ISO2A", "CA", "94560", "7575 GATEWAY BLVD", "ATC16", "ATC37", 1964, 1, 1,"YES",0));
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string access_token = "eyJraWQiOiJyc2EtcHJvZC1iZWxsLWNsZW1lbnRzLUJlSW5WMSIsInR5cCI6IkpXVCIsImFsZyI6IlJTMjU2In0.eyJwb29sX3RpZXIiOiJlbnRlcnByaXNlIiwicGVybWlzc2lvbnMiOlsiTEktUVVBTlRVTSJdLCJpc3MiOiJSTVMtTG9uZy1MaWZlLVRva2VuLUFQSSIsImNvZ25pdG86dXNlcm5hbWUiOiJiZWxsY2xlbWVudHNAYmVsbGNsZW1lbnRzLmNvbSIsImtleV9yZWdpb24iOiJldS13ZXN0LTEiLCJwb29sX2lkIjoiZXUtd2VzdC0yXzNpTHR6VkE1MiIsImV4cCI6MTYwMjM4Mjc4OSwiaWF0IjoxNTcwODI1MTg5LCJwbGFuX2lkIjoieUNDc1lIVEFHNTZtS0dHNzlueDdaNlczOXBpQVN3R2U0S29BZm1XNyJ9.Oe6u56scbzsOfgzlelsiNNRH3zYDpa8PBEQjavgenrNtsY5gD2BMxx8Qe5i-lvcrA4bPkHejJG-pNJOqLDCm0tl3qNHOeeq0r3pyVFIncukFuXJFDF_mZsptgEiFAtkdsa0gp5HHkI6TXZAkSoWb9V1O39-wPOPul8sxBNycyYh368r0pGnaUMnhqklzBAdl_dr9ZC70QjrxM6SiB9HNo19s9gYRFweV9RA1olGjOl0akG7nMZZxe8hrm-_IXyepSqONpXXZrGwiyi84stI4LqjKb9hbMdACezMR0cs7jvW9iX4a3bGhAkSDHhqdEFsmB_yFPfb7bh6WM0aJRIj6ZQ;";

            var methodAction = "POST";
            var request = (HttpWebRequest)WebRequest.Create("https://api.rms.com/li/geocode/latest");

            request.Headers.Add("Authorization", string.Format("Bearer " + access_token));

            AddressToGeoCode test2 = new AddressToGeoCode
            {
                countryCode = "US",
                countryScheme = "ISO2A",
                admin1Code = "CA",
                postalCode = "94560",
                streetAddress = "7575 GATEWAY BLVD"
            };

            /*string inputData = @"{
                              ""countryCode"": ""US"",
                              ""countryScheme"": ""ISO2A"",
                              ""admin1Code"": ""CA"",
                              ""postalCode"": ""94560"",
                              ""streetAddress"": ""7575 GATEWAY BLVD""
                            }";*/

            string inputData = JsonConvert.SerializeObject(test2);

            request.Method = methodAction;

            //write the input data (aka post) to a byte array
            byte[] requestBytes = new ASCIIEncoding().GetBytes(inputData);
            //get the request stream to write the post to
            Stream requestStream = request.GetRequestStream();
            //write the post to the request stream
            requestStream.Write(requestBytes, 0, requestBytes.Length);

            
            //request.Accept = accept;
            using (var response = (HttpWebResponse)request.GetResponse())
            {
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    string test= new StreamReader(response.GetResponseStream()).ReadToEnd();

                    MessageBox.Show(test);
                }
                else
                {
                    throw new Exception();
                }
            }
        }
    }
}
