﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

namespace GeoCode
{
    public partial class UserDefinedFunctions
    {
        [Microsoft.SqlServer.Server.SqlFunction]
        public static SqlString GeoCoder(SqlString address)
        {
            try
            {
                return "ok";
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
    };
}

