﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace RMSAPIClass
{
    public class RMSAPI
    {
        private const string access_token = "eyJraWQiOiJyc2EtcHJvZC1iZWxsLWNsZW1lbnRzLUJlSW5WMSIsInR5cCI6IkpXVCIsImFsZyI6IlJTMjU2In0.eyJwb29sX3RpZXIiOiJlbnRlcnByaXNlIiwicGVybWlzc2lvbnMiOlsiTEktUVVBTlRVTSJdLCJpc3MiOiJSTVMtTG9uZy1MaWZlLVRva2VuLUFQSSIsImNvZ25pdG86dXNlcm5hbWUiOiJiZWxsY2xlbWVudHNAYmVsbGNsZW1lbnRzLmNvbSIsImtleV9yZWdpb24iOiJldS13ZXN0LTEiLCJwb29sX2lkIjoiZXUtd2VzdC0yXzNpTHR6VkE1MiIsImV4cCI6MTYwMjM4Mjc4OSwiaWF0IjoxNTcwODI1MTg5LCJwbGFuX2lkIjoieUNDc1lIVEFHNTZtS0dHNzlueDdaNlczOXBpQVN3R2U0S29BZm1XNyJ9.Oe6u56scbzsOfgzlelsiNNRH3zYDpa8PBEQjavgenrNtsY5gD2BMxx8Qe5i-lvcrA4bPkHejJG-pNJOqLDCm0tl3qNHOeeq0r3pyVFIncukFuXJFDF_mZsptgEiFAtkdsa0gp5HHkI6TXZAkSoWb9V1O39-wPOPul8sxBNycyYh368r0pGnaUMnhqklzBAdl_dr9ZC70QjrxM6SiB9HNo19s9gYRFweV9RA1olGjOl0akG7nMZZxe8hrm-_IXyepSqONpXXZrGwiyi84stI4LqjKb9hbMdACezMR0cs7jvW9iX4a3bGhAkSDHhqdEFsmB_yFPfb7bh6WM0aJRIj6ZQ;";

        private const string BASEURL = "https://api.rms.com/li/";

        public string CallAPI(string url, string JSON)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

            var methodAction = "POST";
            var request = (HttpWebRequest)WebRequest.Create(BASEURL + url);

            request.Headers.Add("Authorization", string.Format("Bearer " + access_token));

            request.Method = methodAction;

            //write the input data (aka post) to a byte array
            byte[] requestBytes = new ASCIIEncoding().GetBytes(JSON);
            //get the request stream to write the post to
            Stream requestStream = request.GetRequestStream();
            //write the post to the request stream
            requestStream.Write(requestBytes, 0, requestBytes.Length);

            //request.Accept = accept;
            try
            {
                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    if (response.StatusCode == HttpStatusCode.OK)
                    {

                        return new StreamReader(response.GetResponseStream()).ReadToEnd();
                    }
                    else
                    {
                        throw new Exception("Error: " + response.StatusCode);
                    }
                }
            }
            catch (WebException e)
            {
                using (WebResponse response = e.Response)
                {
                    HttpWebResponse httpResponse = (HttpWebResponse)response;
                    Console.WriteLine("Error code: {0}", httpResponse.StatusCode);
                    using (Stream data = response.GetResponseStream())
                    {
                        string text = new StreamReader(data).ReadToEnd();
                        Console.WriteLine(text);
                    }
                }

                throw new Exception("Error: " + e.Message);
            }
        }

        public string fl_risk_score(string countryCode, string countryScheme, string admin1Code, string postalCode, string streetAddress, string construction, string occupancy, int yearBuilt, int numOfStories, int firstFloorHeightAboveGround, string basement, int foundationType)
        {
            //GeoCode Address
            GeoCodeResult address = GeoCodeAddress(countryCode, countryScheme, admin1Code, postalCode, streetAddress);

            //Create JSON Object
            RootObject rootObject = new RootObject();

            rootObject.location = new Location()
            {
                address = new Address()
                {
                    countryCode= address.countryCode,
                    countryScheme = address.countryScheme,
                    countryRmsCode = address.countryRmsCode,
                    admin1Code = address.admin1Code,
                    latitude = address.latitude,
                    longitude = address.longitude,
                    rmsGeoModelResolutionCode = address.rmsGeoModelResolutionCode,
                    postalCodeGeoId = address.postalCodeGeoId,
                    admin1GeoId = address.admin1GeoId
                },
                characteristics= new Characteristics()
                {
                    construction= construction,
                    occupancy = occupancy,
                    yearBuilt = yearBuilt,
                    numOfStories = numOfStories,
                    firstFloorHeightAboveGround = firstFloorHeightAboveGround,
                    basement = basement,
                    foundationType = foundationType
                }
            };

            string inputData = JsonConvert.SerializeObject(rootObject, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });

            string outputData = CallAPI("us_fl_risk_score/latest", inputData);

            return outputData;
        }

        public GeoCodeResult GeoCodeAddress(string countryCode, string countryScheme, string admin1Code, string postalCode, string streetAddress)
        {
            AddressToGeoCode addressToGeoCode = new AddressToGeoCode
            {
                countryCode = countryCode,
                countryScheme = countryScheme,
                admin1Code = admin1Code,
                postalCode = postalCode,
                streetAddress = streetAddress
            };

            string inputData = JsonConvert.SerializeObject(addressToGeoCode);

            string outputData = CallAPI("geocode/latest", inputData);

            return JsonConvert.DeserializeObject<GeoCodeResult>(outputData);
        }
    }
}
