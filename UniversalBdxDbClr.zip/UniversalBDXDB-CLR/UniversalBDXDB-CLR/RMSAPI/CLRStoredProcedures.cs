using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;
using System.Net;
using System.Text;
using Microsoft.SqlServer.Server;
using RMSAPI;
using Newtonsoft.Json;

public partial class StoredProcedures
{
    //private const string access_token = "eyJraWQiOiJyc2EtcHJvZC1iZWxsLWNsZW1lbnRzLUJlSW5WMSIsInR5cCI6IkpXVCIsImFsZyI6IlJTMjU2In0.eyJwb29sX3RpZXIiOiJlbnRlcnByaXNlIiwicGVybWlzc2lvbnMiOlsiTEktUVVBTlRVTSJdLCJpc3MiOiJSTVMtTG9uZy1MaWZlLVRva2VuLUFQSSIsImNvZ25pdG86dXNlcm5hbWUiOiJiZWxsY2xlbWVudHNAYmVsbGNsZW1lbnRzLmNvbSIsImtleV9yZWdpb24iOiJldS13ZXN0LTEiLCJwb29sX2lkIjoiZXUtd2VzdC0yXzNpTHR6VkE1MiIsImV4cCI6MTYwMjM4Mjc4OSwiaWF0IjoxNTcwODI1MTg5LCJwbGFuX2lkIjoieUNDc1lIVEFHNTZtS0dHNzlueDdaNlczOXBpQVN3R2U0S29BZm1XNyJ9.Oe6u56scbzsOfgzlelsiNNRH3zYDpa8PBEQjavgenrNtsY5gD2BMxx8Qe5i-lvcrA4bPkHejJG-pNJOqLDCm0tl3qNHOeeq0r3pyVFIncukFuXJFDF_mZsptgEiFAtkdsa0gp5HHkI6TXZAkSoWb9V1O39-wPOPul8sxBNycyYh368r0pGnaUMnhqklzBAdl_dr9ZC70QjrxM6SiB9HNo19s9gYRFweV9RA1olGjOl0akG7nMZZxe8hrm-_IXyepSqONpXXZrGwiyi84stI4LqjKb9hbMdACezMR0cs7jvW9iX4a3bGhAkSDHhqdEFsmB_yFPfb7bh6WM0aJRIj6ZQ;";

    private const string BASEURL = "https://api-use1.rms.com/li/";

    private static string CallAPI(string url, string JSON)
    {
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

        var methodAction = "POST";
        var request = (HttpWebRequest)WebRequest.Create(BASEURL + url);

        request.Headers.Add("Authorization", string.Format(GetAccessToken()));

        request.Method = methodAction;

        //write the input data (aka post) to a byte array
        byte[] requestBytes = new ASCIIEncoding().GetBytes(JSON);
        //get the request stream to write the post to
        Stream requestStream = request.GetRequestStream();
        //write the post to the request stream
        requestStream.Write(requestBytes, 0, requestBytes.Length);

        //request.Accept = accept;
        try
        {
            using (var response = (HttpWebResponse)request.GetResponse())
            {
                if (response.StatusCode == HttpStatusCode.OK)
                {

                    return new StreamReader(response.GetResponseStream()).ReadToEnd();
                }
                else
                {
                    throw new Exception("Error: " + response.StatusCode);
                }
            }
        }
        catch (WebException e)
        {
            using (WebResponse response = e.Response)
            {
                HttpWebResponse httpResponse = (HttpWebResponse)response;
                Console.WriteLine("Error code: {0}", httpResponse.StatusCode);
                using (Stream data = response.GetResponseStream())
                {
                    string text = new StreamReader(data).ReadToEnd();
                    Console.WriteLine(text);
                }
            }

            throw new Exception("Error: " + e.Message);
        }
    }

    private static GeoCodeResult GeoCodeAddress(string applicationSource, string countryCode, string countryScheme, string admin1Code, string postalCode, string streetAddress)
    {
        const string RMSAPIVersion = "20.0";
        int requestID = 0;
        string outputData = "";
        AddressToGeoCode addressToGeoCode = new AddressToGeoCode
        {
            countryCode = countryCode,
            countryScheme = countryScheme,
            admin1Code = admin1Code,
            postalCode = postalCode,
            streetAddress = streetAddress
        };

        string inputData = JsonConvert.SerializeObject(addressToGeoCode);

        //Log Request
        using (SqlConnection connection = new SqlConnection("context connection=true"))
        {
            connection.Open();
            //Lookup Existing Request
            SqlCommand command = new SqlCommand(@"sp_RMSGeoCodeLog_Insert", connection);
            command.CommandType = CommandType.StoredProcedure;
            SqlCommandBuilder.DeriveParameters(command);

            command.Parameters["@ApplicationSource"].Value = applicationSource;
            command.Parameters["@CountryCode"].Value = countryCode;
            command.Parameters["@CountryScheme"].Value = countryScheme;
            command.Parameters["@Admin1Code"].Value = admin1Code;
            command.Parameters["@PostalCode"].Value = postalCode;
            command.Parameters["@StreetAddress"].Value = streetAddress;
            command.Parameters["@RMSAPIVersion"].Value = RMSAPIVersion;

            command.ExecuteScalar();

            if (command.Parameters["@RequestID"].Value != DBNull.Value) requestID = (int)command.Parameters["@RequestID"].Value;
            if (command.Parameters["@ResponseJSON"].Value != DBNull.Value) outputData = (string)command.Parameters["@ResponseJSON"].Value;
        }

        //Call API To Get JSON
        if (outputData=="") outputData = CallAPI("geocode/" + RMSAPIVersion, inputData);

        //Log Response
        using (SqlConnection connection = new SqlConnection("context connection=true"))
        {
            connection.Open();
            SqlCommand command1 = new SqlCommand("UPDATE [dbo].[RMSGeoCodeLog] SET ResponseJSON=@ResponseJSON, [ResponseDate]=@ResponseDate, LookupCacheCount=LookupCacheCount+1  WHERE RequestID=@RequestID", connection);
            command1.Parameters.Add(new SqlParameter("ResponseJSON", outputData));
            command1.Parameters.Add(new SqlParameter("ResponseDate", DateTime.Now));
            command1.Parameters.Add(new SqlParameter("RequestID", requestID));
            command1.ExecuteNonQuery();
        }

        return JsonConvert.DeserializeObject<GeoCodeResult>(outputData);
    }

    private static string GetAccessToken()
    {
        using (SqlConnection connection = new SqlConnection("context connection=true"))
        {
            connection.Open();
            //Lookup Existing Request
            SqlCommand command = new SqlCommand(@"SELECT [access_token] from [dbo].[RMS_Settings]", connection);
            command.CommandType = CommandType.Text;

            return command.ExecuteScalar().ToString();
        }
    }

    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void sp_rms_access_tokenCLR()
    {
        string accesstoken = GetAccessToken();

        SqlDataRecord record = new SqlDataRecord(new SqlMetaData[] { new SqlMetaData("AccessToken", SqlDbType.NVarChar, -1) });
        record.SetString(0, accesstoken);
        SqlContext.Pipe.Send(record);
    }

    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void sp_RMSGeoCodeAddressCLR(string applicationSource, string countryCode, string countryScheme, string admin1Code, string postalCode, string streetAddress)
    {
        //GeoCode Address
        GeoCodeResult address = GeoCodeAddress(applicationSource, countryCode, countryScheme, admin1Code, postalCode, streetAddress);

        string inputData = JsonConvert.SerializeObject(address);

        SqlContext.Pipe.Send(inputData);

        //Return JSON 
        SqlDataRecord record = new SqlDataRecord(new SqlMetaData[] { new SqlMetaData("JSON", SqlDbType.NVarChar, -1) });
        record.SetString(0, inputData);
        SqlContext.Pipe.Send(record);
    }

    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void sp_fl_risk_scoreCLR(string applicationSource, string countryCode, string countryScheme, string admin1Code, string postalCode, string streetAddress, SqlString construction, SqlString occupancy, SqlInt32 yearBuilt, SqlInt32 numOfStories, SqlInt32 firstFloorHeightAboveGround, SqlString basement, SqlInt32 foundationType)
    {
        const string RMSAPIVersion = "1.0";
        int requestID = 0;
        string outputData = "";
        //GeoCode Address
        GeoCodeResult address = GeoCodeAddress(applicationSource, countryCode, countryScheme, admin1Code, postalCode, streetAddress);

        //Create JSON Object
        RootObject rootObject = new RootObject();

        rootObject.location = new Location()
        {
            address = new Address()
            {
                countryCode = address.countryCode,
                countryScheme = address.countryScheme,
                countryRmsCode = address.countryRmsCode,
                admin1Code = address.admin1Code,
                latitude = address.latitude,
                longitude = address.longitude,
                rmsGeoModelResolutionCode = address.rmsGeoModelResolutionCode,
                postalCodeGeoId = address.postalCodeGeoId,
                admin1GeoId = address.admin1GeoId
            },
            characteristics = new Characteristics()
            {
                construction = construction.Value,
                occupancy = (occupancy.IsNull ? null: occupancy.Value),
                yearBuilt = (yearBuilt.IsNull ? null : (int?)yearBuilt.Value),
                numOfStories = (numOfStories.IsNull ? null : (int?)numOfStories.Value),
                firstFloorHeightAboveGround = (firstFloorHeightAboveGround.IsNull ? null : (int?)firstFloorHeightAboveGround.Value),
                basement = (basement.IsNull ? null : basement.Value),
                foundationType = (foundationType.IsNull ? null : (int?)foundationType.Value)
            }
        };

        string inputData = JsonConvert.SerializeObject(rootObject, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });

        SqlContext.Pipe.Send(inputData);

        //Log Request
        using (SqlConnection connection = new SqlConnection("context connection=true"))
        {
            connection.Open();
            //Lookup Existing Request
            SqlCommand command = new SqlCommand(@"sp_RMS_fl_risk_score_Log_Insert", connection);
            command.CommandType = CommandType.StoredProcedure;
            SqlCommandBuilder.DeriveParameters(command);

            command.Parameters["@ApplicationSource"].Value = applicationSource;
            command.Parameters["@CountryCode"].Value = countryCode;
            command.Parameters["@CountryScheme"].Value = countryScheme;
            command.Parameters["@Admin1Code"].Value = admin1Code;
            command.Parameters["@PostalCode"].Value = postalCode;
            command.Parameters["@StreetAddress"].Value = streetAddress;
            command.Parameters["@RequestJSON"].Value = inputData;
            command.Parameters["@RMSAPIVersion"].Value = RMSAPIVersion;

            command.ExecuteScalar();

            if (command.Parameters["@RequestID"].Value != DBNull.Value) requestID = (int)command.Parameters["@RequestID"].Value;
            if (command.Parameters["@ResponseJSON"].Value != DBNull.Value) outputData = (string)command.Parameters["@ResponseJSON"].Value;
        }

        if (outputData == "") outputData = CallAPI("us_fl_risk_score/" + RMSAPIVersion, inputData);

        //Log Response
        using (SqlConnection connection = new SqlConnection("context connection=true"))
        {
            connection.Open();
            SqlCommand command1 = new SqlCommand("UPDATE [dbo].[RMS_fl_risk_score_Log] SET ResponseJSON=@ResponseJSON, [ResponseDate]=@ResponseDate, LookupCacheCount=LookupCacheCount+1  WHERE RequestID=@RequestID", connection);
            command1.Parameters.Add(new SqlParameter("ResponseJSON", outputData));
            command1.Parameters.Add(new SqlParameter("ResponseDate", DateTime.Now));
            command1.Parameters.Add(new SqlParameter("RequestID", requestID));
            command1.ExecuteNonQuery();
        }

        SqlContext.Pipe.Send(outputData);

        //Return JSON 
        SqlDataRecord record = new SqlDataRecord(new SqlMetaData[] { new SqlMetaData("JSON", SqlDbType.NVarChar, -1) });
        record.SetString(0, outputData);
        SqlContext.Pipe.Send(record);
    }

    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void sp_us_fl_loss_costCLR(string applicationSource, string countryCode, string countryScheme, string admin1Code, string postalCode, string streetAddress, SqlString construction, SqlString occupancy, SqlInt32 yearBuilt, SqlInt32 numOfStories, SqlInt32 firstFloorHeightAboveGround, SqlString basement, SqlInt32 foundationType, SqlInt32 buildingValue, SqlInt32 contentsValue, SqlInt32 businessInterruptionValue, SqlInt32 deductibleType, SqlDouble deductibleAmount, SqlDouble limitAmount)
    {
        const string RMSAPIVersion = "1.0";
        int requestID = 0;
        string outputData = "";
        //GeoCode Address
        GeoCodeResult address = GeoCodeAddress(applicationSource, countryCode, countryScheme, admin1Code, postalCode, streetAddress);

        //Create JSON Object
        RootObject rootObject = new RootObject()
        {
            location = new Location()
            {
                address = new Address()
                {
                    countryCode = address.countryCode,
                    countryScheme = address.countryScheme,
                    countryRmsCode = address.countryRmsCode,
                    admin1Code = address.admin1Code,
                    latitude = address.latitude,
                    longitude = address.longitude,
                    rmsGeoModelResolutionCode = address.rmsGeoModelResolutionCode,
                    postalCodeGeoId = address.postalCodeGeoId,
                    admin1GeoId = address.admin1GeoId
                },
                characteristics = new Characteristics()
                {
                    construction = construction.IsNull ? null : construction.Value,
                    occupancy = occupancy.IsNull ? null : occupancy.Value,
                    yearBuilt = yearBuilt.IsNull ? null : (int?)yearBuilt.Value,
                    numOfStories = numOfStories.IsNull ? null : (int?)numOfStories.Value,
                    firstFloorHeightAboveGround = firstFloorHeightAboveGround.IsNull ? null : (int?)firstFloorHeightAboveGround.Value,
                    basement = basement.IsNull ? null : basement.Value,
                    foundationType = foundationType.IsNull ? null : (int?)foundationType.Value,
                },
                coverageValues = new CoverageValues()
                {
                    buildingValue = buildingValue.IsNull ? null : (int?)buildingValue.Value,
                    contentsValue = contentsValue.IsNull ? null : (int?)contentsValue.Value,
                    businessInterruptionValue = businessInterruptionValue.IsNull ? null : (int?)businessInterruptionValue.Value,
                }
            },
            layerOptions = new LayerOptions()
            {
                deductibleType = deductibleType.IsNull ? null : (int?)deductibleType.Value,
                deductibleAmount = deductibleAmount.IsNull ? null : (double?)deductibleAmount.Value,
                limitAmount = limitAmount.IsNull ? null : (double?)limitAmount.Value,
            }
        };

        string inputData = JsonConvert.SerializeObject(rootObject, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });

        SqlContext.Pipe.Send(inputData);

        //Log Request
        using (SqlConnection connection = new SqlConnection("context connection=true"))
        {
            connection.Open();
            //Lookup Existing Request
            SqlCommand command = new SqlCommand(@"sp_RMS_us_fl_loss_cost_Log_Insert", connection);
            command.CommandType = CommandType.StoredProcedure;
            SqlCommandBuilder.DeriveParameters(command);

            command.Parameters["@ApplicationSource"].Value = applicationSource;
            command.Parameters["@CountryCode"].Value = countryCode;
            command.Parameters["@CountryScheme"].Value = countryScheme;
            command.Parameters["@Admin1Code"].Value = admin1Code;
            command.Parameters["@PostalCode"].Value = postalCode;
            command.Parameters["@StreetAddress"].Value = streetAddress;
            command.Parameters["@RequestJSON"].Value = inputData;
            command.Parameters["@RMSAPIVersion"].Value = RMSAPIVersion;

            command.ExecuteScalar();

            if (command.Parameters["@RequestID"].Value != DBNull.Value) requestID = (int)command.Parameters["@RequestID"].Value;
            if (command.Parameters["@ResponseJSON"].Value != DBNull.Value) outputData = (string)command.Parameters["@ResponseJSON"].Value;
        }

        if (outputData == "") outputData = CallAPI("us_fl_loss_cost/" + RMSAPIVersion, inputData);

        //Log Response
        using (SqlConnection connection = new SqlConnection("context connection=true"))
        {
            connection.Open();
            SqlCommand command1 = new SqlCommand("UPDATE [dbo].[RMS_us_fl_loss_cost_Log] SET ResponseJSON=@ResponseJSON, [ResponseDate]=@ResponseDate, LookupCacheCount=LookupCacheCount+1  WHERE RequestID=@RequestID", connection);
            command1.Parameters.Add(new SqlParameter("ResponseJSON", outputData));
            command1.Parameters.Add(new SqlParameter("ResponseDate", DateTime.Now));
            command1.Parameters.Add(new SqlParameter("RequestID", requestID));
            command1.ExecuteNonQuery();
        }

        SqlContext.Pipe.Send(outputData);

        //Return JSON 
        SqlDataRecord record = new SqlDataRecord(new SqlMetaData[] { new SqlMetaData("JSON", SqlDbType.NVarChar, -1) });
        record.SetString(0, outputData);
        SqlContext.Pipe.Send(record);
    }


    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void sp_us_fema_firmCLR(string applicationSource, string countryCode, string countryScheme, string admin1Code, string postalCode, string streetAddress, SqlInt32 proximityDistance)
    {
        const string RMSAPIVersion = "1.0";
        int requestID = 0;
        string outputData = "";
        //GeoCode Address
        GeoCodeResult address = GeoCodeAddress(applicationSource, countryCode, countryScheme, admin1Code, postalCode, streetAddress);

        //Create JSON Object
        RootObject rootObject = new RootObject()
        {
            location = new Location()
            {
                address = new Address()
                {
                    countryCode = address.countryCode,
                    countryScheme = address.countryScheme,
                    countryRmsCode = address.countryRmsCode,
                    admin1Code = address.admin1Code,
                    latitude = address.latitude,
                    longitude = address.longitude,
                    rmsGeoModelResolutionCode = address.rmsGeoModelResolutionCode,
                    postalCodeGeoId = address.postalCodeGeoId,
                    admin1GeoId = address.admin1GeoId
                }
            },
            layerOptions = new LayerOptions()
            {
                distanceUnit = "feet",
                proximityDistance = proximityDistance.IsNull ? null : (int?)proximityDistance.Value
            }
        };

        string inputData = JsonConvert.SerializeObject(rootObject, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });

        SqlContext.Pipe.Send(inputData);

        //Log Request
        using (SqlConnection connection = new SqlConnection("context connection=true"))
        {
            connection.Open();
            //Lookup Existing Request
            SqlCommand command = new SqlCommand(@"sp_RMS_us_fema_firm_Log_Insert", connection);
            command.CommandType = CommandType.StoredProcedure;
            SqlCommandBuilder.DeriveParameters(command);

            command.Parameters["@ApplicationSource"].Value = applicationSource;
            command.Parameters["@CountryCode"].Value = countryCode;
            command.Parameters["@CountryScheme"].Value = countryScheme;
            command.Parameters["@Admin1Code"].Value = admin1Code;
            command.Parameters["@PostalCode"].Value = postalCode;
            command.Parameters["@StreetAddress"].Value = streetAddress;
            command.Parameters["@ProximityDistance"].Value = proximityDistance;
            command.Parameters["@RMSAPIVersion"].Value = RMSAPIVersion;

            command.ExecuteScalar();

            if (command.Parameters["@RequestID"].Value != DBNull.Value) requestID = (int)command.Parameters["@RequestID"].Value;
            if (command.Parameters["@ResponseJSON"].Value != DBNull.Value) outputData = (string)command.Parameters["@ResponseJSON"].Value;
        }

        if (outputData == "") outputData = CallAPI("us_fema_firm/" + RMSAPIVersion, inputData);

        //Log Response
        using (SqlConnection connection = new SqlConnection("context connection=true"))
        {
            connection.Open();
            SqlCommand command1 = new SqlCommand("UPDATE [dbo].[RMS_us_fema_firm_Log] SET ResponseJSON=@ResponseJSON, [ResponseDate]=@ResponseDate, LookupCacheCount=LookupCacheCount+1  WHERE RequestID=@RequestID", connection);
            command1.Parameters.Add(new SqlParameter("ResponseJSON", outputData));
            command1.Parameters.Add(new SqlParameter("ResponseDate", DateTime.Now));
            command1.Parameters.Add(new SqlParameter("RequestID", requestID));
            command1.ExecuteNonQuery();
        }

        SqlContext.Pipe.Send(outputData);

        //Return JSON 
        SqlDataRecord record = new SqlDataRecord(new SqlMetaData[] { new SqlMetaData("JSON", SqlDbType.NVarChar, -1) });
        record.SetString(0, outputData);
        SqlContext.Pipe.Send(record);
    }

    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void sp_us_fl_susceptibilityCLR(string applicationSource, string countryCode, string countryScheme, string admin1Code, string postalCode, string streetAddress, SqlString construction, SqlString occupancy, SqlInt32 yearBuilt, SqlInt32 numOfStories, SqlInt32 firstFloorHeightAboveGround, SqlString basement, SqlInt32 foundationType)
    {
        const string RMSAPIVersion = "1.0";
        int requestID = 0;
        string outputData = "";
        //GeoCode Address
        GeoCodeResult address = GeoCodeAddress(applicationSource, countryCode, countryScheme, admin1Code, postalCode, streetAddress);

        //Create JSON Object
        RootObject rootObject = new RootObject();

        rootObject.location = new Location()
        {
            address = new Address()
            {
                countryCode = address.countryCode,
                countryScheme = address.countryScheme,
                countryRmsCode = address.countryRmsCode,
                admin1Code = address.admin1Code,
                latitude = address.latitude,
                longitude = address.longitude,
                rmsGeoModelResolutionCode = address.rmsGeoModelResolutionCode,
                postalCodeGeoId = address.postalCodeGeoId,
                admin1GeoId = address.admin1GeoId
            },
            characteristics = new Characteristics()
            {
                construction = construction.IsNull ? null : construction.Value,
                occupancy = occupancy.IsNull ? null : occupancy.Value,
                yearBuilt = yearBuilt.IsNull ? null : (int?)yearBuilt.Value,
                numOfStories = numOfStories.IsNull ? null : (int?)numOfStories.Value,
                firstFloorHeightAboveGround = firstFloorHeightAboveGround.IsNull ? null : (int?)firstFloorHeightAboveGround.Value,
                basement = basement.IsNull ? null : basement.Value,
                foundationType = foundationType.IsNull ? null : (int?)foundationType.Value
            }
        };

        string inputData = JsonConvert.SerializeObject(rootObject, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });

        SqlContext.Pipe.Send(inputData);

        //Log Request
        using (SqlConnection connection = new SqlConnection("context connection=true"))
        {
            connection.Open();
            //Lookup Existing Request
            SqlCommand command = new SqlCommand(@"sp_RMS_us_fl_susceptibility_Log_Insert", connection);
            command.CommandType = CommandType.StoredProcedure;
            SqlCommandBuilder.DeriveParameters(command);

            command.Parameters["@ApplicationSource"].Value = applicationSource;
            command.Parameters["@CountryCode"].Value = countryCode;
            command.Parameters["@CountryScheme"].Value = countryScheme;
            command.Parameters["@Admin1Code"].Value = admin1Code;
            command.Parameters["@PostalCode"].Value = postalCode;
            command.Parameters["@StreetAddress"].Value = streetAddress;
            command.Parameters["@RequestJSON"].Value = inputData;
            command.Parameters["@RMSAPIVersion"].Value = RMSAPIVersion;

            command.ExecuteScalar();

            if (command.Parameters["@RequestID"].Value != DBNull.Value) requestID = (int)command.Parameters["@RequestID"].Value;
            if (command.Parameters["@ResponseJSON"].Value != DBNull.Value) outputData = (string)command.Parameters["@ResponseJSON"].Value;
        }

        if (outputData == "") outputData = CallAPI("us_fl_susceptibility/" + RMSAPIVersion, inputData);

        //Log Response
        using (SqlConnection connection = new SqlConnection("context connection=true"))
        {
            connection.Open();
            SqlCommand command1 = new SqlCommand("UPDATE [dbo].[RMS_us_fl_susceptibility_Log] SET ResponseJSON=@ResponseJSON, [ResponseDate]=@ResponseDate, LookupCacheCount=LookupCacheCount+1  WHERE RequestID=@RequestID", connection);
            command1.Parameters.Add(new SqlParameter("ResponseJSON", outputData));
            command1.Parameters.Add(new SqlParameter("ResponseDate", DateTime.Now));
            command1.Parameters.Add(new SqlParameter("RequestID", requestID));
            command1.ExecuteNonQuery();
        }

        SqlContext.Pipe.Send(outputData);

        //Return JSON 
        SqlDataRecord record = new SqlDataRecord(new SqlMetaData[] { new SqlMetaData("JSON", SqlDbType.NVarChar, -1) });
        record.SetString(0, outputData);
        SqlContext.Pipe.Send(record);
    }

    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void sp_us_fl_depth_floodDepthCLR(string applicationSource, string countryCode, string countryScheme, string admin1Code, string postalCode, string streetAddress)
    {
        const string RMSAPIVersion = "1.0";
        int requestID = 0;
        string outputData = "";
        //GeoCode Address
        GeoCodeResult address = GeoCodeAddress(applicationSource, countryCode, countryScheme, admin1Code, postalCode, streetAddress);

        //Create JSON Object
        RootObject rootObject = new RootObject()
        {
            location = new Location()
            {
                address = new Address()
                {
                    countryCode = address.countryCode,
                    countryScheme = address.countryScheme,
                    countryRmsCode = address.countryRmsCode,
                    admin1Code = address.admin1Code,
                    latitude = address.latitude,
                    longitude = address.longitude,
                    rmsGeoModelResolutionCode = address.rmsGeoModelResolutionCode,
                    postalCodeGeoId = address.postalCodeGeoId,
                    admin1GeoId = address.admin1GeoId
                }
            },
            layerOptions = new LayerOptions()
            {
                lookup = "floodDepth"
            }
        };

        string inputData = JsonConvert.SerializeObject(rootObject, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });

        SqlContext.Pipe.Send(inputData);

        //Log Request
        using (SqlConnection connection = new SqlConnection("context connection=true"))
        {
            connection.Open();
            //Lookup Existing Request
            SqlCommand command = new SqlCommand(@"sp_RMS_us_fl_depth_floodDepth_Log_Insert", connection);
            command.CommandType = CommandType.StoredProcedure;
            SqlCommandBuilder.DeriveParameters(command);

            command.Parameters["@ApplicationSource"].Value = applicationSource;
            command.Parameters["@CountryCode"].Value = countryCode;
            command.Parameters["@CountryScheme"].Value = countryScheme;
            command.Parameters["@Admin1Code"].Value = admin1Code;
            command.Parameters["@PostalCode"].Value = postalCode;
            command.Parameters["@StreetAddress"].Value = streetAddress;
            command.Parameters["@RMSAPIVersion"].Value = RMSAPIVersion;

            command.ExecuteScalar();

            if (command.Parameters["@RequestID"].Value != DBNull.Value) requestID = (int)command.Parameters["@RequestID"].Value;
            if (command.Parameters["@ResponseJSON"].Value != DBNull.Value) outputData = (string)command.Parameters["@ResponseJSON"].Value;
        }

        if (outputData == "") outputData = CallAPI("us_fl_depth/" + RMSAPIVersion, inputData);

        //Log Response
        using (SqlConnection connection = new SqlConnection("context connection=true"))
        {
            connection.Open();
            SqlCommand command1 = new SqlCommand("UPDATE [dbo].[RMS_us_fl_depth_floodDepth_Log] SET ResponseJSON=@ResponseJSON, [ResponseDate]=@ResponseDate, LookupCacheCount=LookupCacheCount+1  WHERE RequestID=@RequestID", connection);
            command1.Parameters.Add(new SqlParameter("ResponseJSON", outputData));
            command1.Parameters.Add(new SqlParameter("ResponseDate", DateTime.Now));
            command1.Parameters.Add(new SqlParameter("RequestID", requestID));
            command1.ExecuteNonQuery();
        }

        SqlContext.Pipe.Send(outputData);

        //Return JSON 
        SqlDataRecord record = new SqlDataRecord(new SqlMetaData[] { new SqlMetaData("JSON", SqlDbType.NVarChar, -1) });
        record.SetString(0, outputData);
        SqlContext.Pipe.Send(record);
    }

    public class RMSGeoCodeResponse
    {
        public int id { get; set; }
        public string admin1Code { get; set; }
        public string admin1Name { get; set; }
        public string admin2Code { get; set; }
        public string admin2Name { get; set; }
        public string admin3Code { get; set; }
        public string admin3Name { get; set; }
        public string admin4Code { get; set; }
        public string admin4Name { get; set; }
        public string cityName { get; set; }
        public string countryCode { get; set; }
        public string countryRmsCode { get; set; }
        public string countryName { get; set; }
        public string countryFips { get; set; }
        public string countryScheme { get; set; }
        public int rmsGeocodingResolutionCode { get; set; }
        public int rmsGeoModelResolutionCode { get; set; }
        public double latitude { get; set; }
        public string locationCode { get; set; }
        public double longitude { get; set; }
        public string postalCode { get; set; }
        public string streetAddress { get; set; }
        public string zone1Code { get; set; }
        public int admin1GeoId { get; set; }
        public long admin2GeoId { get; set; }
        public int admin3GeoId { get; set; }
        public int locationCodeGeoId { get; set; }
        public int zone1GeoId { get; set; }
        public int zone2GeoId { get; set; }
        public long cityGeoId { get; set; }
        public int countryGeoId { get; set; }
        public long postalCodeGeoId { get; set; }
        public string geoMatchCode { get; set; }
        public int geoDataSourceId { get; set; }
        public int parcelId { get; set; }
        public string ugid { get; set; }
        public string dataVersion { get; set; }
    }

    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void sp_na_ws_hazardCLR(string applicationSource, string countryCode, string countryScheme, string admin1Code, string postalCode, string streetAddress)
    {
        const string RMSAPIVersion = "18.1";
        int requestID = 0;
        string outputData = "";
        //GeoCode Address
        GeoCodeResult address = GeoCodeAddress(applicationSource, countryCode, countryScheme, admin1Code, postalCode, streetAddress);

        //Create JSON Object
        RootObject rootObject = new RootObject()
        {
            location = new Location()
            {
                address = new Address()
                {
                    countryCode = address.countryCode,
                    countryScheme = address.countryScheme,
                    countryRmsCode = address.countryRmsCode,
                    admin1Code = address.admin1Code,
                    latitude = address.latitude,
                    longitude = address.longitude,
                    rmsGeoModelResolutionCode = address.rmsGeoModelResolutionCode,
                    postalCodeGeoId = address.postalCodeGeoId,
                    admin1GeoId = address.admin1GeoId
                }
            }
        };

        string inputData = JsonConvert.SerializeObject(rootObject, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });

        SqlContext.Pipe.Send(inputData);

        //Log Request
        using (SqlConnection connection = new SqlConnection("context connection=true"))
        {
            connection.Open();
            //Lookup Existing Request
            SqlCommand command = new SqlCommand(@"sp_RMS_na_ws_hazard_Log_Insert", connection);
            command.CommandType = CommandType.StoredProcedure;
            SqlCommandBuilder.DeriveParameters(command);

            command.Parameters["@ApplicationSource"].Value = applicationSource;
            command.Parameters["@CountryCode"].Value = countryCode;
            command.Parameters["@CountryScheme"].Value = countryScheme;
            command.Parameters["@Admin1Code"].Value = admin1Code;
            command.Parameters["@PostalCode"].Value = postalCode;
            command.Parameters["@StreetAddress"].Value = streetAddress;
            command.Parameters["@RMSAPIVersion"].Value = RMSAPIVersion;

            command.ExecuteScalar();

            if (command.Parameters["@RequestID"].Value != DBNull.Value) requestID = (int)command.Parameters["@RequestID"].Value;
            if (command.Parameters["@ResponseJSON"].Value != DBNull.Value) outputData = (string)command.Parameters["@ResponseJSON"].Value;
        }

        if (outputData == "") outputData = CallAPI("na_ws_hazard/" + RMSAPIVersion, inputData);

        //Log Response
        using (SqlConnection connection = new SqlConnection("context connection=true"))
        {
            connection.Open();
            SqlCommand command1 = new SqlCommand("UPDATE [dbo].[RMS_na_ws_hazard_Log] SET ResponseJSON=@ResponseJSON, [ResponseDate]=@ResponseDate, LookupCacheCount=LookupCacheCount+1  WHERE RequestID=@RequestID", connection);
            command1.Parameters.Add(new SqlParameter("ResponseJSON", outputData));
            command1.Parameters.Add(new SqlParameter("ResponseDate", DateTime.Now));
            command1.Parameters.Add(new SqlParameter("RequestID", requestID));
            command1.ExecuteNonQuery();
        }

        SqlContext.Pipe.Send(outputData);

        //Return JSON 
        SqlDataRecord record = new SqlDataRecord(new SqlMetaData[] { new SqlMetaData("JSON", SqlDbType.NVarChar, -1) , new SqlMetaData("LAT", SqlDbType.NVarChar, -1), new SqlMetaData("LNG", SqlDbType.NVarChar, -1) });
        record.SetString(0, outputData);
        record.SetString(1, address.latitude.ToString());
        record.SetString(2, address.longitude.ToString());
        SqlContext.Pipe.Send(record);
    }
}