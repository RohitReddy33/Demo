using System;
using System.Collections.Generic;
using System.Text;

namespace RMSAPI
{
    public class Address
    {
        public string countryCode { get; set; }
        public string countryScheme { get; set; }
        public string countryRmsCode { get; set; }
        public string admin1Code { get; set; }
        public double latitude { get; set; }
        public double longitude { get; set; }
        public int rmsGeoModelResolutionCode { get; set; }
        public long postalCodeGeoId { get; set; }
        public int admin1GeoId { get; set; }
    }

    public class Characteristics
    {
        public string construction { get; set; }
        public string occupancy { get; set; }
        public int? yearBuilt { get; set; }
        public int? numOfStories { get; set; }
        public int? firstFloorHeightAboveGround { get; set; }
        public string basement { get; set; }
        public int? foundationType { get; set; }
    }

    public class CoverageValues
    {
        public int? buildingValue { get; set; }
        public int? contentsValue { get; set; }
        public int? businessInterruptionValue { get; set; }
    }

    public class Location
    {
        public Address address { get; set; }
        public Characteristics characteristics { get; set; }
        public CoverageValues coverageValues { get; set; }
    }

    public class LayerOptions
    {
        public int? deductibleType { get; set; }
        public double? deductibleAmount { get; set; }
        public double? limitAmount { get; set; }
        public string distanceUnit { get; set; }
        public double? proximityDistance { get; set; }
        public string lookup { get; set; }
    }

    public class Layer
    {
        public string name { get; set; }
        public string version { get; set; }
        //public Options options { get; set; }
    }

    public class RootObject
    {
        public Location location { get; set; }
        public LayerOptions layerOptions { get; set; }
        public List<Layer> layers { get; set; }
    }


    public class AddressToGeoCode
    {
        public string countryCode { get; set; }
        public string countryScheme { get; set; }
        public string admin1Code { get; set; }
        public string postalCode { get; set; }
        public string streetAddress { get; set; }
    }

    public class GeoCodeResult
    {
        public int id { get; set; }
        public string admin1Code { get; set; }
        public string admin1Name { get; set; }
        public string admin2Code { get; set; }
        public string admin2Name { get; set; }
        public string admin3Code { get; set; }
        public string admin3Name { get; set; }
        public string admin4Code { get; set; }
        public string admin4Name { get; set; }
        public string cityName { get; set; }
        public string countryCode { get; set; }
        public string countryName { get; set; }
        public string countryScheme { get; set; }
        public double latitude { get; set; }
        public double longitude { get; set; }
        public string postalCode { get; set; }
        public string streetAddress { get; set; }
        public string name { get; set; }
        public int admin1GeoId { get; set; }
        public long admin2GeoId { get; set; }
        public int admin3GeoId { get; set; }
        public long cityGeoId { get; set; }
        public string countryFips { get; set; }
        public int countryGeoId { get; set; }
        public string countryRmsCode { get; set; }
        public int geoDataSourceId { get; set; }
        public string geoMatchCode { get; set; }
        public string locationCode { get; set; }
        public int locationCodeGeoId { get; set; }
        public long parcelId { get; set; }
        public long postalCodeGeoId { get; set; }
        public int rmsGeoModelResolutionCode { get; set; }
        public int rmsGeocodingResolutionCode { get; set; }
        public string ugid { get; set; }
        public string zone1Code { get; set; }
        public int zone1GeoId { get; set; }
        public int zone2GeoId { get; set; }
        public string dataVersion { get; set; }
    }
}
