﻿CREATE PROCEDURE [dbo].[sp_us_fl_loss_cost]
	@applicationSource [NVARCHAR](MAX),
	@countryCode [NVARCHAR](MAX),
	@countryScheme [NVARCHAR](MAX),
	@admin1Code [NVARCHAR](MAX),
	@postalCode [NVARCHAR](MAX),
	@streetAddress [NVARCHAR](MAX),
	@construction [NVARCHAR](MAX),
	@occupancy [NVARCHAR](MAX),
	@yearBuilt [INT],
	@numOfStories [INT],
	@firstFloorHeightAboveGround [INT],
	@basement [NVARCHAR](MAX),
	@foundationType [INT],
	@buildingValue [INT],
	@contentsValue [INT],
	@businessInterruptionValue [INT],
	@deductibleType [INT],
	@deductibleAmount [FLOAT],
	@limitAmount [FLOAT]
AS
	DECLARE @JasonData TABLE (
			JSON VARCHAR(MAX) NULL
		);

	INSERT INTO @JasonData
	EXECUTE [dbo].[sp_us_fl_loss_costCLR] 
	   @applicationSource
	  ,@countryCode
	  ,@countryScheme
	  ,@admin1Code
	  ,@postalCode
	  ,@streetAddress
	  ,@construction
	  ,@occupancy
	  ,@yearBuilt
	  ,@numOfStories
	  ,@firstFloorHeightAboveGround
	  ,@basement
	  ,@foundationType
	  ,@buildingValue
	  ,@contentsValue
	  ,@businessInterruptionValue
	  ,@deductibleType
	  ,@deductibleAmount
	  ,@limitAmount

	DECLARE @JSON NVARCHAR(MAX)

	SELECT @JSON=JSON
	FROM @JasonData


	--SELECT RESULTS
	SELECT JsonDataResult.*
		FROM OPENJSON (@JSON, N'$')
		  WITH (
			contentsAlr float N'$.contentsAlr',
			contentsAlrFlood float N'$.contentsAlrFlood',
			buildingAlr float N'$.buildingAlr',
			grossLoss float N'$.grossLoss',
			buildingAlrFlood float N'$.buildingAlrFlood',
			businessInterruptionAlrFlood float N'$.businessInterruptionAlrFlood',
			contentsAlrSurge float N'$.contentsAlrSurge',
			businessInterruptionAlr float N'$.businessInterruptionAlr',
			buildingAlrSurge float N'$.buildingAlrSurge',
			businessInterruptionAlrSurge float N'$.businessInterruptionAlrSurge'
		  ) AS JsonDataResult;