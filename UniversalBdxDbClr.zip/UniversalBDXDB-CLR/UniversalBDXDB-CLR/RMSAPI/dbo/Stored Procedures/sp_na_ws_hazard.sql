﻿CREATE PROCEDURE [dbo].[sp_na_ws_hazard]
	@applicationSource [nvarchar](max),
	@countryCode [nvarchar](max),
	@countryScheme [nvarchar](max),
	@admin1Code [nvarchar](max),
	@postalCode [nvarchar](max),
	@streetAddress [nvarchar](max)

AS
	DECLARE @JasonData TABLE (
			JSON VARCHAR(MAX) NULL,
			LAT VARCHAR(MAX) NULL,
			LNG VARCHAR(MAX) NULL
		);

	INSERT INTO @JasonData
	EXECUTE [dbo].sp_na_ws_hazardCLR 
	   @applicationSource
	  ,@countryCode
	  ,@countryScheme
	  ,@admin1Code
	  ,@postalCode
	  ,@streetAddress

	DECLARE @JSON NVARCHAR(MAX)

	SELECT @JSON=JSON
	FROM @JasonData

	SELECT @JSON AS JSON

	--SELECT RESULTS
	SELECT JsonDataResult.*
		FROM OPENJSON (@JSON, N'$')
		  WITH (
			"elevationGround" VARCHAR(200) N'$."elevationGround"',
			"distanceToCoast" VARCHAR(200) N'$."distanceToCoast"',
			"elevationGroundUnit" VARCHAR(200) N'$."elevationGroundUnit"',
			"distanceToCoastUnit" VARCHAR(200) N'$."distanceToCoastUnit"'
		  ) AS JsonDataResult;
	
	SELECT LAT, LNG FROM @JasonData