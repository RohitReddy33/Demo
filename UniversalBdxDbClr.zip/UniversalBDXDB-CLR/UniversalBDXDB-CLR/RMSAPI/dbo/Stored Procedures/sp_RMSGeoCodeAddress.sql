﻿CREATE PROCEDURE [dbo].[sp_RMSGeoCodeAddress]
	@applicationSource [NVARCHAR](MAX),
	@countryCode [NVARCHAR](MAX),
	@countryScheme [NVARCHAR](MAX),
	@admin1Code [NVARCHAR](MAX),
	@postalCode [NVARCHAR](MAX),
	@streetAddress [NVARCHAR](MAX)
AS

	DECLARE @JasonData TABLE (
			JSON VARCHAR(MAX) NULL
		);

	INSERT INTO @JasonData
	EXECUTE [dbo].[sp_RMSGeoCodeAddressCLR] 
	   @applicationSource
	  ,@countryCode
	  ,@countryScheme
	  ,@admin1Code
	  ,@postalCode
	  ,@streetAddress

	DECLARE @JSON NVARCHAR(MAX)

	SELECT @JSON=JSON
	FROM @JasonData

	--SELECT RESULTS
	SELECT JsonDataResult.*
		FROM OPENJSON (@JSON, N'$')
		  WITH (
			id INT N'$.id',
			admin1Code VARCHAR(20) N'$.admin1Code',
			admin1Name VARCHAR(20) N'$.admin1Name',
			admin2Code VARCHAR(20) N'$.admin2Code',
			admin2Name VARCHAR(20) N'$.admin2Name',
			admin3Code VARCHAR(20) N'$.admin3Code',
			admin3Name VARCHAR(20) N'$.admin3Name',
			admin4Code VARCHAR(20) N'$.admin4Code',
			admin4Name VARCHAR(20) N'$.admin4Name',
			cityName VARCHAR(20) N'$.cityName',
			countryCode VARCHAR(20) N'$.countryCode',
			countryName VARCHAR(20) N'$.countryName',
			countryScheme VARCHAR(20) N'$.countryScheme',
			latitude FLOAT N'$.latitude',
			longitude FLOAT N'$.longitude',
			postalCode VARCHAR(20) N'$.postalCode',
			streetAddress VARCHAR(20) N'$.streetAddress',
			name VARCHAR(20) N'$.name',
			admin1GeoId BIGINT N'$.admin1GeoId',
			admin2GeoId BIGINT N'$.admin2GeoId',
			admin3GeoId BIGINT N'$.admin3GeoId',
			cityGeoId BIGINT N'$.cityGeoId',
			countryFips VARCHAR(20) N'$.countryFips',
			countryGeoId BIGINT N'$.countryGeoId',
			countryRmsCode VARCHAR(20) N'$.countryRmsCode',
			geoDataSourceId INT N'$.geoDataSourceId',
			geoMatchCode VARCHAR(20) N'$.geoMatchCode',
			locationCode VARCHAR(20) N'$.locationCode',
			locationCodeGeoId BIGINT N'$.locationCodeGeoId',
			parcelId BIGINT N'$.parcelId',
			postalCodeGeoId BIGINT N'$.postalCodeGeoId',
			rmsGeoModelResolutionCode INT N'$.rmsGeoModelResolutionCode',
			rmsGeocodingResolutionCode INT N'$.rmsGeocodingResolutionCode',
			ugid VARCHAR(20) N'$.ugid',
			zone1Code VARCHAR(20) N'$.zone1Code',
			zone1GeoId INT N'$.zone1GeoId',
			zone2GeoId INT N'$.zone2GeoId',
			dataVersion VARCHAR(20) N'$.dataVersion'
		  ) AS JsonDataResult;