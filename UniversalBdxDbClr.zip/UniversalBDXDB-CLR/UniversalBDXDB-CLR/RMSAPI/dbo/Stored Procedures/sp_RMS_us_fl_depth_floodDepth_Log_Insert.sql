﻿CREATE PROC [dbo].[sp_RMS_us_fl_depth_floodDepth_Log_Insert]
(
	@ApplicationSource VARCHAR(255),
	@CountryCode VARCHAR(500),
	@CountryScheme VARCHAR(50),
	@Admin1Code VARCHAR(50),
	@PostalCode VARCHAR(50),
	@StreetAddress VARCHAR(255),
	@RMSAPIVersion VARCHAR(50),
	@ResponseJSON NVARCHAR(MAX) = NULL OUTPUT ,
	@RequestID INT = NULL OUTPUT
)
AS
	SELECT @RequestID=[RequestID],
                @ResponseJSON =[ResponseJSON]
            FROM [dbo].RMS_us_fl_depth_floodDepth_Log
        WHERE [CountryCode] = @CountryCode AND
                [CountryScheme] = @CountryScheme AND
                [Admin1Code] = @Admin1Code AND
                [PostalCode] = @PostalCode AND
                [StreetAddress] = @StreetAddress

	IF @@ROWCOUNT=0
	BEGIN
		INSERT INTO [dbo].RMS_us_fl_depth_floodDepth_Log ([ApplicationSource], [CountryCode], [CountryScheme], [Admin1Code], [PostalCode] ,[StreetAddress], RMSAPIVersion) VALUES (@ApplicationSource, @CountryCode, @CountryScheme, @Admin1Code, @PostalCode, @StreetAddress, @RMSAPIVersion); 
		SELECT @RequestID=CAST(@@IDENTITY AS INT)
	END
GO