﻿CREATE PROCEDURE [dbo].[sp_fl_risk_score]
	@applicationSource [NVARCHAR](MAX),
	@countryCode [NVARCHAR](MAX),
	@countryScheme [NVARCHAR](MAX),
	@admin1Code [NVARCHAR](MAX),
	@postalCode [NVARCHAR](MAX),
	@streetAddress [NVARCHAR](MAX),
	@construction [NVARCHAR](MAX),
	@occupancy [NVARCHAR](MAX),
	@yearBuilt [INT],
	@numOfStories [INT],
	@firstFloorHeightAboveGround [INT],
	@basement [NVARCHAR](MAX),
	@foundationType [INT]
AS

	DECLARE @JasonData TABLE (
			JSON VARCHAR(MAX) NULL
		);

	INSERT INTO @JasonData
	EXECUTE [dbo].[sp_fl_risk_scoreCLR] 
	   @applicationSource
	  ,@countryCode
	  ,@countryScheme
	  ,@admin1Code
	  ,@postalCode
	  ,@streetAddress
	  ,@construction
	  ,@occupancy
	  ,@yearBuilt
	  ,@numOfStories
	  ,@firstFloorHeightAboveGround
	  ,@basement
	  ,@foundationType

	DECLARE @JSON NVARCHAR(MAX)

	SELECT @JSON=JSON
	FROM @JasonData


	--SELECT RESULTS
	SELECT JsonDataResult.*
		FROM OPENJSON (@JSON, N'$')
		  WITH (
			score250yr VARCHAR(200) N'$.score250yr',
			score100yr VARCHAR(200) N'$.score100yr',
			score500yr VARCHAR(200) N'$.score500yr',
			scoreOverall VARCHAR(200) N'$.scoreOverall'
		  ) AS JsonDataResult;