﻿CREATE PROCEDURE [dbo].[sp_us_fema_firm]
	@applicationSource [NVARCHAR](MAX),
	@countryCode [NVARCHAR](MAX),
	@countryScheme [NVARCHAR](MAX),
	@admin1Code [NVARCHAR](MAX),
	@postalCode [NVARCHAR](MAX),
	@streetAddress [NVARCHAR](MAX),
	@proximityDistance [INT]
AS
	DECLARE @JasonData TABLE (
			JSON VARCHAR(MAX) NULL
		);

	INSERT INTO @JasonData
	EXECUTE [dbo].[sp_us_fema_firmCLR] 
		@applicationSource
		,@countryCode
		,@countryScheme
		,@admin1Code
		,@postalCode
		,@streetAddress
		,@proximityDistance

	DECLARE @JSON NVARCHAR(MAX)

	SELECT @JSON=JSON
	FROM @JasonData


	--SELECT RESULTS
	SELECT JsonDataResult.*
		FROM OPENJSON (@JSON, N'$')
		  WITH (
			panel VARCHAR(200) N'$.panel',
			community VARCHAR(200) N'$.community',
			panfloodZoneel VARCHAR(200) N'$.floodZone',
			panelDate date N'$.panelDate',
			bfe VARCHAR(200) N'$.bfe',
			annualProbability VARCHAR(200) N'$.annualProbability',
			levees VARCHAR(200) N'$.levees',
			otherZones VARCHAR(200) N'$.otherZones',
			flMatch VARCHAR(200) N'$.flMatch',
			floodway VARCHAR(200) N'$.floodway',
			cobra VARCHAR(200) N'$.cobra'
		  ) AS JsonDataResult;
