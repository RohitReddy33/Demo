﻿CREATE PROCEDURE [dbo].[sp_us_fl_susceptibility]
	@applicationSource [NVARCHAR](MAX),
	@countryCode [NVARCHAR](MAX),
	@countryScheme [NVARCHAR](MAX),
	@admin1Code [NVARCHAR](MAX),
	@postalCode [NVARCHAR](MAX),
	@streetAddress [NVARCHAR](MAX),
	@construction [NVARCHAR](MAX),
	@occupancy [NVARCHAR](MAX),
	@yearBuilt [INT],
	@numOfStories [INT],
	@firstFloorHeightAboveGround [INT],
	@basement [NVARCHAR](MAX),
	@foundationType [INT]
AS

	DECLARE @JasonData TABLE (
			JSON VARCHAR(MAX) NULL
		);

	INSERT INTO @JasonData
	EXECUTE [dbo].[sp_us_fl_susceptibilityCLR] 
	   @applicationSource
	  ,@countryCode
	  ,@countryScheme
	  ,@admin1Code
	  ,@postalCode
	  ,@streetAddress
	  ,@construction
	  ,@occupancy
	  ,@yearBuilt
	  ,@numOfStories
	  ,@firstFloorHeightAboveGround
	  ,@basement
	  ,@foundationType

	DECLARE @JSON NVARCHAR(MAX)

	SELECT @JSON=JSON
	FROM @JasonData


	--SELECT RESULTS
	SELECT JsonDataResult.*
		FROM OPENJSON (@JSON, N'$')
		  WITH (
			dtmElevation VARCHAR(200) N'$.dtmElevation',
			firstFloorHeightAboveGround VARCHAR(200) N'$.firstFloorHeightAboveGround',
			percentBasement VARCHAR(200) N'$.percentBasement',
			warningscode VARCHAR(max) N'$.warnings[0].code',
			warningsmessage VARCHAR(max) N'$.warnings[0].message'
		  ) AS JsonDataResult;
