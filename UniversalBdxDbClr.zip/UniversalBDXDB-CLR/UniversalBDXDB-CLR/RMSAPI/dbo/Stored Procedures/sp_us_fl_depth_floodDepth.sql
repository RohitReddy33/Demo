﻿CREATE PROCEDURE [dbo].sp_us_fl_depth_floodDepth
	@applicationSource [NVARCHAR](MAX),
	@countryCode [NVARCHAR](MAX),
	@countryScheme [NVARCHAR](MAX),
	@admin1Code [NVARCHAR](MAX),
	@postalCode [NVARCHAR](MAX),
	@streetAddress [NVARCHAR](MAX)
AS
	DECLARE @JasonData TABLE (
			JSON VARCHAR(MAX) NULL
		);

	INSERT INTO @JasonData
	EXECUTE [dbo].sp_us_fl_depth_floodDepthCLR 
		@applicationSource
		,@countryCode
		,@countryScheme
		,@admin1Code
		,@postalCode
		,@streetAddress

	DECLARE @JSON NVARCHAR(MAX)

	SELECT @JSON=JSON
	FROM @JasonData

	SELECT @JSON AS JSON

	--SELECT RESULTS
	SELECT JsonDataResult.*
		FROM OPENJSON (@JSON, N'$')
		  WITH (
			depthSurgeUndef500yr VARCHAR(200) N'$.depthSurgeUndef500yr',
			depthSurgeDef50yr VARCHAR(200) N'$.depthSurgeDef50yr',
			depthInlandDef100yr VARCHAR(200) N'$.depthInlandDef100yr',
			depthCombinedUndef30yr VARCHAR(200) N'$.depthCombinedUndef30yr',
			depthInlandUndef1000yr VARCHAR(200) N'$.depthInlandUndef1000yr',
			depthSurgeUndef250yr VARCHAR(200) N'$.depthSurgeUndef250yr',
			depthSurgeDef1000yr VARCHAR(200) N'$.depthSurgeDef1000yr',
			depthInlandDef50yr VARCHAR(200) N'$.depthInlandDef50yr',
			depthCombinedDef250yr VARCHAR(200) N'$.depthCombinedDef250yr',
			depthInlandUndef50yr VARCHAR(200) N'$.depthInlandUndef50yr',
			depthCombinedDef1000yr VARCHAR(200) N'$.depthCombinedDef1000yr',
			depthSurgeUndef50yr VARCHAR(200) N'$.depthSurgeUndef50yr',
			depthSurgeUndef200yr VARCHAR(200) N'$.depthSurgeUndef200yr',
			depthInlandUndef200yr VARCHAR(200) N'$.depthInlandUndef200yr',
			depthInlandUndef100yr VARCHAR(200) N'$.depthInlandUndef100yr',
			depthSurgeDef250yr VARCHAR(200) N'$.depthSurgeDef250yr',
			depthSurgeDef200yr VARCHAR(200) N'$.depthSurgeDef200yr',
			depthSurgeDef30yr VARCHAR(200) N'$.depthSurgeDef30yr',
			depthCombinedUndef50yr VARCHAR(200) N'$.depthCombinedUndef50yr',
			depthCombinedDef100yr VARCHAR(200) N'$.depthCombinedDef100yr',
			depthCombinedUndef200yr VARCHAR(200) N'$.depthCombinedUndef200yr',
			depthInlandDef250yr VARCHAR(200) N'$.depthInlandDef250yr',
			depthCombinedDef50yr VARCHAR(200) N'$.depthCombinedDef50yr',
			depthSurgeUndef1000yr VARCHAR(200) N'$.depthSurgeUndef1000yr',
			depthInlandUndef500yr VARCHAR(200) N'$.depthInlandUndef500yr',
			depthCombinedUndef500yr VARCHAR(200) N'$.depthCombinedUndef500yr',
			status VARCHAR(200) N'$.status',
			depthCombinedUndef1000yr VARCHAR(200) N'$.depthCombinedUndef1000yr',
			depthInlandUndef250yr VARCHAR(200) N'$.depthInlandUndef250yr',
			depthCombinedDef500yr VARCHAR(200) N'$.depthCombinedDef500yr',
			depthSurgeUndef30yr VARCHAR(200) N'$.depthSurgeUndef30yr',
			depthSurgeDef100yr VARCHAR(200) N'$.depthSurgeDef100yr',
			depthCombinedUndef250yr VARCHAR(200) N'$.depthCombinedUndef250yr',
			depthCombinedDef200yr VARCHAR(200) N'$.depthCombinedDef200yr',
			depthCombinedDef30yr VARCHAR(200) N'$.depthCombinedDef30yr',
			depthSurgeDef500yr VARCHAR(200) N'$.depthSurgeDef500yr',
			depthCombinedUndef100yr VARCHAR(200) N'$.depthCombinedUndef100yr',
			depthInlandDef500yr VARCHAR(200) N'$.depthInlandDef500yr',
			depthSurgeUndef100yr VARCHAR(200) N'$.depthSurgeUndef100yr',
			depthInlandDef30yr VARCHAR(200) N'$.depthInlandDef30yr',
			depthInlandUndef30yr VARCHAR(200) N'$.depthInlandUndef30yr',
			depthInlandDef1000yr VARCHAR(200) N'$.depthInlandDef1000yr',
			depthInlandDef200yr VARCHAR(200) N'$.depthInlandDef200yr'
		  ) AS JsonDataResult;