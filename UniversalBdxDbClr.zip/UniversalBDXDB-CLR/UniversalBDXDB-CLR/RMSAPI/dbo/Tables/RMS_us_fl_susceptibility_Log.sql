﻿CREATE TABLE [dbo].[RMS_us_fl_susceptibility_Log](
	[RequestID] [int] IDENTITY(1,1) NOT NULL,
	[RequestDate] [datetime] NULL,
	[RequestUser] [varchar](50) NULL,
	[ApplicationSource] [varchar](255) NULL,
	[CountryCode] [varchar](500) NULL,
	[CountryScheme] [varchar](50) NULL,
	[Admin1Code] [varchar](50) NULL,
	[PostalCode] [varchar](50) NULL,
	[StreetAddress] [varchar](255) NULL,
	[RequestJSON] [nvarchar](max) NULL,
	[ResponseJSON] [nvarchar](max) NULL,
	[ResponseDate] [datetime] NULL,
	[LookupCacheCount] [int] NULL,
	 [RMSAPIVersion] VARCHAR(50) NULL
 CONSTRAINT [PK_RMS_us_fl_susceptibility_Log] PRIMARY KEY CLUSTERED 
(
	[RequestID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[RMS_us_fl_susceptibility_Log] ADD  CONSTRAINT [DF_RMS_us_fl_susceptibility_Log_RequestDate]  DEFAULT (getdate()) FOR [RequestDate]
GO
ALTER TABLE [dbo].[RMS_us_fl_susceptibility_Log] ADD  CONSTRAINT [DF_RMS_us_fl_susceptibility_Log_RequestUser]  DEFAULT (right(suser_sname(),len(suser_sname())-charindex('\',suser_sname()))) FOR [RequestUser]
GO
ALTER TABLE [dbo].[RMS_us_fl_susceptibility_Log] ADD  CONSTRAINT [DF_RMS_us_fl_susceptibility_Log_LookupCacheCount]  DEFAULT ((0)) FOR [LookupCacheCount]
GO
ALTER TABLE [dbo].[RMS_us_fl_susceptibility_Log]  WITH CHECK ADD  CONSTRAINT [CK_RMS_us_fl_susceptibility_Log_CheckJSON] CHECK  ((isjson([ResponseJSON])=(1)))
GO

ALTER TABLE [dbo].[RMS_us_fl_susceptibility_Log] CHECK CONSTRAINT [CK_RMS_us_fl_susceptibility_Log_CheckJSON]
GO
ALTER TABLE [dbo].[RMS_us_fl_susceptibility_Log]  WITH CHECK ADD  CONSTRAINT [CK_RMS_us_fl_susceptibility_Log_CheckJSONRequest] CHECK  ((isjson([RequestJSON])=(1)))
GO

ALTER TABLE [dbo].[RMS_us_fl_susceptibility_Log] CHECK CONSTRAINT [CK_RMS_us_fl_susceptibility_Log_CheckJSONRequest]