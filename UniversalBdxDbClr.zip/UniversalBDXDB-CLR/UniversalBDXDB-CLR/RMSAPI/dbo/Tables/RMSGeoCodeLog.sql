﻿CREATE TABLE [dbo].[RMSGeoCodeLog](
	[RequestID] [INT] IDENTITY(1,1) NOT NULL,
	[RequestDate] [DATETIME] NULL,
	[RequestUser] [VARCHAR](50) NULL,
	[ApplicationSource] [VARCHAR](255) NULL,
	[CountryCode] [VARCHAR](500) NULL,
	[CountryScheme] [VARCHAR](50) NULL,
	[Admin1Code] [VARCHAR](50) NULL,
	[PostalCode] [VARCHAR](50) NULL,
	[StreetAddress] [VARCHAR](255) NULL,
	[ResponseJSON] [NVARCHAR](MAX) NULL,
	[ResponseDate] [DATETIME] NULL,
	[LookupCacheCount] [INT] NULL,
 [RMSAPIVersion] VARCHAR(50) NULL, 
    CONSTRAINT [PK_RMSGeoCodeLog] PRIMARY KEY CLUSTERED 
(
	[RequestID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[RMSGeoCodeLog] ADD  CONSTRAINT [DF_RMSGeoCodeLog_RequestDate]  DEFAULT (getdate()) FOR [RequestDate]
GO

ALTER TABLE [dbo].[RMSGeoCodeLog] ADD  CONSTRAINT [DF_RMSGeoCodeLog_RequestUser]  DEFAULT (right(suser_sname(),len(suser_sname())-charindex('\',suser_sname()))) FOR [RequestUser]
GO

ALTER TABLE [dbo].[RMSGeoCodeLog] ADD  CONSTRAINT [DF_RMSGeoCodeLog_LookupCacheCount]  DEFAULT ((0)) FOR [LookupCacheCount]
GO

ALTER TABLE [dbo].[RMSGeoCodeLog]  WITH CHECK ADD  CONSTRAINT [CK_RMSGeoCodeLog_CheckJSON] CHECK  ((isjson([ResponseJSON])=(1)))
GO

ALTER TABLE [dbo].[RMSGeoCodeLog] CHECK CONSTRAINT [CK_RMSGeoCodeLog_CheckJSON]
GO


