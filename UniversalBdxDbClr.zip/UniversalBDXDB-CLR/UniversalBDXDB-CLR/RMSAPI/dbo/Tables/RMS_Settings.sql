﻿create table [dbo].[RMS_Settings](
	[access_token] [varchar](8000) not null
)