﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;
using System.Net;
using System.Xml;

namespace SanctionsCheck
{
    public partial class UserDefinedFunctions
    {
        [Microsoft.SqlServer.Server.SqlProcedure]
        public static void sp_SanctionsCheck(SqlString InsuredName, double TermSimilarity, int MinScore, out double Score, out bool Passed, out string URL)
        {
            try
            {
                string url = @"http://www.clientclear.co.uk/api/SearchName?searchPhrase=" + System.Uri.EscapeDataString(InsuredName.Value) + "&termSimilarity=" + TermSimilarity.ToString() + "&minimumScore=" + MinScore.ToString() + "searchAka=true";
                URL = url;
                HttpWebRequest myReq = (HttpWebRequest)WebRequest.Create(url);
                myReq.Method = WebRequestMethods.Http.Get;
                myReq.Accept = "application/xml";

                var response = (HttpWebResponse)myReq.GetResponse();

                //XML
                System.Xml.XmlDocument xmlDoc = new System.Xml.XmlDocument();
                xmlDoc.Load(response.GetResponseStream());

                Score = 0;
                foreach (XmlElement i in xmlDoc.DocumentElement.ChildNodes)
                {
                    if (i.Name == "MatchedItem")
                    {
                        if (Double.Parse(i["HitScore"].InnerText) > Score)
                            Score = Double.Parse(i["HitScore"].InnerText);
                    }
                }

                //Return Messages
                if (Score < MinScore)
                {
                    Passed = true;
                }
                else
                {
                    Passed = false;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    };
}

