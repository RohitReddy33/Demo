using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;
using System.Net;
using Microsoft.SqlServer.Server;

public partial class StoredProcedures
{
    public class TokenObject
    {
        public string token { get; set; }
        public long expires { get; set; }
        public bool ssl { get; set; }
    }
    private static string GetAccessToken()
    {
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

        var methodAction = "GET";

        const string url = "https://www.arcgis.com/sharing/generateToken?username=charlie.grosvenor@bellandclements.com&password=vwDv47C2&f=json&referer=arcgis.com";

        var request = (HttpWebRequest)WebRequest.Create(url);
        request.Method = methodAction;

        try
        {
            using (var response = (HttpWebResponse)request.GetResponse())
            {
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    TokenObject tokenObject = Newtonsoft.Json.JsonConvert.DeserializeObject<TokenObject>(new StreamReader(response.GetResponseStream()).ReadToEnd());
                    return tokenObject.token;
                }
                else
                {
                    throw new Exception("Error: " + response.StatusCode);
                }
            }
        }
        catch (WebException e)
        {
            using (WebResponse response = e.Response)
            {
                HttpWebResponse httpResponse = (HttpWebResponse)response;
                Console.WriteLine("Error code: {0}", httpResponse.StatusCode);
                using (Stream data = response.GetResponseStream())
                {
                    string text = new StreamReader(data).ReadToEnd();
                    Console.WriteLine(text);
                }
            }

            throw new Exception("Error: " + e.Message);
        }
        return "";
    }

    public class SpatialReference
    {
        public int wkid { get; set; }
        public int latestWkid { get; set; }
    }

    public class Location
    {
        public double x { get; set; }
        public double y { get; set; }
        public SpatialReference spatialReference { get; set; }
    }

    public class RootObject
    {
        public int objectId { get; set; }
        public string name { get; set; }
        public string value { get; set; }
        public Location location { get; set; }
        public object properties { get; set; }
        public object catalogItems { get; set; }
        public List<object> catalogItemVisibilities { get; set; }
    }


    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void sp_ESRI_Distance_To_Coast (SqlDouble lat, SqlDouble lng)
    {
        string token = GetAccessToken();
        SqlContext.Pipe.Send(token);

        string url = @"https://oceans2.arcgis.com/arcgis/rest/services/Distance_to_Coast/ImageServer/identify?geometry=%7B%22x%22%3A{0}%2C%22y%22%3A{1}%2C%22spatialReference%22%3A%7B%22wkid%22%3A4326%7D%7D&geometryType=esriGeometryPoint&mosaicRule=&renderingRule=&renderingRules=&pixelSize=&time=&returnGeometry=false&returnCatalogItems=false&f=pjson&token={2}";

        var methodAction = "GET";
        var request = (HttpWebRequest)WebRequest.Create(string.Format(url, lat, lng, token));
        request.Method = methodAction;

        try
        {
            using (var response = (HttpWebResponse)request.GetResponse())
            {
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    string responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();

                    RootObject rootObject = Newtonsoft.Json.JsonConvert.DeserializeObject<RootObject>(responseString);

                    //Return JSON 
                    SqlDataRecord record = new SqlDataRecord(new SqlMetaData[] { new SqlMetaData("JSON", SqlDbType.NVarChar, -1), new SqlMetaData("value", SqlDbType.Int) });
                    record.SetString(0, responseString);
                    record.SetInt32(1, int.Parse(rootObject.value));
                    SqlContext.Pipe.Send(record);
                   
                    SqlContext.Pipe.Send(rootObject.value);

                    return ;
                }
                else
                {
                    throw new Exception("Error: " + response.StatusCode);
                }
            }
        }
        catch (WebException e)
        {
            using (WebResponse response = e.Response)
            {
                HttpWebResponse httpResponse = (HttpWebResponse)response;
                Console.WriteLine("Error code: {0}", httpResponse.StatusCode);
                using (Stream data = response.GetResponseStream())
                {
                    string text = new StreamReader(data).ReadToEnd();
                    Console.WriteLine(text);
                }
            }

            throw new Exception("Error: " + e.Message);
        }
    }

    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void sp_ESRI_GeoCodeCLR(SqlString Street, SqlString City, SqlString State, SqlString Postal, out float Latitude, out float Longitude, out string Addr_type, out string JSON)
    {
        Latitude = 0;
        Longitude = 0;
        Addr_type = "";
        JSON = "";
        ESRI.ESRIGeocoder eSRIGeocoder = new ESRI.ESRIGeocoder();

        ESRI.ESRIGeocoder.ESRICoordinates eSRICoordinates = eSRIGeocoder.GeoCode(Street.Value, City.Value, State.Value, Postal.Value);

        Latitude = (float)eSRICoordinates.Latitude;
        Longitude = (float)eSRICoordinates.Longitude;
        Addr_type = eSRICoordinates.Addr_type;
        JSON = eSRICoordinates.JSON;
    }
}
