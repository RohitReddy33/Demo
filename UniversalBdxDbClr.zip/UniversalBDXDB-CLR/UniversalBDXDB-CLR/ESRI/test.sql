﻿DECLARE @Street nvarchar(max)
DECLARE @City nvarchar(max)
DECLARE @State nvarchar(max)
DECLARE @Postal nvarchar(max)
DECLARE @Latitude numeric(18,0)
DECLARE @Longitude numeric(18,0)
DECLARE @Addr_type nvarchar(max)
DECLARE @JSON nvarchar(max)

-- TODO: Set parameter values here.

execute [dbo].[sp_ESRI_GeoCodeCLR] 
   '1 Main Street'
  ,'Brooklen'
  ,'NY'
  ,'12312'
  ,@Latitude output
  ,@Longitude output
  ,@Addr_type output
  ,@JSON output

select  @Latitude




