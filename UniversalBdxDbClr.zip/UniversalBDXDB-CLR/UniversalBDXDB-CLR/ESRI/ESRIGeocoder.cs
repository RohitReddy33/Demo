using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;

namespace ESRI
{
    class ESRIGeocoder
    {
        private const string username = "BellandClements";
        private const string password = "tWVVUWZsh2w3kH5L";
        public class TokenObject
        {
            public string token { get; set; }
            public long expires { get; set; }
            public bool ssl { get; set; }
        }

        TokenObject _tokenObject = null;

        private string GetAccessToken()
        {
            if (_tokenObject != null)
            {
                DateTime dateTime1970 = new DateTime(1970, 1, 1);

                if (DateTime.Now < dateTime1970.AddMilliseconds(_tokenObject.expires)) return _tokenObject.token;
            }

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

            var methodAction = "GET";

            const string url = "https://www.arcgis.com/sharing/generateToken?username={0}&password={1}&f=json&referer=arcgis.com";

            var request = (HttpWebRequest)WebRequest.Create(string.Format(url, username, password));
            request.Method = methodAction;

            try
            {
                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        _tokenObject = Newtonsoft.Json.JsonConvert.DeserializeObject<TokenObject>(new StreamReader(response.GetResponseStream()).ReadToEnd());
                        return _tokenObject.token;
                    }
                    else
                    {
                        throw new Exception("Error: " + response.StatusCode);
                    }
                }
            }
            catch (WebException e)
            {
                using (WebResponse response = e.Response)
                {
                    HttpWebResponse httpResponse = (HttpWebResponse)response;
                    Console.WriteLine("Error code: {0}", httpResponse.StatusCode);
                    using (Stream data = response.GetResponseStream())
                    {
                        string text = new StreamReader(data).ReadToEnd();
                        Console.WriteLine(text);
                    }
                }

                throw new Exception("Error: " + e.Message);
            }
        }

        private class SpatialReference
        {
            public int wkid { get; set; }
            public int latestWkid { get; set; }
        }

        private class Location
        {
            public double x { get; set; }
            public double y { get; set; }
            public SpatialReference spatialReference { get; set; }
        }

        private class Attributes
        {
            public string Addr_type { get; set; }
        }

        private class Extent
        {
            public double xmin { get; set; }
            public double ymin { get; set; }
            public double xmax { get; set; }
            public double ymax { get; set; }
        }

        private class Candidate
        {
            public string address { get; set; }
            public Location location { get; set; }
            public double score { get; set; }
            public Attributes attributes { get; set; }
            public Extent extent { get; set; }
        }

        private class RootObjectGeoCode
        {
            public SpatialReference spatialReference { get; set; }
            public List<Candidate> candidates { get; set; }
        }

        public class ESRICoordinates
        {
            public ESRICoordinates()
            {

            }

            public ESRICoordinates(double latitude, double longitude, double score, string jSON, string addr_type)
            {
                Latitude = latitude;
                Longitude = longitude;
                Score = score;
                JSON = jSON;
                Addr_type = addr_type;
            }

            public double Latitude { get; set; }

            public double Longitude { get; set; }

            public double Score { get; set; }

            public string JSON { get; set; }

            public string Addr_type { get; set; }
        }

        public ESRICoordinates GeoCode(string InsuredStreet, string InsuredCity, string InsuredState, string InsuredZipCode)
        {
            string accessTokten = GetAccessToken();
            string address = WebUtility.UrlEncode(string.Format("{0},{1},{2},{3}", InsuredStreet, InsuredCity, InsuredState, InsuredZipCode).Replace(",,", ","));

            string url = "https://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer/findAddressCandidates?f=pjson&outFields=Addr_type&SingleLine={0}&forStorage=true&token={1}";

            var methodAction = "GET";
            var request = (HttpWebRequest)WebRequest.Create(string.Format(url, address, accessTokten));
            request.Method = methodAction;

            try
            {
                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        string responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();

                        RootObjectGeoCode rootObject = Newtonsoft.Json.JsonConvert.DeserializeObject<RootObjectGeoCode>(responseString);

                        ESRICoordinates eSRICoordinates = new ESRICoordinates();

                        eSRICoordinates.Latitude = rootObject.candidates[0].location.x;
                        eSRICoordinates.Longitude = rootObject.candidates[0].location.y;
                        eSRICoordinates.Score = rootObject.candidates[0].score;
                        eSRICoordinates.Addr_type = rootObject.candidates[0].attributes.Addr_type;
                        eSRICoordinates.JSON = responseString;

                        return eSRICoordinates;
                    }
                    else
                    {
                        throw new Exception("Error: " + response.StatusCode);
                    }
                }
            }
            catch (WebException e)
            {
                using (WebResponse response = e.Response)
                {
                    HttpWebResponse httpResponse = (HttpWebResponse)response;
                    Console.WriteLine("Error code: {0}", httpResponse.StatusCode);
                    using (Stream data = response.GetResponseStream())
                    {
                        string text = new StreamReader(data).ReadToEnd();
                        Console.WriteLine(text);
                    }
                }

                throw new Exception("Error: " + e.Message);
            }
        }
    }
}
