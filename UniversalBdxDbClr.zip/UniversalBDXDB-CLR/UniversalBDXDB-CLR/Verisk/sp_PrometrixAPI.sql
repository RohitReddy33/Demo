﻿CREATE PROCEDURE [dbo].[sp_PrometrixAPI]
	@streetAddress [nvarchar](max),
	@city [nvarchar](max),
	@state [nvarchar](max),
	@zipcode [nvarchar](max),
	@applicationSource [nvarchar](max)
AS
	CREATE TABLE #TempTable
	(
		RequestID INT,
		XMLData XML
	)

	DECLARE @RequestID INT

	--if Already looked up and less then 2 years get from cache.
	SELECT @RequestID=RequestID FROM PrometrixAPILog WHERE RequestDate>DATEADD(YEAR,-2, GETDATE())
				AND StreetAddress=@streetAddress AND City=@city AND State=@state AND Zip=@zipcode
					
	IF @RequestID IS NOT NULL
		BEGIN		
			UPDATE PrometrixAPILog
				SET LookupCacheCount=ISNULL(LookupCacheCount,0) + 1
			WHERE RequestID=@RequestID

			INSERT INTO #TempTable
			SELECT RequestID, Response
			FROM PrometrixAPILog
			WHERE RequestID=@RequestID
		END
	ELSE
		BEGIN
			INSERT INTO #TempTable
			EXEC sp_PrometrixAPICLR @streetAddress, @city, @state, @zipcode, @applicationSource
		END


	SELECT CASE WHEN @RequestID IS NULL THEN 'LIVE' ELSE 'CACHE' END AS Source, #TempTable.RequestID, PrometrixAPILog.RequestDate, 
			C.query('*').value('(/BuildDescription)[1]', 'varchar(255)') AS BuildDescription,
			C.query('*').value('(/RiskId)[1]', 'varchar(255)') AS RiskId,
			C.query('*').value('(/YearBuilt)[1]', 'varchar(255)') AS YearBuilt,
			C.query('*').value('(/NumberOfStories)[1]', 'varchar(255)') AS NumberOfStories,
			C.query('*').value('(/SquareFootage)[1]', 'varchar(255)') AS SquareFootage,		
			C.query('*').value('(/RoofShape)[1]', 'varchar(255)') AS RoofShape,
			C.query('*').value('(/RoofConstruction)[1]', 'varchar(255)') AS RoofConstruction,
			C.query('*').value('(/RoofAge/RoofYear)[1]', 'varchar(255)') AS RoofAge,
			C.query('*').value('(/RoofAge/ConfidenceScore)[1]', 'varchar(255)') AS RoofAgeConfidenceScore,
			C.query('*').value('(/ConstructionType/Code)[1]', 'varchar(255)') AS ConstructionTypeCode,
			C.query('*').value('(/ConstructionType/Description)[1]', 'varchar(255)') AS ConstructionTypeDescription,
			C.query('*').value('(/OccupancyType/Code)[1]', 'varchar(255)') AS OccupancyTypeCode,
			C.query('*').value('(/OccupancyType/Description)[1]', 'varchar(255)') AS OccupancyTypeDescription
	FROM #TempTable 
		CROSS APPLY XMLData.nodes('BellAndClementsCustomReports/BellAndClementsCustomReport') T(C)
		INNER JOIN PrometrixAPILog ON #TempTable.RequestID=PrometrixAPILog.RequestID


	DROP TABLE #TempTable