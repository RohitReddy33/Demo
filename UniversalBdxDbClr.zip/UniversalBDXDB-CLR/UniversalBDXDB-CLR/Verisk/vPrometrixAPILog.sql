﻿CREATE VIEW vPrometrixAPILog
As
SELECT PrometrixAPILog.[RequestID],
      PrometrixAPILog.[RequestDate],
      PrometrixAPILog.[RequestUser],
      PrometrixAPILog.[ApplicationSource],
      PrometrixAPILog.[StreetAddress],
      PrometrixAPILog.[City],
      PrometrixAPILog.[State],
      PrometrixAPILog.[Zip],
      PrometrixAPILog.[URL],
      PrometrixAPILog.[ResponseDate],
      PrometrixAPILog.[LookupCacheCount], 
		C.query('*').value('(/BuildDescription)[1]', 'varchar(255)') AS BuildDescription,
		C.query('*').value('(/RiskId)[1]', 'varchar(255)') AS RiskId,
		C.query('*').value('(/YearBuilt)[1]', 'varchar(255)') AS YearBuilt,
		C.query('*').value('(/NumberOfStories)[1]', 'varchar(255)') AS NumberOfStories,
		C.query('*').value('(/SquareFootage)[1]', 'varchar(255)') AS SquareFootage,		
		C.query('*').value('(/RoofShape)[1]', 'varchar(255)') AS RoofShape,
		C.query('*').value('(/RoofConstruction)[1]', 'varchar(255)') AS RoofConstruction,
		C.query('*').value('(/RoofAge/RoofYear)[1]', 'varchar(255)') AS RoofAge,
		C.query('*').value('(/RoofAge/ConfidenceScore)[1]', 'varchar(255)') AS RoofAgeConfidenceScore,
		C.query('*').value('(/ConstructionType/Code)[1]', 'varchar(255)') AS ConstructionTypeCode,
		C.query('*').value('(/ConstructionType/Description)[1]', 'varchar(255)') AS ConstructionTypeDescription,
		C.query('*').value('(/OccupancyType/Code)[1]', 'varchar(255)') AS OccupancyTypeCode,
		C.query('*').value('(/OccupancyType/Description)[1]', 'varchar(255)') AS OccupancyTypeDescription
	FROM PrometrixAPILog
	CROSS APPLY Response.nodes('BellAndClementsCustomReports/BellAndClementsCustomReport') T(C)