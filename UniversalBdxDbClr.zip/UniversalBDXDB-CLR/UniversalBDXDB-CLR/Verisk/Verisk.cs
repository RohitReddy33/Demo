﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Verisk
{ 
    public class PrometrixAPI
    {
        private static readonly string URL = "https://prometrixapiuat.iso.com/uw/Address/Report/BellAndClements?streetname={0}&city={1}&state={2}&zip={3}";
        private static readonly string Username = "BellClementsUAT";
        private static readonly string Branch = "001";
        private static readonly string Password = "SMbH9!j8PF";

        public static string GetAuthenticationToken()
        {
            string postData = "grant_type=password&username=" + Username + "&Password=" + Password;
            var data = Encoding.ASCII.GetBytes(postData);

            var request = (HttpWebRequest)WebRequest.Create("https://veriskcpapiuat.iso.com/login");
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = data.Length;

            using (var stream = request.GetRequestStream())
            {
                stream.Write(data, 0, data.Length);
            }

            using (var response = (HttpWebResponse)request.GetResponse())
            {
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                    //JObject o = JObject.Parse(responseString);

                    AccessToken accessToken = new AccessToken(responseString);

                    return accessToken.access_token;
                    //return (string)o["access_token"];
                }
                else
                {
                    throw new Exception();
                }
            }
        }

        public static string APICall(SqlString streetAddress, SqlString city, SqlString state, SqlString zipcode)
        {
            //Build URL
            string url = string.Format(URL, streetAddress.Value, city.Value, state.Value, zipcode.Value);

            var accept = "text/xml"; //application/json
            var methodAction = "GET";
            var request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = methodAction;
            request.Accept = accept;
            request.Headers.Add("access_token", GetAuthenticationToken());
            request.Headers.Add("branch", "001");
            using (var response = (HttpWebResponse)request.GetResponse())
            {
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    return new StreamReader(response.GetResponseStream()).ReadToEnd();
                }
                else
                {
                    throw new Exception();
                }
            }
        }

        private struct AccessToken
        {
            public AccessToken(string jSONResponse)
            {
                access_token = "";
                token_type = "";
                expires_in = 0;
                token_date = DateTime.Now;

                jSONResponse = jSONResponse.Substring(1, jSONResponse.Length - 2);

                string[] responsearray = jSONResponse.Split(',');

                foreach (string i in responsearray)
                {
                    string name = i.Substring(0, i.IndexOf(':')).Replace("\"", "");
                    string value = i.Substring(i.IndexOf(":") + 1).Replace("\"", "");

                    if (name == "access_token") access_token = value;
                    if (name == "token_type") token_type = value;
                    if (name == "expires_in") expires_in = int.Parse(value);
                }
            }

            public string access_token;
            public string token_type;
            public DateTime token_date;
            public int expires_in;
        }
    }
}
