using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Text;
using System.Net;

public partial class StoredProcedures
{
    private static readonly string zws_id="X1-ZWz1925pqg4wej_540hi";
    private static readonly string ZillowURL = "http://www.zillow.com/webservice/GetDeepSearchResults.htm?zws-id={0}&address={1}&citystatezip={2}&rentzestimate={3}";

    public static APICallResult ZillowAPICall(SqlString streetAddress, SqlString city, SqlString state, SqlString zipcode)
    {
        //Build URL
        string address = streetAddress.Value + "," + city.Value + "," + state.Value + "," + zipcode.Value;

        string url = string.Format(ZillowURL, zws_id, address, zipcode.Value, true);

        SqlContext.Pipe.Send(url);

        var accept = "text/xml"; //application/json
        var methodAction = "GET";
        var request = (HttpWebRequest)WebRequest.Create(url);
        request.Method = methodAction;
        request.Accept = accept;
        using (var response = (HttpWebResponse)request.GetResponse())
        {
            if (response.StatusCode == HttpStatusCode.OK)
            {
                APICallResult result = new APICallResult();
                result.URL = url;
                result.XML = new StreamReader(response.GetResponseStream()).ReadToEnd();

                return result;
            }
            else
            {
                throw new Exception();
            }
        }
    }

    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void sp_ZillowAPICLR(SqlString streetAddress, SqlString city, SqlString state, SqlString zipcode, SqlString applicationSource)
    {
        int requestID = 0;

        //Log Request
        using (SqlConnection connection = new SqlConnection("context connection=true"))
        {
            connection.Open();
            SqlCommand command = new SqlCommand("INSERT INTO [dbo].[ZillowAPILog] ([ApplicationSource],[StreetAddress] ,[City] ,[State] ,[Zip]) VALUES (@ApplicationSource, @StreetAddress, @City ,@State, @Zip); SELECT CAST(@@IDENTITY AS INT)", connection);
            command.Parameters.Add(new SqlParameter("ApplicationSource", applicationSource));
            command.Parameters.Add(new SqlParameter("StreetAddress", streetAddress));
            command.Parameters.Add(new SqlParameter("City", city));
            command.Parameters.Add(new SqlParameter("State", state));
            command.Parameters.Add(new SqlParameter("Zip", zipcode));
            requestID = (int)command.ExecuteScalar();
        }

        if (!streetAddress.IsNull) streetAddress = new SqlString(System.Uri.EscapeDataString(streetAddress.Value));
        if (!city.IsNull) city = new SqlString(System.Uri.EscapeDataString(city.Value));

        //Get XML
        APICallResult aPICallResult = ZillowAPICall(streetAddress, city, state, zipcode);

        //Error when over quota
        var xmlDocument = new XmlDocument();
        xmlDocument.Load(new StringReader(aPICallResult.XML));

        var nsmgr = new XmlNamespaceManager(xmlDocument.NameTable);
        nsmgr.AddNamespace("SearchResults", "http://www.zillow.com/static/xsd/SearchResults.xsd");

        var code = xmlDocument.SelectSingleNode("/SearchResults:searchresults/message/code", nsmgr).InnerText;
        var codeText = xmlDocument.SelectSingleNode("/SearchResults:searchresults/message/text", nsmgr).InnerText;

        if (code == "7") throw new Exception("Error: this account has reached is maximum number of calls for today");

        SqlContext.Pipe.Send(accessToken.access_token);

        //Log Response
        using (SqlConnection connection = new SqlConnection("context connection=true"))
        {
            connection.Open();
            SqlCommand command1 = new SqlCommand("UPDATE [dbo].[ZillowAPILog] SET [Response] = @Response, [ResponseDate]=@ResponseDate, URL=@URL, Code=@Code, Message=@Message WHERE RequestID=@RequestID", connection);
            command1.Parameters.Add(new SqlParameter("Response", new SqlXml(aPICallResult.XML.ToStream())));
            command1.Parameters.Add(new SqlParameter("ResponseDate", DateTime.Now));            
            command1.Parameters.Add(new SqlParameter("URL", aPICallResult.URL));
            command1.Parameters.Add(new SqlParameter("Code", code));
            command1.Parameters.Add(new SqlParameter("Message", codeText));
            command1.Parameters.Add(new SqlParameter("RequestID", requestID));
            command1.ExecuteNonQuery();
        }

        //Return XML
        SqlDataRecord record = new SqlDataRecord(new SqlMetaData("RequestID", SqlDbType.Int), new SqlMetaData("XMLResponse", SqlDbType.Xml));

        // Mark the begining of the result-set.
        SqlContext.Pipe.SendResultsStart(record);

        record.SetInt32(0, requestID);
        record.SetSqlXml(1, new SqlXml(new XmlTextReader(new System.IO.StringReader(aPICallResult.XML))));

        // Send the row back to the client.
        SqlContext.Pipe.SendResultsRow(record);

        // Mark the end of the result-set.
        SqlContext.Pipe.SendResultsEnd();
    }
}
