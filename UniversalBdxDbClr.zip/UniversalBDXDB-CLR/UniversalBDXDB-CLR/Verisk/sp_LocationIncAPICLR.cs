using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Text;
using System.Net;

public partial class StoredProcedures
{
    private static readonly string auth_token_LocationInc= "3697b700b388e6490c5e9ee74f087198fa0a6e0fa931fe74a327a6d6d460404b";
    private static readonly string LocationIncURL = "https://api.locationinc.com/api/v1/addr?auth_token={0}&request_uuid={1}&address={2}";    

    public static APICallResult LocationIncAPICall(int UUID, SqlString streetAddress, SqlString city, SqlString state, SqlString zipcode)
    {
        ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

        //Build URL
        string address = streetAddress.Value + "," + city.Value + "," + state.Value + "," + zipcode.Value;

        string url = string.Format(LocationIncURL, auth_token_LocationInc, UUID.ToString(),address);

        SqlContext.Pipe.Send(url);

        var accept = "text/xml"; //application/json
        var methodAction = "GET";
        var request = (HttpWebRequest)WebRequest.Create(url);
        request.Method = methodAction;
        request.Accept = accept;
        using (var response = (HttpWebResponse)request.GetResponse())
        {
            if (response.StatusCode == HttpStatusCode.OK)
            {
                APICallResult result = new APICallResult();
                result.URL = url;
                result.XML = new StreamReader(response.GetResponseStream()).ReadToEnd();

                return result;
            }
            else
            {
                throw new Exception();
            }
        }
    }

    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void sp_LocationIncAPICLR(SqlString streetAddress, SqlString city, SqlString state, SqlString zipcode, SqlString applicationSource)
    {
        int requestID = 0;

        //Log Request
        using (SqlConnection connection = new SqlConnection("context connection=true"))
        {
            connection.Open();
            SqlCommand command = new SqlCommand("INSERT INTO [dbo].[LocationIncAPILog] ([ApplicationSource],[StreetAddress] ,[City] ,[State] ,[Zip]) VALUES (@ApplicationSource, @StreetAddress, @City ,@State, @Zip); SELECT CAST(@@IDENTITY AS INT)", connection);
            command.Parameters.Add(new SqlParameter("ApplicationSource", applicationSource));
            command.Parameters.Add(new SqlParameter("StreetAddress", streetAddress));
            command.Parameters.Add(new SqlParameter("City", city));
            command.Parameters.Add(new SqlParameter("State", state));
            command.Parameters.Add(new SqlParameter("Zip", zipcode));
            requestID = (int)command.ExecuteScalar();
        }

        if (!streetAddress.IsNull) streetAddress = new SqlString(System.Uri.EscapeDataString(streetAddress.Value));
        if (!city.IsNull) city = new SqlString(System.Uri.EscapeDataString(city.Value));

        //Get XML
        APICallResult aPICallResult = LocationIncAPICall(requestID, streetAddress, city, state, zipcode);

        //Log Response
        using (SqlConnection connection = new SqlConnection("context connection=true"))
        {
            connection.Open();
            SqlCommand command1 = new SqlCommand("UPDATE [dbo].[LocationIncAPILog] SET [Response] = @Response, [ResponseDate]=@ResponseDate, URL=@URL, Code=@Code, Message=@Message WHERE RequestID=@RequestID", connection);
            command1.Parameters.Add(new SqlParameter("Response", aPICallResult.XML));
            command1.Parameters.Add(new SqlParameter("ResponseDate", DateTime.Now));            
            command1.Parameters.Add(new SqlParameter("URL", aPICallResult.URL));
            command1.Parameters.Add(new SqlParameter("Code", null));
            command1.Parameters.Add(new SqlParameter("Message", null));
            command1.Parameters.Add(new SqlParameter("RequestID", requestID));
            command1.ExecuteNonQuery();
        }

        //Return Data
        SqlDataRecord record = new SqlDataRecord(new SqlMetaData("RequestID", SqlDbType.Int), new SqlMetaData("JSONResponse", SqlDbType.VarChar,-1));

        // Mark the begining of the result-set.
        SqlContext.Pipe.SendResultsStart(record);

        record.SetInt32(0, requestID);
        record.SetSqlString(1, aPICallResult.XML);

        // Send the row back to the client.
        SqlContext.Pipe.SendResultsRow(record);

        // Mark the end of the result-set.
        SqlContext.Pipe.SendResultsEnd();
    }
}
