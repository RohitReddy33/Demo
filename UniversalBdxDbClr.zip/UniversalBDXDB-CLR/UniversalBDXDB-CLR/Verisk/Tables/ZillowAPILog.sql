﻿CREATE TABLE [dbo].[ZillowAPILog](
	[RequestID] [int] IDENTITY(1,1) NOT NULL,
	[RequestDate] [datetime] NULL DEFAULT GETDATE(),
	[RequestUser] [varchar](50) NULL DEFAULT (right(suser_sname(),(len(suser_sname()) - charindex('\',suser_sname())))),
	[ApplicationSource] [varchar](255) NULL,
	[StreetAddress] [varchar](500) NULL,
	[City] [varchar](50) NULL,
	[State] [varchar](50) NULL,
	[Zip] [varchar](50) NULL,
	[URL] [varchar](255) NULL,
	[Response] [xml] NULL,
	[ResponseDate] [datetime] NULL,
	[LookupCacheCount] [int] NULL,
	[Code] Varchar(255) NULL,
	[Message] Varchar(255) NULL
 CONSTRAINT [PK_ZillowAPILog] PRIMARY KEY CLUSTERED 
(
	[RequestID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
