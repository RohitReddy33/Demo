﻿CREATE TABLE [dbo].[LocationIncAPILog]
(
	[RequestID] [int] IDENTITY(1,1) NOT NULL,
	[RequestDate] [datetime] NULL DEFAULT GETDATE(),
	[RequestUser] [varchar](50) NULL DEFAULT (right(suser_sname(),(len(suser_sname()) - charindex('\',suser_sname())))),
	[ApplicationSource] [varchar](255) NULL,
	[StreetAddress] [varchar](500) NULL,
	[City] [varchar](50) NULL,
	[State] [varchar](50) NULL,
	[Zip] [varchar](50) NULL,
	[URL] [varchar](255) NULL,
	[Response] VARCHAR(MAX) NULL,
	[ResponseDate] [datetime] NULL,
	[LookupCacheCount] [int] NULL,
	[Code] Varchar(255) NULL,
	[Message] Varchar(255) NULL, 
    CONSTRAINT [PK_LocationIncAPILog] PRIMARY KEY ([RequestID])
)
