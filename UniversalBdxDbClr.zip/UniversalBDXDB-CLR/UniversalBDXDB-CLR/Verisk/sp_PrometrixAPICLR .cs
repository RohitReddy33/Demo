#define TESTACCOUNT

using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;
using System.IO;
using System.Xml;
using System.Text;
using System.Net;

public static class ExtensionMethods2
{
    public static Stream ToStream(this string str)
    {
        MemoryStream stream = new MemoryStream();
        StreamWriter writer = new StreamWriter(stream);
        writer.Write(str);
        writer.Flush();
        stream.Position = 0;
        return stream;
    }
}

public partial class StoredProcedures
{
#if (TESTACCOUNT)
    private static readonly string URL = "https://prometrixapiuat.iso.com/uw/Address/Report/BellAndClements?streetname={0}&city={1}&state={2}&zip={3}";
    private static readonly string Username = "BellClementsUAT";
    private static readonly string Branch = "001";
    private static readonly string Password = "SMbH9!j8PF";
    private static readonly string AuthURL = "https://veriskcpapiuat.iso.com/login";
#else
    private static readonly string URL = "https://prometrixapi.iso.com/uw/Address/Report/BellAndClements?streetname={0}&city={1}&state={2}&zip={3}";
    private static readonly string Username = "BellClementsAPI";
    private static readonly string Branch = "001";
    private static readonly string Password = "fY36va*e2G";
    private static readonly string AuthURL = "https://veriskcpapi.iso.com/login";
#endif


    private static AccessToken accessToken = new AccessToken();

    public static string GetAuthenticationToken()
    {
        lock (accessToken)
        {
            if (accessToken.IsExpired())
            {
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

                string postData = "grant_type=password&username=" + Username + "&Password=" + Password;
                var data = Encoding.ASCII.GetBytes(postData);

                var request = (HttpWebRequest)WebRequest.Create(AuthURL);
                request.Method = "POST";
                request.ContentType = "application/x-www-form-urlencoded";
                request.ContentLength = data.Length;

                using (var stream = request.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }

                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                        //JObject o = JObject.Parse(responseString);

                        accessToken = new AccessToken(responseString);

                        return accessToken.access_token;
                        //return (string)o["access_token"];
                    }
                    else
                    {
                        throw new Exception();
                    }
                }
            }
            else
            {
                return accessToken.access_token;
            }
        }
    }

    public struct APICallResult
    {
        public string URL;
        public string XML;
    }

    public static APICallResult APICall(SqlString streetAddress, SqlString city, SqlString state, SqlString zipcode)
    {
        //Build URL
        string url = string.Format(URL, streetAddress.Value, city.Value, state.Value, zipcode.Value);

        SqlContext.Pipe.Send(url);
        SqlContext.Pipe.Send(Username);

        ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

        var accept = "text/xml"; //application/json
        var methodAction = "GET";
        var request = (HttpWebRequest)WebRequest.Create(url);
        request.Method = methodAction;
        request.Accept = accept;
        request.Headers.Add("access_token", GetAuthenticationToken());
        request.Headers.Add("branch", "001");
        using (var response = (HttpWebResponse)request.GetResponse())
        {
            if (response.StatusCode == HttpStatusCode.OK)
            {
                APICallResult result = new APICallResult();
                result.URL = url;
                result.XML= new StreamReader(response.GetResponseStream()).ReadToEnd();

                return result;
            }
            else
            {
                throw new Exception();
            }
        }
    }

    private class AccessToken : INullable
    {
        public AccessToken()
        {
            access_token = "";
        }

        public AccessToken(string jSONResponse)
        {
            access_token = "";
            token_type = "";
            expires_in = 0;
            token_date = DateTime.Now;

            jSONResponse = jSONResponse.Substring(1, jSONResponse.Length - 2);

            string[] responsearray = jSONResponse.Split(',');

            foreach (string i in responsearray)
            {
                string name = i.Substring(0, i.IndexOf(':')).Replace("\"", "");
                string value = i.Substring(i.IndexOf(":") + 1).Replace("\"", "");

                if (name == "access_token") access_token = value;
                if (name == "token_type") token_type = value;
                if (name == "expires_in") expires_in = int.Parse(value);
            }
        }

        public string access_token;
        public string token_type;
        public DateTime token_date;
        public int expires_in;

        public bool IsNull
        {
            get
            {
                return access_token == "";
            }
        }

        public bool IsExpired()
        {
            if (IsNull || token_date.AddSeconds(expires_in-30)<DateTime.Now)
            {
                return true;
            }
            return false;
        }
    }

    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void sp_PrometrixAPICLR(SqlString streetAddress, SqlString city, SqlString state, SqlString zipcode, SqlString applicationSource)
    {
        int requestID = 0;

        //Log Request
        using (SqlConnection connection = new SqlConnection("context connection=true"))
        {
            connection.Open();
            SqlCommand command = new SqlCommand("INSERT INTO [dbo].[PrometrixAPILog] ([ApplicationSource],[StreetAddress] ,[City] ,[State] ,[Zip]) VALUES (@ApplicationSource, @StreetAddress, @City ,@State, @Zip); SELECT CAST(@@IDENTITY AS INT)", connection);
            command.Parameters.Add(new SqlParameter("ApplicationSource", applicationSource));
            command.Parameters.Add(new SqlParameter("StreetAddress", streetAddress));
            command.Parameters.Add(new SqlParameter("City", city));
            command.Parameters.Add(new SqlParameter("State", state));
            command.Parameters.Add(new SqlParameter("Zip", zipcode));
            requestID = (int)command.ExecuteScalar();
        }

        if (!streetAddress.IsNull) streetAddress = new SqlString(System.Uri.EscapeDataString(streetAddress.Value));
        if (!city.IsNull) city = new SqlString(System.Uri.EscapeDataString(city.Value));

        //Get XML
        APICallResult aPICallResult = APICall(streetAddress, city, state, zipcode);

        SqlContext.Pipe.Send(accessToken.access_token);

        //Log Response
        using (SqlConnection connection = new SqlConnection("context connection=true"))
        {
            connection.Open();
            SqlCommand command1 = new SqlCommand("UPDATE [dbo].[PrometrixAPILog] SET [Response] = @Response, [ResponseDate]=@ResponseDate, URL=@URL WHERE RequestID=@RequestID", connection);
            command1.Parameters.Add(new SqlParameter("Response", new SqlXml(aPICallResult.XML.ToStream())));
            command1.Parameters.Add(new SqlParameter("ResponseDate", DateTime.Now));
            command1.Parameters.Add(new SqlParameter("RequestID", requestID));
            command1.Parameters.Add(new SqlParameter("URL", aPICallResult.URL));
            command1.ExecuteNonQuery();
        }

        //Return XML
        SqlDataRecord record = new SqlDataRecord(new SqlMetaData("RequestID", SqlDbType.Int), new SqlMetaData("XMLResponse", SqlDbType.Xml));

        // Mark the begining of the result-set.
        SqlContext.Pipe.SendResultsStart(record);

        record.SetInt32 (0, requestID);
        record.SetSqlXml(1, new SqlXml(new XmlTextReader(new System.IO.StringReader(aPICallResult.XML))));

        // Send the row back to the client.
        SqlContext.Pipe.SendResultsRow(record);

        // Mark the end of the result-set.
        SqlContext.Pipe.SendResultsEnd();
    }
}