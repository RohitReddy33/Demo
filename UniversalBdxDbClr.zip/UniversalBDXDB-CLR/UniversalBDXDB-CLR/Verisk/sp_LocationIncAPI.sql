﻿CREATE PROCEDURE [dbo].[sp_LocationIncAPI]
	@streetAddress [nvarchar](max),
	@city [nvarchar](max),
	@state [nvarchar](max),
	@zipcode [nvarchar](max),
	@applicationSource [nvarchar](max)
AS
	CREATE TABLE #TempTable
	(
		RequestID INT,
		XMLData VARCHAR(MAX)
	)

	DECLARE @RequestID INT

	--if Already looked up and less then 2 years get from cache.
	SELECT @RequestID=RequestID FROM LocationIncAPILog WHERE RequestDate>DATEADD(YEAR,-2, GETDATE())
				AND StreetAddress=@streetAddress AND City=@city AND State=@state AND Zip=@zipcode
					
	IF @RequestID IS NOT NULL
		BEGIN		
			UPDATE LocationIncAPILog
				SET LookupCacheCount=ISNULL(LookupCacheCount,0) + 1
			WHERE RequestID=@RequestID

			INSERT INTO #TempTable
			SELECT RequestID, Response
			FROM LocationIncAPILog
			WHERE RequestID=@RequestID
		END
	ELSE
		BEGIN
			INSERT INTO #TempTable
			EXEC sp_LocationIncAPICLR @streetAddress, @city, @state, @zipcode, @applicationSource
		END

	DECLARE @JSON VARCHAR(max)

	SELECT @JSON=XMLData
	FROM #TempTable

	SELECT  JSON_VALUE(@JSON,'$.data.data_products."block.fire_risk".fire_risk') AS fire_risk, JSON_VALUE(@JSON,'$.data.data_products."block.fire_risk".fire_risk') AS water_risk

	DROP TABLE #TempTable

GO