﻿CREATE PROCEDURE [dbo].[sp_ZillowAPI]
	@streetAddress [nvarchar](max),
	@city [nvarchar](max),
	@state [nvarchar](max),
	@zipcode [nvarchar](max),
	@applicationSource [nvarchar](max)
AS
	CREATE TABLE #TempTable
	(
		RequestID INT,
		XMLData XML
	)

	DECLARE @RequestID INT

	--if Already looked up and less then 2 years get from cache.
	SELECT @RequestID=RequestID FROM ZillowAPILog WHERE RequestDate>DATEADD(YEAR,-2, GETDATE())
				AND StreetAddress=@streetAddress AND City=@city AND State=@state AND Zip=@zipcode
					
	IF @RequestID IS NOT NULL
		BEGIN		
			UPDATE ZillowAPILog
				SET LookupCacheCount=ISNULL(LookupCacheCount,0) + 1
			WHERE RequestID=@RequestID

			INSERT INTO #TempTable
			SELECT RequestID, Response
			FROM ZillowAPILog
			WHERE RequestID=@RequestID
		END
	ELSE
		BEGIN
			INSERT INTO #TempTable
			EXEC sp_ZillowAPICLR @streetAddress, @city, @state, @zipcode, @applicationSource
		END

	UPDATE #TempTable SET XMLData=REPLACE(CAST(XMLData AS VARCHAR(MAX)),'SearchResults:searchresults','SearchResults')

	SELECT CASE WHEN @RequestID IS NULL THEN 'LIVE' ELSE 'CACHE' END AS Source, #TempTable.RequestID, ZillowAPILog.RequestDate
			,C.query('*').value('(/links/homedetails)[1]', 'varchar(255)') AS homedetailsURL
			,C.query('*').value('(/links/graphsanddata)[1]', 'varchar(255)') AS graphsanddataURL
			,C.query('*').value('(/links/mapthishome)[1]', 'varchar(255)') AS mapthishomeURL
			,C.query('*').value('(/links/comparables)[1]', 'varchar(255)') AS comparablesURL
			,C.query('*').value('(/yearBuilt)[1]', 'varchar(255)') AS yearBuilt
			,C.query('*').value('(/lotSizeSqFt)[1]', 'varchar(255)') AS lotSizeSqFt
			,C.query('*').value('(/finishedSqFt)[1]', 'varchar(255)') AS finishedSqFt
			,C.query('*').value('(/bathrooms)[1]', 'varchar(255)') AS bathrooms
			,C.query('*').value('(/bedrooms)[1]', 'varchar(255)') AS bedrooms
			,C.query('*').value('(/totalRooms)[1]', 'varchar(255)') AS totalRooms
	FROM #TempTable 
		CROSS APPLY XMLData.nodes('/SearchResults/response/results/result') T(C)
		INNER JOIN ZillowAPILog ON #TempTable.RequestID=ZillowAPILog.RequestID

	DROP TABLE #TempTable
