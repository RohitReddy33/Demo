﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Text;
using Microsoft.SqlServer.Server;
[Serializable]
[Microsoft.SqlServer.Server.SqlUserDefinedAggregate(Format.UserDefined, MaxByteSize = -1)]
public class CSV : IBinarySerialize
{
    private StringBuilder Result;
    public void Init()
    {
        this.Result = new StringBuilder();
    }

    public void Accumulate(SqlChars Value)
    {
        if (Value.IsNull) return;
        if (Result.Length > 0) this.Result.Append(",");
        this.Result.Append(Value.Value);
    }
    public void Merge(CSV Group)
    {
        this.Result.Append(Group.Result);
    }
    public SqlChars Terminate()
    {
        return new SqlChars(this.Result.ToString());
    }
    public void Read(System.IO.BinaryReader r)
    {
        this.Result = new StringBuilder(r.ReadString());
    }
    public void Write(System.IO.BinaryWriter w)
    {
        w.Write(this.Result.ToString());
    }
}