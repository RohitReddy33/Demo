﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;
using System.IO;
using System.Collections;

public partial class UserDefinedFunctions
{
    [SqlFunction(Name = "CLRSplit",
    FillRowMethodName = "FillRow", TableDefinition = "ID NVARCHAR(max)")]
    public static IEnumerable SqlArray([SqlFacet(MaxSize = -1)]SqlString str, SqlChars delimiter)
    {
        if (str.IsNull) return new string[] { };
        //return single element array if no delimiter is specified
        if (delimiter.Length == 0)
            return new string[1] { str.Value };

        //split the string and return a string array
        return str.Value.Split(delimiter[0]);
    }

    public static void FillRow(object row, out SqlString str)
    {
        //set the column value
        str = new SqlString((string)row);
    }

    [Microsoft.SqlServer.Server.SqlFunction]
    public static bool IsValidDocucorpFileName(SqlString input)
    {
        System.Text.RegularExpressions.Regex fileNameRegEx = new System.Text.RegularExpressions.Regex(@"DCXP_[A-Z]{1,15}_.*", System.Text.RegularExpressions.RegexOptions.Compiled);

        if (input.IsNull) return false;

        if (fileNameRegEx.Match(input.Value.ToUpper()).Value == input.Value.ToUpper()) return true;

        return false;
    }

    [Microsoft.SqlServer.Server.SqlFunction]
    public static bool ValidCharsForStreetAddress(SqlString input)
    {
        System.Text.RegularExpressions.Regex fileNameRegEx = new System.Text.RegularExpressions.Regex(@"[\w\s\.\-\&,\+\#\/'\(\):;\042]*", System.Text.RegularExpressions.RegexOptions.Compiled);

        if (input.IsNull) return false;

        if (fileNameRegEx.Match(input.Value.ToUpper()).Value == input.Value.ToUpper()) return true;

        return false;
    }

    [Microsoft.SqlServer.Server.SqlFunction]
    public static bool IsValidUniversalFileName(SqlString input)
    {
        System.Text.RegularExpressions.Regex fileNameRegEx = new System.Text.RegularExpressions.Regex(@"[A|G|L|U][P|C]_[A-Z]{1,15}_[A-Z][0-9]{4}(_|[A-Z])[0-9]{2}[A-Z]{3}[0-9]{2}[P|W]\.XLSX?", System.Text.RegularExpressions.RegexOptions.Compiled);

        if (input.IsNull) return false;

        if (fileNameRegEx.Match(input.Value.ToUpper()).Value == input.Value.ToUpper()) return true;

        return false;
    }

    [Microsoft.SqlServer.Server.SqlFunction]
    public static bool IsValidLegacyFileName(SqlString input)
    {
        if (IsValidLegacyGLUKFileName(input) || IsValidLegacyAMIGFileName(input))
        {
            return true;
        }

        return false;
    }

    [Microsoft.SqlServer.Server.SqlFunction]
    public static bool IsValidLegacyGLUKFileName(SqlString input)
    {
        System.Text.RegularExpressions.Regex fileNameRegEx = new System.Text.RegularExpressions.Regex(@"G[A-Z]{2}[P|C][A-Z]{1}[0-9]{4}[0-9]{2}[0-9]{4}\.XLSX?", System.Text.RegularExpressions.RegexOptions.Compiled);

        if (input.IsNull) return false;

        if (fileNameRegEx.Match(input.Value.ToUpper()).Value == input.Value.ToUpper()) return true;

        return false;
    }

    [Microsoft.SqlServer.Server.SqlFunction]
    public static bool IsValidLegacyAMIGFileName(SqlString input)
    {
        System.Text.RegularExpressions.Regex fileNameRegEx = new System.Text.RegularExpressions.Regex(@"[A-Z]{3}[P|C][0-9]{4}(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC){1}[0-9]{4}\.XLSX?", System.Text.RegularExpressions.RegexOptions.Compiled);

        if (input.IsNull) return false;

        if (fileNameRegEx.Match(input.Value.ToUpper()).Value == input.Value.ToUpper()) return true;

        return false;
    }

    [Microsoft.SqlServer.Server.SqlFunction]
    public static bool IsValidFileName(SqlString input)
    {
        if (IsValidLegacyFileName(input) || IsValidUniversalFileName(input) || IsValidDocucorpFileName(input)) return true;

        return false;
    }

    [Microsoft.SqlServer.Server.SqlFunction]
    public static SqlString GetFileNameContract(SqlString input)
    {
        if (input.IsNull) return null;

        string afterUniqueAgentReference = input.Value.Substring(input.Value.IndexOf("_") + 1);
        afterUniqueAgentReference = afterUniqueAgentReference.Substring(afterUniqueAgentReference.IndexOf("_") + 1);

        return afterUniqueAgentReference.Substring(1, 4);
    }

    [Microsoft.SqlServer.Server.SqlFunction]
    public static SqlString GetFileNameSection(SqlString input)
    {
        if (input.IsNull) return null;

        string afterUniqueAgentReference = input.Value.Substring(input.Value.IndexOf("_") + 1);
        afterUniqueAgentReference = afterUniqueAgentReference.Substring(afterUniqueAgentReference.IndexOf("_") + 1);

        return afterUniqueAgentReference.Substring(5, 1);
    }

    [Microsoft.SqlServer.Server.SqlFunction]
    public static SqlString GetFileNameUniqueAgentReference(SqlString input)
    {
        return "ACME";
    }

    [Microsoft.SqlServer.Server.SqlFunction]
    public static SqlBoolean DoesInsuredAddressContainInvalidCharacters(SqlString input)
    {
        if (input.IsNull) return false;

        System.Text.RegularExpressions.Regex fileNameRegEx = new System.Text.RegularExpressions.Regex(@"[a-zA-Z0-9\s''-\.\#\&\\/]*", System.Text.RegularExpressions.RegexOptions.Compiled);

        if (fileNameRegEx.Match(input.Value.ToUpper()).Value != input.Value.ToUpper()) return true;

        return false;
    }

    [Microsoft.SqlServer.Server.SqlFunction]
    public static SqlBoolean DoesStringContainNumbers(SqlString input)
    {
        if (input.IsNull) return false;

        System.Text.RegularExpressions.Regex fileNameRegEx = new System.Text.RegularExpressions.Regex(@"(?=(?:.*?\d){2})", System.Text.RegularExpressions.RegexOptions.Compiled);

        return fileNameRegEx.Match(input.Value).Success;
    }

    [Microsoft.SqlServer.Server.SqlFunction]
    public static SqlBoolean DoesStringContainUpperCase(SqlString input)
    {
        if (input.IsNull) return false;

        System.Text.RegularExpressions.Regex fileNameRegEx = new System.Text.RegularExpressions.Regex(@"(?=(?:.*?[A-Z]){1})", System.Text.RegularExpressions.RegexOptions.Compiled);

        return fileNameRegEx.Match(input.Value).Success;
    }

    [Microsoft.SqlServer.Server.SqlFunction]
    public static SqlBoolean DoesStringContainLowerCase(SqlString input)
    {
        if (input.IsNull) return false;

        System.Text.RegularExpressions.Regex fileNameRegEx = new System.Text.RegularExpressions.Regex(@"(?=(?:.*?[a-z]){1})", System.Text.RegularExpressions.RegexOptions.Compiled);

        return fileNameRegEx.Match(input.Value).Success;
    }

    [Microsoft.SqlServer.Server.SqlFunction]
    public static SqlBoolean DoesStringContainSpecialCharacters(SqlString input)
    {
        if (input.IsNull) return false;

        System.Text.RegularExpressions.Regex fileNameRegEx = new System.Text.RegularExpressions.Regex(@"(?=(?:.*?[!@#$%*()_+^&}{:;?.]){1})", System.Text.RegularExpressions.RegexOptions.Compiled);

        return fileNameRegEx.Match(input.Value).Success;
    }

    [Microsoft.SqlServer.Server.SqlFunction]
    public static SqlBoolean DoesStringMatchRegEx(SqlString input, SqlString regEx)
    {
        if (input.IsNull) return false;

        System.Text.RegularExpressions.Regex fileNameRegEx = new System.Text.RegularExpressions.Regex(regEx.Value);

        return (fileNameRegEx.Match(input.Value).Value == input.Value);
    }
};
