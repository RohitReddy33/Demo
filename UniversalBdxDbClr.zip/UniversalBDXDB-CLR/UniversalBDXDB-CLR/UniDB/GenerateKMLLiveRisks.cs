﻿//using System;
//using System.Data;
//using System.Data.SqlClient;
//using System.Data.SqlTypes;
//using Microsoft.SqlServer.Server;
//using System.IO;
//using System.Xml;


//public partial class StoredProcedures
//{
//    [Microsoft.SqlServer.Server.SqlProcedure]
//    public static void GenerateKMLLiveRisks(string insuredState, string insuredCounty, string companyId, SqlDateTime inforceDate, SqlDateTime startDate, string windIndication, string contractType, string businessArea, int includePendingData, out SqlXml results, out int kMLNoDocFeatures)
//    {
//        kMLNoDocFeatures = 0;
//        using (SqlConnection connection = new SqlConnection("context connection=true"))
//        {
//            connection.Open();
//            SqlCommand command = new SqlCommand();
//            command.CommandText = @"sp_rInforceAggregates2Geo";
//            command.CommandType = CommandType.StoredProcedure;
//            command.Connection = connection;
//            SqlCommandBuilder.DeriveParameters(command);

//            command.Parameters["@insuredState"].Value=insuredState;
//            command.Parameters["@insuredCounty"].Value=insuredCounty;
//            command.Parameters["@companyId"].Value=companyId;
//            command.Parameters["@inforceDate"].Value=inforceDate;
//            command.Parameters["@startDate"].Value=startDate;
//            command.Parameters["@windIndication"].Value=windIndication;
//            command.Parameters["@contractType"].Value=contractType;
//            command.Parameters["@businessArea"].Value=businessArea;
//            command.Parameters["@includePendingData"].Value = includePendingData;

//            SqlDataReader reader = command.ExecuteReader();

//            using (var buffer = new MemoryStream())
//            {
//                using (XmlWriter writer = XmlWriter.Create(buffer, new XmlWriterSettings { CheckCharacters = false }))
//                {
//                    writer.WriteStartDocument();
//                    writer.WriteStartElement("kml", "http://www.opengis.net/kml/2.2");
//                    //Document
//                    writer.WriteStartElement("Document");
//                    writer.WriteElementString("name", "B&C Data " + DateTime.Now.ToString());
//                    writer.WriteElementString("open", "1");
//                    writer.WriteElementString("description", @"Policies Live At: " + DateTime.Now.ToString());

//                    string companyName = "";
//                    string contractRef = "";

//                    using (reader)
//                    {
//                        while (reader.Read())
//                        {
//                            if (string.Compare(companyName, (string)reader["CompanyName"]) != 0)
//                            {
//                                if (companyName != "")
//                                {
//                                    writer.WriteEndElement();
//                                    writer.WriteEndElement();
//                                }
//                                companyName = (string)reader["CompanyName"];
//                                contractRef = "";
//                                //Folder
//                                writer.WriteStartElement("Folder");
//                                writer.WriteElementString("name", companyName);
//                                writer.WriteElementString("description", companyName);
//                            }

//                            if (string.Compare(contractRef, (string)reader["contract"]) != 0)
//                            {
//                                if (contractRef != "") writer.WriteEndElement();
//                                contractRef = (string)reader["contract"];
//                                //Folder
//                                writer.WriteStartElement("Folder");
//                                writer.WriteElementString("name", contractRef);
//                                writer.WriteElementString("description", "Contract:" + contractRef);
//                            }

//                            kMLNoDocFeatures++;
//                            writer.WriteStartElement("Placemark");
//                            writer.WriteElementString("name", reader["policyno"].ToString());
//                            writer.WriteStartElement("description");

//                            writer.WriteCData(@"<table style='width: 100%; border: 1.5pt solid #808080;'>
//	                            <tr>
//		                            <td style='font-weight: bold; color: white; border-style: none; background-color: #808080;width: 110px;'>PolicyNo</td>
//		                            <td style='font-weight: bold;color: white;border-style: none;background-color: #808080;'>" + reader["policyno"] + @"</td>
//	                            </tr>
//	                            <tr>
//		                            <td style='border-style: none;width: 110px;' valign='top'>Effective Date:</td>
//		                            <td style='border-style: none;'>" + (reader["EffectiveDate"] is DateTime ? ((DateTime)reader["EffectiveDate"]).ToString("ddMMMyyyy") : "") + @"</td>
//	                            </tr>
//	                            <tr>
//		                            <td style='border-style: none;width: 110px;' valign='top'>Expiry Date:</td>
//		                            <td style='border-style: none;'>" + (reader["ExpirationDate"] is DateTime ? ((DateTime)reader["ExpirationDate"]).ToString("ddMMMyyyy") : "") + @"</td>
//	                            </tr>
//	                            <tr>
//		                            <td style='border-style: none;width: 110px;' valign='top'>Insured Address:</td>
//		                            <td style='border-style: none;'>" + reader["InsuredAddressText"].ToString() + @"</td>
//	                            </tr>
//	                            <tr>
//		                            <td style='border-style: none;width: 110px;' valign='top'>Property Limit:</td>
//		                            <td style='border-style: none;'>" + (reader["TotalPropertyLimit"] is DBNull ? "0" : ((Decimal)reader["TotalPropertyLimit"]).ToString("N2")) + @"</td>
//	                            </tr>
//	                            <tr>
//		                            <td style='border-style: none;' colspan='2'>
//			                            <p><a href='https://bridge.bellandclements.com/Pages/RecordsViewer/PolicyRecordViewer.aspx?policyNo=" + reader["policyNo"] + @"' target='_new'>View In Records Viewer</a></p>
//		                            </td>
//	                            </tr>
//                            </table>");
//                            writer.WriteEndElement();
//                            writer.WriteStartElement("Point");
//                            writer.WriteElementString("coordinates", reader["Long"].ToString() + "," + reader["Lat"].ToString());
//                            writer.WriteEndElement();
//                            writer.WriteEndElement();
//                        }
//                    }
//                    reader.Close();

//                    writer.WriteEndElement();
//                    writer.Flush();
//                }

//                buffer.Position = 0;
//                using (XmlReader xmlReader = XmlReader.Create(buffer, new XmlReaderSettings { CheckCharacters = false }))
//                {
//                    results=new SqlXml(xmlReader);
//                }
//            }
//        }

//    }
//};
