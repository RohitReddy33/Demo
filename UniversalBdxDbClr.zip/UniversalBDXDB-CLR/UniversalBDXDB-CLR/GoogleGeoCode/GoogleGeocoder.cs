﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Web;
using System.Net;
using System.Xml.Linq;
using System.Security.Cryptography;

namespace GeoCode
{
    internal interface IGeocoder
    {
        GoogleCoordinates Geocode(string address);
    }

    public class GoogleCoordinates
    {
        public GoogleCoordinates(double latitude, double longitude, string location_Type)
        {
            Latitude = latitude;
            Longitude = longitude;
            Location_Type = location_Type;
        }

        public double Latitude { get; private set; }

        public double Longitude { get; private set; }

        public string Location_Type { get; private set; }
    }

    public class GoogleElevation
    {
        public GoogleElevation(double elevation, double resolution, string status)
        {
            Elevation = elevation;
            Resolution = resolution;
            Status = status;
        }

        public double Elevation { get; private set; }

        public double Resolution { get; private set; }

        public string Status { get; private set; }
    }

    internal class GoogleGeocoder : IGeocoder
    {
        private const string ServiceUri = "http://maps.googleapis.com/maps/api/geocode/xml?address={0}&region=be&sensor=false";
        private const string ServiceUriElevation = "http://maps.googleapis.com/maps/api/elevation/xml?locations={0}";
        private const string ClientID = "gme-bellandclementsltd1";
        private const string CryptoKey = "KMDIB1ye46UOpwdUP4d2hQvJoHU=";

        public GoogleCoordinates Geocode(string address)
        {
            if (string.IsNullOrEmpty(address))
                throw new ArgumentNullException("address");

            string requestUriString = string.Format(ServiceUri, Uri.EscapeDataString(address));

            if (ClientID != "")
            {
                requestUriString += "&client=" + ClientID;

                //Sign
                requestUriString = Sign(requestUriString, CryptoKey);
            }

            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(requestUriString);

            try
            {
                WebResponse response = request.GetResponse();

                System.Xml.XmlReader responseXML = System.Xml.XmlReader.Create(response.GetResponseStream());

                XDocument xdoc = XDocument.Load(responseXML);

                // Verify the GeocodeResponse status
                string status = xdoc.Element("GeocodeResponse").Element("status").Value;
                ValidateGeocodeResponseStatus(status, address);

                XElement locationElement = xdoc.Element("GeocodeResponse").Element("result").Element("geometry").Element("location");
                double latitude = (double)locationElement.Element("lat");
                double longitude = (double)locationElement.Element("lng");

                XElement locationTypeElement = xdoc.Element("GeocodeResponse").Element("result").Element("geometry").Element("location_type");

                return new GoogleCoordinates(latitude, longitude, locationTypeElement.Value);
            }
            catch (UnknownAddressException)
            {
                return new GoogleCoordinates(0, 0, "UNKNOWN_ADDRESS");
            }
            catch (InvalidRequestException)
            {
                return new GoogleCoordinates(0, 0, "INVALID_REQUEST");
            }
            catch (WebException ex)
            {
                switch (ex.Status)
                {
                    case WebExceptionStatus.NameResolutionFailure:
                        throw new ServiceOfflineException("The Google Maps geocoding service appears to be offline.", ex);
                    default:
                        throw;
                }
            }
        }

        public GoogleElevation Elevation(double latitude, double longitude)
        {
            string requestUriString = string.Format(ServiceUriElevation, latitude + "," + longitude);

            if (ClientID != "")
            {
                requestUriString += "&client=" + ClientID;

                //Sign
                requestUriString = Sign(requestUriString, CryptoKey);
            }

            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(requestUriString);

            try
            {
                WebResponse response = request.GetResponse();

                System.Xml.XmlReader responseXML = System.Xml.XmlReader.Create(response.GetResponseStream());

                XDocument xdoc = XDocument.Load(responseXML);

                // Verify the GeocodeResponse status
                string status = xdoc.Element("ElevationResponse").Element("status").Value;
                ValidateGeocodeResponseStatus(status, latitude, longitude);

                XElement locationElement = xdoc.Element("ElevationResponse").Element("result");
                double elevation = (double)locationElement.Element("elevation");
                double resolution = (double)locationElement.Element("resolution");

                XElement statusElement = xdoc.Element("ElevationResponse").Element("status");

                return new GoogleElevation(elevation, resolution, statusElement.Value);
            }
            catch (UnknownAddressException)
            {
                return new GoogleElevation(0, 0, "UNKNOWN_ADDRESS");
            }
            catch (InvalidRequestException)
            {
                return new GoogleElevation(0, 0, "INVALID_REQUEST");
            }
            catch (WebException ex)
            {
                switch (ex.Status)
                {
                    case WebExceptionStatus.NameResolutionFailure:
                        throw new ServiceOfflineException("The Google Maps geocoding service appears to be offline.", ex);
                    default:
                        throw;
                }
            }
        }

        public class ServiceOfflineException : Exception
        {
            public ServiceOfflineException()
            {
            }

            public ServiceOfflineException(string message)
                : base(message)
            {
            }

            public ServiceOfflineException(string message, Exception ex)
                : base(message)
            {
            }
        }

        public class UnknownAddressException : Exception
        {
            public UnknownAddressException()
            {
            }

            public UnknownAddressException(string message)
                : base(message)
            {
            }
        }

        public class OverQueryLimitException : Exception
        {
            public OverQueryLimitException()
            {
            }

            public OverQueryLimitException(string message)
                : base(message)
            {
            }
        }

        public class InvalidRequestException : Exception
        {
            public InvalidRequestException()
            {
            }

            public InvalidRequestException(string message)
                : base(message)
            {
            }
        }

        private void ValidateGeocodeResponseStatus(string status, string address)
        {
            switch (status)
            {
                case "ZERO_RESULTS":
                    string message = string.Format("No coordinates found for address \"{0}\".", address);
                    throw new UnknownAddressException(message);
                case "OVER_QUERY_LIMIT":
                    throw new OverQueryLimitException();
                case "INVALID_REQUEST":
                    throw new InvalidRequestException();
                case "OK":
                    break;
                default:
                    throw new Exception("Unkown status code: " + status + ".");
            }
        }

        private void ValidateGeocodeResponseStatus(string status, double latitude, double longitude)
        {
            string message = "";
            switch (status)
            {
                case "UNKNOWN_ERROR":
                    message = string.Format("Unknown error for address \"{0}\".", latitude + "," + longitude);
                    throw new UnknownAddressException(message);
                case "REQUEST_DENIED":
                    message = string.Format("Request Denied for address \"{0}\".", latitude + "," + longitude);
                    throw new UnknownAddressException(message);
                case "OVER_QUERY_LIMIT":
                    throw new OverQueryLimitException();
                case "INVALID_REQUEST":
                    throw new InvalidRequestException();
                case "OK":
                    break;
                default:
                    throw new Exception("Unkown status code: " + status + ".");
            }
        }

        public static string Sign(string url, string keyString)
        {
            ASCIIEncoding encoding = new ASCIIEncoding();
            // converting key to bytes will throw an exception, need to replace '-' and '_' characters first.     
            string usablePrivateKey = keyString.Replace("-", "+").Replace("_", "/");
            byte[] privateKeyBytes = Convert.FromBase64String(usablePrivateKey);
            Uri uri = new Uri(url); byte[] encodedPathAndQueryBytes = encoding.GetBytes(uri.LocalPath + uri.Query);
            // compute the hash    
            HMACSHA1 algorithm = new HMACSHA1(privateKeyBytes);
            byte[] hash = algorithm.ComputeHash(encodedPathAndQueryBytes);
            // convert the bytes to string and make url-safe by replacing '+' and '/' characters    
            string signature = Convert.ToBase64String(hash).Replace("+", "-").Replace("/", "_");
            // Add the signature to the existing URI.    
            return uri.Scheme + "://" + uri.Host + uri.LocalPath + uri.Query + "&signature=" + signature;
        }
    }
}

