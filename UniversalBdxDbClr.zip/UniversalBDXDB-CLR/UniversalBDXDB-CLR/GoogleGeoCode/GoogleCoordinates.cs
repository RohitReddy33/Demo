﻿//using System;
//using System.Data;
//using System.Data.SqlClient;
//using System.Data.SqlTypes;
//using Microsoft.SqlServer.Server;

//public struct GoogleCoordinates : INullable
//{
//    public GoogleCoordinates(double latitude, double longitude, string location_Type)
//    {
//        m_Latitude = latitude;
//        m_Longitude = longitude;
//        m_Location_Type = location_Type;
//        m_Null = false;
//    }

//    public override string ToString()
//    {
//        // Replace the following code with your code
//        return m_Latitude.ToString() + ";" + m_Longitude.ToString() + ";" + m_Location_Type;
//    }

//    public bool IsNull
//    {
//        get
//        {
//            // Put your code here
//            return m_Null;
//        }
//    }

//    public static GoogleCoordinates Null
//    {
//        get
//        {
//            GoogleCoordinates h = new GoogleCoordinates();
//            h.m_Null = true;
//            return h;
//        }
//    }

//    public static GoogleCoordinates Parse(SqlString s)
//    {
//        if (s.IsNull)
//            return Null;
//        GoogleCoordinates u = new GoogleCoordinates();
//        // Put your code here
//        return u;
//    }

//    // Private member
//    private bool m_Null;
//    private double m_Latitude;
//    private double m_Longitude;
//    private string m_Location_Type;

//    public double Latitude
//    {
//        get
//        {
//            return m_Latitude;
//        }
//    }

//    public double Longitude
//    {
//        get
//        {
//            return m_Longitude;
//        }
//    }

//    public string Location_Type
//    {
//        get
//        {
//            return m_Location_Type;
//        }
//    }
//}


