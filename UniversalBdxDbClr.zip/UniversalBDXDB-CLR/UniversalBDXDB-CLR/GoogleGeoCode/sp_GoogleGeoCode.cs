﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

namespace GeoCode
{
    public partial class StoredProcedures
    {
        [Microsoft.SqlServer.Server.SqlProcedure]
        public static void sp_GoogleGeoCode(SqlString address, out double Latitude, out double Longitude, out string LocationType)
        {
            Latitude = 0;
            Longitude = 0;
            LocationType = "Error";
            try
            {
                GoogleGeocoder googleGeocoder = new GoogleGeocoder();

                GoogleCoordinates cord = googleGeocoder.Geocode(address.Value);

                Latitude = cord.Latitude;
                Longitude = cord.Longitude;
                LocationType = cord.Location_Type;

            }
            catch (Exception)
            {
                
            }
        }

        [Microsoft.SqlServer.Server.SqlProcedure]
        public static void sp_GoogleElevation(double Latitude, double Longitude, out double Elevation, out double Resolution)
        {
            Elevation = 0;
            Resolution = 0;
            try
            {
                GoogleGeocoder googleGeocoder = new GoogleGeocoder();

                GoogleElevation cord = googleGeocoder.Elevation(Latitude, Longitude);

                Elevation = cord.Elevation;
                Resolution = cord.Resolution;
            }
            catch (Exception)
            {

            }
        }
    };
}