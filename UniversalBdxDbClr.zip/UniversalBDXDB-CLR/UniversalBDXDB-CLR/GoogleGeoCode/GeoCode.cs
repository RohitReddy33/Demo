﻿//using System;
//using System.Data;
//using System.Data.SqlClient;
//using System.Data.SqlTypes;
//using Microsoft.SqlServer.Server;

//namespace GeoCode
//{
//    public partial class UserDefinedFunctions
//    {
//        [Microsoft.SqlServer.Server.SqlFunction]
//        public static GoogleCoordinates GeoCoder(SqlString address)
//        {
//            try
//            {
//                GoogleGeocoder googleGeocoder  = new GoogleGeocoder();

//                GoogleCoordinates cord = googleGeocoder.Geocode(address.Value);

//                return cord;
//            }
//            catch (Exception ex)
//            {
//                throw ex;
//            }
//        }
//    };
//}

