﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Models.Domain.Shared
{
    public class ValidationResult
    {
        public string Key { get; set; }
        public List<string> ErrorMessages { get; set; }
    }
}
