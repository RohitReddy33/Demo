﻿
using Microsoft.AspNetCore.Http;

namespace Models.Domain.Shared
{
    public class Attachment
    {
        public byte[] Content { get; set; }
        public string FileName { get; set; }
        public string ContentType { get; set; }
        public string Path { get; set; }
        public IFormFile formFile { get; set; }
        public string UserName { get; set; }
        public int UserCompanyId { get; set; }
        public string UserEmail { get; set; }
    }
}
