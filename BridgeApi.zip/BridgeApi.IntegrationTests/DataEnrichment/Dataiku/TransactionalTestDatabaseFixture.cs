﻿using BridgeApi.Enquiry.Contexts;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using Xunit;

namespace BridgeApi.IntegrationTests.DataEnrichment.Dataiku
{
    #region TransactionalUniversalBDXDBContextFixture
    public class TransactionalTestDatabaseFixture : IDisposable
    {
        public UniversalBdxContext DbContext { get; private set; }

        public TransactionalTestDatabaseFixture()
        {                      

            DbContext = CreateDbContext();            
        }

        public void Dispose()
        {
            DbContext.Dispose();
        }

        private UniversalBdxContext CreateDbContext()
        {
            var host = Host.CreateDefaultBuilder().Build();
            var config = host.Services.GetRequiredService<IConfiguration>();
            

            var options = new DbContextOptionsBuilder<UniversalBdxContext>()
                .UseLazyLoadingProxies()
                .UseSqlServer(config.GetConnectionString("universalDatabaseConnection"))                 
                .Options;
           

            var context = new UniversalBdxContext(options);

            //context.Database.EnsureDeleted();
            context.Database.EnsureCreated();

            return context;
        }
    }
    #endregion

    #region CollectionDefinition
    [CollectionDefinition("TransactionalTests")]
    public class TransactionalTestsCollection : ICollectionFixture<TransactionalTestDatabaseFixture>
    {
    }
    #endregion
}
