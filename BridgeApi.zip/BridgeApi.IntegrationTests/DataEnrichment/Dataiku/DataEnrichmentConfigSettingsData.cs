﻿using BridgeApi.DataEnrichmentJobs.Helper;

namespace BridgeApi.IntegrationTests.DataEnrichment.Dataiku
{
    public static class DataEnrichmentConfigSettingsData
    {
        private static readonly string[] TransactionTypes = { "NEW", "QTE", "ENQ" };
        private static readonly string[] BusinessArea = { "GLUK", "Lloyds" };

        public static DataEnrichmentConfigSettings GetDataikuTargetedRateCriteria()
        {
            return new DataEnrichmentConfigSettings()
            {
                HangFireServerDatabaseConnection = string.Empty,
                DataikuTargetedRateCriteria = new DataikuTargetedRateCriteria()
                {
                    CronExp = string.Empty,
                    ContractYear = 2009,
                    Tivfgu = 2000000,
                    ExcludedPolicyNo = "GLUK2309",
                    NumberofLocations = 1,
                    PlacementType = 2,
                    HereonPercentage = 100,
                    TransactionTypes = TransactionTypes,
                    BusinessArea = BusinessArea
                }
            };
        }
    }
}
