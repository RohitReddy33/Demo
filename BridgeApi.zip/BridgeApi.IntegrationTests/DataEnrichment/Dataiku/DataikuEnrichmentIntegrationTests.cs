﻿
using BridgeApi.DataEnrichmentJobs.Helper;
using BridgeApi.DataEnrichmentJobs.Services.Dataiku;
using BridgeApi.Enquiry.Contexts;
using BridgeApi.Enquiry.Services;
using BridgeApi.Repositories;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.Net.Http;
using Xunit;

namespace BridgeApi.IntegrationTests.DataEnrichment.Dataiku
{
    public class DataikuEnrichmentIntegrationTests : IClassFixture<TransactionalTestDatabaseFixture>
    {
      

        private UniversalBdxContext dbContext;
        private IUniversalBdxRepository universalBdxRepository;
        private IDataikuService dataikuService;
        private DataEnrichmentConfigSettings dataEnrichmentConfiguration;
        private DataikuEnrichmentService dataikuEnrichmentService;

        public DataikuEnrichmentIntegrationTests(TransactionalTestDatabaseFixture fixture)
        {
            var host = Host.CreateDefaultBuilder().Build();
            var config = host.Services.GetRequiredService<IConfiguration>();
            var httpClient = new HttpClient();

            dbContext = fixture.DbContext;
            universalBdxRepository = new UniversalBdxRepository(dbContext, null, config);
            dataEnrichmentConfiguration = DataEnrichmentConfigSettingsData.GetDataikuTargetedRateCriteria();
            dataikuService = new DataikuService(httpClient, config,null);

            dataikuEnrichmentService = new DataikuEnrichmentService(universalBdxRepository, dataikuService, dataEnrichmentConfiguration);
        }

        [Fact]
        public void SyncTempPolicyTargetedRateforhomeowner()
        {
            dataikuEnrichmentService.SyncTempPolicyTargetedRateforhomeowner();
            Assert.Equal(1, 1);
        }
        [Fact]
        public void SyncPolicyTargetedRateforhomeowner()
        {
            dataikuEnrichmentService.SyncPolicyTargetedRateforhomeowner();
            Assert.Equal(1, 1);
        }
    }
}
            


