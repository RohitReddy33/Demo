﻿namespace BridgeApi.Constants
{
    public class PolicyConstants
    {
        public const string SameCompanyPolicy = "SameCompanyPolicy";
        public const string InternalCompanyPolicy = "InternalCompanyPolicy";
        public const string IdentityPolicy = "IdentityPolicy";
        public const string PropertyUnderwritingToolPolicy = "PropertyUnderwritingToolPolicy";
        public const string RecordsEditorPolicy = "RecordsEditorPolicy";
        public const string RecordsEditorResourcePolicy = "RecordsEditorResourcePolicy";
        public const string RecordsEditorAllReourcesPolicy = "RecordsEditorAllReourcesPolicy";
        public const string NotifyPolicy = "NotifyPolicy";
        public const string InternalPolicy = "InternalPolicy";
        public const string LawyersProfessionalLiabilitiesPolicy = "LawyersProfessionalLiabilitiesPolicy";
        public const string PolicySearcherRequirement = "PolicySearcherRequirement";
        public const string ClaimSearcherRequirement = "ClaimSearcherRequirement";
        public const string ApplicationAuthorizationRequirement = "ApplicationAuthorizationRequirement";
    }
    public class RoleConstants
    {
        public const string RecordsEditor = "Records Editor";
        public const string RecordsEditorReadOnly = "Records Editor Read Only";
        public const string RecordsViewer = "Records Viewer";
        public const string RecordsEditorRecordsOrRecordsEditorReadonly = "Records Editor,Records Editor Read Only";
        public const string UploadBordereau = "Upload Bordereau";
    }
}
