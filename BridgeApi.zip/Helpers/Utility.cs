﻿using System;
using System.Text.RegularExpressions;

namespace Helpers
{
    public static class Utility
    {
        public static bool IsValidStringValue(string value)
        {
            if (!string.IsNullOrEmpty(value) && !string.IsNullOrWhiteSpace(value)
                    && !value.Equals("undefined", StringComparison.OrdinalIgnoreCase))
                return true;

            return false;
        }
        
        public static bool ValidateContractRef(string contractRefs)
        {
            var validValues = true;
            var validContractRefRegEx = "[a-zA-Z0-9]{1,12}$";
            
            if(string.IsNullOrEmpty(contractRefs))
                return true;

            foreach (var value in contractRefs.Split(','))
            {
                var match = Regex.Match(value, validContractRefRegEx, RegexOptions.IgnoreCase);
                if (!match.Success)
                {
                    return validValues = false;
                }
            }

            return validValues;
        }

        public static bool ValidateTransCode(string transCodes)
        {
            var validValues = true;
            var validtransCodesRegEx = "[a-zA-Z]{1,3}$";

            if (string.IsNullOrEmpty(transCodes))
                return true;

            foreach (var value in transCodes.Split(','))
            {
                var match = Regex.Match(value, validtransCodesRegEx, RegexOptions.IgnoreCase);
                if (!match.Success)
                {
                    return validValues = false;
                }
            }

            return validValues;
        }
    }
}
