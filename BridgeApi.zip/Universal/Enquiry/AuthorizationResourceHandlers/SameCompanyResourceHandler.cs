﻿using System.Threading.Tasks;
using BridgeApi.Enquiry.Requirements;
using Microsoft.AspNetCore.Authorization;

namespace BridgeApi.Enquiry.AuthorizationResourceHandlers
{
    public class SameCompanyResourceHandler : AuthorizationHandler<SameCompanyRequirement, string>
    {
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, SameCompanyRequirement requirement, string resource)
        {
            if (context.User.Identity.IsAuthenticated && 
                (context.User.Identity.AuthenticationType == "Negotiate" 
                 || context.User.Identity.AuthenticationType == "Windows"
                 || context.User.Identity.AuthenticationType == "NTLM"))
            {
                context.Succeed(requirement);
                return Task.CompletedTask;
            }

            const string companyIdClaimKey = "companyId";
            if (!context.User.HasClaim(x => x.Type == companyIdClaimKey)) return Task.CompletedTask;

            var companyId = context.User.FindFirst(x => x.Type == companyIdClaimKey).Value;
            if (companyId != resource) return Task.CompletedTask;
            context.Succeed(requirement);
            return Task.CompletedTask;
        }
    }
}
