﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class NatureOfLocations
    {
        public NatureOfLocations()
        {
            TempPolicyTransactionsLocationsTransportation = new HashSet<TempPolicyTransactionsLocationsTransportation>();
            TempPolicyTransactionsTransportation = new HashSet<TempPolicyTransactionsTransportation>();
        }

        public int NatureOfLocations1 { get; set; }
        public string Description { get; set; }

        public virtual ICollection<TempPolicyTransactionsLocationsTransportation> TempPolicyTransactionsLocationsTransportation { get; set; }
        public virtual ICollection<TempPolicyTransactionsTransportation> TempPolicyTransactionsTransportation { get; set; }
    }
}
