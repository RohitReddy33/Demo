﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class KmlfeedCategories
    {
        public KmlfeedCategories()
        {
            Kmlfeeds = new HashSet<Kmlfeeds>();
        }

        public int KmlfeedCategoryId { get; set; }
        public string CategoryName { get; set; }
        public bool ShowOnEbridge { get; set; }

        public virtual ICollection<Kmlfeeds> Kmlfeeds { get; set; }
    }
}
