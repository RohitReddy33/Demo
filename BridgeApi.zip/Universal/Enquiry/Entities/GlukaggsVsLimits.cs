﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class GlukaggsVsLimits
    {
        public string BordMonthYear { get; set; }
        public string BusinessArea { get; set; }
        public string Gluksection { get; set; }
        public int ContractYear { get; set; }
        public int CompanyId { get; set; }
        public string CompanyName { get; set; }
        public string Description { get; set; }
        public string ContractRef { get; set; }
        public string StateCode { get; set; }
        public string Zone { get; set; }
        public long? Total { get; set; }
        public long? Wind { get; set; }
        public long? Quake { get; set; }
        public long? Flood { get; set; }
        public long? TotalUsage { get; set; }
        public long? WindUsage { get; set; }
        public long? QuakeUsage { get; set; }
        public long? FloodUsage { get; set; }
        public float? Total1 { get; set; }
        public float? Wind1 { get; set; }
        public float? Quake1 { get; set; }
        public float? Flood1 { get; set; }
        public decimal? PropertyPremium { get; set; }
    }
}
