﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class RatingSpreadsheetsZonesLookupZip
    {
        public int RatingSpreadSheetZoneId { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public bool? Include { get; set; }
        public DateTime? DateCreated { get; set; }

        public virtual RatingSpreadsheetsZonesLookup RatingSpreadSheetZone { get; set; }
    }
}
