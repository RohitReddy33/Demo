﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempPolicyTransactionsLocationsProtections
    {
        public long TempLocationsId { get; set; }
        public string Protections { get; set; }

        public virtual ArchiveTempPolicyTransactionsLocations TempLocations { get; set; }
    }
}
