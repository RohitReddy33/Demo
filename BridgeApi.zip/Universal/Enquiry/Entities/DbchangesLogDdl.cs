﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class DbchangesLogDdl
    {
        public int Id { get; set; }
        public int? ChangeId { get; set; }
        public DateTime? DateCreated { get; set; }
        public string UserCreated { get; set; }
        public string EventType { get; set; }
        public string Tsqlcommand { get; set; }
    }
}
