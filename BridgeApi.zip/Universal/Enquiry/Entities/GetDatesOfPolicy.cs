﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class GetDatesOfPolicy
    {
        public long? Id { get; set; }
        public string TransactionType { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
    }
}
