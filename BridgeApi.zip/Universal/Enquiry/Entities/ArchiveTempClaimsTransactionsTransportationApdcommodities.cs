﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempClaimsTransactionsTransportationApdcommodities
    {
        public long TempClaimsTransportationApdcommodityId { get; set; }
        public long TempTransportationId { get; set; }
        public string ApdcommodityScheme { get; set; }
        public int ApdcommodityType { get; set; }

        public virtual ArchiveTempClaimsTransactionsTransportation TempTransportation { get; set; }
    }
}
