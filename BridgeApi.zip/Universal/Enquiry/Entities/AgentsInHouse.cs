﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsInHouse
    {
        public int? CompanyId { get; set; }
        public string AgentsOfficeClientCode { get; set; }
        public string AgentsOffice { get; set; }
        public int Id { get; set; }
        public bool? InUse { get; set; }

        public virtual Agents Company { get; set; }
    }
}
