﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsContractsUnderwriters
    {
        public int Id { get; set; }
        public int UnderwriterId { get; set; }
        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }
        public bool? IsLead { get; set; }
        public string AppliesTo { get; set; }
        public decimal? WrittenLinePercentage { get; set; }
        public decimal? SignedLinePercentage { get; set; }
        public string UnderwritersReference { get; set; }

        public virtual AgentsContracts AgentsContracts { get; set; }
        public virtual Underwriters Underwriter { get; set; }
    }
}
