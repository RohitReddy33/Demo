﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class GlukEstimates
    {
        public double? Id { get; set; }
        public double? EstimatedOfNpipayableasPc { get; set; }
        public decimal? EstimatedNpi { get; set; }
        public decimal? EstimatedNetProfit { get; set; }
        public decimal? EstimatedProfitCommissiontoMga { get; set; }
        public decimal? EstimatedProfitCommissiontoBc { get; set; }
        public decimal? EstimatedUltimateNetProfit { get; set; }
    }
}
