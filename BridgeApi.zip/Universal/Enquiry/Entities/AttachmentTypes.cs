﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AttachmentTypes
    {
        public AttachmentTypes()
        {
            TempPolicyTransactionsAttachments = new HashSet<TempPolicyTransactionsAttachments>();
        }

        public long AttachmentType { get; set; }
        public string Description { get; set; }
        public bool? ShowInClientDropDownHomeowners { get; set; }
        public bool? ShowInClientDropDownCommercial { get; set; }

        public virtual ICollection<TempPolicyTransactionsAttachments> TempPolicyTransactionsAttachments { get; set; }
    }
}
