﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class IsocountryCodes
    {
        public string Iso3a { get; set; }
        public string CountryScheme { get; set; }
        public string CountryCode { get; set; }

        public virtual IsocountrySchemes CountrySchemeNavigation { get; set; }
    }
}
