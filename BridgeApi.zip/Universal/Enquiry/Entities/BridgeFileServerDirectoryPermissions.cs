﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class BridgeFileServerDirectoryPermissions
    {
        public long DirectoryId { get; set; }
        public string Username { get; set; }

        public virtual BridgeFileServerDirectory Directory { get; set; }
        public virtual AgentsWebUsers UsernameNavigation { get; set; }
    }
}
