﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ApiservicesLog
    {
        public DateTime? OnDateTime { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public bool? IsValidUser { get; set; }
        public string HttpRequest { get; set; }
        public string RequestIpaddress { get; set; }
        public string RequestHostName { get; set; }
        public string Response { get; set; }
        public string ServiceName { get; set; }
        public string Narrative { get; set; }
        public byte[] RequestBody { get; set; }
    }
}
