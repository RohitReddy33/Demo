﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempPolicyTransactionsTransportationImporterErrors
    {
        public long TempTransportationId { get; set; }
        public string FieldName { get; set; }
        public string Notes { get; set; }
        public string FieldValue { get; set; }

        public virtual ArchiveTempPolicyTransactionsTransportation TempTransportation { get; set; }
    }
}
