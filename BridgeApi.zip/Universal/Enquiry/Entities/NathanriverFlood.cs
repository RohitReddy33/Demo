﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class NathanriverFlood
    {
        public double ZoneId { get; set; }
        public string Explanation { get; set; }
        public int? Score { get; set; }
    }
}
