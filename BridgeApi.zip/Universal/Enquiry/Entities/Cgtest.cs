﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Cgtest
    {
        public long? Policykey { get; set; }
        public long? PolicyTransactionsKey { get; set; }
    }
}
