﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ErrorSeverityLevels
    {
        public int ErrorSeverityLevel { get; set; }
        public string Description { get; set; }
        public string Color { get; set; }
    }
}
