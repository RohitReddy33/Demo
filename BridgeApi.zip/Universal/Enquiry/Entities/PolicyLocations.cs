﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PolicyLocations
    {
        public int CompanyId { get; set; }
        public string PolicyNo { get; set; }
        public int? LocationNumber { get; set; }
        public decimal? CoInsurancePercentage { get; set; }
        public string InsuredStreet { get; set; }
        public string InsuredCity { get; set; }
        public string InsuredCounty { get; set; }
        public string InsuredState { get; set; }
        public string InsuredZipCode { get; set; }
        public string InsuredCountryScheme { get; set; }
        public string InsuredCountryCode { get; set; }
        public int? NumberofBuildings { get; set; }
        public string IsopropertyCode { get; set; }
        public string AmigclassOfBusinessCode { get; set; }
        public string OccupancyScheme { get; set; }
        public string OccupancyCode { get; set; }
        public string ConstructionCodeScheme { get; set; }
        public string ConstructionCode { get; set; }
        public decimal? ProtectionClass { get; set; }
        public string Protections { get; set; }
        public decimal? YearBuilt { get; set; }
        public int? NumberofStories { get; set; }
        public decimal? Squarefootage { get; set; }
        public string FloodZone { get; set; }
        public decimal? RoofConstructionCode { get; set; }
        public decimal? RoofShapeCode { get; set; }
        public decimal? RoofLastUpdated { get; set; }
        public decimal? WiringLastUpdated { get; set; }
        public decimal? PlumbingLastUpdated { get; set; }
        public decimal? HeatingLastUpdated { get; set; }
        public string Isoglclass { get; set; }
        public decimal? TotalPropertyPremium { get; set; }
        public decimal? TotalPropertyLimit { get; set; }
        public decimal? PropertyPremium { get; set; }
        public decimal? PropertyLimit { get; set; }
        public decimal? PropertyPremiumB { get; set; }
        public decimal? PropertyLimitB { get; set; }
        public decimal? LimitBuildingCoverageA { get; set; }
        public decimal? LimitContentsCoverageC { get; set; }
        public decimal? LimitBusinessInterruptionCoverageD { get; set; }
        public decimal? LimitOtherCoverageB { get; set; }
        public decimal? Rate { get; set; }
        public decimal? Aopdeductible { get; set; }
        public decimal? WindLimit { get; set; }
        public decimal? WindHailHurricaneDeductible { get; set; }
        public decimal? Catdeductible { get; set; }
        public decimal? QuakeLimit { get; set; }
        public decimal? QuakeDeductible { get; set; }
        public decimal? FloodLimit { get; set; }
        public decimal? FloodDeductible { get; set; }
        public decimal? Impremium { get; set; }
        public decimal? InlandMarineLimit { get; set; }
        public string EquipmentBreakdown { get; set; }
        public decimal? EquipmentBreakdownPremium { get; set; }
        public decimal? TerrorismPremium { get; set; }
        public decimal? Triprapremium { get; set; }
        public decimal? Tivfgu { get; set; }
        public decimal? LiabilityPremium { get; set; }
        public decimal? ProductsCompletedOperationsPremium { get; set; }
        public decimal? AllOther { get; set; }
        public decimal? LiabilityLimit { get; set; }
        public decimal? GlaggregateLimit { get; set; }
        public string PremiumBasis { get; set; }
        public decimal? PremiumBasisValue { get; set; }
        public decimal? RateProductsCompletedOperations { get; set; }
        public decimal? RateAllOther { get; set; }
        public decimal? LiabilityDeductible { get; set; }
        public decimal? PersonalAccidentPremium { get; set; }
        public decimal? Elpremium { get; set; }
        public decimal? Ellimit { get; set; }
        public decimal? Plpremium { get; set; }
        public decimal? Pllimit { get; set; }
        public int? GluksltbrokerId { get; set; }

        public virtual Policy Policy { get; set; }
    }
}
