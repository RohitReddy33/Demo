﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ConcordeGlukmfgHomes2
    {
        public string PolicyNumber { get; set; }
        public double? LocationNo { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public double? Zip { get; set; }
        public DateTime? EffectiveDt { get; set; }
        public DateTime? ExpirationDt { get; set; }
        public long? TransId { get; set; }
        public string ConstructionCodeScheme { get; set; }
        public string ConstructionCode { get; set; }
        public string OriginalConstructionCodeScheme { get; set; }
        public string OriginalConstructionCode { get; set; }
        public decimal? CoverageForm { get; set; }
    }
}
