﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PricingMappingConstructionCodes
    {
        public string ConstructionCodeScheme { get; set; }
        public string ConstructionCode { get; set; }
        public string EngineEquivalent { get; set; }
    }
}
