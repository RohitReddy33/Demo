﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class JohnsonAndJohnsonQuoteTestConfirmed2
    {
        public double? Quoteversionid { get; set; }
        public string QHoLocationPostalcode { get; set; }
        public string QHoLocationStreet { get; set; }
        public string QHoLocationStreetNumber { get; set; }
        public string QHoLocationCity { get; set; }
        public string QHoLocationState { get; set; }
        public string QHoLocationCountry { get; set; }
        public double? QHoLocationvaluationAmount { get; set; }
        public string QHoConstructiontype { get; set; }
        public double? QHoBuiltyear { get; set; }
        public string QHoProtectionclass { get; set; }
        public string QHoOccupancytype { get; set; }
        public bool QHoIsPriorlossesLast3years { get; set; }
        public bool QHoIsPdFireCentral { get; set; }
        public bool QHoIsPdBurglarCentral { get; set; }
        public bool QHoIsPdSprinklers { get; set; }
        public bool QHoIsPdGatedcommunity { get; set; }
        public bool QHoIsPdStormShutters { get; set; }
        public double? QHoOtherstructuresAmount { get; set; }
        public double? QHoPersonalpropertyAmount { get; set; }
        public double? QHoLossofuseAmount { get; set; }
        public double? QHoPersonalliabilityAmount { get; set; }
        public double? PHoAdditionalacreageAcres { get; set; }
        public string PHoHeatSourceAlternate { get; set; }
        public double? PHoAopDeductibleAmount { get; set; }
        public bool PHoIsCoverageWind { get; set; }
        public double? PHoWindDeductiblePercent { get; set; }
        public bool PHoIsCoverageEq { get; set; }
        public double? PHoEqDeductiblePercent { get; set; }
        public double? PHoPersonalinjuryAmount { get; set; }
        public double? PHoIncreasedmedicalpaymentsAmount { get; set; }
        public bool PHoIsIncreasedlawordinance { get; set; }
        public bool PHoIsExtendedreplacementcost { get; set; }
        public double? PHoLossassessmentAmount { get; set; }
        public double? PHoWatersewagebackupAmount { get; set; }
        public double? PHoMoldsublimitAmount { get; set; }
        public double? PHoAnimalliabilitysublimitAmount { get; set; }
        public string PHoDwellingValuation { get; set; }
        public string PHoPersonalpropertyValuation { get; set; }
        public bool PHoIsCoverageIfp { get; set; }
        public bool PHoHasExtendedliabilityforrentedlocations { get; set; }
        public string InsuredState { get; set; }
        public long TransId { get; set; }
        public string PolicyNo { get; set; }
        public string InsuredName { get; set; }
        public long LocId { get; set; }
        public string ConstructionCode { get; set; }
        public string ConstructionCodeScheme { get; set; }
        public string OccupancyCode { get; set; }
        public string OccupancyScheme { get; set; }
    }
}
