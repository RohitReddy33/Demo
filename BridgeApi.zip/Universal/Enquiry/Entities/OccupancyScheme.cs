﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class OccupancyScheme
    {
        public OccupancyScheme()
        {
            Occupancy = new HashSet<Occupancy>();
        }

        public string OccupancyScheme1 { get; set; }
        public byte? DataQualityIndex { get; set; }

        public virtual ICollection<Occupancy> Occupancy { get; set; }
    }
}
