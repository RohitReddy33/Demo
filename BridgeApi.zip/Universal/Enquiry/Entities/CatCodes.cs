﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class CatCodes
    {
        public string Catnumber { get; set; }
        public string Catname { get; set; }
        public decimal Year { get; set; }
        public string Notes { get; set; }
        public bool? ExcludeFromOverallAmigreport { get; set; }
        public bool? Mroutlier { get; set; }
        public DateTime? ValidForLossFrom { get; set; }
        public DateTime? ValidForLossTo { get; set; }
    }
}
