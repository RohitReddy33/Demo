﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PcscatCodes
    {
        public string PcscatCode { get; set; }
        public int? Year { get; set; }
        public DateTime? DateFrom { get; set; }
        public DateTime? DateTo { get; set; }
        public string Lcocat { get; set; }
        public string Conditions { get; set; }
        public string Locations { get; set; }
    }
}
