﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsWebUsersRoleMembership
    {
        public string Username { get; set; }
        public string RoleName { get; set; }

        public virtual AgentsWebRoles RoleNameNavigation { get; set; }
        public virtual AgentsWebUsers UsernameNavigation { get; set; }
    }
}
