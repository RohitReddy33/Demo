﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class EmailerLog
    {
        public int Id { get; set; }
        public string UniqueAgentReference { get; set; }
        public string PolicyProcessorSystemName { get; set; }
        public DateTime? RunDate { get; set; }
        public DateTime? EmailFilesAfterDate { get; set; }
        public bool? DoNotShowSuccess { get; set; }
        public string Username { get; set; }
    }
}
