﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ClaimsTransactionsTransportationVehicleDetails
    {
        public long TransportationId { get; set; }
        public long TempClaimsTransportationVehicleDetailsId { get; set; }
        public long TempTransportationId { get; set; }
        public string DriverName { get; set; }
        public byte? DriverAge { get; set; }
        public byte? DriverNoDrivingConvictions { get; set; }
        public string TypeOfVehicle { get; set; }
        public string Vin { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public decimal? Year { get; set; }
        public decimal? Acv { get; set; }
        public decimal? ValueOfLoad { get; set; }
        public bool? NonOwned { get; set; }
        public string TotalLossType { get; set; }

        public virtual ClaimsTransactionsTransportation Transportation { get; set; }
    }
}
