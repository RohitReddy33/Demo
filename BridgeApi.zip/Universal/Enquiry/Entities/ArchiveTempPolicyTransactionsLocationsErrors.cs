﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempPolicyTransactionsLocationsErrors
    {
        public long TempLocationsId { get; set; }
        public int LocationErrorId { get; set; }
        public string SystemMessage { get; set; }

        public virtual ArchiveTempPolicyTransactionsLocations TempLocations { get; set; }
    }
}
