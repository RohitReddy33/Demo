﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsContractsState
    {
        public AgentsContractsState()
        {
            AgentsContractsZones = new HashSet<AgentsContractsZones>();
        }

        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }
        public string Statecode { get; set; }
        public string Notes { get; set; }
        public bool? Active { get; set; }
        public decimal? CalcWindTotalAggregate { get; set; }
        public double? CalcWindPercentageUtilised { get; set; }
        public decimal? CalcQuakeTotalAggregate { get; set; }
        public double? CalcQuakePercentageUtilised { get; set; }
        public decimal? CalcFloodTotalAggregate { get; set; }
        public double? CalcFloodPercentageUtilised { get; set; }
        public decimal? CalcAllTotalAggregate { get; set; }
        public double? CalcAllPercentageUtilised { get; set; }
        public bool? NoLimit { get; set; }

        public virtual AgentsContracts AgentsContracts { get; set; }
        public virtual ICollection<AgentsContractsZones> AgentsContractsZones { get; set; }
    }
}
