﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class RestapiLogEvent
    {
        public DateTime OnDate { get; set; }
        public string Message { get; set; }
    }
}
