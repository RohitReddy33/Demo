﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsIssues
    {
        public int Id { get; set; }
        public int CompanyId { get; set; }
        public string Data { get; set; }

        public virtual Agents Company { get; set; }
    }
}
