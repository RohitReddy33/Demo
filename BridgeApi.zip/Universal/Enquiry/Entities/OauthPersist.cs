﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class OauthPersist
    {
        public string TokenType { get; set; }
        public int ExpiresIn { get; set; }
        public int ExtExpiresIn { get; set; }
        public long ExpiresOn { get; set; }
        public long NotBefore { get; set; }
        public string Resource { get; set; }
        public string AccessToken { get; set; }
        public DateTime CalculatedExpiry { get; set; }
        public bool IsSandbox { get; set; }
    }
}
