﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class NathanpopulationDensity
    {
        public double ZoneId { get; set; }
        public string Explanation { get; set; }
    }
}
