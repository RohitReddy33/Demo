﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsWebUsers
    {
        public AgentsWebUsers()
        {
            AgentsWebLoginAttempts = new HashSet<AgentsWebLoginAttempts>();
            AgentsWebUsersAllowedContracts = new HashSet<AgentsWebUsersAllowedContracts>();
            AgentsWebUsersEmailerFileTypes = new HashSet<AgentsWebUsersEmailerFileTypes>();
            AgentsWebUsersProfiles = new HashSet<AgentsWebUsersProfiles>();
            AgentsWebUsersReportsPermissions = new HashSet<AgentsWebUsersReportsPermissions>();
            AgentsWebUsersRoleMembership = new HashSet<AgentsWebUsersRoleMembership>();
            BridgeFileServer = new HashSet<BridgeFileServer>();
            BridgeFileServerDirectoryPermissions = new HashSet<BridgeFileServerDirectoryPermissions>();
        }

        public string Username { get; set; }
        public string FullName { get; set; }
        public string Password { get; set; }
        public string HashEncPassword { get; set; }
        public int CompanyId { get; set; }
        public bool? AgentManageable { get; set; }
        public string Email { get; set; }
        public DateTime CreationDate { get; set; }
        public DateTime? LastLoginDate { get; set; }
        public DateTime? LastActivityDate { get; set; }
        public DateTime? LastPasswordChangedDate { get; set; }
        public DateTime? LastLockedOutDate { get; set; }
        public bool? MustChangePasswordnextLogin { get; set; }
        public int? FailedPasswordAttemptCount { get; set; }
        public DateTime? FailedPasswordAttemptWindowStart { get; set; }
        public bool AccountLocked { get; set; }
        public Guid? UserKey { get; set; }
        public string PolicyProcessorSystemName { get; set; }
        public string ClaimProcessorSystemName { get; set; }
        public bool EmailUserSubmissionReport { get; set; }
        public bool EmailAllRecordsOnSubmissionReport { get; set; }
        public bool EmailAttachSubmissionReport { get; set; }
        public DateTime? EmailFilesAfterDate { get; set; }
        public DateTime? EmailDateLastSent { get; set; }
        public bool? EmailDoNotShowSuccess { get; set; }
        public bool EmailJustPolicyProcessorSystemNameRecords { get; set; }
        public bool Deleted { get; set; }
        public bool? Wsaccess { get; set; }
        public bool? WsaccessAllowMultiClientUploads { get; set; }
        public bool? DisclaimerAccepted { get; set; }
        public bool? EmailUserBridgeAnnouncements { get; set; }
        public bool RequestDocucorpDiagnosis { get; set; }
        public DateTime? WslastAccess { get; set; }
        public DateTime? WslastHeartBeat { get; set; }
        public DateTime? WslastUpload { get; set; }
        public int? WsheartBeatAlertNoContactAfterXhours { get; set; }
        public DateTime? WsheartBeatAlertLastTriggeredDate { get; set; }
        public bool? FtpserverAccess { get; set; }
        public string TableauUsername { get; set; }

        public virtual Agents Company { get; set; }
        public virtual ICollection<AgentsWebLoginAttempts> AgentsWebLoginAttempts { get; set; }
        public virtual ICollection<AgentsWebUsersAllowedContracts> AgentsWebUsersAllowedContracts { get; set; }
        public virtual ICollection<AgentsWebUsersEmailerFileTypes> AgentsWebUsersEmailerFileTypes { get; set; }
        public virtual ICollection<AgentsWebUsersProfiles> AgentsWebUsersProfiles { get; set; }
        public virtual ICollection<AgentsWebUsersReportsPermissions> AgentsWebUsersReportsPermissions { get; set; }
        public virtual ICollection<AgentsWebUsersRoleMembership> AgentsWebUsersRoleMembership { get; set; }
        public virtual ICollection<BridgeFileServer> BridgeFileServer { get; set; }
        public virtual ICollection<BridgeFileServerDirectoryPermissions> BridgeFileServerDirectoryPermissions { get; set; }
    }
}
