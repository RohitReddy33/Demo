﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ApimIsyClTransactionsBatch
    {
        public ApimIsyClTransactionsBatch()
        {
            ApimIsyClTransactions = new HashSet<ApimIsyClTransactions>();
        }

        public string ApimIsyClTransactionsBatchId { get; set; }
        public DateTime DateCreated { get; set; }
        public int BordMonth { get; set; }
        public int BordYear { get; set; }
        public DateTime? DateSubmitted { get; set; }
        public byte[] Jsoncontents { get; set; }
        public byte[] BatchJsoncontents { get; set; }
        public byte[] MracisResponse { get; set; }
        public virtual ICollection<ApimIsyClTransactions> ApimIsyClTransactions { get; set; }
    }
}
