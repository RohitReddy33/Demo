﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class RatingHsbpersonalLinesCoverages
    {
        public RatingHsbpersonalLinesCoverages()
        {
            RatingHsbpersonalLines = new HashSet<RatingHsbpersonalLines>();
            RatingHsbpersonalLinesLimitBands = new HashSet<RatingHsbpersonalLinesLimitBands>();
        }

        public int CoverageId { get; set; }
        public string CoverageDescription { get; set; }
        public string CoverageLevel { get; set; }

        public virtual ICollection<RatingHsbpersonalLines> RatingHsbpersonalLines { get; set; }
        public virtual ICollection<RatingHsbpersonalLinesLimitBands> RatingHsbpersonalLinesLimitBands { get; set; }
    }
}
