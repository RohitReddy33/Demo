﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AirsconstructionLookup
    {
        public string SrcType { get; set; }
        public string SrcBldgType { get; set; }
        public double? ScrConstrCode { get; set; }
        public string AirconstrType { get; set; }
        public double? AirconstrCode { get; set; }
    }
}
