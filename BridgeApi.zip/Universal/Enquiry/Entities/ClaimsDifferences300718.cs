﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ClaimsDifferences300718
    {
        public int? CompanyId { get; set; }
        public string ClaimNo { get; set; }
        public string ContractRef { get; set; }
    }
}
