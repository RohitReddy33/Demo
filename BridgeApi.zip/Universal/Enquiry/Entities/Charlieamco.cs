﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Charlieamco
    {
        public string CompanyName { get; set; }
        public string PolicyNo { get; set; }
        public string LocationNumber { get; set; }
        public decimal? Aopdeductible { get; set; }
        public decimal? Catdeductible { get; set; }
        public decimal? WindHailHurricaneDeductible { get; set; }
        public decimal? WindHailHurricaneDeductibleNamedStorm { get; set; }
        public decimal? TotalPropertyLimit { get; set; }
        public decimal? WindLimit { get; set; }
        public decimal? NewWindHailHurricaneDeductible { get; set; }
    }
}
