﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Glukuwplan
    {
        public string BusinessArea { get; set; }
        public int ContractYear { get; set; }
        public string Gluksection { get; set; }
        public string CompanyName { get; set; }
        public string Statecode { get; set; }
        public string Zone { get; set; }
        public string Notes { get; set; }
        public string Description { get; set; }
        public bool? Active { get; set; }
        public string ContractRef { get; set; }
        public decimal? PropertyLimit { get; set; }
        public decimal? LiabilityLimit { get; set; }
        public decimal? Cpllimit { get; set; }
        public decimal? PropertyAnnualGwpilimit { get; set; }
        public decimal? LiabilityAnnualGwpilimit { get; set; }
        public decimal? PropertyStateEstimatedPi { get; set; }
        public decimal? LiabilityStateEstimatedPi { get; set; }
        public decimal? PropertyMgaprofitCommissionPayback { get; set; }
        public decimal? LiabilityMgaprofitCommissionPayback { get; set; }
        public decimal? PropertyBcprofitCommissionOfMgapc { get; set; }
        public decimal? LiabilityBcprofitCommissionOfMgapc { get; set; }
        public decimal? PropertyPaysPcbelow { get; set; }
        public decimal? LiabilityPaysPcbelow { get; set; }
        public decimal? PropertyPcdeferredBelow { get; set; }
        public decimal? LiabilityPcdeferredBelow { get; set; }
        public decimal? TotalAggregateLimitInclusiveofExWind { get; set; }
        public decimal? WindaggregateLimit { get; set; }
        public decimal? QuakeaggregateEstimateLimit { get; set; }
        public decimal? FloodaggregateEstimateLimit { get; set; }
        public decimal? PropertyEstimatedOfNpipayableasPc { get; set; }
        public decimal? LiabilityEstimatedOfNpipayableasPc { get; set; }
        public decimal? PropertyEstimatedNetLossRatio { get; set; }
        public decimal? LiabilityEstimatedNetLossRatio { get; set; }
        public decimal? PropertyEstimatedGpi { get; set; }
        public decimal? LiabilityEstimatedGpi { get; set; }
        public decimal? PropertyEstimatedNpi { get; set; }
        public decimal? LiabilityEstimatedNpi { get; set; }
        public decimal? PropertyEstimatedNetProfit { get; set; }
        public decimal? LiabilityEstimatedNetProfit { get; set; }
        public decimal? PropertyEstimatedProfitCommissiontoMga { get; set; }
        public decimal? LiabilityEstimatedProfitCommissiontoMga { get; set; }
        public decimal? PropertyEstimatedProfitCommissiontoBc { get; set; }
        public decimal? LiabilityEstimatedProfitCommissiontoBc { get; set; }
        public decimal? PropertyEstimatedUltimateNetProfit { get; set; }
        public decimal? LiabilityEstimatedUltimateNetProfit { get; set; }
    }
}
