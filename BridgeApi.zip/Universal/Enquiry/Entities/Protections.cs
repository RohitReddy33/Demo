﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Protections
    {
        public Protections()
        {
            PolicyTransactionsProtections = new HashSet<PolicyTransactionsProtections>();
        }

        public string Protections1 { get; set; }
        public string Description { get; set; }

        public virtual ICollection<PolicyTransactionsProtections> PolicyTransactionsProtections { get; set; }
    }
}
