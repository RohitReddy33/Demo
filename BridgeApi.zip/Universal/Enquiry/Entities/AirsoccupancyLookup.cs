﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AirsoccupancyLookup
    {
        public string SrcType { get; set; }
        public string SrcOccScheme { get; set; }
        public double? SrcOccCode { get; set; }
        public string AiroccType { get; set; }
        public double? AiroccCode { get; set; }
    }
}
