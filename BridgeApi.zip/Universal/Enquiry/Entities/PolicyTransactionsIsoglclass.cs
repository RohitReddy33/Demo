﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PolicyTransactionsIsoglclass
    {
        public long TransId { get; set; }
        public string Isoglclass { get; set; }
        public int Id { get; set; }
        public string Description { get; set; }
        public string PremiumBasis { get; set; }
        public decimal? PremiumBasisValue { get; set; }
        public double? RateProductsCompletedOperations { get; set; }
        public double? RateAllOther { get; set; }
        public decimal? ProductsCompletedOperationsPremium { get; set; }
        public decimal? AllOther { get; set; }
        public bool? AppliesAllLocations { get; set; }

        public virtual PolicyTransactions Trans { get; set; }
    }
}
