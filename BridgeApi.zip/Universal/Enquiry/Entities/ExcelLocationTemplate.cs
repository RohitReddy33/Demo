﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ExcelLocationTemplate
    {
        public string RecordUniqueIdentifier { get; set; }
        public string UniqueAgentReference { get; set; }
        public string PolicyNo { get; set; }
        public string EndorsementNumber { get; set; }
        public string InsuredName { get; set; }
        public int? LocationNumber { get; set; }
        public string InsuredStreet { get; set; }
        public string InsuredCity { get; set; }
        public string InsuredCounty { get; set; }
        public string InsuredState { get; set; }
        public string InsuredZipCode { get; set; }
        public string InsuredCountryScheme { get; set; }
        public string InsuredCountryCode { get; set; }
        public int? NumberofBuildings { get; set; }
        public string OccupancyScheme { get; set; }
        public string OccupancyCode { get; set; }
        public string ConstructionCodeScheme { get; set; }
        public string ConstructionCode { get; set; }
        public string ProtectionClass { get; set; }
        public string Protections { get; set; }
        public decimal? YearBuilt { get; set; }
        public int? NumberofStories { get; set; }
        public decimal? Squarefootage { get; set; }
        public string RoofConstructionScheme { get; set; }
        public decimal? RoofConstructionCode { get; set; }
        public string RoofShapeScheme { get; set; }
        public decimal? RoofShapeCode { get; set; }
        public decimal? RoofLastUpdated { get; set; }
        public decimal? WiringLastUpdated { get; set; }
        public decimal? PlumbingLastUpdated { get; set; }
        public decimal? HeatingLastUpdated { get; set; }
        public decimal? TotalPropertyLimit { get; set; }
        public decimal? LimitBuildingCoverageA { get; set; }
        public decimal? LimitContentsCoverageC { get; set; }
        public decimal? LimitBusinessInterruptionCoverageD { get; set; }
        public decimal? LimitOtherCoverageB { get; set; }
        public decimal? Aopdeductible { get; set; }
        public decimal? WindLimit { get; set; }
        public decimal? WindHailHurricaneDeductible { get; set; }
        public decimal? WindHailHurricaneDeductibleNamedStorm { get; set; }
        public decimal? QuakeLimit { get; set; }
        public decimal? QuakeDeductible { get; set; }
        public decimal? FloodLimit { get; set; }
        public decimal? FloodDeductible { get; set; }
        public decimal? InlandMarineLimit { get; set; }
        public string EquipmentBreakdown { get; set; }
        public decimal? CrimeLimit { get; set; }
        public decimal? CrimeDeductible { get; set; }
        public decimal? Tivfgu { get; set; }
        public string Isoglclass { get; set; }
        public decimal? LiabilityLimit { get; set; }
        public decimal? GlaggregateLimit { get; set; }
        public decimal? LiabilityDeductible { get; set; }
        public decimal? Rate { get; set; }
        public string PremiumBasis { get; set; }
        public decimal? PremiumBasisValue { get; set; }
    }
}
