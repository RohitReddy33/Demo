﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class LogImportedFilesLogs
    {
        public string ImportFilename { get; set; }
        public int DuplicateFileSeq { get; set; }
        public DateTime LogDate { get; set; }
        public string Description { get; set; }
    }
}
