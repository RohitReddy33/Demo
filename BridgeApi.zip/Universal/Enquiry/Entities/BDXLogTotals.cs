﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BridgeApi.Enquiry.Models.Entities
{
    public class BDXLogTotals
    {
        public double GrossPremium { get; set; }
        public string Source { get; set; }
    }
}
