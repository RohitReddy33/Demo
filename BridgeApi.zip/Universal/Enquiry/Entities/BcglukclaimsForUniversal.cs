﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class BcglukclaimsForUniversal
    {
        public int ClaimId { get; set; }
        public string ContractRef { get; set; }
        public string SubCompanyName { get; set; }
        public string ClaimNumber { get; set; }
        public string InsuredName { get; set; }
        public string ClaimantName { get; set; }
        public string PolicyNumber { get; set; }
        public DateTime? InceptionDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public DateTime? DateofLoss { get; set; }
        public string CauseofLoss { get; set; }
        public string CatNumber { get; set; }
        public string LossCounty { get; set; }
        public string LossState { get; set; }
        public decimal? PaidClaimIndemnity { get; set; }
        public decimal? PaidLaeallOther { get; set; }
        public decimal OutstandingClaim { get; set; }
        public decimal? PreviousOutstandingClaim { get; set; }
        public decimal OutstandingLae { get; set; }
        public decimal? PreviousOutstandingLae { get; set; }
        public string PaidOffBdx { get; set; }
        public int Litigation { get; set; }
        public string Adjuster { get; set; }
        public string Attorney { get; set; }
        public string ClaimStatus { get; set; }
        public int? BordYear { get; set; }
        public int? BordMonth { get; set; }
    }
}
