﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Claims
    {
        public int CompanyId { get; set; }
        public string PolicyNo { get; set; }
        public string ClaimNumber { get; set; }

        public virtual Agents Company { get; set; }
    }
}
