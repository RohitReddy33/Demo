﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ApimIsyClTransactions
    {
        public long ApimIsyClTransactionsId { get; set; }
        public long TempPremiumsId { get; set; }
        public string RecordUniqueIdentifier { get; set; }
        public DateTime DateCreated { get; set; }
        public string ApimIsyClTransactionsBatchId { get; set; }
        public string PolicyNumber { get; set; }
        public string InitialStatusCode { get; set; }
        public byte[] InitialResponse { get; set; }
        public string LastStatusCode { get; set; }
        public byte[] LastResponse { get; set; }
        public DateTime? DateLastResponsePolled { get; set; }

        public virtual ApimIsyClTransactionsBatch ApimIsyClTransactionsBatch { get; set; }
    }
}
