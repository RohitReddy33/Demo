﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class KmlplacemarkLimitBands
    {
        public string LimitBandName { get; set; }
        public string BusinessArea { get; set; }
        public int LimitBandFrom { get; set; }
        public int LimitBandTo { get; set; }
        public string IconHref { get; set; }
        public string Color { get; set; }
    }
}
