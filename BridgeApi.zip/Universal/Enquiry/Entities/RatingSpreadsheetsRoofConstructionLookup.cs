﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class RatingSpreadsheetsRoofConstructionLookup
    {
        public string Name { get; set; }
        public string V11equivalent { get; set; }
        public long Id { get; set; }
        public string Brit { get; set; }
        public string Hiscox { get; set; }
        public string Atl { get; set; }
    }
}
