﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AnnualLossesRpt2018Result
    {
        public long? ClaimsTransId { get; set; }
        public string CompanyName { get; set; }
        public int? CompanyId { get; set; }
        public string ClaimNumber { get; set; }
        public string PolicyNo { get; set; }
        public string ContractYear { get; set; }
        public string CauseOfLoss { get; set; }
        public string InsuredName { get; set; }
        public string Description { get; set; }
        public string ContractRef { get; set; }
        public string BusinessArea { get; set; }
        public string SummaryLob { get; set; }
        public DateTime? FirstReported { get; set; }
        public DateTime? LastReported { get; set; }
        public DateTime? DateOfLoss { get; set; }
        public decimal? IndemnityPaid { get; set; }
        public decimal? AdjusterExpensePaid { get; set; }
        public decimal? LegalExpensePaid { get; set; }
        public decimal? AllOtherExpensePaid { get; set; }
        public decimal? IndemnityReserve { get; set; }
        public decimal? ExpenseReserve { get; set; }
        public decimal? TotalIncurred { get; set; }
        public decimal? ContractShare { get; set; }
        public decimal? SumContractShare { get; set; }
        public decimal? LiabilityShare { get; set; }
        public decimal? SumLiabilityShare { get; set; }
    }
}
