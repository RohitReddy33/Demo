﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class CauseOfLossCodes
    {
        public string CauseOfLossCode { get; set; }
        public string TypeOfLoss { get; set; }
        public string Description { get; set; }
        public string NewCauseofLoss { get; set; }
        public bool? IsValidForCatcode { get; set; }
        public bool? IsClaimsSystemLegacy { get; set; }
        public bool? IsExemptFromCatdateRangeChecking { get; set; }
        public string GlisecobcodePremiumType { get; set; }
    }
}
