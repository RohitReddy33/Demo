﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class CoverageFormListing
    {
        public decimal CoverageForm { get; set; }
        public string Description { get; set; }
        public string MunichReEquivalent { get; set; }
    }
}
