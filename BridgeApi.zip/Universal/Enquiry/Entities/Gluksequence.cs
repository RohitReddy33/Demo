﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Gluksequence
    {
        public string Section { get; set; }
        public string Gluksequence1 { get; set; }
    }
}
