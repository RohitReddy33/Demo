﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PlcommercialIndicator
    {
        public long PlcommercialIndicatorId { get; set; }
        public string PlcommercialIndicator1 { get; set; }
        public string Description { get; set; }
    }
}
