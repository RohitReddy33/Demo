﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class OldGlobalEnd
    {
        public int Policyid { get; set; }
        public int BulkEndorsementId { get; set; }
        public DateTime? Createdate { get; set; }
        public string Transtype { get; set; }
        public string PolicyNo { get; set; }
        public DateTime? EnddateEffective { get; set; }
        public DateTime? DateExpiry { get; set; }
        public string PlacementTypeId { get; set; }
        public string Clientname { get; set; }
        public string Clientcode { get; set; }
        public decimal? HereonPercentage { get; set; }
        public string Contractref { get; set; }
        public string PremiumType { get; set; }
        public decimal? TotalPremium { get; set; }
        public decimal? Commission { get; set; }
        public decimal? Bccommission { get; set; }
        public string Note { get; set; }
        public byte? NonPremium { get; set; }
        public decimal? TerrorismPremium { get; set; }
        public decimal? Contractshare { get; set; }
        public decimal? PropertyLimit { get; set; }
        public decimal? LiabilityLimit { get; set; }
        public decimal? AutoLimit { get; set; }
        public decimal? Windlimit { get; set; }
        public decimal? FloodLimit { get; set; }
        public decimal? Quakelimit { get; set; }
        public decimal? Deductible { get; set; }
        public decimal? CatDeductible { get; set; }
        public decimal? AutoDeductible { get; set; }
        public string InsuredName { get; set; }
        public string InsuredStreet { get; set; }
        public string InsuredStreetAuto { get; set; }
        public string InsuredCity { get; set; }
        public string InsuredCityAuto { get; set; }
        public string InsuredZip { get; set; }
        public string InsuredZipAuto { get; set; }
        public string InsuredCounty { get; set; }
        public string InsuredCountyAuto { get; set; }
        public string InsuredState { get; set; }
        public string InsuredStateAuto { get; set; }
        public string Protections { get; set; }
        public string Occupancycode { get; set; }
        public string Occupancy { get; set; }
        public string AutoOccupancy { get; set; }
        public string Constructioncode { get; set; }
        public string Perils { get; set; }
        public int? Zoneperil { get; set; }
        public string SltbrokerTaxNumber { get; set; }
        public string SltbrokerName { get; set; }
        public string Sltbrokerstate { get; set; }
        public string SltbrokerstateAddress { get; set; }
        public int? Locationnumber { get; set; }
        public int? YearBuilt { get; set; }
        public string DistanceFromSaltWater { get; set; }
        public decimal? Building { get; set; }
        public decimal? BusinessIncome { get; set; }
        public decimal? Bpplimit { get; set; }
        public decimal? OtherCoverageBlimit { get; set; }
        public int? EndNumber { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public byte? IsReinstatement { get; set; }
        public decimal? Tivfguauto { get; set; }
        public decimal? AttachmentPointAuto { get; set; }
        public decimal? SizeOfLayerAuto { get; set; }
    }
}
