﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class GeocodingCount
    {
        public DateTime RequestDate { get; set; }
        public int? NoGeoCodes { get; set; }
    }
}
