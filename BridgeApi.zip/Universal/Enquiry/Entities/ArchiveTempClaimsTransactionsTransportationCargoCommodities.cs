﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempClaimsTransactionsTransportationCargoCommodities
    {
        public long TempClaimsTransportationCargoCommodityId { get; set; }
        public long TempTransportationId { get; set; }
        public string CargoCommodityScheme { get; set; }
        public int CargoCommodityType { get; set; }

        public virtual ArchiveTempClaimsTransactionsTransportation TempTransportation { get; set; }
    }
}
