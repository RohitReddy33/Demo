﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ConstructionCodeScheme
    {
        public ConstructionCodeScheme()
        {
            ConstructionCodes = new HashSet<ConstructionCodes>();
        }

        public string ConstructionCodeScheme1 { get; set; }
        public byte? DataQualityIndex { get; set; }

        public virtual ICollection<ConstructionCodes> ConstructionCodes { get; set; }
    }
}
