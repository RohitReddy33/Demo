﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class OldGlobalrefimport
    {
        public string BusinessArea { get; set; }
        public double? ContractRef { get; set; }
        public double? ContractYear { get; set; }
        public string Policyref { get; set; }
    }
}
