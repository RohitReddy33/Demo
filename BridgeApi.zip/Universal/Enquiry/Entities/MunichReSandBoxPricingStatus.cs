﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class MunichReSandBoxPricingStatus
    {
        public string AppName { get; set; }
        public DateTime? LogDate { get; set; }
        public string HealthStatus { get; set; }
    }
}
