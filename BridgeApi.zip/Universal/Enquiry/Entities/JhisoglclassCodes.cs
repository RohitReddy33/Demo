﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class JhisoglclassCodes
    {
        public string OldIsoglcode { get; set; }
        public string NewIsoglcode { get; set; }
    }
}
