﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class RatingHsbpersonalLinesDwellingType
    {
        public int? DwellingType { get; set; }
        public string DwellingTypeDesc { get; set; }
        public string IsooccupancyCodeEquivalent { get; set; }
    }
}
