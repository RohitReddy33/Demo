﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Kmltickets
    {
        public Guid KmlticketId { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime ExpiryDate { get; set; }
        public int? CompanyId { get; set; }
        public string Username { get; set; }
        public DateTime RunDate { get; set; }
        public string Kmldata { get; set; }
        public int? KmlnoDocFeatures { get; set; }
        public DateTime? KmldataCreateDate { get; set; }
        public int? KmlgeneratedTime { get; set; }
        public int? MapLoadCount { get; set; }
    }
}
