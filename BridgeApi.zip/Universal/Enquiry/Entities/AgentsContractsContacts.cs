﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsContractsContacts
    {
        public int Id { get; set; }
        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }
        public int AgentContactUniqueId { get; set; }
        public string ContactType { get; set; }

        public virtual AgentsContractsStatic AgentsContractsStatic { get; set; }
    }
}
