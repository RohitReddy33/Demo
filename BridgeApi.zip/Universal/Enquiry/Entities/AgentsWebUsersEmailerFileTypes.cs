﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsWebUsersEmailerFileTypes
    {
        public string Username { get; set; }
        public string Filetype { get; set; }

        public virtual AgentsWebUsers UsernameNavigation { get; set; }
    }
}
