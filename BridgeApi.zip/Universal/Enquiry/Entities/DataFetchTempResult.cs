﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace BridgeApi.Enquiry.Models.Entities
{
    public class DataFetchTempResult
    {
        public string TransactionSource { get; set; }
        public string PolicyNo { get; set; }
        public string InsuredName { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int? ContractYear { get; set; }
        public string ContractDescription { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? ExpirationDate { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? TotalPropertyLimit { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? PlacementType { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? SizeofLayer { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? AttachmentPoint { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? CATPremiumEstimate { get; set; }

        public string LocationNumber { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? WindHailHurricaneDeductible { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? MinimumQuakeDeductible { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? QuakeDeductible { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? LimitBuildingCoverageA { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? LimitContentsCoverageC { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? LimitBusinessInterruptionCoverageD { get; set; }
        public string OccupancyCode { get; set; }
        public string ConstructionCode { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? Squarefootage { get; set; }
        public int? NumberOfStories { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? YearBuilt { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? RoofLastUpdated { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? RoofConstructionCode { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? RoofShapeCode { get; set; }
        public int? EQBaseIsolation { get; set; }
        public int? EQCladdingType { get; set; }
        public int? EQConstructionQuality { get; set; }
        public int? EQEquipmentSupportMaintenance { get; set; }
        public int? EQEngineeredFoundation { get; set; }
        public int? EQSprinklerLeakageSusceptibility { get; set; }
        public int? EQFrameBolted { get; set; }
        public int? EQUnreinforcedMasonryPartitionsorChimneys { get; set; }
        public int? EQAppendagesandOrnamentation { get; set; }
        public int? EQVerticalIrregularity { get; set; }
        public int? EQPounding { get; set; }
        public int? EQPlanIrregularity { get; set; }
        public int? EQShortColumnCondition { get; set; }
        public int? EQSprinklerType { get; set; }
        public int? EQSoftStory { get; set; }
        public int? EQStructuralUpgrade { get; set; }
        public int? EQTiltUpRetrofit { get; set; }
        public int? EQUnreinforcedMasonryRetrofit { get; set; }
        public int? EQCrippleWalls { get; set; }
        public string InsuredStreet { get; set; }
        public string InsuredCity { get; set; }
        public string InsuredCounty { get; set; }
        public string InsuredState { get; set; }
        public string InsuredZipCode { get; set; }
        public long? TempPremiumsID { get; set; }
        public string RecordUniqueIdentifier { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? WindLimit { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? QuakeLimit { get; set; }
        public int? EQMechanicalandElectricalEquipmentEarthquakeBracing { get; set; }
        public string EQSprinklerLeakageCoverageFlag { get; set; }
        public double? GOOGLE_X { get; set; }
        public double? GOOGLE_Y { get; set; }
        public string GOOGLE_LOCATION_TYPE { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? PolicyDQICoreScore { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? PolicyQuakeScore { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? PolicyWindScore { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? LocationCoreScore { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? LocationQuakeScored { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? LocationWindScore { get; set; }
        public int? CompanyID { get; set; }
        public string CompanyName { get; set; }
        // Todo Map GeoCodeInsuredAddress


        public string BasementType { get; set; }
        [Column(TypeName = "decimal(18,2)")]
        public decimal? LimitOtherCoverageB { get; set; }
        public decimal? FirstFloorHeightAboveGround { get; set; }
        public int? FlfoundationType { get; set; }
        public bool? HasStiltsOverWater { get; set; }
        public bool? IsMobileHome { get; set; }
        public bool? IsVacant { get; set; }
        public bool? IsBuildersRisk { get; set; }
        public decimal? ModifierUnderwriterPriceAdjustment { get; set; }
        public DateTime? DateOfLastLoss { get; set; }
        public decimal? CoverageForm { get; set; }
        public short? QuoteType { get; set; }
        public decimal? TargetedRate { get; set; }

        public bool? Bankruptcy { get; set; }
        public bool? Foreclosure { get; set; }
        public int? ElevationType { get; set; }
        public bool? HasBreakawayWalls { get; set; }
        public bool? BelowFloorEnclosureHasElevator { get; set; }
        public bool? HasAttachedGarage { get; set; }
        public bool? HouseElevatedAfterPriorFloodLoss { get; set; }

        public void TreatCodes()
        {
            OccupancyCode = !string.IsNullOrEmpty(OccupancyCode)  ? OccupancyCode.Substring(0, 4) : OccupancyCode;
            ConstructionCode = !string.IsNullOrEmpty(ConstructionCode) ? ConstructionCode.Substring(0, 2) : ConstructionCode;

            //OccupancyCode = OccupancyCode?.Substring(0, 4);
            //ConstructionCode = ConstructionCode?.Substring(0, 2);
        }
    }
}