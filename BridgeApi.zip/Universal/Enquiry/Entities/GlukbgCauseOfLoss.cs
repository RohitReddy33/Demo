﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class GlukbgCauseOfLoss
    {
        public string NewclaimNumber { get; set; }
        public string Claimnumber { get; set; }
        public string Insured { get; set; }
        public string Policy { get; set; }
        public DateTime? Inceptdate { get; set; }
        public DateTime? Expirydate { get; set; }
        public DateTime? Dateofloss { get; set; }
        public string Causeofloss { get; set; }
        public string F9 { get; set; }
        public string F10 { get; set; }
        public string F11 { get; set; }
        public string F12 { get; set; }
        public string F13 { get; set; }
        public string F14 { get; set; }
        public string F15 { get; set; }
        public string F16 { get; set; }
        public string F17 { get; set; }
        public string F18 { get; set; }
        public string F19 { get; set; }
        public string F20 { get; set; }
        public string F21 { get; set; }
        public string F22 { get; set; }
        public string F23 { get; set; }
        public string F24 { get; set; }
        public string F25 { get; set; }
    }
}
