﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ReportsTableReportsOnServers
    {
        public int ReportId { get; set; }
        public int ReportCategoryId { get; set; }
        public string ReportName { get; set; }
        public string ReportPath { get; set; }
        public bool? ShowInMenu { get; set; }
        public bool? DefaultReport { get; set; }
        public bool? AgentManageable { get; set; }
        public bool ShowInInternalBridge { get; set; }
        public bool IsTableau { get; set; }
        public int? OnReportServerIbridge { get; set; }
        public int? OnReportServerEbridge { get; set; }
        public int? OnTableauServer { get; set; }
    }
}
