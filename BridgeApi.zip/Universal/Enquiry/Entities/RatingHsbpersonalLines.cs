﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class RatingHsbpersonalLines
    {
        public int HsbpersonalLinesRatesId { get; set; }
        public int? CoverageId { get; set; }
        public int? LimitBandId { get; set; }
        public int? CompanyId { get; set; }
        public decimal? HsbpersonalLinesRate { get; set; }
        public DateTime RateEffectiveDate { get; set; }
        public DateTime RateExpirationDate { get; set; }

        public virtual Agents Company { get; set; }
        public virtual RatingHsbpersonalLinesCoverages Coverage { get; set; }
        public virtual RatingHsbpersonalLinesLimitBands LimitBand { get; set; }
    }
}
