﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsWebUsersAllowedContracts
    {
        public string Username { get; set; }
        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }

        public virtual AgentsWebUsers UsernameNavigation { get; set; }
    }
}
