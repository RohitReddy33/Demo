﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PremiumTypes
    {
        public PremiumTypes()
        {
            AgentsContractsGlisecob = new HashSet<AgentsContractsGlisecob>();
            PolicyTransactionsContractsPremiums = new HashSet<PolicyTransactionsContractsPremiums>();
        }

        public string PremiumType { get; set; }
        public string Description { get; set; }

        public virtual ICollection<AgentsContractsGlisecob> AgentsContractsGlisecob { get; set; }
        public virtual ICollection<PolicyTransactionsContractsPremiums> PolicyTransactionsContractsPremiums { get; set; }
    }
}
