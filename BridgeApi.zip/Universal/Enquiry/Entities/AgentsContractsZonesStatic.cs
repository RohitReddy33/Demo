﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsContractsZonesStatic
    {
        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }
        public string Statecode { get; set; }
        public int ZoneId { get; set; }
        public decimal? TotalAggregateLimitInclusiveofExWind { get; set; }
        public decimal? WindaggregateLimit { get; set; }
        public decimal? QuakeaggregateEstimateLimit { get; set; }
        public decimal? FloodaggregateEstimateLimit { get; set; }
        public string Notes { get; set; }
        public bool? Active { get; set; }
        public bool? AssumeWind { get; set; }
        public bool? AssumeQuake { get; set; }
        public bool? AssumeFlood { get; set; }
        public decimal? CalcWindTotalAggregate { get; set; }
        public double? CalcWindPercentageUtilised { get; set; }
        public decimal? CalcQuakeTotalAggregate { get; set; }
        public double? CalcQuakePercentageUtilised { get; set; }
        public decimal? CalcFloodTotalAggregate { get; set; }
        public double? CalcFloodPercentageUtilised { get; set; }
        public decimal? CalcAllTotalAggregate { get; set; }
        public double? CalcAllPercentageUtilised { get; set; }
        public decimal? CalcGwpitoDate { get; set; }
        public decimal? CalcNwpitoDate { get; set; }
        public decimal? CalcActualNetLossRatio { get; set; }
        public decimal? CalcPaidToDateClaims { get; set; }
        public decimal? CalcCurrentOutstanding { get; set; }
        public decimal? CalcIncurred { get; set; }
        public decimal? PropertyStateEstimatedPi { get; set; }
        public decimal? LiabilityStateEstimatedPi { get; set; }
        public decimal? ScenarioEstUsage { get; set; }
        public string AfsNotes { get; set; }

        public virtual AgentsContractsStateStatic AgentsContractsStateStatic { get; set; }
    }
}
