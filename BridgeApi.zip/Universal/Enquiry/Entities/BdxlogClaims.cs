﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class BdxlogClaims
    {
        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }
        public int BordYear { get; set; }
        public int BordMonth { get; set; }
        public int SignedOffByAgentId { get; set; }
        public DateTime? AccountCurrentSignedOffClaims { get; set; }
        public string AccountCurrentSignedOffByClaims { get; set; }
        public DateTime? MoveToLiveAttemptedClaims { get; set; }
    }
}
