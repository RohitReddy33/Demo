﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Isocountries
    {
        public string Country { get; set; }
        public string Iso2a { get; set; }
        public string Iso3a { get; set; }
        public int? Iso3n { get; set; }
        public string Fips { get; set; }
    }
}
