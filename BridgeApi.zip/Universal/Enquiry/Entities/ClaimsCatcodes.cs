﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ClaimsCatcodes
    {
        public long Code { get; set; }
        public string Name { get; set; }
    }
}
