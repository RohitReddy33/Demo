﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsWebUsersPasswordHistory
    {
        public string Username { get; set; }
        public DateTime PasswordChangeDate { get; set; }
        public string Password { get; set; }
    }
}
