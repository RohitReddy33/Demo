﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempPolicyTransactionsImporterErrors
    {
        public long TempPremiumsId { get; set; }
        public string FieldName { get; set; }
        public string Notes { get; set; }
        public string FieldValue { get; set; }

        public virtual ArchiveTempPolicyTransactions TempPremiums { get; set; }
    }
}
