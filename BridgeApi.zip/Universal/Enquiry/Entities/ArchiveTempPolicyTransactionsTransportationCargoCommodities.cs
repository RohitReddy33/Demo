﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempPolicyTransactionsTransportationCargoCommodities
    {
        public long TempTransportationCargoCommodityId { get; set; }
        public long TempTransportationId { get; set; }
        public string CargoCommodityScheme { get; set; }
        public int? CargoCommodityType { get; set; }
        public decimal? CargoCommodityPercentage { get; set; }

        public virtual ArchiveTempPolicyTransactionsTransportation TempTransportation { get; set; }
    }
}
