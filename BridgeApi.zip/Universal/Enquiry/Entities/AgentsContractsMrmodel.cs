﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsContractsMrmodel
    {
        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }
        public decimal? WindAaladjustToMrFactor { get; set; }
        public decimal? QuakeAaladjustToMrFactor { get; set; }
        public decimal? ScsaaladjustToMrFactor { get; set; }
        public decimal? WinterstormAaladjusttoMrFactor { get; set; }
        public decimal? Budget27AdjusttoMrfactor { get; set; }
        public decimal? Budget28AdjusttoMrfactor { get; set; }
        public decimal? Budget29AdjusttoMrfactor { get; set; }
        public decimal? Budget39AdjusttoMrfactor { get; set; }
        public decimal? Budget36AdjusttoMrfactor { get; set; }
        public decimal? Budget37AdjusttoMrfactor { get; set; }
        public decimal? Budget41AdjusttoMrfactor { get; set; }
        public decimal? BasicLr { get; set; }
        public decimal? LargeLrlimit { get; set; }
        public decimal? LargeLrprofile { get; set; }
        public decimal? ProfitCommission { get; set; }
        public decimal? GlukfrontingFee { get; set; }
        public decimal? Mrexpenses { get; set; }
        public decimal? InvestmentIncome { get; set; }
        public decimal? LossAdjusterExpensesFactor { get; set; }
        public decimal? CatLrfactor { get; set; }
        public decimal? CostofCapitalFactor { get; set; }
        public decimal? CatIntensitySc27 { get; set; }
        public decimal? CatIntensitySc28 { get; set; }
        public decimal? CatIntensitySc29 { get; set; }
        public decimal? CatIntensitySc36 { get; set; }
        public decimal? CatIntensitySc37 { get; set; }
        public decimal? CatIntensitySc39 { get; set; }
        public decimal? CatIntensitySc41 { get; set; }
        public decimal? ReturnonCapitalFactor { get; set; }
        public decimal? FireCostofCapital { get; set; }

        public virtual AgentsContracts AgentsContracts { get; set; }
    }
}
