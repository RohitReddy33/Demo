﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PolicyContracts
    {
        public string PolicyNo { get; set; }
        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }
        public double? ContractShare { get; set; }
        public double? LiabilityShare { get; set; }
        public decimal? Commission { get; set; }
        public decimal? Bccommission { get; set; }
    }
}
