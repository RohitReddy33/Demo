﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsWebUsersReportsPermissions
    {
        public string Username { get; set; }
        public int ReportId { get; set; }

        public virtual Reports Report { get; set; }
        public virtual AgentsWebUsers UsernameNavigation { get; set; }
    }
}
