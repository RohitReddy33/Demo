﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class BridgeAsperrors
    {
        public int Id { get; set; }
        public DateTime? DateTimeLogged { get; set; }
        public string LoggedInUser { get; set; }
        public string Message { get; set; }
        public string Source { get; set; }
        public string TargetSite { get; set; }
        public string StackTrace { get; set; }
        public string InnerException { get; set; }
    }
}
