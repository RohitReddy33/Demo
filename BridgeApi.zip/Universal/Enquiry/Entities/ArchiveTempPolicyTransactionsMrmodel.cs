﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempPolicyTransactionsMrmodel
    {
        public long TempPremiumsId { get; set; }
        public decimal? RunningTotalPropertyPremium { get; set; }
        public decimal? Bcbudget27 { get; set; }
        public decimal? Bcbudget28 { get; set; }
        public decimal? Bcbudget29 { get; set; }
        public decimal? Bcbudget36 { get; set; }
        public decimal? Bcbudget37 { get; set; }
        public decimal? Bcbudget39 { get; set; }
        public decimal? Bcbudget41 { get; set; }
        public decimal? EstMreWindAal { get; set; }
        public decimal? EstMreQuakeAal { get; set; }
        public decimal? EstMreScsaal { get; set; }
        public decimal? EstMreWinterstormAal { get; set; }
        public decimal? EstMreBcbudget27 { get; set; }
        public decimal? EstMreBcbudget28 { get; set; }
        public decimal? EstMreBcbudget29 { get; set; }
        public decimal? EstMreBcbudget36 { get; set; }
        public decimal? EstMreBcbudget37 { get; set; }
        public decimal? EstMreBcbudget39 { get; set; }
        public decimal? EstMreBcbudget41 { get; set; }
        public decimal? EstMreCatLossWind { get; set; }
        public decimal? EstMreCatLossQuake { get; set; }
        public decimal? EstMreValueAdded { get; set; }
        public decimal? EstMreValueAddedWindQuake { get; set; }
        public decimal? EstMreBreakEvenPremium { get; set; }
        public decimal? EstMreBreakEvenPremiumWindQuake { get; set; }
        public decimal? EstMreCostCapitalWind { get; set; }
        public decimal? EstMreCostCapitalQuake { get; set; }
        public DateTime? CreateDate { get; set; }

        public virtual ArchiveTempPolicyTransactions TempPremiums { get; set; }
    }
}
