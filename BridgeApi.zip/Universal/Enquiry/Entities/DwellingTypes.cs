﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class DwellingTypes
    {
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
