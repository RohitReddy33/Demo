﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsWebRoles
    {
        public AgentsWebRoles()
        {
            AgentsWebUsersRoleMembership = new HashSet<AgentsWebUsersRoleMembership>();
        }

        public string RoleName { get; set; }
        public string Description { get; set; }
        public bool? DefaultRole { get; set; }
        public bool? AgentManageable { get; set; }

        public virtual ICollection<AgentsWebUsersRoleMembership> AgentsWebUsersRoleMembership { get; set; }
    }
}
