﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempClaimsTransactionsErrors
    {
        public int ClaimErrorId { get; set; }
        public long TempClaimsId { get; set; }
        public string SystemMessage { get; set; }
        public string AdditionalInfo { get; set; }

        public virtual ArchiveTempClaimsTransactions TempClaims { get; set; }
    }
}
