﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PolicyTransactionsRmspurePremiums
    {
        public long TransId { get; set; }
        public int DlmProfId { get; set; }
        public string PerilType { get; set; }
        public int Rmsversion { get; set; }
        public decimal? Premium { get; set; }
        public DateTime? RmsrunDate { get; set; }

        public virtual PolicyTransactions Trans { get; set; }
    }
}
