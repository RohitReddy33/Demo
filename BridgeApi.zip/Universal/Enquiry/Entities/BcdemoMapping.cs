﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class BcdemoMapping
    {
        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public string NewContractRef { get; set; }
        public string Notes { get; set; }
    }
}
