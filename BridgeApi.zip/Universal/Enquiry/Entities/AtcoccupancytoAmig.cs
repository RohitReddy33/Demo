﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AtcoccupancytoAmig
    {
        public double? OccType { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public double? ClassofBusinessCode { get; set; }
        public string ClassofBusinessDescription { get; set; }
    }
}
