﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempClaimsTransactionsTransportation
    {
        public ArchiveTempClaimsTransactionsTransportation()
        {
            ArchiveTempClaimsTransactionsTransportationApdcommodities = new HashSet<ArchiveTempClaimsTransactionsTransportationApdcommodities>();
            ArchiveTempClaimsTransactionsTransportationCargoCommodities = new HashSet<ArchiveTempClaimsTransactionsTransportationCargoCommodities>();
            ArchiveTempClaimsTransactionsTransportationTrailerDetails = new HashSet<ArchiveTempClaimsTransactionsTransportationTrailerDetails>();
            ArchiveTempClaimsTransactionsTransportationVehicleDetails = new HashSet<ArchiveTempClaimsTransactionsTransportationVehicleDetails>();
        }

        public long TempTransportationId { get; set; }
        public long TempClaimsId { get; set; }
        public decimal? ValueOfLoad { get; set; }
        public int? Apdcommodities { get; set; }
        public int? CargoCommodities { get; set; }

        public virtual ArchiveTempClaimsTransactions TempClaims { get; set; }
        public virtual ICollection<ArchiveTempClaimsTransactionsTransportationApdcommodities> ArchiveTempClaimsTransactionsTransportationApdcommodities { get; set; }
        public virtual ICollection<ArchiveTempClaimsTransactionsTransportationCargoCommodities> ArchiveTempClaimsTransactionsTransportationCargoCommodities { get; set; }
        public virtual ICollection<ArchiveTempClaimsTransactionsTransportationTrailerDetails> ArchiveTempClaimsTransactionsTransportationTrailerDetails { get; set; }
        public virtual ICollection<ArchiveTempClaimsTransactionsTransportationVehicleDetails> ArchiveTempClaimsTransactionsTransportationVehicleDetails { get; set; }
    }
}
