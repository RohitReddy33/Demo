﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class GlukpolicyDed
    {
        public string UniqueAgentReference { get; set; }
        public string PolicyNo { get; set; }
        public decimal? Catdeductible { get; set; }
    }
}
