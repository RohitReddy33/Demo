﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class RatingSpreadsheetsMessages
    {
        public int RatingSpreadSheetId { get; set; }
        public int MessageId { get; set; }
        public string Description { get; set; }
        public string Sheet { get; set; }
        public string Cell { get; set; }
        public bool DeclineIfValue { get; set; }
        public bool ReferToUnderwritersIfValue { get; set; }
        public string DeclineSpecificValue { get; set; }
        public string ReferToUnderwritersIfSpecificValue { get; set; }
    }
}
