﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempPolicyTransactionsAimcoverages
    {
        public long TempPremiumsId { get; set; }
        public string Contract { get; set; }
        public string Coverage { get; set; }
        public double? ContractPercentage { get; set; }
        public decimal? GrossPremium { get; set; }
        public decimal? NetCommission { get; set; }
        public decimal? NetPremium { get; set; }

        public virtual ArchiveTempPolicyTransactions TempPremiums { get; set; }
    }
}
