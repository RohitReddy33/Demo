﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class RatingSpreadsheetsDeductible
    {
        public string OccupancyCode { get; set; }
        public int Deductible { get; set; }
        public decimal? MaxLimit { get; set; }
        public decimal? MinLimit { get; set; }
    }
}
