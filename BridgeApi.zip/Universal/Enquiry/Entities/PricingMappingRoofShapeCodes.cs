﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PricingMappingRoofShapeCodes
    {
        public string RoofShapeScheme { get; set; }
        public decimal RoofShapeCode { get; set; }
        public string EngineEquivalent { get; set; }
    }
}
