﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsContractsClaimsSettlingAuth
    {
        public int Id { get; set; }
        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }
        public string Description { get; set; }
        public string LimitOfAuthority { get; set; }
        public decimal SpecifiedLimit { get; set; }
        public string HandlerCompanyName { get; set; }
        public bool? IsTpa { get; set; }
    }
}
