﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PrevalidationPolicyLookupLog
    {
        public DateTime? OnDateTime { get; set; }
        public string SuppliedUserName { get; set; }
        public string SuppliedPassword { get; set; }
        public bool? IsValidUser { get; set; }
        public string SuppliedPolicyNumber { get; set; }
        public string SuppliedAgentReference { get; set; }
        public string RequestIpaddress { get; set; }
        public string RequestHostName { get; set; }
        public string ResponseXml { get; set; }
    }
}
