﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class McHineLog
    {
        public Guid WsticketId { get; set; }
        public DateTime TicketRequestDate { get; set; }
        public string ClientFileName { get; set; }
        public string FileStatus { get; set; }
        public string PreXsltfileName { get; set; }
        public string ProcessingLog { get; set; }
    }
}
