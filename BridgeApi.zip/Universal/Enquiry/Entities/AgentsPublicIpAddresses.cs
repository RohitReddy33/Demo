﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsPublicIpAddresses
    {
        public int CompanyId { get; set; }
        public string NetworkAddress { get; set; }
        public string NetMask { get; set; }

        public virtual Agents Company { get; set; }
    }
}
