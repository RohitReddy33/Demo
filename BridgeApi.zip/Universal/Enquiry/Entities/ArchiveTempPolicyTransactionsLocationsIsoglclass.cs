﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempPolicyTransactionsLocationsIsoglclass
    {
        public long TempLocationsId { get; set; }
        public string Isoglclass { get; set; }
        public int? Id { get; set; }
        public string Description { get; set; }
        public string PremiumBasis { get; set; }
        public decimal? PremiumBasisValue { get; set; }
        public double? RateProductsCompletedOperations { get; set; }
        public double? RateAllOther { get; set; }
        public decimal? ProductsCompletedOperationsPremium { get; set; }
        public decimal? AllOther { get; set; }

        public virtual ArchiveTempPolicyTransactionsLocations TempLocations { get; set; }
    }
}
