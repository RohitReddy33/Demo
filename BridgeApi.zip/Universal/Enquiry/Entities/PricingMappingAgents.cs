﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PricingMappingAgents
    {
        public string UniqueAgentReference { get; set; }
        public string EngineEquivalent { get; set; }
    }
}
