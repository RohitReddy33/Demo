﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Occupancy
    {
        public string OccupancyScheme { get; set; }
        public string OccupancyCode { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string EquivalentRmscode { get; set; }
        public string AmigclassOfBusinessCode { get; set; }
        public string EquivalentGlukoccupancy { get; set; }
        public string EquivalentAtccode { get; set; }
        public string EquivalentIsopropCode { get; set; }
        public bool? RmsmodelOccupancy { get; set; }
        public string MunichReEquivalent { get; set; }
        public bool? Gdprpii { get; set; }

        public virtual OccupancyScheme OccupancySchemeNavigation { get; set; }
    }
}
