﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class FtpTargetUpdate31may2018
    {
        public long Id { get; set; }
        public long? TempPremiumsId { get; set; }
        public long? TempLocationsId { get; set; }
    }
}
