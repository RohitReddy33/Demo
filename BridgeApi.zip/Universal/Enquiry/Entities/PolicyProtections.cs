﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PolicyProtections
    {
        public string PolicyNo { get; set; }
        public int CompanyId { get; set; }
        public string Protections { get; set; }

        public virtual Policy Policy { get; set; }
    }
}
