﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class CancellationCodes
    {
        public int CancellationCode { get; set; }
        public string CancellationDescription { get; set; }
        public string RatingBasis { get; set; }
    }
}
