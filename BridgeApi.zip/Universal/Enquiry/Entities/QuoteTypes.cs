﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class QuoteTypes
    {
        public int QuoteType { get; set; }
        public string Description { get; set; }
        public string UnderwritingPack { get; set; }
        public string TriggerUnderwritingPack { get; set; }
        public string UnderwritingPackAvailableWhen { get; set; }
        public string ShortDescription { get; set; }
        public string RatingTool { get; set; }
    }
}
