﻿namespace BridgeApi.Enquiry.Models.Entities
{
    public class PlacementTypeDropDownItem
    {
        public int PlacementType { get; set; }
        public string Description { get; set; }
        public int OrderBy { get; set; }
    }
}
