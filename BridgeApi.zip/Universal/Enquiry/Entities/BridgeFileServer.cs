﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class BridgeFileServer
    {
        public long Id { get; set; }
        public int? CompanyId { get; set; }
        public string FileName { get; set; }
        public long? FileSize { get; set; }
        public DateTime? DateUploaded { get; set; }
        public string UserName { get; set; }
        public string ClientIp { get; set; }
        public string ContentType { get; set; }
        public byte[] Content { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime? DateDeleted { get; set; }
        public string DeletedBy { get; set; }
        public long? DirectoryId { get; set; }

        public virtual Agents Company { get; set; }
        public virtual BridgeFileServerDirectory Directory { get; set; }
        public virtual AgentsWebUsers UserNameNavigation { get; set; }
    }
}
