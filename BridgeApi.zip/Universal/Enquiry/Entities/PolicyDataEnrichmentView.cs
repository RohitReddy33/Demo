﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PolicyDataEnrichmentView
    {
        public int? CompanyId { get; set; }
        public string PolicyNo { get; set; }
        public int LocationNumber { get; set; }
        public int BuildingNumber { get; set; }
        public string InsuredName { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public decimal? YearBuilt { get; set; }
        public int? NumberofStories { get; set; }
        public decimal? Squarefootage { get; set; }
        public decimal? RoofConstructionCode { get; set; }
        public decimal? RoofShapeCode { get; set; }
        public decimal? RoofLastUpdated { get; set; }
        public int? EqbaseIsolation { get; set; }
        public int? EqcladdingType { get; set; }
        public int? EqconstructionQuality { get; set; }
        public int? EqequipmentSupportMaintenance { get; set; }
        public int? EqengineeredFoundation { get; set; }
        public int? EqsprinklerLeakageSusceptibility { get; set; }
        public int? EqframeBolted { get; set; }
        public int? EqunreinforcedMasonryPartitionsorChimneys { get; set; }
        public int? EqmechanicalandElectricalEquipmentEarthquakeBracing { get; set; }
        public int? EqappendagesandOrnamentation { get; set; }
        public int? EqverticalIrregularity { get; set; }
        public int? Eqpounding { get; set; }
        public int? EqplanIrregularity { get; set; }
        public int? EqshortColumnCondition { get; set; }
        public int? EqsprinklerType { get; set; }
        public int? EqsoftStory { get; set; }
        public int? EqstructuralUpgrade { get; set; }
        public int? EqtiltUpRetrofit { get; set; }
        public int? EqunreinforcedMasonryRetrofit { get; set; }
        public int? EqcrippleWalls { get; set; }
    }
}
