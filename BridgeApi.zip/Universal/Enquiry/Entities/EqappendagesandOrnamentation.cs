﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class EqappendagesandOrnamentation
    {
        public int Code { get; set; }
        public string Description { get; set; }
    }
}
