﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ReportingQuarters
    {
        public int? Qtr { get; set; }
    }
}
