﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsContractsGlisecob
    {
        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }
        public string PremiumType { get; set; }
        public string Glisecobcode { get; set; }

        public virtual AgentsContracts AgentsContracts { get; set; }
        public virtual Glisecobcodes GlisecobcodeNavigation { get; set; }
        public virtual PremiumTypes PremiumTypeNavigation { get; set; }
    }
}
