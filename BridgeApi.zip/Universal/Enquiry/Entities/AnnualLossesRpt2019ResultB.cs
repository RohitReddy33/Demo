﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AnnualLossesRpt2019ResultB
    {
        public string ClaimNumber { get; set; }
        public string PolicyNo { get; set; }
        public int? CompanyId { get; set; }
        public DateTime? DateOfLoss { get; set; }
        public string InsuredName { get; set; }
        public DateTime? LastReported { get; set; }
        public string SummaryLob { get; set; }
    }
}
