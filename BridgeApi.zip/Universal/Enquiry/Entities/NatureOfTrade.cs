﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class NatureOfTrade
    {
        public NatureOfTrade()
        {
            TempPolicyTransactionsLocationsTransportation = new HashSet<TempPolicyTransactionsLocationsTransportation>();
            TempPolicyTransactionsTransportation = new HashSet<TempPolicyTransactionsTransportation>();
        }

        public int NatureOfTrade1 { get; set; }
        public string Description { get; set; }

        public virtual ICollection<TempPolicyTransactionsLocationsTransportation> TempPolicyTransactionsLocationsTransportation { get; set; }
        public virtual ICollection<TempPolicyTransactionsTransportation> TempPolicyTransactionsTransportation { get; set; }
    }
}
