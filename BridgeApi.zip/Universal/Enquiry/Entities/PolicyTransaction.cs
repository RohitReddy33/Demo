﻿namespace BridgeApi.Enquiry.Models.Entities
{
    public class PolicyTransaction
    {
        public string RecordType { get; set; }
        public string PolicyNo { get; set; }
        public string PolicyNoDesc { get; set; }
    }
}
