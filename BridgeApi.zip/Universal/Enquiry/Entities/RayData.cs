﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class RayData
    {
        public string ContractRef { get; set; }
        public long ClaimsId { get; set; }
        public int? BordMonth { get; set; }
        public int? BordYear { get; set; }
        public int ContractYear { get; set; }
        public string ClientCode { get; set; }
        public string PolicyNo { get; set; }
        public string ClaimNumber { get; set; }
        public string InsuredName { get; set; }
        public DateTime? DateOfLoss { get; set; }
        public string CauseOfLoss { get; set; }
        public string CatNumber { get; set; }
        public decimal? PaymentAmountIndemnity { get; set; }
        public decimal? PaymentAmountAdjustmentExpenses { get; set; }
        public decimal? PaymentAmountLegalExpenses { get; set; }
        public decimal? PaymentAmountAllOtherLae { get; set; }
        public decimal? IndemnityReserve { get; set; }
        public decimal? Laereserve { get; set; }
        public string ClaimStatus { get; set; }
        public string PaidOffBdx { get; set; }
        public string LossState { get; set; }
        public string LossCounty { get; set; }
        public string Glukref { get; set; }
        public string Jcs { get; set; }
        public string LiabilityClaim { get; set; }
    }
}
