﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsContractsZonesSub
    {
        public int SubZoneId { get; set; }
        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }
        public string Statecode { get; set; }
        public int ZoneId { get; set; }
        public bool? Wind { get; set; }
        public bool? Flood { get; set; }
        public bool? Quake { get; set; }

        public virtual AgentsContractsZones AgentsContractsZones { get; set; }
    }
}
