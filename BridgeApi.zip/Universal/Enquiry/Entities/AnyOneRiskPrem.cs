﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AnyOneRiskPrem
    {
        public string Contract { get; set; }
        public decimal? AnyOneRisk { get; set; }
    }
}
