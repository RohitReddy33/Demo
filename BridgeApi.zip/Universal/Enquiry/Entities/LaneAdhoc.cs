﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class LaneAdhoc
    {
        public string PolicyNo { get; set; }
        public string InsuredStreet { get; set; }
        public string InsuredCity { get; set; }
        public string InsuredCounty { get; set; }
        public string InsuredState { get; set; }
        public double? InsuredZipCode { get; set; }
        public string OccupancyDescription { get; set; }
        public string ConstructionDescription { get; set; }
        public double? PropertyPremium { get; set; }
        public double? PropertyLimit { get; set; }
        public double? WindLimit { get; set; }
        public double? MrX { get; set; }
        public double? MrY { get; set; }
        public string GeoCodeInsuredAddress { get; set; }
    }
}
