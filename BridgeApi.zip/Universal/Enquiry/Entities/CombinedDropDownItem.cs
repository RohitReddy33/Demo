﻿using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public class CombinedDropDownItem
    {
        public IEnumerable<PolicyTransaction> PolicyTransactions { get; set; }
        public IEnumerable<DropDownItem> AppendagesandOrnamentations { get; set; }
        public IEnumerable<DropDownItem> BaseIsolations { get; set; }
        public IEnumerable<DropDownItem> CladdingTypes { get; set; }
        public IEnumerable<DropDownItem> ConstructionQualities { get; set; }
        public IEnumerable<DropDownItem> CrippleWalls { get; set; }
        public IEnumerable<DropDownItem> EquipmentSupportMaintenances { get; set; }
        public IEnumerable<DropDownItem> FrameBolts { get; set; }
        public IEnumerable<DropDownItem> MechanicalandElectricalEquipmentEarthquakeBracings { get; set; }
        public IEnumerable<DropDownItem> EngineeredFoundations { get; set; }
        public IEnumerable<DropDownItem> PlanIrregularities { get; set; }
        public IEnumerable<DropDownItem> Poundings { get; set; }
        public IEnumerable<DropDownItem> ShortColumnConditions { get; set; }
        public IEnumerable<DropDownItem> SoftStories { get; set; }
        public IEnumerable<DropDownItem> SprinklerLeakageSusceptibilities { get; set; }
        public IEnumerable<DropDownItem> SprinklerTypes { get; set; }
        public IEnumerable<DropDownItem> TiltUpRetrofits { get; set; }
        public IEnumerable<DropDownItem> UnreinforcedMasonryPartitionsorChimneys { get; set; }
        public IEnumerable<DropDownItem> UnreinforcedMasonryRetrofits { get; set; }
        public IEnumerable<DropDownItem> StructuralUpgrades { get; set; }
        public IEnumerable<DropDownItem> VerticalIrregularities { get; set; }
        public IEnumerable<PlacementTypeDropDownItem> PlacementTypes { get; set; }
        public IEnumerable<DropDownItem> ElevationType { get; set; }
    }
}
