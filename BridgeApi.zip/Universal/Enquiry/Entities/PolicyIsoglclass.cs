﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PolicyIsoglclass
    {
        public string PolicyNo { get; set; }
        public int CompanyId { get; set; }
        public string Isoglclass { get; set; }

        public virtual Policy Policy { get; set; }
    }
}
