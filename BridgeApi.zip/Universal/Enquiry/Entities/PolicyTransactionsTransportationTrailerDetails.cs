﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PolicyTransactionsTransportationTrailerDetails
    {
        public long TransportationId { get; set; }
        public long TempTransportationTrailerDetailsId { get; set; }
        public long TempTransportationId { get; set; }
        public string TypeOfTrailer { get; set; }
        public string Vin { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public decimal? Year { get; set; }
        public decimal? Acv { get; set; }
        public bool? NonOwnedTrailer { get; set; }

        public virtual PolicyTransactionsTransportation Transportation { get; set; }
    }
}
