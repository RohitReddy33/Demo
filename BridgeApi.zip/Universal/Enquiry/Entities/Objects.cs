﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Objects
    {
        public string UserName { get; set; }
        public string DatabaseName { get; set; }
        public string SchemaName { get; set; }
        public string ObjectName { get; set; }
        public string ObjectType { get; set; }
        public DateTime? DateCreated { get; set; }
        public DateTime? DateDropped { get; set; }
        public string Description { get; set; }
        public bool? Production { get; set; }
        public DateTime? LastExecute { get; set; }
    }
}
