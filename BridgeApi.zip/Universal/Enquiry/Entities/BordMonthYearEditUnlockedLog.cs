﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class BordMonthYearEditUnlockedLog
    {
        public long Id { get; set; }
        public int BordYear { get; set; }
        public int BordMonth { get; set; }
        public bool? EditingUnlocked { get; set; }
        public string EditingUnlockedReason { get; set; }
        public string UserUnlocked { get; set; }
        public DateTime? DateUnlocked { get; set; }
    }
}
