﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ContracttypesTb
    {
        public string ContractType { get; set; }
        public int ContractNumericType { get; set; }
        public string ContractName { get; set; }
    }
}
