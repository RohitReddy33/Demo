﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempPolicyTransactionsLocationsImporterErrors
    {
        public long TempLocationsId { get; set; }
        public string FieldName { get; set; }
        public string Notes { get; set; }
        public string FieldValue { get; set; }

        public virtual ArchiveTempPolicyTransactionsLocations TempLocations { get; set; }
    }
}
