﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class LocationTransactionTypes
    {
        public string LocationTransactionType { get; set; }
    }
}
