﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ApdratingCategories
    {
        public int RatingCategory { get; set; }
        public string Description { get; set; }
        public string ShortDescription { get; set; }
    }
}
