﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PricingMappingPremiumBasis
    {
        public string PremiumBasisCode { get; set; }
        public string EngineEquivalent { get; set; }
    }
}
