﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Kmlfeeds
    {
        public int KmlfeedId { get; set; }
        public Guid? KmlfeedUniqueId { get; set; }
        public string Name { get; set; }
        public int? KmlfeedCategoryId { get; set; }
        public string Description { get; set; }
        public string LinkUrl { get; set; }
        public bool ShowOnEbridge { get; set; }
        public byte[] Kmldata { get; set; }
        public string KmldataContentType { get; set; }
        public string KmldataFileName { get; set; }

        public virtual KmlfeedCategories KmlfeedCategory { get; set; }
    }
}
