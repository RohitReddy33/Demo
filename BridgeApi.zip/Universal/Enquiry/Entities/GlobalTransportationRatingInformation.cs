﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class GlobalTransportationRatingInformation
    {
        public string PolicyNo { get; set; }
        public double? ApdescrowGrossPremium { get; set; }
        public double? ApdescrowAcv { get; set; }
        public string ApdhowLongInBusiness { get; set; }
        public string ApdfleetSizeValue { get; set; }
        public double? ApdisEscrow { get; set; }
        public string ApdcommodityCargo { get; set; }
        public double? Apdexclude { get; set; }
        public double? DolavgValueExposed { get; set; }
        public string DolavgValueBand { get; set; }
        public string MtchowLongInBusiness { get; set; }
        public string MtclimitSize { get; set; }
        public string MtcfleetSizeNoUnits { get; set; }
        public string Mtccatgroup { get; set; }
        public double? MtcnoofUnits { get; set; }
        public double? Mtclimit { get; set; }
    }
}
