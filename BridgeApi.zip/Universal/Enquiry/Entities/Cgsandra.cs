﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Cgsandra
    {
        public string Policyno { get; set; }
        public decimal? GrossPremium { get; set; }
        public decimal? Commission { get; set; }
    }
}
