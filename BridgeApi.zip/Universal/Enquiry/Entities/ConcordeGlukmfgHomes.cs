﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ConcordeGlukmfgHomes
    {
        public string PolicyNo { get; set; }
        public DateTime? ExpDate { get; set; }
        public string CurrentQuoteStatus { get; set; }
        public double? LocationNumber { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public double? Zip { get; set; }
        public long? TransId { get; set; }
        public long? LocId { get; set; }
        public string ConstructionCodeScheme { get; set; }
        public string ConstructionCode { get; set; }
        public string OriginalConstructionCodeScheme { get; set; }
        public string OriginalConstructionCode { get; set; }
    }
}
