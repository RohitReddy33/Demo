﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class RatingHsbpersonalLinesLimitBands
    {
        public RatingHsbpersonalLinesLimitBands()
        {
            RatingHsbpersonalLines = new HashSet<RatingHsbpersonalLines>();
        }

        public int LimitBandId { get; set; }
        public int? CoverageId { get; set; }
        public string LimitBandDescription { get; set; }
        public decimal? LimitMinimum { get; set; }
        public decimal? LimitMaximum { get; set; }

        public virtual RatingHsbpersonalLinesCoverages Coverage { get; set; }
        public virtual ICollection<RatingHsbpersonalLines> RatingHsbpersonalLines { get; set; }
    }
}
