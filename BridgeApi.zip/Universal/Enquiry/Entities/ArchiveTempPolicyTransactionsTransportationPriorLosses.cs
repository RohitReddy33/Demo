﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempPolicyTransactionsTransportationPriorLosses
    {
        public long? TempTransportationId { get; set; }
        public DateTime? DateOfLoss { get; set; }
        public string CauseOfLoss { get; set; }
        public string ClaimStatus { get; set; }
        public decimal? TotalIncurred { get; set; }

        public virtual ArchiveTempPolicyTransactionsTransportation TempTransportation { get; set; }
    }
}
