﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ReportingServicesReports
    {
        public int ReportId { get; set; }
        public string ReportName { get; set; }
        public string ReportFile { get; set; }
    }
}
