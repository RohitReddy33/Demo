﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class RayData2
    {
        public string Contract { get; set; }
        public string CHolderId { get; set; }
        public string PolicyNo { get; set; }
        public string ClaimNumber { get; set; }
        public string InsuredName { get; set; }
        public DateTime? DateOfLoss { get; set; }
        public string CauseOfLoss { get; set; }
        public string CatNumber { get; set; }
        public double? PaymentAmountIndemnity { get; set; }
        public double? PaymentAmountAdjustmentExpenses { get; set; }
        public double? PaymentAmountLegalExpenses { get; set; }
        public double? PaymentAmountAllOtherLae { get; set; }
        public double? IndemnityReserve { get; set; }
        public double? LaeReserve { get; set; }
        public string ClaimStatus { get; set; }
        public string PaidOffBdx { get; set; }
        public string LossState { get; set; }
        public string GlukRef { get; set; }
        public string LossCounty { get; set; }
        public string Jcs { get; set; }
        public string LiabilityClaim { get; set; }
    }
}
