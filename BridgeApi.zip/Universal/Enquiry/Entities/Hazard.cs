﻿namespace BridgeApi.Enquiry.Models.Entities
{
    public class Hazard
    {
        public int TempPremiumsId { get; set; }
        public string PolicyNo { get; set; }
        public string LocationNumber { get; set; }
        public string InsuredStreet { get; set; }
        public string InsuredCity { get; set; }
        public string InsuredCounty { get; set; }
        public string InsuredState { get; set; }
        public string InsuredZipCode { get; set; }
        public double MR_X { get; set; }
        public double MR_Y { get; set; }
        public string MReGeocodeQualityScore { get; set; }
        public string MReOverallRiskScore { get; set; }
        public string PeoplePerKM2 { get; set; }
        public int Elevation { get; set; }
        public string MReElevation { get; set; }
        public string MReEarthquakeScore { get; set; }
        public string MReVolcanoesScore { get; set; }
        public string MReTsunamiScore { get; set; }
        public string MReTropicalCycloneScore { get; set; }
        public string MReExtratropcialStormScore { get; set; }
        public string MReHailScore { get; set; }
        public string MReTornadoScore { get; set; }
        public string MReLightningScore { get; set; }
        public string MReWildfireScore { get; set; }
        public string MReRiverFloodScore { get; set; }
        public string MReFlashFloodScore { get; set; }
        public string MReStormSurgeScore { get; set; }
        public string RMSGeocodeQualityScore { get; set; }
        public string RMSQuakeSoilType { get; set; }
        public string RMSQuakeLandslide { get; set; }
        public string RMSQuakeLiquefaction { get; set; }
        public string RMSWindElevation { get; set; }
        public string RMSFloodElevation { get; set; }
        public string RMSBuildingElevation { get; set; }
        public string RMSBaseFloodElevation { get; set; }
        public string RMSWindManRough { get; set; }
        public string RMSWindNatRough{ get; set; }
        public string RMSNFIPRate { get; set; }
        public string RMSNFIPYear { get; set; }
        public string RMSWindDistCoast { get; set; }
        public int MRScenario { get; set; }
        public int MRScenarioTier { get; set; }
    }
}
