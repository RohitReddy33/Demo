﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class CitationRecodes
    {
        public int PerilsId { get; set; }
        public string PerilsDescription { get; set; }
        public int? CrplacementTypeid { get; set; }
        public int? Crzoneperilsid { get; set; }
        public int? Crcazoneperildsid { get; set; }
    }
}
