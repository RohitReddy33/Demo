﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempPolicyTransactionsContractsPremiums
    {
        public long TempPremiumsId { get; set; }
        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }
        public string PremiumType { get; set; }
        public decimal? Premium { get; set; }
        public decimal? Commission { get; set; }
        public decimal? Bccommission { get; set; }

        public virtual ArchiveTempPolicyTransactionsContracts ArchiveTempPolicyTransactionsContracts { get; set; }
    }
}
