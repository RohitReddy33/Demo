﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Amcopolicies
    {
        public string PolicyNo { get; set; }
    }
}
