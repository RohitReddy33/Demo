﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class GlobalImportExcludedRecords
    {
        public int GlobalPolicyId { get; set; }
        public int GlobalEndorsementId { get; set; }
        public string PolicyNo { get; set; }
        public string Notes { get; set; }
        public string UserCreated { get; set; }
        public DateTime? DateCreated { get; set; }
    }
}
