﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class IsoglclassOptionalCoverages
    {
        public string FormNo { get; set; }
        public string AdditionalCharge { get; set; }
        public string AdditionalPercentage { get; set; }
        public double? AskExposure { get; set; }
        public double? ExposureBasis { get; set; }
        public double? MinimumPremium { get; set; }
        public string DisplayNotes { get; set; }
        public double? Isoglclass { get; set; }
        public string SubCoverageCode { get; set; }
        public double? UnderwriterOnly { get; set; }
        public string ExposureDisplay { get; set; }
        public string OptionalCoverageOccurrence { get; set; }
        public string OptionalCoverageAggregate { get; set; }
        public string RateType { get; set; }
        public string Occurrence { get; set; }
        public string Aggregate { get; set; }
        public string AgencyInclude { get; set; }
        public string AgencyExclude { get; set; }
        public double? AddressIndicator { get; set; }
        public long IsoglclassOptionalCoveragesId { get; set; }
    }
}
