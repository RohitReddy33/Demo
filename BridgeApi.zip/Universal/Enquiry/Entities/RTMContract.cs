﻿using System.ComponentModel.DataAnnotations.Schema;

namespace BridgeApi.Enquiry.Models.Entities
{
    public class RTMContract
    {
        public string Contract { get; set; }

        public string Zone { get; set; }

        public string Type { get; set; }

        [Column("Inforce Aggregate", TypeName = "decimal(18,2)")]
        public decimal InforceAggregate { get; set; }

        [Column("Contracted Limit", TypeName = "decimal(18,2)")]
        public decimal ContractedLimit { get; set; }

        [Column("Remaining Aggregate", TypeName = "decimal(18,2)")]
        public decimal RemainingAggregate { get; set; }

        [NotMapped]
        public string StateCode { get; set; }

        [NotMapped]
        public int ContractYear { get; set; }
    }
}
