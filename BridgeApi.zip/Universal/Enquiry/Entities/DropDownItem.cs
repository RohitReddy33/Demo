﻿namespace BridgeApi.Enquiry.Models.Entities
{
    public class DropDownItem
    {
        public int Code { get; set; }
        public string Description { get; set; }
    }
}
