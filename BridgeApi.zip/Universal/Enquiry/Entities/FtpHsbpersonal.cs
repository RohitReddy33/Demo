﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class FtpHsbpersonal
    {
        public string PolicyNo { get; set; }
        public string InsuredName { get; set; }
        public decimal? DwellingSlGwp { get; set; }
        public decimal? DwellingEbGwp { get; set; }
        public decimal? HomeownersHspGwp { get; set; }
        public decimal? HomeownersSlGwp { get; set; }
        public decimal? HomeownersEbGwp { get; set; }
        public bool Canceled { get; set; }
    }
}
