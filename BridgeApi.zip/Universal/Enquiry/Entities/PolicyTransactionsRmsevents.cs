﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PolicyTransactionsRmsevents
    {
        public long TransId { get; set; }
        public int RmseventId { get; set; }
        public double? Rmsperspvalue { get; set; }
        public int Rmsversion { get; set; }
        public int DlmProfId { get; set; }
    }
}
