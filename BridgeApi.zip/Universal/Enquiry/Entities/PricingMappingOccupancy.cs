﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PricingMappingOccupancy
    {
        public string OccupancyScheme { get; set; }
        public string OccupancyCode { get; set; }
        public string EngineEquivalent { get; set; }
    }
}
