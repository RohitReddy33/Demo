﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ProdLaneWindadj
    {
        public string CompanyName { get; set; }
        public double? InvoiceNo { get; set; }
        public string TransactionType { get; set; }
        public string PolicyNo { get; set; }
        public double? LocationNumber { get; set; }
        public string InsuredStreet { get; set; }
        public string InsuredCity { get; set; }
        public string InsuredCounty { get; set; }
        public string InsuredState { get; set; }
        public double? TotalPropertyLimit { get; set; }
        public double? Aopdeductible { get; set; }
        public string WindLimit { get; set; }
        public string WindHailHurricaneDeductible { get; set; }
        public string WindHailHurricaneDeductibleNamedStorm { get; set; }
        public double? AlisWindlimit { get; set; }
        public double? AlisWindHailHurricaneDeductible { get; set; }
        public string AlisWindHailHurricaneDeductibleNamedStorm { get; set; }
        public long? TransId { get; set; }
        public long? LocId { get; set; }
        public int? BordYear { get; set; }
        public int? BordMonth { get; set; }
    }
}
