﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class IsocountrySchemes
    {
        public IsocountrySchemes()
        {
            IsocountryCodes = new HashSet<IsocountryCodes>();
        }

        public string CountryScheme { get; set; }

        public virtual ICollection<IsocountryCodes> IsocountryCodes { get; set; }
    }
}
