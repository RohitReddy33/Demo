﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class DbchangesLog
    {
        public int ChangeId { get; set; }
        public DateTime? DateCreated { get; set; }
        public string UserCreated { get; set; }
        public string ChangeDescription { get; set; }
        public bool? Locked { get; set; }
        public DateTime? UnlockedDate { get; set; }
        public DateTime? LockedDate { get; set; }
    }
}
