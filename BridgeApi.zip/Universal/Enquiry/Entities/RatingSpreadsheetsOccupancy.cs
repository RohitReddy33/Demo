﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class RatingSpreadsheetsOccupancy
    {
        public string OccupancyCode { get; set; }
        public string Brit { get; set; }
        public string Hiscox { get; set; }
        public string Atl { get; set; }
    }
}
