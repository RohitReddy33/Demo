﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AmigclassOfBusinessCode
    {
        public string AmigclassOfBusinessCode1 { get; set; }
        public string ClassOfBusinessCodeName { get; set; }
    }
}
