﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class InsuredEntityTypes
    {
        public string Scheme { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string MunichReEquivalent { get; set; }
    }
}
