﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Isoglclass1
    {
        public string Isoglclass { get; set; }
        public string Description { get; set; }
    }
}
