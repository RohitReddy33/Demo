﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class RoofConstructionCodes
    {
        public decimal RoofConstructionCode { get; set; }
        public string RoofConstructionScheme { get; set; }
        public string Description { get; set; }
        public decimal? V11 { get; set; }
        public string MunichReEquivalent { get; set; }
    }
}
