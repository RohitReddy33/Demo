﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Isocurrencies
    {
        public string IsocurrencyCode { get; set; }
        public string Description { get; set; }
        public string AccessFormString { get; set; }
    }
}
