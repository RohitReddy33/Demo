﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AccountsGlobalPayable
    {
        public int Id { get; set; }
        public string BordereauMonth { get; set; }
        public int? BordereauYear { get; set; }
        public string PolicyRef { get; set; }
        public string ClientName { get; set; }
        public string ClientCode { get; set; }
        public string AssuredName { get; set; }
        public string ReassuredName { get; set; }
        public string ClientZip { get; set; }
        public string ClientAddress { get; set; }
        public string ScheduleName { get; set; }
        public string Usstate { get; set; }
        public string UscountyOfSchedule { get; set; }
        public string CountryOfSchedule { get; set; }
        public string ZipCodeOfSchedule { get; set; }
        public string SettlementCurrency { get; set; }
        public string OriginalCurrency { get; set; }
        public decimal? SumInsured { get; set; }
        public string TransactionType { get; set; }
        public decimal? GrossPremium { get; set; }
        public decimal? NetPremium { get; set; }
        public string TransactionReference { get; set; }
        public string TransactionDescription { get; set; }
        public string SltlicenseNumber { get; set; }
        public string SltlicenseHolder { get; set; }
        public string ZipSltbroker { get; set; }
        public string SltbrokerAddress { get; set; }
        public string Sltstate { get; set; }
        public string Slanumber { get; set; }
        public string GlukStatus { get; set; }
        public string PolicyNo { get; set; }
        public decimal? GlukNet { get; set; }
        public int? TempPremiumsId { get; set; }
        public string GlukpolicyNo { get; set; }
    }
}
