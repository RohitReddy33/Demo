﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace BridgeApi.Enquiry.Models.Entities
{
    public class BDXLogContractMonthlyTotal
    {
        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }
        public string CompanyName { get; set; }
        public string GlobalPolicyRef { get; set; }
        public int BordYear { get; set; }
        public int BordMonth { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? GrossPremium { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? GlobalGrossPremium { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? GrossPremiumError { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? Commission { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal? BCCommission { get; set; }
        public DateTime? BDXRecieved { get; set; }
        public DateTime? BDXFirstImported { get; set; }
        public DateTime? MoveToLiveDate { get; set; }
        public DateTime? IntoGlobal { get; set; }
        public DateTime? AccountCurrentSignedOff { get; set; }
        public string AccountCurrentSignedOffBy { get; set; }
        public int? NoRecordsError { get; set; }
        public string ProcessedBy { get; set; }
        public bool? NillBdx { get; set; }
        public string SubmissionType { get; set; }

    }
}
