﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PolicyTransactionsTransportationApdcommodities
    {
        public long TransportationId { get; set; }
        public long TempTransportationApdcommodityId { get; set; }
        public long TempTransportationId { get; set; }
        public string ApdcommodityScheme { get; set; }
        public int? ApdcommodityType { get; set; }

        public virtual PolicyTransactionsTransportation Transportation { get; set; }
    }
}
