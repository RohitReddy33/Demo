﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempPolicyTransactionsTransportationVehicleDetails
    {
        public long TempTransportationVehicleDetailsId { get; set; }
        public long TempTransportationId { get; set; }
        public string TypeOfVehicle { get; set; }
        public string Vin { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public decimal? Year { get; set; }
        public decimal? Acv { get; set; }

        public virtual ArchiveTempPolicyTransactionsTransportation TempTransportation { get; set; }
    }
}
