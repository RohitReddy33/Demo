﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempPolicyTransactionsDocucorpIncludedForms
    {
        public int Id { get; set; }
        public long TempPremiumsId { get; set; }
        public string FormName { get; set; }
        public string EditionDate { get; set; }
        public string Description { get; set; }
        public string Version { get; set; }

        public virtual ArchiveTempPolicyTransactions TempPremiums { get; set; }
    }
}
