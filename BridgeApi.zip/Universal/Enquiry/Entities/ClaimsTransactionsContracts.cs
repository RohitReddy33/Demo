﻿using System;
using System.Collections.Generic;
using BridgeApi.Enquiry.Entities;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ClaimsTransactionsContracts
    {
        public long ClaimsTransId { get; set; }
        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }
        public decimal? ContractShare { get; set; }
        public decimal? LiabilityShare { get; set; }
        public decimal? EquipmentBreakdownShare { get; set; }

        public virtual AgentsContracts AgentsContracts { get; set; }
        public virtual ClaimsTransactions ClaimsTrans { get; set; }
    }
}
