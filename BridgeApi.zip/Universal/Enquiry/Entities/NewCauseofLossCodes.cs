﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class NewCauseofLossCodes
    {
        public string Codes { get; set; }
        public string NewMapping { get; set; }
    }
}
