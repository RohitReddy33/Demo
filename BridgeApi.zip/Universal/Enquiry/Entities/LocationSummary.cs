﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class LocationSummary
    {
        public long? TempPremiumsId { get; set; }
        public double? PropertyPremium { get; set; }
        public decimal? PropertyLimit { get; set; }
        public double? PropertyPremiumB { get; set; }
        public decimal? PropertyLimitB { get; set; }
        public decimal? LimitBuildingCoverageA { get; set; }
        public decimal? LimitContentsCoverageC { get; set; }
        public decimal? LimitBusinessInterruptionCoverageD { get; set; }
        public decimal? WindLimit { get; set; }
        public decimal? QuakeLimit { get; set; }
        public decimal? FloodLimit { get; set; }
        public decimal? InlandMarineLimit { get; set; }
        public decimal? EquipmentBreakdownPremium { get; set; }
        public decimal? Triprapremium { get; set; }
        public decimal? Tivfgu { get; set; }
        public decimal? LiabilityPremium { get; set; }
        public decimal? LiabilityLimit { get; set; }
        public decimal? GlaggregateLimit { get; set; }
    }
}
