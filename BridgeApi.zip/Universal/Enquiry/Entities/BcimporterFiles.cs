﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class BcimporterFiles
    {
        public string Description { get; set; }
        public string RegEx { get; set; }
        public bool? Enabled { get; set; }
        public DateTime? LastImport { get; set; }
        public DateTime? LastSuccessImport { get; set; }
        public bool? AllowFileReplace { get; set; }
        public string SubmissionType { get; set; }
        public bool? Wsallowed { get; set; }
    }
}
