﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PolicyHistory
    {
        public long Id { get; set; }
        public string CompanyId { get; set; }
        public string CompanyName { get; set; }
        public string ContractType { get; set; }
        public string BusinessType { get; set; }
        public string PolicyNo { get; set; }
        public string CurrentPolicyNo { get; set; }
        public string ExpiringPolicyNo { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public DateTime? LastEndorsementDate { get; set; }
        public string LastEndorsementTransactionType { get; set; }
        public string PolicyStatus { get; set; }
        public string InsuredName { get; set; }
        public string InsuredStreet { get; set; }
        public string InsuredCity { get; set; }
        public string InsuredCounty { get; set; }
        public string InsuredState { get; set; }
        public string InsuredZipcode { get; set; }
        public string MailingStreet { get; set; }
        public string MailingCity { get; set; }
        public string MailingCounty { get; set; }
        public string MailingState { get; set; }
        public string MailingZipcode { get; set; }
        public decimal GrossPremium { get; set; }
        public decimal Commission { get; set; }
        public decimal BcCommission { get; set; }
        public decimal PropertyPremium { get; set; }
        public decimal PropertyLimit { get; set; }
        public decimal WindLimit { get; set; }
        public decimal QuakeLimit { get; set; }
        public decimal FloodLimit { get; set; }
        public decimal LiabilityPremium { get; set; }
        public decimal LiabilityLimit { get; set; }
        public int NumberofLocations { get; set; }
        public int ContractYear { get; set; }
    }
}
