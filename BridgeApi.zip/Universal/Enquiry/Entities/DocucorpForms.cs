﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class DocucorpForms
    {
        public string FormName { get; set; }
        public string FormDescription { get; set; }
        public int? ProcessOrder { get; set; }
        public bool? PickupFormsetId { get; set; }
        public bool? ExactMarchFormName { get; set; }
    }
}
