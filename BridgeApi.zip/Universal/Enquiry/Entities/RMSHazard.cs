﻿namespace BridgeApi.Enquiry.Models.Entities
{
    public class HazardScore
    {
        public int LocationNumber { get; set; }
        public string MRHazardName { get; set; }
        public string MRHazardNameAlias { get; set; }
        public string MRHazardDesc { get; set; }
        public int MRHazardScore { get; set; }
        public int BarLength { get; set; }
    }
}
