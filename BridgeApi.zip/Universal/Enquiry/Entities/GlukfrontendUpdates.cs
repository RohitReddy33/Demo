﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class GlukfrontendUpdates
    {
        public int Id { get; set; }
        public DateTime UpdateTime { get; set; }
        public string UpdatingUser { get; set; }
        public string UpdatingTable { get; set; }
        public string PrimaryKey { get; set; }
        public string UpdatingField { get; set; }
        public string OldValue { get; set; }
        public string NewValue { get; set; }
    }
}
