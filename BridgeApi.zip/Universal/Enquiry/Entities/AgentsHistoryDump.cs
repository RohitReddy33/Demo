﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsHistoryDump
    {
        public int NumCompanyId { get; set; }
        public string TxtCompanyName { get; set; }
        public string MemCisHistory { get; set; }
        public int NumCountryId { get; set; }
    }
}
