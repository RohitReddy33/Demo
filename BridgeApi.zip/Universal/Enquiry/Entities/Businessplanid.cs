﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Businessplanid
    {
        public int? Id { get; set; }
    }
}
