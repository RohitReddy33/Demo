﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ReasonsDeclined
    {
        public long ReasonsDeclinedId { get; set; }
        public string ReasonsDeclined1 { get; set; }
    }
}
