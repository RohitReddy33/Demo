﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Policy
    {
        public Policy()
        {
            PolicyLocations = new HashSet<PolicyLocations>();
        }

        public int CompanyId { get; set; }
        public string Xlsoffice { get; set; }
        public int? ContractPeriod { get; set; }
        public string IsocurrencyCode { get; set; }
        public string CompanyNumber { get; set; }
        public string InsuredName { get; set; }
        public string CertificateNumber { get; set; }
        public string PolicyNo { get; set; }
        public string ExpiringPolicyNumber { get; set; }
        public string CurrentPolicyNumber { get; set; }
        public string PlcommercialIndicator { get; set; }
        public decimal? CoverageForm { get; set; }
        public decimal? PlacementType { get; set; }
        public decimal? CoInsurancePercentage { get; set; }
        public decimal? HereonPercentage { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public string MailingStreet { get; set; }
        public string MailingCity { get; set; }
        public string MailingCounty { get; set; }
        public string MailingState { get; set; }
        public string MailingZipCode { get; set; }
        public string MailingCountryScheme { get; set; }
        public string MailingCountryCode { get; set; }
        public string InsuredStreet { get; set; }
        public string InsuredCity { get; set; }
        public string InsuredCounty { get; set; }
        public string InsuredState { get; set; }
        public string InsuredZipCode { get; set; }
        public string InsuredCountryScheme { get; set; }
        public string InsuredCountryCode { get; set; }
        public int? NumberofLocations { get; set; }
        public int? NumberofBuildings { get; set; }
        public string IsopropertyCode { get; set; }
        public string AmigclassOfBusinessCode { get; set; }
        public string OccupancyScheme { get; set; }
        public string OccupancyCode { get; set; }
        public string ConstructionCodeScheme { get; set; }
        public string ConstructionCode { get; set; }
        public string ProtectionClass { get; set; }
        public string Protections { get; set; }
        public decimal? YearBuilt { get; set; }
        public int? NumberofStories { get; set; }
        public decimal? Squarefootage { get; set; }
        public string FloodZone { get; set; }
        public decimal? RoofConstructionCode { get; set; }
        public decimal? RoofShapeCode { get; set; }
        public decimal? RoofLastUpdated { get; set; }
        public decimal? WiringLastUpdated { get; set; }
        public decimal? PlumbingLastUpdated { get; set; }
        public decimal? HeatingLastUpdated { get; set; }
        public string Isoglclass { get; set; }
        public decimal? GrossPremium { get; set; }
        public decimal? Commission { get; set; }
        public decimal? NetPremium { get; set; }
        public string Payable { get; set; }
        public decimal? TotalPropertyPremium { get; set; }
        public decimal? TotalPropertyLimit { get; set; }
        public decimal? PropertyPremium { get; set; }
        public decimal? PropertyLimit { get; set; }
        public decimal? PropertyPremiumB { get; set; }
        public decimal? PropertyLimitB { get; set; }
        public decimal? LimitBuildingCoverageA { get; set; }
        public decimal? LimitContentsCoverageC { get; set; }
        public decimal? LimitBusinessInterruptionCoverageD { get; set; }
        public decimal? LimitOtherCoverageB { get; set; }
        public decimal? Rate { get; set; }
        public decimal? Aopdeductible { get; set; }
        public decimal? WindLimit { get; set; }
        public decimal? WindHailHurricaneDeductible { get; set; }
        public decimal? Catdeductible { get; set; }
        public decimal? QuakeLimit { get; set; }
        public decimal? QuakeDeductible { get; set; }
        public decimal? FloodLimit { get; set; }
        public decimal? FloodDeductible { get; set; }
        public decimal? Impremium { get; set; }
        public decimal? FullTermEndorsementPremium { get; set; }
        public decimal? InlandMarineLimit { get; set; }
        public string EquipmentBreakdown { get; set; }
        public decimal? EquipmentBreakdownPremium { get; set; }
        public decimal? TerrorismPremium { get; set; }
        public decimal? Triprapremium { get; set; }
        public decimal? Tivfgu { get; set; }
        public decimal? AttachmentPoint { get; set; }
        public decimal? SizeofLayer { get; set; }
        public decimal? LiabilityPremium { get; set; }
        public decimal? ProductsCompletedOperationsPremium { get; set; }
        public decimal? AllOther { get; set; }
        public decimal? LiabilityLimit { get; set; }
        public decimal? GlaggregateLimit { get; set; }
        public string PremiumBasis { get; set; }
        public decimal? PremiumBasisValue { get; set; }
        public decimal? RateProductsCompletedOperations { get; set; }
        public decimal? RateAllOther { get; set; }
        public decimal? LiabilityDeductible { get; set; }
        public decimal? PersonalAccidentPremium { get; set; }
        public decimal? Elpremium { get; set; }
        public decimal? Ellimit { get; set; }
        public decimal? Plpremium { get; set; }
        public decimal? Pllimit { get; set; }
        public decimal? TotalInsurancePremiumTax { get; set; }
        public decimal? SurveyFees { get; set; }
        public string SltbrokerNumber { get; set; }
        public string SltbrokerName { get; set; }
        public string SltbrokerAddress { get; set; }
        public string Sltstate { get; set; }
        public string SurplusLinesTransactionNumber { get; set; }
        public string Naic { get; set; }
        public string CedingCoNameRetailAgent { get; set; }
        public int? LastBordYearReported { get; set; }
        public int? LastBordMonthReported { get; set; }
        public DateTime? CancellationDate { get; set; }
        public DateTime? LastEndorsementDate { get; set; }
        public string GeoCodeInsuredAddressText { get; set; }
        public string InsuredAddressText { get; set; }
        public string RoofShapeScheme { get; set; }
        public string RoofConstructionScheme { get; set; }

        public virtual PolicyIsoglclass PolicyIsoglclass { get; set; }
        public virtual PolicyProtections PolicyProtections { get; set; }
        public virtual ICollection<PolicyLocations> PolicyLocations { get; set; }
    }
}
