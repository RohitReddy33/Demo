﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PolicyTransactionsTransportationPriorLosses
    {
        public int PriorLossId { get; set; }
        public long? TransportationId { get; set; }
        public long? TempTransportationId { get; set; }
        public DateTime? DateOfLoss { get; set; }
        public string CauseOfLoss { get; set; }
        public string ClaimStatus { get; set; }
        public decimal? TotalIncurred { get; set; }
        public int TempPriorLossId { get; set; }

        public virtual PolicyTransactionsTransportation Transportation { get; set; }
    }
}
