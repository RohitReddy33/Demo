﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class OpenClaims
    {
        public long ClaimsTransId { get; set; }
        public int? CompanyId { get; set; }
        public int? SubCompanyId { get; set; }
        public string Xlsoffice { get; set; }
        public int? BordMonth { get; set; }
        public int? BordYear { get; set; }
        public int? ContractPeriod { get; set; }
        public string IsocurrencyCode { get; set; }
        public string TransactionType { get; set; }
        public string CompanyNumber { get; set; }
        public string Expr1 { get; set; }
        public string InsuredName { get; set; }
        public string ClaimantName { get; set; }
        public string CertificateNumber { get; set; }
        public string PolicyNo { get; set; }
        public DateTime? PolicyEffectiveDate { get; set; }
        public DateTime? PolicyExpirationDate { get; set; }
        public DateTime? DateOfLoss { get; set; }
        public string CauseOfLoss { get; set; }
        public string Catnumber { get; set; }
        public string Sltstate { get; set; }
        public string LossState { get; set; }
        public string LossCounty { get; set; }
        public decimal? PaidClaimIndemnity { get; set; }
        public decimal? PaidClaimProperty { get; set; }
        public decimal? PaidClaimBi { get; set; }
        public decimal? Subrogation { get; set; }
        public decimal? Salvage { get; set; }
        public decimal? ThirdPartyAdministratorFee { get; set; }
        public decimal? PaidLaeadjuster { get; set; }
        public decimal? PaidLaelegal { get; set; }
        public decimal? PaidLaeallOther { get; set; }
        public decimal? OutstandingClaimIndemnityReserve { get; set; }
        public decimal? OutstandingLaereserve { get; set; }
        public string PaidOffBdx { get; set; }
        public bool? Litigation { get; set; }
        public string SubBrokerName { get; set; }
        public string Adjuster { get; set; }
        public string Attorney { get; set; }
        public string ClaimStatus { get; set; }
        public DateTime? DateCreated { get; set; }
        public string UserCreated { get; set; }
        public DateTime? DateModified { get; set; }
        public string UserModified { get; set; }
        public long? OrderId { get; set; }
        public string GlukoldClaimNumber { get; set; }
        public string MigrationContractRef { get; set; }
        public string MigrationSectionNumber { get; set; }
        public string MigrationBusinessArea { get; set; }
        public long? MigrationOldSystemId { get; set; }
        public int? GlobalMovementId { get; set; }
        public int? GlobalClaimId { get; set; }
        public long? TempClaimsId { get; set; }
        public string Notes { get; set; }
        public long? OriginalClaimsTransId { get; set; }
        public DateTime? DateClaimMade { get; set; }
        public string Denial { get; set; }
        public string RefertoUnderwriter { get; set; }
        public string MedicareStatusCheckIndicator { get; set; }
        public string MedicareOutcomeofStatusCheck { get; set; }
        public decimal? MedicareIncurredAmount { get; set; }
        public string LossAdjusterClaimFileNo { get; set; }
        public string TpafileHandlerEmail { get; set; }
        public string AttorneyClaimFileNo { get; set; }
        public string PublicAttorneyFirm { get; set; }
        public string PublicAdjusterCompany { get; set; }
        public string PublicAdjusterClaimFileNo { get; set; }
        public string PublicAttorneyClaimFileNo { get; set; }
        public string LitigationType { get; set; }
        public int? ClaimResolutionCode { get; set; }
    }
}
