﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class LocationIncResults
    {
        public string Companyid { get; set; }
        public string Policyno { get; set; }
        public int? Fire { get; set; }
        public int? Water { get; set; }
    }
}
