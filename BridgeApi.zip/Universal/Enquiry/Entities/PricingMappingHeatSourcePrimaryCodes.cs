﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PricingMappingHeatSourcePrimaryCodes
    {
        public string Code { get; set; }
        public string EngineEquivalent { get; set; }
    }
}
