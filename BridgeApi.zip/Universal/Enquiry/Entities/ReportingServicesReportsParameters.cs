﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ReportingServicesReportsParameters
    {
        public int ReportId { get; set; }
        public int ParameterId { get; set; }
        public string ParameterName { get; set; }
        public string ParameterFriendlyName { get; set; }
        public string ParameterType { get; set; }
        public string ComboSource { get; set; }
        public bool? UseCombo { get; set; }
    }
}
