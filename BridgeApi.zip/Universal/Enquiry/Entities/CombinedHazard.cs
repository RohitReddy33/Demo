﻿using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public class CombinedHazard
    {
        public IEnumerable<Hazard> HazardEntities { get; set; }
        public IEnumerable<HazardScore> HazardScoreEntities { get; set; }
    }
}
