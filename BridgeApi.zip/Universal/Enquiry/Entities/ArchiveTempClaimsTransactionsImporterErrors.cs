﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempClaimsTransactionsImporterErrors
    {
        public long TempClaimsId { get; set; }
        public string FieldName { get; set; }
        public string Notes { get; set; }
        public string FieldValue { get; set; }

        public virtual ArchiveTempClaimsTransactions TempClaims { get; set; }
    }
}
