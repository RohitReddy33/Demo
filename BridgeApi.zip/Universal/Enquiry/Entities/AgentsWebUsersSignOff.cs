﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsWebUsersSignOff
    {
        public int SignOffId { get; set; }
        public int CompanyId { get; set; }
        public string Username { get; set; }
        public DateTime SignOffDate { get; set; }
    }
}
