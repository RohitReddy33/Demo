﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PolicyTransactionsProtections
    {
        public long TransId { get; set; }
        public string Protections { get; set; }

        public virtual Protections ProtectionsNavigation { get; set; }
        public virtual PolicyTransactions Trans { get; set; }
    }
}
