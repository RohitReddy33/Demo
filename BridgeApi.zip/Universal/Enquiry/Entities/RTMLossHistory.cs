﻿using System.ComponentModel.DataAnnotations.Schema;

namespace BridgeApi.Enquiry.Models.Entities
{
    public class RTMLossHistory
    {
        public string ClaimNumber { get; set; }
        public string DateOfLoss { get; set; }
        public string TypeOfLoss { get; set; }
        public string CauseOfLoss { get; set; }

        [Column("PolicyNo")]
        public string PolicyNumber { get; set; }
    }
}
