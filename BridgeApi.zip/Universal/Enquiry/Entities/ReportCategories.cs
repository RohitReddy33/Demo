﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ReportCategories
    {
        public ReportCategories()
        {
            Reports = new HashSet<Reports>();
        }

        public int ReportCategoryId { get; set; }
        public string CategoryName { get; set; }
        public bool? ShowInMenu { get; set; }
        public bool AgentManageable { get; set; }

        public virtual ICollection<Reports> Reports { get; set; }
    }
}
