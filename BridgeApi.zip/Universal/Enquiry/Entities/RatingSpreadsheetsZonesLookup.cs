﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class RatingSpreadsheetsZonesLookup
    {
        public RatingSpreadsheetsZonesLookup()
        {
            RatingSpreadsheetsZonesLookupCounty = new HashSet<RatingSpreadsheetsZonesLookupCounty>();
            RatingSpreadsheetsZonesLookupZip = new HashSet<RatingSpreadsheetsZonesLookupZip>();
        }

        public int RatingSpreadSheetZoneId { get; set; }
        public int RatingSpreadSheetId { get; set; }
        public string State { get; set; }
        public string Zone { get; set; }
        public decimal? DistanceToCoastMin { get; set; }
        public decimal? DistanceToCoastMax { get; set; }
        public string ConstructionCodeScheme { get; set; }
        public string ConstructionCode { get; set; }
        public bool? WholeState { get; set; }
        public bool? Problem { get; set; }
        public int? ShapeFileId { get; set; }
        public bool? ExcludeWind { get; set; }
        public int? OldRatingSpreadSheetZoneId { get; set; }
        public decimal? RatingOverrideFactor { get; set; }
        public int? CopyOfRatingSpreadSheetZoneId { get; set; }
        public bool? ReferToUnderwriters { get; set; }
        public bool? Decline { get; set; }

        public virtual ICollection<RatingSpreadsheetsZonesLookupCounty> RatingSpreadsheetsZonesLookupCounty { get; set; }
        public virtual ICollection<RatingSpreadsheetsZonesLookupZip> RatingSpreadsheetsZonesLookupZip { get; set; }
    }
}
