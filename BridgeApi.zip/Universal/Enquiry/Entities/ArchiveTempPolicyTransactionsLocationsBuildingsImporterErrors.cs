﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempPolicyTransactionsLocationsBuildingsImporterErrors
    {
        public long TempBuildingsId { get; set; }
        public string FieldName { get; set; }
        public string Notes { get; set; }
        public string FieldValue { get; set; }

        public virtual ArchiveTempPolicyTransactionsLocationsBuildings TempBuildings { get; set; }
    }
}
