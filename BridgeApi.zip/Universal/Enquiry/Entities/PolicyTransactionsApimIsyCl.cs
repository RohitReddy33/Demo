﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PolicyTransactionsApimIsyCl
    {
        public long Id { get; set; }
        public long TransId { get; set; }
        public DateTime DateCreated { get; set; }
        public string TransactionReasonCode { get; set; }
        public string CancelMethod { get; set; }
        public string PolicyTypeCode { get; set; }

        public virtual PolicyTransactions Trans { get; set; }
    }
}
