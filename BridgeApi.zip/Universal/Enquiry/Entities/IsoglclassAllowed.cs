﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class IsoglclassAllowed
    {
        public int CompanyId { get; set; }
        public string Statecode { get; set; }
        public string Isoglclass { get; set; }
        public string Description { get; set; }
        public string GlpremisesAuthority { get; set; }
        public string ProductsCompletedOpsAuthority { get; set; }
        public string PropertyAuthority { get; set; }
    }
}
