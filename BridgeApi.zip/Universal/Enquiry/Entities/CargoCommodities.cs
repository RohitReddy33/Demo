﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class CargoCommodities
    {
        public string CargoCommodityScheme { get; set; }
        public int CargoCommodityType { get; set; }
        public string Description { get; set; }
        public string Category { get; set; }
        public bool? Target { get; set; }
    }
}
