﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsSubMissionType
    {
        public double? CompanyId { get; set; }
        public string CompanyName { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int? ContractYear { get; set; }
        public string Description { get; set; }
        public double? IsRealTime { get; set; }
        public string SubmissionType { get; set; }
        public string F9 { get; set; }
        public string F10 { get; set; }
    }
}
