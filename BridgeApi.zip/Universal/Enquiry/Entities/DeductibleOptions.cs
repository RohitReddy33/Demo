﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class DeductibleOptions
    {
        public int DeductibleOptionId { get; set; }
        public int? DeductibleCategoryId { get; set; }
        public decimal Option { get; set; }
        public DateTime? ValidFrom { get; set; }
        public DateTime? ValidTo { get; set; }
        public int? OptionNumber { get; set; }
        public bool? IsDefault { get; set; }

        public virtual DeductibleCategories DeductibleCategory { get; set; }
    }
}
