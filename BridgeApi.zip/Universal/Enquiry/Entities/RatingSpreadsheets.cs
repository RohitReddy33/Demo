﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class RatingSpreadsheets
    {
        public int RatingSpreadSheetId { get; set; }
        public string Name { get; set; }
        public string FilePath { get; set; }
        public string StoredProcedure { get; set; }
        public bool? Active { get; set; }
        public int? NumberOptions { get; set; }
        public int? QuoteType { get; set; }
        public string Syndicate { get; set; }
        public bool? IsTestRater { get; set; }
    }
}
