﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Apdcommodities
    {
        public string ApdcommodityScheme { get; set; }
        public int ApdcommodityType { get; set; }
        public string Description { get; set; }
        public int? RatingCategory { get; set; }
    }
}
