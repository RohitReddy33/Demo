﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class BcclaimsAuthorities
    {
        public string TypeOfLoss { get; set; }
        public string BusinessArea { get; set; }
        public decimal BcclaimAuthority { get; set; }
    }
}
