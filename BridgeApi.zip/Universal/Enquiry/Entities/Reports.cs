﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Reports
    {
        public Reports()
        {
            AgentsWebUsersReportsPermissions = new HashSet<AgentsWebUsersReportsPermissions>();
        }

        public int ReportId { get; set; }
        public int ReportCategoryId { get; set; }
        public string ReportName { get; set; }
        public string ReportPath { get; set; }
        public bool? ShowInMenu { get; set; }
        public bool? DefaultReport { get; set; }
        public bool? AgentManageable { get; set; }
        public bool ShowInInternalBridge { get; set; }
        public bool IsTableau { get; set; }
        public string ReportingServicesPathIbridge { get; set; }
        public string ReportingServicesPathEbridge { get; set; }

        public virtual ReportCategories ReportCategory { get; set; }
        public virtual ICollection<AgentsWebUsersReportsPermissions> AgentsWebUsersReportsPermissions { get; set; }
    }
}
