﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempPolicyTransactionsTransportationApdacvunitBanding
    {
        public long TempTransportationId { get; set; }
        public decimal? BandFrom { get; set; }
        public decimal? BandTo { get; set; }
        public short? UnitCount { get; set; }
        public int TempApdacvunitBandingId { get; set; }
        public decimal? Aopdeductible { get; set; }

        public virtual ArchiveTempPolicyTransactionsTransportation TempTransportation { get; set; }
    }
}
