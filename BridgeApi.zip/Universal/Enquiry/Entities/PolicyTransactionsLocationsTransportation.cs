﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PolicyTransactionsLocationsTransportation
    {
        public long TransportationLocId { get; set; }
        public long LocId { get; set; }
        public int? TempLocationsTransportationId { get; set; }
        public long? TempLocationsId { get; set; }
        public string TransportationType { get; set; }
        public decimal? AnyOneLoss { get; set; }
        public decimal? AnyOneUnit { get; set; }
        public decimal? AvgValueInAterminal { get; set; }
        public decimal? FullTermEndorsementPremium { get; set; }
        public int? NoOfUnits { get; set; }
        public int? RadiusOfUse { get; set; }
        public decimal? Tivfgu { get; set; }
        public string TypeOfVehicle { get; set; }
        public int? YearsInBusiness { get; set; }
        public decimal? AnyOneCombination { get; set; }
        public int? Apdcommodities { get; set; }
        public int? AvgNoOfUnits { get; set; }
        public decimal? AvgValuePerUnit { get; set; }
        public int? MaxNoOfUnits { get; set; }
        public int? NatureOfLocations { get; set; }
        public int? TypeOfUnits { get; set; }
        public int? NatureOfTrade { get; set; }
        public int? NoOfWreckerTowingUnits { get; set; }
        public decimal? OnHookLimit { get; set; }
        public int? TypeOfLiability { get; set; }
        public decimal? AvgValuePerShipment { get; set; }
        public decimal? TotalValueAtAnyOneTerminal { get; set; }
        public int? TypeOfCarrier { get; set; }
        public int? CargoCommodities { get; set; }
        public string Dotnumber { get; set; }
        public string Mcnumber { get; set; }
        public int? TotalActualCashValueOfScheduledItems { get; set; }

        public virtual PolicyTransactionsLocations Loc { get; set; }
    }
}
