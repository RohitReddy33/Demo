﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsContactsTypes
    {
        public AgentsContactsTypes()
        {
            AgentsContacts = new HashSet<AgentsContacts>();
        }

        public string ContactType { get; set; }

        public virtual ICollection<AgentsContacts> AgentsContacts { get; set; }
    }
}
