﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempPolicyTransactionsRmspurePremiums
    {
        public long TempPremiumsId { get; set; }
        public int DlmProfId { get; set; }
        public string PerilType { get; set; }
        public int Rmsversion { get; set; }
        public decimal? Premium { get; set; }
        public DateTime? RmsrunDate { get; set; }

        public virtual ArchiveTempPolicyTransactions TempPremiums { get; set; }
    }
}
