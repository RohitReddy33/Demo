﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class JointCertDashboard
    {
        public long TransId { get; set; }
        public int CompanyId { get; set; }
        public string CompanyName { get; set; }
        public string PolicyNo { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public string InsuredName { get; set; }
        public decimal? GrossPremium { get; set; }
        public decimal? PropertyPremium { get; set; }
        public double? LloydspropertyPremium { get; set; }
        public double? LloydsliabilityPremium { get; set; }
        public double? GlukpropertyPremium { get; set; }
        public double? GlukliabilityPremium { get; set; }
        public decimal? Tivfgu { get; set; }
        public decimal? PropertyLimit { get; set; }
        public double? GlukpropShare { get; set; }
        public double? GlukliabShare { get; set; }
        public double? LloydspropShare { get; set; }
        public double? LloydsliabShare { get; set; }
        public int Renewal { get; set; }
        public int New { get; set; }
        public int IsShared { get; set; }
        public string GlukcontractDescription { get; set; }
        public string LloydscontractDescription { get; set; }
        public string JointCertsStatus { get; set; }
        public string LimitBand { get; set; }
    }
}
