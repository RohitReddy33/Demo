﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class CrimeInsuranceAgreement
    {
        public int CrimeInsuranceAgreement1 { get; set; }
        public string CrimeInsuranceAgreementText { get; set; }
    }
}
