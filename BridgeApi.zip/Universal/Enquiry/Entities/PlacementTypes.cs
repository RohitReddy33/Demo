﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PlacementTypes
    {
        public decimal PlacementType { get; set; }
        public string Description { get; set; }
    }
}
