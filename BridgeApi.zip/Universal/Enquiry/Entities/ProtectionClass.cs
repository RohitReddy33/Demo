﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ProtectionClass
    {
        public string ProtectionClass1 { get; set; }
        public string MunichReEquivalent { get; set; }
    }
}
