﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class HarrisZones
    {
        public string ZipCode { get; set; }
        public string HarrisZone { get; set; }
    }
}
