﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class NoWindLimit
    {
        public string PolicyNo { get; set; }
        public string TransactionType { get; set; }
        public double? AfterEndWindLimit { get; set; }
        public double? WindLimitNew { get; set; }
    }
}
