﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class EqtoolUsage
    {
        public string Type { get; set; }
        public int Enqcount { get; set; }
        public int Loccount { get; set; }
        public string User { get; set; }
        public string ShortName { get; set; }
        public DateTime? Datecreated { get; set; }
        public string PolicyNo { get; set; }
        public string Insuredname { get; set; }
        public string Insuredstreet { get; set; }
        public string Insuredcity { get; set; }
        public string Insuredcounty { get; set; }
        public string Insuredstate { get; set; }
        public string State { get; set; }
        public string Insuredzipcode { get; set; }
        public double? MrY { get; set; }
        public double? MrX { get; set; }
        public decimal? PropertyLimit { get; set; }
        public string BusinessArea { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public string Name { get; set; }
        public decimal? GrossPremium { get; set; }
    }
}
