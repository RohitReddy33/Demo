﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class BordMonthYear
    {
        public long Id { get; set; }
        public int BordYear { get; set; }
        public int BordMonth { get; set; }
        public bool ClosedAmig { get; set; }
        public bool ClosedGluk { get; set; }
        public bool ClosedIronShore { get; set; }
        public bool ClosedGlukInhouse { get; set; }
        public bool ClosedLloyds { get; set; }
        public bool EarnedRun { get; set; }
        public int CurrentMonthGluk { get; set; }
        public string UserUpdated { get; set; }
        public DateTime? DateUpdated { get; set; }
        public int? ClosedInhouseClaimsBordYear { get; set; }
        public int? ClosedInhouseClaimsBordMonth { get; set; }
        public string ClosedAmigBy { get; set; }
        public DateTime? ClosedAmigDate { get; set; }
        public string ClosedGlukBy { get; set; }
        public DateTime? ClosedGlukDate { get; set; }
        public string ClosedIronShoreBy { get; set; }
        public DateTime? ClosedIronShoreDate { get; set; }
        public string ClosedGlukInhouseBy { get; set; }
        public DateTime? ClosedGlukInhouseDate { get; set; }
        public string ClosedLloydsBy { get; set; }
        public DateTime? ClosedLloydsDate { get; set; }
        public bool? EditingUnlocked { get; set; }
        public string EditingUnlockedReason { get; set; }
        public bool ClosedPeslic { get; set; }
        public string ClosedPeslicBy { get; set; }
        public DateTime? ClosedPeslicDate { get; set; }
        public bool ClosedAaic { get; set; }
        public string ClosedAaicBy { get; set; }
        public DateTime? ClosedAaicDate { get; set; }
    }
}
