﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class LogImportedFilesWs
    {
        public LogImportedFilesWs()
        {
            LogImportedFiles = new HashSet<LogImportedFiles>();
        }

        public Guid WsticketId { get; set; }
        public string UniqueAgentReference { get; set; }
        public string Username { get; set; }
        public DateTime TicketRequestDate { get; set; }
        public string ClientFileName { get; set; }
        public bool FileSaved { get; set; }
        public int? FileStatus { get; set; }
        public byte[] FileContents { get; set; }
        public DateTime? TicketEndProcessingDate { get; set; }
        public int? ProcessingTimeMillisecond { get; set; }
        public string PreXsltfileName { get; set; }
        public string ProcessingLog { get; set; }
        public bool? XsltfallBackTransformationUsed { get; set; }
        public string ProcessingLogClient { get; set; }
        public DateTime? FileSavedDate { get; set; }
        public DateTime? ProcessingStartDate { get; set; }

        public virtual ICollection<LogImportedFiles> LogImportedFiles { get; set; }
    }
}
