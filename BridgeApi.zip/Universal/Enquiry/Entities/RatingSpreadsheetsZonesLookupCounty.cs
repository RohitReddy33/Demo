﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class RatingSpreadsheetsZonesLookupCounty
    {
        public int RatingSpreadSheetZoneId { get; set; }
        public string State { get; set; }
        public string County { get; set; }
        public bool? Include { get; set; }
        public DateTime? DateCreated { get; set; }

        public virtual RatingSpreadsheetsZonesLookup RatingSpreadSheetZone { get; set; }
    }
}
