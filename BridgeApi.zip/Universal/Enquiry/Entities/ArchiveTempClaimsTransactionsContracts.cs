﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempClaimsTransactionsContracts
    {
        public long TempClaimsId { get; set; }
        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }
        public decimal? ContractShare { get; set; }
        public decimal? LiabilityShare { get; set; }
        public decimal? EquipmentBreakdownShare { get; set; }

        public virtual ArchiveTempClaimsTransactions TempClaims { get; set; }
    }
}
