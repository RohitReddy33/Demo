﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class RecordsInTempWithContractsNotSetToMoveToLive
    {
        public int CompanyId { get; set; }
        public string CompanyName { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int? ContractYear { get; set; }
        public bool? IsUsingMoveToLive { get; set; }
    }
}
