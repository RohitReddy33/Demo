﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempPolicyTransactionsTransportationTrailerDetails
    {
        public long TempTransportationTrailerDetailsId { get; set; }
        public long TempTransportationId { get; set; }
        public string TypeOfTrailer { get; set; }
        public string Vin { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public decimal? Year { get; set; }
        public decimal? Acv { get; set; }
        public bool? NonOwnedTrailer { get; set; }

        public virtual ArchiveTempPolicyTransactionsTransportation TempTransportation { get; set; }
    }
}
