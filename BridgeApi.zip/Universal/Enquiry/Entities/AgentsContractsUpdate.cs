﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsContractsUpdate
    {
        public double? Companyid { get; set; }
        public string Agent { get; set; }
        public string Contact { get; set; }
        public double? ContractNo { get; set; }
        public string EmailAddress { get; set; }
        public string CreditController { get; set; }
    }
}
