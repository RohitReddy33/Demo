﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsContractsStatic
    {
        public AgentsContractsStatic()
        {
            AgentsContractsContacts = new HashSet<AgentsContractsContacts>();
            AgentsContractsStateStatic = new HashSet<AgentsContractsStateStatic>();
        }

        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }
        public string AgentsSystemKnowsContractAs { get; set; }
        public string Description { get; set; }
        public string TransitionTo { get; set; }
        public decimal? AgentCommission { get; set; }
        public decimal? Bccommission { get; set; }
        public decimal? Gwpi { get; set; }
        public decimal? WarningPercentage { get; set; }
        public bool? WindSplit { get; set; }
        public string GlukcontractXlsletter { get; set; }
        public bool? Active { get; set; }
        public string Notes { get; set; }
        public decimal? CalcTotalAggregateLimitInclusiveExWind { get; set; }
        public decimal? CalcWindTotalAggregate { get; set; }
        public double? CalcWindPercentageUtilised { get; set; }
        public decimal? CalcQuakeTotalAggregate { get; set; }
        public double? CalcQuakePercentageUtilised { get; set; }
        public decimal? CalcFloodTotalAggregate { get; set; }
        public double? CalcFloodPercentageUtilised { get; set; }
        public decimal? CalcAllTotalAggregate { get; set; }
        public double? CalcAllPercentageUtilised { get; set; }
        public decimal? CalcGwpitoDate { get; set; }
        public decimal? CalcNwpitoDate { get; set; }
        public decimal? CalcActualNetLossRatio { get; set; }
        public decimal? CalcPaidToDateClaims { get; set; }
        public decimal? CalcCurrentOutstanding { get; set; }
        public decimal? CalcIncurred { get; set; }
        public int? Subclientid { get; set; }
        public decimal? ThirdPartyComm { get; set; }
        public string ProcessingLogic { get; set; }
        public DateTime? ContractEffectiveDate { get; set; }
        public DateTime? ContractExpirationDate { get; set; }
        public bool? AutoCalculateCommission { get; set; }
        public bool? AgentCanVaryCommission { get; set; }
        public string Gluksection { get; set; }
        public int? MaxPolicyPeriodinDays { get; set; }
        public bool? WrittenAllowed { get; set; }
        public decimal? PropertyLimit { get; set; }
        public decimal? LiabilityLimit { get; set; }
        public decimal? LiabilityAggLimit { get; set; }
        public decimal? Cpllimit { get; set; }
        public decimal? OverLimitErrorPercentage { get; set; }
        public decimal? MinimumPercentageShare { get; set; }
        public bool? MinimumPercentageShareApplies { get; set; }
        public decimal? MinimumAccessContractB { get; set; }
        public decimal? PropertyLimitOver { get; set; }
        public decimal? MinimumAccessContractBnew { get; set; }
        public decimal? AllowedOverPercentageEndorsement { get; set; }
        public byte[] Pdf { get; set; }
        public string Filename { get; set; }
        public decimal? PropertyAnnualGwpilimit { get; set; }
        public decimal? PropertyMgaprofitCommissionPayback { get; set; }
        public decimal? PropertyBcprofitCommissionOfMgapc { get; set; }
        public decimal? PropertyPaysPcbelow { get; set; }
        public decimal? PropertyPcdeferredBelow { get; set; }
        public decimal? PropertyEstimatedOfNpipayableasPc { get; set; }
        public decimal? PropertyEstimatedNetLossRatio { get; set; }
        public decimal? PropertyEstimatedGpi { get; set; }
        public decimal? PropertyEstimatedNpi { get; set; }
        public decimal? PropertyEstimatedNetProfit { get; set; }
        public decimal? PropertyEstimatedProfitCommissiontoMga { get; set; }
        public decimal? PropertyEstimatedProfitCommissiontoBc { get; set; }
        public decimal? PropertyEstimatedUltimateNetProfit { get; set; }
        public decimal? PropertyActualProfitCommissiontoMga { get; set; }
        public decimal? PropertyActualProfitCommissiontoBc { get; set; }
        public decimal? LiabilityAnnualGwpilimit { get; set; }
        public decimal? LiabilityMgaprofitCommissionPayback { get; set; }
        public decimal? LiabilityBcprofitCommissionOfMgapc { get; set; }
        public decimal? LiabilityPaysPcbelow { get; set; }
        public decimal? LiabilityPcdeferredBelow { get; set; }
        public decimal? LiabilityEstimatedOfNpipayableasPc { get; set; }
        public decimal? LiabilityEstimatedNetLossRatio { get; set; }
        public decimal? LiabilityEstimatedGpi { get; set; }
        public decimal? LiabilityEstimatedNpi { get; set; }
        public decimal? LiabilityEstimatedNetProfit { get; set; }
        public decimal? LiabilityEstimatedProfitCommissiontoMga { get; set; }
        public decimal? LiabilityEstimatedProfitCommissiontoBc { get; set; }
        public decimal? LiabilityEstimatedUltimateNetProfit { get; set; }
        public decimal? LiabilityActualProfitCommissiontoMga { get; set; }
        public decimal? LiabilityActualProfitCommissiontoBc { get; set; }
        public decimal? MrcatLossEstimate { get; set; }
        public decimal? CatPremium { get; set; }
        public decimal? MrpropertyAttritionPremium { get; set; }
        public decimal? MrpropertyBreakEvenGlr { get; set; }
        public decimal? MrpropertyAttritionalBreakEvenGlr { get; set; }
        public decimal? MrliabilityAttritionPremium { get; set; }
        public decimal? MrliabilityBreakEvenGlr { get; set; }
        public decimal? MrliabilityAttritionalBreakEvenGlr { get; set; }
        public decimal? MrpropertyEstimatedGlr { get; set; }
        public decimal? MrpropertyEstimatedExCatGlr { get; set; }
        public decimal? MrpropertyEstimatedAttritionalGlr { get; set; }
        public decimal? MrliabilityEstimatedGlr { get; set; }
        public decimal? MrliabilityEstimatedAttritionalGlr { get; set; }
        public decimal? MrpropertyEstimatedValueAdded { get; set; }
        public decimal? MrpropertyRollingRenewOther { get; set; }
        public string MrliabilityEstimatedValueAdded { get; set; }
        public decimal? MrliabilityRollingRenewOther { get; set; }
        public int? PropertyPatternId { get; set; }
        public int? LiabilityPatternId { get; set; }
        public bool? IsRealTime { get; set; }
        public bool? IsLegacyBdx { get; set; }
        public bool? IsTempTablesTesting { get; set; }
        public bool? IsUsingMoveToLive { get; set; }
        public bool? IsUsingMoveToLiveClaims { get; set; }
        public int? MoveToLiveMethod { get; set; }
        public int? MoveToLiveMethodClaims { get; set; }
        public string Wca { get; set; }
        public bool? Rmsmodeled { get; set; }
        public string ClaimsProcessingLogic { get; set; }
        public bool? ProcessEndasExt { get; set; }
        public bool? MoveGlobalAccountingFiguresOver { get; set; }
        public bool? MoveGlobalClaimFiguresOver { get; set; }
        public bool? MandatoryAccountingEffectiveDate { get; set; }
        public bool? AllowPreviousContractYearLimitOnRenewal { get; set; }
        public string GlobalPolicyRef { get; set; }
        public string Oldsection { get; set; }
        public decimal? PropertyEstimatedGrossLossRatio { get; set; }
        public decimal? LiabilityEstimatedGrossLossRatio { get; set; }
        public string SubmissionType { get; set; }
        public string SubmissionTypeScheme { get; set; }
        public bool? IsExportedForBackfillData { get; set; }
        public bool? AccountCurrentSignOffEnabled { get; set; }
        public bool? ShowInAccountCurrent { get; set; }
        public string SubmissionTypeSchemeClaims { get; set; }
        public bool? AccountCurrentSignOffEnabledClaims { get; set; }
        public bool? ShowInAccountCurrentClaims { get; set; }
        public string PolicyIssuance { get; set; }
        public string UserUpdated { get; set; }
        public DateTime? DateUpdated { get; set; }
        public decimal? AnyOneUnitLimit { get; set; }
        public decimal? AnyOneCombinationLimit { get; set; }
        public decimal? AnyOneLossLimit { get; set; }
        public decimal? AnyOneEventCatTerminalLimit { get; set; }
        public string PropertyRiskCode { get; set; }
        public bool? LloydsTerrorRisk { get; set; }
        public string LiabilityRiskCode { get; set; }
        public string TriariskCode { get; set; }
        public string EqbriskCode { get; set; }
        public string ThirdPartyCommBasis { get; set; }
        public decimal? GrossPremiumRiskLimit { get; set; }
        public string SubmissionTypeClaims { get; set; }
        public bool? NonHsbequipmentBreakdown { get; set; }
        public bool? RealTimeModelingEnabled { get; set; }
        public bool? HasAccurateLocationData { get; set; }
        public short? RealTimeModelingPriority { get; set; }
        public string Glukcobcode { get; set; }

        public virtual Agents Company { get; set; }
        public virtual ICollection<AgentsContractsContacts> AgentsContractsContacts { get; set; }
        public virtual ICollection<AgentsContractsStateStatic> AgentsContractsStateStatic { get; set; }
    }
}
