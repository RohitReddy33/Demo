﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class MoveToLiveLog
    {
        public int LogId { get; set; }
        public DateTime? RunDate { get; set; }
        public int? CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public bool? TestRun { get; set; }
        public int? BordYear { get; set; }
        public int? BordMonth { get; set; }
        public string ContractYear { get; set; }
        public bool? RecordsError { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public string UserRan { get; set; }
        public bool? RoleBack { get; set; }
    }
}
