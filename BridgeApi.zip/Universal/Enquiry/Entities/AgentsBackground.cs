﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsBackground
    {
        public int Id { get; set; }
        public int CompanyId { get; set; }
        public string WhenFounded { get; set; }
        public string FounderInformation { get; set; }
        public decimal? TotalAnnualPremiumVolume { get; set; }
        public decimal? TotalAnnualPremiumBellClementsBusiness { get; set; }
        public int? TotalNumberOfStaff { get; set; }
        public string GeographicAreasOfOperation { get; set; }
        public string FreeTextDescriptionHtml { get; set; }
        public string SpecialRelationshipsOfInterestHtml { get; set; }
        public string VisitorTravelOptionsHtml { get; set; }
        public string VisitorAccommodationOptionsHtml { get; set; }
        public string VisitorInfoHtml { get; set; }
        public string TypesOfBusinessWrittenHtml { get; set; }
        public string OtherEscompaniesRepresentedHtml { get; set; }

        public virtual Agents Company { get; set; }
    }
}
