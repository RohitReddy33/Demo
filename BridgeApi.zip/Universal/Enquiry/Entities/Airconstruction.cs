﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Airconstruction
    {
        public double Code { get; set; }
        public string Category { get; set; }
        public string Construction { get; set; }
    }
}
