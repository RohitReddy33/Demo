﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class OccupancyPerGlobal
    {
        public string OccupancyId { get; set; }
        public int OccupancyCode { get; set; }
    }
}
