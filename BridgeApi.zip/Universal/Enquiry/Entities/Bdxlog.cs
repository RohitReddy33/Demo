﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Bdxlog
    {
        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }
        public int BordYear { get; set; }
        public int BordMonth { get; set; }
        public DateTime? BdxfirstImported { get; set; }
        public decimal? GrossPremium { get; set; }
        public decimal? Commission { get; set; }
        public decimal? Bccommission { get; set; }
        public decimal? GrossPremiumError { get; set; }
        public int? NoRecords { get; set; }
        public int? NoRecordsError { get; set; }
        public DateTime? Bdxrecieved { get; set; }
        public DateTime? ErrorsAdvised { get; set; }
        public DateTime? ResponseRecieved { get; set; }
        public string ProcessedBy { get; set; }
        public bool NillBdx { get; set; }
        public DateTime? MoveToLiveDate { get; set; }
        public DateTime? IntoGlobal { get; set; }
        public string Comments { get; set; }
        public DateTime? AccountCurrentSignedOff { get; set; }
        public string AccountCurrentSignedOffBy { get; set; }
        public DateTime? MoveToLiveAttempted { get; set; }
        public DateTime? AccountCurrentSignedOffClaims { get; set; }
        public string AccountCurrentSignedOffByClaims { get; set; }
        public bool? Override { get; set; }
        public DateTime? MoveToLiveAttemptedClaims { get; set; }
        public int? AccountCurrentClaimsSignedOffByTpacompanyId { get; set; }
        public string MovedToLiveUser { get; set; }
    }
}
