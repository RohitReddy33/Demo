﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ProcessingLogic
    {
        public string ProcessingLogic1 { get; set; }
    }
}
