﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class MunichLiabilityPolicies
    {
        public string PolicyNo { get; set; }
        public string InsuredName { get; set; }
        public string InsuredState { get; set; }
        public string CompanyName { get; set; }
        public string PlacementType { get; set; }
        public double? LiabilityLimit { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public double? GrossPremium { get; set; }
        public double? NetPremium { get; set; }
        public decimal? Commission { get; set; }
    }
}
