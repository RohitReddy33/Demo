﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempPolicyTransactionsErrors
    {
        public long TempPremiumsId { get; set; }
        public int PremiumErrorId { get; set; }
        public string SystemMessage { get; set; }

        public virtual ArchiveTempPolicyTransactions TempPremiums { get; set; }
    }
}
