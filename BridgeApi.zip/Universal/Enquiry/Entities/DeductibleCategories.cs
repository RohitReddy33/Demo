﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class DeductibleCategories
    {
        public DeductibleCategories()
        {
            DeductibleOptions = new HashSet<DeductibleOptions>();
        }

        public int DeductibleCategoryId { get; set; }
        public int CompanyId { get; set; }
        public decimal? CoverageForm { get; set; }
        public string Peril { get; set; }
        public string State { get; set; }
        public int? Tier { get; set; }
        public string County { get; set; }

        public virtual ICollection<DeductibleOptions> DeductibleOptions { get; set; }
    }
}
