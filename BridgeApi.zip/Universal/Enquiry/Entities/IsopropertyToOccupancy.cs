﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class IsopropertyToOccupancy
    {
        public double? IsopropCode { get; set; }
        public string Description { get; set; }
        public string Glukdescription { get; set; }
        public double? Gluk { get; set; }
    }
}
