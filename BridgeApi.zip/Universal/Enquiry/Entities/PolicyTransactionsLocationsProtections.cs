﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PolicyTransactionsLocationsProtections
    {
        public long LocId { get; set; }
        public string Protections { get; set; }

        public virtual PolicyTransactionsLocations Loc { get; set; }
    }
}
