﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Gluksltoccupancy
    {
        public string PolicyNumber { get; set; }
        public string InsuredName { get; set; }
        public string InsuredAddress { get; set; }
        public string InsuredCity { get; set; }
        public string InsuredState { get; set; }
        public double? InsuredZipCode { get; set; }
        public string StateSlBrokerLicenseNumber { get; set; }
        public string SlBrokerName { get; set; }
        public string BrokerAddress { get; set; }
        public string BrokerCity { get; set; }
        public string BrokerState { get; set; }
        public string BrokerZipCode { get; set; }
        public string ClassOfBusiness { get; set; }
        public DateTime? InceptionDate { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public double? Premium { get; set; }
    }
}
