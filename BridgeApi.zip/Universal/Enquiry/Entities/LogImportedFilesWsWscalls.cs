﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class LogImportedFilesWsWscalls
    {
        public int Id { get; set; }
        public Guid WsticketId { get; set; }
        public string MethodCall { get; set; }
        public int? FileStatus { get; set; }
        public DateTime? LogDate { get; set; }
    }
}
