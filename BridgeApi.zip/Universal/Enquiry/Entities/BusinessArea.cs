﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class BusinessArea
    {
        public string BusinessArea1 { get; set; }
        public string Letter { get; set; }
        public string InternalEmailAddresses { get; set; }
    }
}
