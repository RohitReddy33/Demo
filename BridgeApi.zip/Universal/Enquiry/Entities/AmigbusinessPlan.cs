﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AmigbusinessPlan
    {
        public double? Id { get; set; }
        public string Coverholder { get; set; }
        public string Contract { get; set; }
        public string State { get; set; }
        public string County { get; set; }
        public double? AggLimit { get; set; }
        public decimal? Windex { get; set; }
        public double? Notes { get; set; }
        public int? CoverHolderId { get; set; }
    }
}
