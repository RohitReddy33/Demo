﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempPolicyTransactionsContracts
    {
        public int Id { get; set; }
        public long? Idold { get; set; }
        public long TempPremiumsId { get; set; }
        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }
        public decimal? ContractShare { get; set; }
        public decimal? LiabilityShare { get; set; }
        public decimal? GrossPremium { get; set; }
        public decimal? Commission { get; set; }
        public decimal? Bccommission { get; set; }
        public decimal? CommissionPercentage { get; set; }
        public decimal? EquipmentBreakdownShare { get; set; }
        public decimal? BccommissionPercentage { get; set; }

        public virtual ArchiveTempPolicyTransactions TempPremiums { get; set; }
    }
}
