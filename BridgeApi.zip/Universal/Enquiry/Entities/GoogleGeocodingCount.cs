﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class GoogleGeocodingCount
    {
        public DateTime RequestDate { get; set; }
        public int? NoGeoCodes { get; set; }
    }
}
