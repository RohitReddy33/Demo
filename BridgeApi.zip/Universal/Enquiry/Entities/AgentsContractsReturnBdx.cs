﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsContractsReturnBdx
    {
        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }
        public int Bordyear { get; set; }
        public int BordMonth { get; set; }
        public string FileContentType { get; set; }
        public string FileName { get; set; }
        public byte[] FileContent { get; set; }
        public DateTime? DateAdded { get; set; }
        public string UserAdded { get; set; }

        public virtual AgentsContracts AgentsContracts { get; set; }
        public virtual BordMonthYear Bord { get; set; }
    }
}
