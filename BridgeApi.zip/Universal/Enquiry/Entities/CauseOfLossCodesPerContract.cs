﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class CauseOfLossCodesPerContract
    {
        public string CauseOfLossCode { get; set; }
        public string ContractRef { get; set; }
    }
}
