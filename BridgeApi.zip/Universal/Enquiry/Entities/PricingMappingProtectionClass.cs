﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PricingMappingProtectionClass
    {
        public string ProtectionClass { get; set; }
        public string EngineEquivalent { get; set; }
    }
}
