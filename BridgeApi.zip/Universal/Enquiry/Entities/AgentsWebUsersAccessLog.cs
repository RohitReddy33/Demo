﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsWebUsersAccessLog
    {
        public string Username { get; set; }
        public DateTime? LogTime { get; set; }
        public string UserAgent { get; set; }
        public string UserHostAddress { get; set; }
        public string UserHostName { get; set; }
        public string FilePath { get; set; }
        public string RawUrl { get; set; }
        public int? Bytes { get; set; }
    }
}
