﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class LogImportedFiles
    {
        public LogImportedFiles()
        {
            TempPolicyTransactions = new HashSet<TempPolicyTransactions>();
        }
        public string ImportFilename { get; set; }
        public int DuplicateFileSeq { get; set; }
        public string UniqueAgentReference { get; set; }
        public Guid? WsticketId { get; set; }
        public int? FileTypeId { get; set; }
        public DateTime? ImportFileDate { get; set; }
        public DateTime? DateImported { get; set; }
        public DateTime? DateCorrectionDetectorPremiumsRun { get; set; }
        public DateTime? DateCorrectionDetectorLocationsRun { get; set; }
        public DateTime? DateCheckPremiumsRun { get; set; }
        public DateTime? DateCheckLocationsRun { get; set; }
        public DateTime? DateCheckClaimsRun { get; set; }
        public bool? PremiumErrorsGenerated { get; set; }
        public bool? LocationErrorsGenerated { get; set; }
        public bool? ClaimErrorsGenerated { get; set; }
        public DateTime? DateAgentAdvised { get; set; }
        public bool? MovedToLive { get; set; }
        public string PickedUpFrom { get; set; }
        public string SavedTo { get; set; }
        public string Contract { get; set; }
        public string Section { get; set; }
        public DateTime? GlukenteredDateFrom { get; set; }
        public DateTime? GlukenteredDateTo { get; set; }
        public bool? OldSystem { get; set; }
        public DateTime? DatePostImportStart { get; set; }
        public DateTime? DatePostImportEnd { get; set; }
        public int? PostImportProcessingTimeMillisecond { get; set; }
        public string TpauniqueAgentReference { get; set; }

        public virtual LogImportedFilesWs Wsticket { get; set; }
        public virtual ICollection<TempPolicyTransactions> TempPolicyTransactions { get; set; }
    }
}
