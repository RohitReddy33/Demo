﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PolicyTransactionsContracts
    {
        public long TransId { get; set; }
        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }
        public double? ContractShare { get; set; }
        public double? LiabilityShare { get; set; }
        public decimal? GrossPremium { get; set; }
        public decimal? Commission { get; set; }
        public decimal? Bccommission { get; set; }
        public string Notes { get; set; }
        public DateTime? DateModified { get; set; }
        public string UserModified { get; set; }
        public decimal? EquipmentBreakdownShare { get; set; }
        public decimal? CommissionPercentage { get; set; }
        public decimal? BccommissionPercentage { get; set; }

        public virtual AgentsContracts AgentsContracts { get; set; }
        public virtual PolicyTransactions Trans { get; set; }
    }
}
