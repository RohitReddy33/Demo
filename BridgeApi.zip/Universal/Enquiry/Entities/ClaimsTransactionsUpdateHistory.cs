﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ClaimsTransactionsUpdateHistory
    {
        public int Id { get; set; }
        public long? ClaimsTransId { get; set; }
        public string FieldName { get; set; }
        public DateTime? DateModified { get; set; }
        public string UserModified { get; set; }
        public string PreviousValue { get; set; }
    }
}
