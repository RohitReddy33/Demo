﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class MunichReNathanInputStructure
    {
        public string CountryIsocode { get; set; }
        public string RegionState { get; set; }
        public string ZipCode { get; set; }
        public string City { get; set; }
        public string StreetHouseNumber { get; set; }
        public int? Street { get; set; }
        public int? HouseNumber { get; set; }
        public decimal? TotalSumInsured { get; set; }
    }
}
