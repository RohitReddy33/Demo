﻿namespace BridgeApi.Enquiry.Models.Entities
{
    public class NewEnquiryPolicyResult
    {
        public long tempPremiumId { get; set; }
        public string policyNumber { get; set; }
    }
}
