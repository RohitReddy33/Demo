﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ArchiveTempClaimsTransactionsTransportationTrailerDetails
    {
        public long TempClaimsTransportationTrailerDetailsId { get; set; }
        public long TempTransportationId { get; set; }
        public string TypeOfTrailer { get; set; }
        public string Vin { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public decimal? Year { get; set; }
        public decimal? Acv { get; set; }
        public decimal? ValueOfLoad { get; set; }
        public bool? NonOwned { get; set; }
        public string TotalLossType { get; set; }

        public virtual ArchiveTempClaimsTransactionsTransportation TempTransportation { get; set; }
    }
}
