﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class RDelayDocucorpReport
    {
        public string CompanyName { get; set; }
        public string TransactionType { get; set; }
        public string ImportFilename { get; set; }
        public string PolicyNo { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? DateImported { get; set; }
        public int? NumberDays { get; set; }
    }
}
