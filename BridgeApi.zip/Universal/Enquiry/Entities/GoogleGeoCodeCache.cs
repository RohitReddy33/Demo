﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class GoogleGeoCodeCache
    {
        public int Id { get; set; }
        public DateTime? Importdate { get; set; }
        public string Address { get; set; }
        public double? Latitude { get; set; }
        public double? Longitude { get; set; }
        public string LocationType { get; set; }
    }
}
