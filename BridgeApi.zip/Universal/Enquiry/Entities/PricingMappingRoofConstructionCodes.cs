﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PricingMappingRoofConstructionCodes
    {
        public string RoofConstructionScheme { get; set; }
        public decimal RoofConstructionCode { get; set; }
        public string EngineEquivalentNew { get; set; }
        public string EngineEquivalent { get; set; }
        public string Engine { get; set; }
    }
}
