﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PortalContactUs
    {
        public string TxtUserName { get; set; }
        public string TxtLocation { get; set; }
        public string TxtJobTitle { get; set; }
        public string EmailAddress { get; set; }
        public Guid Rowguid { get; set; }
        public bool IsPortalContact { get; set; }
        public string TxtCompany { get; set; }
        public string TxtContent { get; set; }
        public string TxtDdl { get; set; }
    }
}
