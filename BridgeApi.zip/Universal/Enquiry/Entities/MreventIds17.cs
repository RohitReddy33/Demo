﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class MreventIds17
    {
        public long EventId { get; set; }
        public decimal? Weight { get; set; }
        public decimal? ScalingFactor { get; set; }
        public string Scenario { get; set; }
        public int? ContractPeriod { get; set; }
    }
}
