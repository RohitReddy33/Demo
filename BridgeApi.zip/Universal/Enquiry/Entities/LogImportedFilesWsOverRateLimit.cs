﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class LogImportedFilesWsOverRateLimit
    {
        public int Id { get; set; }
        public Guid WsticketId { get; set; }
        public DateTime TicketRequestDate { get; set; }
        public string ClientFileName { get; set; }
    }
}
