﻿namespace BridgeApi.Enquiry.Models.Entities
{
    public class ContractDropDown
    {
        public string ContractRef { get; set; }
        public string ContractDescription { get; set; }
    }
}
