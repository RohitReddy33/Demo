﻿using System;
using System.Collections.Generic;
using BridgeApi.Enquiry.Entities;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ClaimsTransactionsTransportation
    {
        public ClaimsTransactionsTransportation()
        {
            ClaimsTransactionsTransportationApdcommodities = new HashSet<ClaimsTransactionsTransportationApdcommodities>();
            ClaimsTransactionsTransportationCargoCommodities = new HashSet<ClaimsTransactionsTransportationCargoCommodities>();
            ClaimsTransactionsTransportationTrailerDetails = new HashSet<ClaimsTransactionsTransportationTrailerDetails>();
            ClaimsTransactionsTransportationVehicleDetails = new HashSet<ClaimsTransactionsTransportationVehicleDetails>();
        }

        public long TransportationId { get; set; }
        public long ClaimsTransId { get; set; }
        public long TempTransportationId { get; set; }
        public long TempClaimsId { get; set; }
        public decimal? ValueOfLoad { get; set; }
        public int? Apdcommodities { get; set; }
        public int? CargoCommodities { get; set; }

        public virtual ClaimsTransactions ClaimsTrans { get; set; }
        public virtual ICollection<ClaimsTransactionsTransportationApdcommodities> ClaimsTransactionsTransportationApdcommodities { get; set; }
        public virtual ICollection<ClaimsTransactionsTransportationCargoCommodities> ClaimsTransactionsTransportationCargoCommodities { get; set; }
        public virtual ICollection<ClaimsTransactionsTransportationTrailerDetails> ClaimsTransactionsTransportationTrailerDetails { get; set; }
        public virtual ICollection<ClaimsTransactionsTransportationVehicleDetails> ClaimsTransactionsTransportationVehicleDetails { get; set; }
    }
}
