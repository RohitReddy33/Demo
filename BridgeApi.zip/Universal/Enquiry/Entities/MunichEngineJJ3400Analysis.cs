﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class MunichEngineJJ3400Analysis
    {
        public string Src { get; set; }
        public string PolicyNo { get; set; }
        public string InsuredName { get; set; }
        public int? ContractYear { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public DateTime? DateImported { get; set; }
        public decimal? GrossPremium { get; set; }
        public decimal? PropertyPremium { get; set; }
        public decimal? PropertyLimit { get; set; }
        public decimal? PropertyRate { get; set; }
        public decimal? WindLimit { get; set; }
        public decimal? QuakeLimit { get; set; }
        public decimal? FloodLimit { get; set; }
        public decimal? Tivfgu { get; set; }
        public string InsuredState { get; set; }
        public string InsuredCounty { get; set; }
        public int? Scenario { get; set; }
        public int? Tier { get; set; }
        public int? NathanDistanceToCoastInMeters { get; set; }
        public decimal? NathanDistanceToCoastInMiles { get; set; }
        public string MrDistanceToCoastlimitBand { get; set; }
        public double? MrX { get; set; }
        public double? MrY { get; set; }
        public string TransactionType { get; set; }
        public int PremiumIncomeLimit { get; set; }
        public decimal? ModifierUnderwriterPriceAdjustment { get; set; }
        public short? MrQualind { get; set; }
        public string CoverageForm { get; set; }
        public string ConstructionDescription { get; set; }
        public string OccupancyDesciption { get; set; }
    }
}
