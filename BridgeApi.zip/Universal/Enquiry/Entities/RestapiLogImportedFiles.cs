﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class RestapiLogImportedFiles
    {
        public DateTime OnDate { get; set; }
        public string FileName { get; set; }
        public string Outcome { get; set; }
        public byte[] FileContent { get; set; }
    }
}
