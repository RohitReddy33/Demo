﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ContractSummary
    {
        public string BordPeriod { get; set; }
        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }
        public string ContractType { get; set; }
        public string Gluksection { get; set; }
        public string Catno { get; set; }
        public double? GrossWrittenPropertyPremium { get; set; }
        public double? NetWrittenPropertyPremium { get; set; }
        public double? GrossEarnedPropertyPremium { get; set; }
        public double? NetEarnedPropertyPremium { get; set; }
        public double? GrossWrittenLiabilityPremium { get; set; }
        public double? NetWrittenLiabilityPremium { get; set; }
        public double? GrossEarnedLiabilityPremium { get; set; }
        public double? NetEarnedLiabilityPremium { get; set; }
        public double? GrossWrittenTerrorismPremium { get; set; }
        public double? NetWrittenTerrorismPremium { get; set; }
        public double? GrossEarnedTerrorismPremium { get; set; }
        public double? NetEarnedTerrorismPremium { get; set; }
        public double? GrossWrittenEquipmentBreakdownPremium { get; set; }
        public double? NetWrittenEquipmentBreakdownPremium { get; set; }
        public double? GrossEarnedEquipmentBreakdownPremium { get; set; }
        public double? NetEarnedEquipmentBreakdownPremium { get; set; }
        public double? PropertyPaid { get; set; }
        public double? LiabilityPaid { get; set; }
        public double? TerrorismPaid { get; set; }
        public double? EquipmentBreakdownPaid { get; set; }
        public double? PropertyOutstanding { get; set; }
        public double? LiabilityOutstanding { get; set; }
        public double? TerrorismOutstanding { get; set; }
        public double? EquipmentBreakdownOutstanding { get; set; }
    }
}
