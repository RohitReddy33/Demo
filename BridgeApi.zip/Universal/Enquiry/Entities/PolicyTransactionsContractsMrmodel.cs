﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PolicyTransactionsContractsMrmodel
    {
        public long TransId { get; set; }
        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }
        public decimal? RunningTotalPropertyPremium { get; set; }
        public double? EstMreBcbudget27 { get; set; }
        public double? EstMreBcbudget36 { get; set; }
        public double? EstMreBcbudget37 { get; set; }
        public double? EstMreBcbudget39 { get; set; }
        public double? EstMreBcbudget41 { get; set; }
        public double? EstMreBcbudget44 { get; set; }
        public double? EstMreBcbudget70 { get; set; }
        public double? EstMreBcbudget71 { get; set; }
        public double? EstMreBcbudget73 { get; set; }
        public double? EstMreBcbudget78 { get; set; }
        public decimal? EstMreBcbudget75 { get; set; }
        public double? EstMreWindAal { get; set; }
        public double? EstMreQuakeAal { get; set; }
        public double? EstMreScsaal { get; set; }
        public double? EstMreWinterstormAal { get; set; }
        public double? EstMreCatLossWind { get; set; }
        public double? EstMreCatLossQuake { get; set; }
        public double? EstMreCostCapitalWind { get; set; }
        public double? EstMreCostCapitalQuake { get; set; }
        public double? EstMreCostCapitalScs { get; set; }
        public double? EstMreCatLossFireFollowing { get; set; }
        public double? EstMreValueAddedWind { get; set; }
        public double? EstMreValueAddedQuake { get; set; }
        public double? EstMreValueAdded { get; set; }
        public double? EstMreBreakEvenPremiumWindQuake { get; set; }
        public double? EstMreBreakEvenPremium { get; set; }
        public double? EstMreBreakEvenPremiumWind { get; set; }
        public double? EstMreBreakEvenPremiumQuake { get; set; }
        public double? EstMreCostCapitalFire { get; set; }
        public decimal? EstMreFireFollowingAal { get; set; }
        public DateTime? CreateDate { get; set; }

        public virtual PolicyTransactionsContracts PolicyTransactionsContracts { get; set; }
    }
}
