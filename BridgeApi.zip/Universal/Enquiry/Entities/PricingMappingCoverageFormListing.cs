﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PricingMappingCoverageFormListing
    {
        public decimal CoverageForm { get; set; }
        public string EngineEquivalent { get; set; }
        public string PricingEngine { get; set; }
    }
}
