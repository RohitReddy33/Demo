﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsWebLoginAttempts
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string UserAgent { get; set; }
        public string UserHostAddress { get; set; }
        public string UserHostName { get; set; }
        public DateTime LoginDate { get; set; }
        public bool? Success { get; set; }
        public string ScreenRes { get; set; }
        public bool? ByPass { get; set; }

        public virtual AgentsWebUsers UsernameNavigation { get; set; }
    }
}
