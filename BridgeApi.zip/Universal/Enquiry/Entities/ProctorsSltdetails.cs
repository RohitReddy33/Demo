﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ProctorsSltdetails
    {
        public string State { get; set; }
        public string Licensee { get; set; }
        public string LicenseNo { get; set; }
        public string Address { get; set; }
    }
}
