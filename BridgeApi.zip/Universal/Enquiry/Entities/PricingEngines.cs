﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class PricingEngines
    {
        public int? CompanyId { get; set; }
        public string UniqueAgentReference { get; set; }
        public string TransactionType { get; set; }
        public bool? IsTestingJson { get; set; }
        public string PricingEngine { get; set; }
        public string PricingEngineVersion { get; set; }
        public string ContractRef { get; set; }
        public bool? AutoGenQte { get; set; }
    }
}
