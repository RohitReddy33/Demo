﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsContractsTransitions
    {
        public int Companyid { get; set; }
        public string BusinessArea { get; set; }
        public string ContractRef { get; set; }
        public int ContractYear { get; set; }
        public string TransitionTo { get; set; }
        public int? TransitionCompanyId { get; set; }

        public virtual AgentsContracts AgentsContracts { get; set; }
    }
}
