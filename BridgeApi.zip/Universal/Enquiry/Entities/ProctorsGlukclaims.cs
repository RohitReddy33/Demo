﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ProctorsGlukclaims
    {
        public string Claimnumber { get; set; }
        public string Insured { get; set; }
        public string Policy { get; set; }
        public DateTime? Dateofloss { get; set; }
        public string Causeofloss { get; set; }
    }
}
