﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class DataretentionAnonymization
    {
        public long Id { get; set; }
        public DateTime DateCreated { get; set; }
        public string SourceTable { get; set; }
        public string SourceColumn { get; set; }
        public long? SourceId { get; set; }
        public string OriginalValue { get; set; }
        public int? CompanyId { get; set; }
    }
}
