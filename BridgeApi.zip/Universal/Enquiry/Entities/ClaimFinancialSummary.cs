﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ClaimFinancialSummary
    {
        public int? CompanyId { get; set; }
        public string ClaimNumber { get; set; }
        public int? Qty { get; set; }
        public decimal? PaidClaimIndemnity { get; set; }
        public decimal? PaidClaimProperty { get; set; }
        public decimal? PaidClaimBi { get; set; }
        public decimal? Subrogation { get; set; }
        public decimal? Salvage { get; set; }
        public decimal? ThirdPartyAdministratorFee { get; set; }
        public decimal? PaidLaeadjuster { get; set; }
        public decimal? PaidLaelegal { get; set; }
        public decimal? PaidLaeallOther { get; set; }
        public decimal? PaidCoverageAttorneyFee { get; set; }
        public decimal? PaidDefenseAttorneyFee { get; set; }
        public decimal? PaidMedicalPayment { get; set; }
        public decimal? OutstandingClaimIndemnityReserve { get; set; }
        public decimal? OutstandingLaereserve { get; set; }
        public decimal? OutstandingTpafeeReserve { get; set; }
        public decimal? OutstandingCoverageAttorneyFeeReserve { get; set; }
        public decimal? OutstandingDefenseAttorneyFeeReserve { get; set; }
        public decimal? OutstandingOtherFeeReserve { get; set; }
    }
}
