﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class GetLatestContractShare
    {
        public int? Id { get; set; }
        public decimal? ContractShare { get; set; }
    }
}
