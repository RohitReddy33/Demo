﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class HailSizes
    {
        public string Id { get; set; }
        public string Description { get; set; }
        public decimal SizeInches { get; set; }
    }
}
