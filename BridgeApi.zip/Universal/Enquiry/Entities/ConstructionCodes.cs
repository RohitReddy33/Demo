﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ConstructionCodes
    {
        public string ConstructionCodeScheme { get; set; }
        public string ConstructionCode { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string EquivalentRmscode { get; set; }
        public string GlobalMappingField { get; set; }
        public string Glukequivalent { get; set; }
        public string Amigequivalent { get; set; }
        public string IsofireEquivalent { get; set; }
        public string MunichReEquivalent { get; set; }

        public virtual ConstructionCodeScheme ConstructionCodeSchemeNavigation { get; set; }
    }
}
