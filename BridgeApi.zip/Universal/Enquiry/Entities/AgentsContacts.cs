﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class AgentsContacts
    {
        public int CompanyId { get; set; }
        public string BusinessArea { get; set; }
        public string ContactName { get; set; }
        public string ContactType { get; set; }
        public string JobTitle { get; set; }
        public string EmailAddress { get; set; }
        public string Phone { get; set; }
        public bool? IsUsingMoveToLive { get; set; }
        public int UniqueId { get; set; }
        public bool? PublishOnCoverholderFactSheet { get; set; }
        public string UserUpdated { get; set; }
        public DateTime? DateUpdated { get; set; }
        public DateTime? DateCreated { get; set; }
        public string UserCreated { get; set; }

        public virtual Agents Company { get; set; }
        public virtual AgentsContactsTypes ContactTypeNavigation { get; set; }
    }
}
