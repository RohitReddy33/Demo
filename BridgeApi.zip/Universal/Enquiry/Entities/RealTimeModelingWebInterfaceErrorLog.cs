﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class RealTimeModelingWebInterfaceErrorLog
    {
        public long Id { get; set; }
        public DateTime DateLogged { get; set; }
        public string Message { get; set; }
        public string Source { get; set; }
        public string StackTrace { get; set; }
        public string UserName { get; set; }
    }
}
