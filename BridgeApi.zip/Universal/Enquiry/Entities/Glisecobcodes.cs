﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class Glisecobcodes
    {
        public Glisecobcodes()
        {
            AgentsContractsGlisecob = new HashSet<AgentsContractsGlisecob>();
        }

        public string Glisecobcode { get; set; }
        public string Description { get; set; }
        public string GlisetreatyMapping { get; set; }

        public virtual ICollection<AgentsContractsGlisecob> AgentsContractsGlisecob { get; set; }
    }
}
