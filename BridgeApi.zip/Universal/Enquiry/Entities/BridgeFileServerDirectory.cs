﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class BridgeFileServerDirectory
    {
        public BridgeFileServerDirectory()
        {
            BridgeFileServer = new HashSet<BridgeFileServer>();
            BridgeFileServerDirectoryPermissions = new HashSet<BridgeFileServerDirectoryPermissions>();
        }

        public long Id { get; set; }
        public string Directory { get; set; }

        public virtual ICollection<BridgeFileServer> BridgeFileServer { get; set; }
        public virtual ICollection<BridgeFileServerDirectoryPermissions> BridgeFileServerDirectoryPermissions { get; set; }
    }
}
