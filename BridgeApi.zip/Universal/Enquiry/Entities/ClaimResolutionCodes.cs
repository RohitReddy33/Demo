﻿using System;
using System.Collections.Generic;

namespace BridgeApi.Enquiry.Models.Entities
{
    public partial class ClaimResolutionCodes
    {
        public int Id { get; set; }
        public string Text { get; set; }
        public bool? ClaimPaymentAllowed { get; set; }
    }
}
