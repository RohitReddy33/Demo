﻿using System;

namespace BridgeApi.Enquiry.Models.Entities
{
    public class RiskDetails
    {
        public Address Address { get; set; }
        public long TempPremiumsId { get; set; }
        public string LocationNumber { get; set; }
        public int? AppendagesAndOrnamentation { get; set; }
        public int? BaseIsolation { get; set; }
        public decimal? BuildingLimit { get; set; }
        public decimal? BusinessInterruptionLimit { get; set; }
        public int? CladdingType { get; set; }
        public int? CompanyId { get; set; }
        public string Construction { get; set; }
        public int? ConstructionQuality { get; set; }
        public decimal? ContentsLimit { get; set; }
        public string ContractNumber { get; set; }
        public int? CrippleWalls { get; set; }
        public int? EngineeredFoundation { get; set; }
        public int? EquipmentSupportMaintenance { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public int? FrameBolted { get; set; }
        public DateTime? InceptionDate { get; set; }
        public string InsuredName { get; set; }
        public int? MechanicalAndElectricalQuipmentEqBracing { get; set; }
        public int? NumberOfStories { get; set; }
        public string Occupancy { get; set; }
        public decimal? PlacementType { get; set; }
        public int? PlanIrregularity { get; set; }
        public int? Pounding { get; set; }
        public decimal? PropertyLimit { get; set; }
        public decimal? QuakeDeductible { get; set; }
        public decimal? RoofConstruction { get; set; }
        public decimal? RoofShape { get; set; }
        public string RoofUpdated { get; set; }
        public decimal? SizeOfLayer { get; set; }
        public decimal? AttachmentPoint { get; set; }
        public int? ShortColumnCondition { get; set; }
        public int? SoftStory { get; set; }
        public int? SprinklerCoverage { get; set; }
        public int? SprinklerLeakageSusceptibility { get; set; }
        public int? SprinklerType { get; set; }
        public decimal? SquareFeet { get; set; }
        public int? StructuralUpgrade { get; set; }
        public decimal? TargetPremium { get; set; }
        public int? TiltUpRetrofit { get; set; }
        public int? UnreinforcedMasonryPartitionsorChimneys { get; set; }
        public int? UnreinforcedMasonryRetrofit { get; set; }
        public int? VerticalIrregularity { get; set; }
        public int? YearBuilt { get; set; }

        public short? QuoteType { get; set; }
        public string BasementType { get; set; }
        public decimal? OtherLimit { get; set; }
        public decimal? FirstFloorHeightAboveGround { get; set; }
        public int? FlfoundationType { get; set; }
        public bool? HasStiltsOverWater { get; set; }
        public bool? IsMobileHome { get; set; }
        public bool? IsVacant { get; set; }
        public bool? IsBuildersRisk { get; set; }
        public decimal? ModifierUnderwriterPriceAdjustment { get; set; }
        public DateTime? DateOfLastLoss { get; set; }
        public decimal? CoverageForm { get; set; }
        public decimal? TargetedRate { get; set; }

        public bool? Bankruptcy { get; set; }
        public bool? Foreclosure { get; set; }
        public int? ElevationType { get; set; }
        public bool? HasBreakawayWalls { get; set; }
        public bool? BelowFloorEnclosureHasElevator { get; set; }
        public bool? HasAttachedGarage { get; set; }
        public bool? HouseElevatedAfterPriorFloodLoss { get; set; }
    }
}
