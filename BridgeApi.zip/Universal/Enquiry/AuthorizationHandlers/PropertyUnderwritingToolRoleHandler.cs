﻿using BridgeApi.AuthorizationHandlers;
using BridgeApi.Enquiry.Requirements;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using System.Threading.Tasks;

namespace BridgeApi.Enquiry.AuthorizationHandlers
{
    public class PropertyUnderwritingToolRoleHandler : CommonAuthorizationHandler<PropertyUnderwritingToolRequirement>
    {
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, PropertyUnderwritingToolRequirement requirement)
        {
            if (base.IsWindowsAuthenticated(context))
            {
                context.Succeed(requirement);
                return Task.CompletedTask;
            }

            if (!context.User.HasClaim(x => x.Type == ClaimTypes.Role && (x.Value == "Property Underwriting Tool Beta" || x.Value == "Property Underwriting Tool V2")))
            {
                return Task.CompletedTask;
            }

            context.Succeed(requirement);
            return Task.CompletedTask;
        }
    }
}
