﻿using BridgeApi.AuthorizationHandlers;
using BridgeApi.Enquiry.Requirements;
using Microsoft.AspNetCore.Authorization;
using System.Linq;
using System.Threading.Tasks;

namespace BridgeApi.Enquiry.AuthorizationHandlers
{
    public class IdentityHandler : CommonAuthorizationHandler<IdentityRequirement>
    {
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, IdentityRequirement requirement)
        {
            if (base.IsWindowsAuthenticated(context))
            {
                context.Succeed(requirement);
                return Task.CompletedTask;
            }

            var scope = context.User.Claims.Where(x => x.Type == "scope").ToList();
            if (scope != null && scope.Any(c => c.Value == "identity"))
            {
                context.Succeed(requirement);
                return Task.CompletedTask;
            }

            return Task.CompletedTask;
        }
    }
}
