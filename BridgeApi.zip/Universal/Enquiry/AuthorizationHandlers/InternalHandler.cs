﻿using System.Threading.Tasks;
using BridgeApi.AuthorizationHandlers;
using BridgeApi.Enquiry.Requirements;
using Microsoft.AspNetCore.Authorization;

namespace BridgeApi.Enquiry.AuthorizationHandlers
{
    public class InternalHandler : CommonAuthorizationHandler<InternalRequirement>
    {
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, InternalRequirement requirement)
        {
            if (base.IsWindowsAuthenticated(context))
            {
                context.Succeed(requirement);
            }

            var result = context.User.FindFirst(x => x.Type == "client_id" && x.Value == "machine");
            if (result != null)
            {
                context.Succeed(requirement);
            }

            return Task.CompletedTask;
        }
    }
}
