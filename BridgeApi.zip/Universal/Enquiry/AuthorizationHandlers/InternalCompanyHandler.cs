﻿using BridgeApi.AuthorizationHandlers;
using BridgeApi.Enquiry.Requirements;
using Microsoft.AspNetCore.Authorization;
using Serilog;
using System.Threading.Tasks;

namespace BridgeApi.Enquiry.AuthorizationHandlers
{
    public class InternalCompanyHandler : CommonAuthorizationHandler<InternalCompanyRequirement>
    {
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, InternalCompanyRequirement requirement)
        {
            Log.Logger.Information(
                $"IsAuthenticated: {context.User.Identity.IsAuthenticated} Authentication Type: {context.User.Identity.AuthenticationType}");
            
            if (base.IsWindowsAuthenticated(context))
            {
                context.Succeed(requirement);
                return Task.CompletedTask;
            }

            const string companyIdClaimKey = "companyId";
            if (!context.User.HasClaim(x => x.Type == companyIdClaimKey)) return Task.CompletedTask;

            var companyId = context.User.FindFirst(x => x.Type == companyIdClaimKey).Value;
            if (companyId != requirement.CompanyId) return Task.CompletedTask;
            
            context.Succeed(requirement);
            return Task.CompletedTask;
        }
    }
}
