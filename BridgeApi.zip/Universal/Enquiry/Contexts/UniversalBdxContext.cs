﻿using BridgeApi.Enquiry.Entities;
using BridgeApi.Enquiry.Models.Entities;
using Microsoft.EntityFrameworkCore;

namespace BridgeApi.Enquiry.Contexts
{
    public partial class UniversalBdxContext : DbContext
    {
        public UniversalBdxContext()
        {
        }

        public UniversalBdxContext(DbContextOptions<UniversalBdxContext> options)
            : base(options)
        {
        }

        public virtual DbSet<CancellationCodes> CancellationCodes { get; set; }
        public virtual DbSet<ClaimsTransactions> ClaimsTransactions { get; set; }
        public virtual DbSet<TempClaimsTransactions> TempClaimsTransactions { get; set; }
        public virtual DbSet<TempPolicyTransactionsPremiumOffers> TempPolicyTransactionsPremiumOffers { get; set; }
        public virtual DbSet<Agents> Agents { get; set; }
        public virtual DbSet<AgentsContracts> AgentsContracts { get; set; }
        public virtual DbSet<AgentsWebLoginAttempts> AgentsWebLoginAttempts { get; set; }
        public virtual DbSet<AgentsWebRoles> AgentsWebRoles { get; set; }
        public virtual DbSet<AgentsWebUsers> AgentsWebUsers { get; set; }
        public virtual DbSet<AgentsWebUsersAllowedContracts> AgentsWebUsersAllowedContracts { get; set; }
        public virtual DbSet<AgentsWebUsersEmailerFileTypes> AgentsWebUsersEmailerFileTypes { get; set; }
        public virtual DbSet<AgentsWebUsersProfiles> AgentsWebUsersProfiles { get; set; }
        public virtual DbSet<AgentsWebUsersReportsPermissions> AgentsWebUsersReportsPermissions { get; set; }
        public virtual DbSet<AgentsWebUsersRoleMembership> AgentsWebUsersRoleMembership { get; set; }
        public virtual DbSet<ArchiveTempPolicyTransactions> ArchiveTempPolicyTransactions { get; set; }
        public virtual DbSet<ArchiveTempPolicyTransactionsContracts> ArchiveTempPolicyTransactionsContracts { get; set; }
        public virtual DbSet<ArchiveTempPolicyTransactionsLocations> ArchiveTempPolicyTransactionsLocations { get; set; }
        public virtual DbSet<Bdxlog> Bdxlog { get; set; }
        public virtual DbSet<BordMonthYear> BordMonthYear { get; set; }
        public virtual DbSet<BridgeFileServer> BridgeFileServer { get; set; }
        public virtual DbSet<BridgeFileServerDirectory> BridgeFileServerDirectory { get; set; }
        public virtual DbSet<BridgeFileServerDirectoryPermissions> BridgeFileServerDirectoryPermissions { get; set; }
        public virtual DbSet<ConstructionCodeScheme> ConstructionCodeScheme { get; set; }
        public virtual DbSet<ConstructionCodes> ConstructionCodes { get; set; }
        public virtual DbSet<LogImportedFiles> LogImportedFiles { get; set; }
        public virtual DbSet<LogImportedFilesWs> LogImportedFilesWs { get; set; }
        public virtual DbSet<Occupancy> Occupancy { get; set; }
        public virtual DbSet<OccupancyScheme> OccupancyScheme { get; set; }
        public virtual DbSet<PolicyTransactions> PolicyTransactions { get; set; }
        public virtual DbSet<PolicyTransactionsContracts> PolicyTransactionsContracts { get; set; }
        public virtual DbSet<PolicyTransactionsLocations> PolicyTransactionsLocations { get; set; }
        public virtual DbSet<PolicyTransactionsLocationsBuildings> PolicyTransactionsLocationsBuildings { get; set; }
        public virtual DbSet<PolicyTransactionsLocationsIsoglclassProfessionalLiabilityLawyers> PolicyTransactionsLocationsIsoglclassProfessionalLiabilityLawyers { get; set; }
        public virtual DbSet<PolicyTransactionsLocationsTaxesFeesSurcharges> PolicyTransactionsLocationsTaxesFeesSurcharges { get; set; }
        public virtual DbSet<ReportCategories> ReportCategories { get; set; }
        public virtual DbSet<Reports> Reports { get; set; }
        public virtual DbSet<TempPolicyTransactions> TempPolicyTransactions { get; set; }
        public virtual DbSet<TempPolicyTransactionsContracts> TempPolicyTransactionsContracts { get; set; }
        public virtual DbSet<TempPolicyTransactionsLocations> TempPolicyTransactionsLocations { get; set; }
        public virtual DbSet<ScenarioZips> ScenarioZips { get; set; }
        public virtual DbSet<ApimIsyClTransactions> ApimIsyClTransactions { get; set; }
        public virtual DbSet<ApimIsyClTransactionsBatch> ApimIsyClTransactionsBatch { get; set; }
        public virtual DbSet<PolicyTransactionsApimIsyCl> PolicyTransactionsApimIsyCl { get; set; }
        public virtual DbSet<VwPolicyTransactionsLocationsIsoglclassProfessionalLiabilityLawyersIsyClRollup> VwPolicyTransactionsLocationsIsoglclassProfessionalLiabilityLawyersIsyClRollup { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PolicyTransactionsApimIsyCl>(entity =>
            {
                entity.ToTable("PolicyTransactions_APIM_ISyCL");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.CancelMethod).HasMaxLength(255);

                entity.Property(e => e.DateCreated)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.TransId).HasColumnName("TransID");

                entity.Property(e => e.TransactionReasonCode).HasMaxLength(255);

                entity.HasOne(d => d.Trans)
                    .WithMany(p => p.PolicyTransactionsApimIsyCl)
                    .HasForeignKey(d => d.TransId)
                    .HasConstraintName("FK__PolicyTra__Trans__2582CF58");
            });

            modelBuilder.Entity<ApimIsyClTransactions>(entity =>
            {
                entity.ToTable("APIM_ISyCL_Transactions");

                entity.Property(e => e.ApimIsyClTransactionsId).HasColumnName("APIM_ISyCL_Transactions_ID");

                entity.Property(e => e.ApimIsyClTransactionsBatchId)
                    .IsRequired()
                    .HasColumnName("APIM_ISyCL_Transactions_Batch_ID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DateCreated)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DateLastResponsePolled).HasColumnType("datetime");

                entity.Property(e => e.InitialStatusCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.LastStatusCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.PolicyNumber)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.RecordUniqueIdentifier)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TempPremiumsId).HasColumnName("TempPremiumsID");

                entity.HasOne(d => d.ApimIsyClTransactionsBatch)
                    .WithMany(p => p.ApimIsyClTransactions)
                    .HasForeignKey(d => d.ApimIsyClTransactionsBatchId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__APIM_ISyC__APIM___6182AAC6");
            });

            modelBuilder.Entity<ApimIsyClTransactionsBatch>(entity =>
            {
                entity.ToTable("APIM_ISyCL_Transactions_Batch");

                entity.Property(e => e.ApimIsyClTransactionsBatchId)
                    .HasColumnName("APIM_ISyCL_Transactions_Batch_ID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BatchJsoncontents).HasColumnName("BatchJSONContents");

                entity.Property(e => e.DateCreated)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DateSubmitted).HasColumnType("datetime");

                entity.Property(e => e.Jsoncontents)
                    .IsRequired()
                    .HasColumnName("JSONContents");
            });

            modelBuilder.Entity<CancellationCodes>(entity =>
            {
                entity.HasKey(e => e.CancellationCode);

                entity.Property(e => e.CancellationDescription)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.RatingBasis)
                    .HasMaxLength(25)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ClaimsTransactions>(entity =>
            {
                entity.HasKey(e => e.ClaimsTransId);

                entity.HasIndex(e => e.CompanyId)
                    .HasDatabaseName("ix_CompanyId");

                entity.HasIndex(e => e.TempClaimsId)
                    .HasDatabaseName("ix_ClaimsTransactions_TempClaimsID");

                entity.HasIndex(e => new { e.BordMonth, e.BordYear })
                    .HasDatabaseName("ix_BordPeriod");

                entity.HasIndex(e => new { e.TempClaimsId, e.CompanyId })
                    .HasDatabaseName("IX_CompanyID_Includes");

                entity.HasIndex(e => new { e.TransactionType, e.MigrationBusinessArea })
                    .HasDatabaseName("ixClaimsTransaction_TransactionType_MigrationBusinessArea");

                entity.HasIndex(e => new { e.BordMonth, e.BordYear, e.CompanyId, e.ClaimsTransId })
                    .HasDatabaseName("ix_ClaimsTransactions_BordMonth_BordYear_CompanyID_ClaimsTransID");

                entity.HasIndex(e => new { e.CompanyId, e.PolicyNo, e.ClaimantName, e.ClaimNumber, e.ClaimsTransId })
                    .HasDatabaseName("ix_ClaimsTransactions_CompanyID_PolicyNo_ClaimantName_ClaimNumber_ClaimsTransID");

                entity.HasIndex(e => new { e.BordMonth, e.BordYear, e.OrderId, e.CompanyId, e.ClaimNumber, e.PolicyNo })
                    .HasDatabaseName("ix_ClaimsTransactions_BordMonth_BordYear_OrderID_CompanyID_ClaimNumber_PolicyNo");

                entity.HasIndex(e => new { e.BordMonth, e.BordYear, e.ClaimStatus, e.OrderId, e.ClaimNumber, e.PolicyNo, e.ClaimsTransId, e.CompanyId })
                    .HasDatabaseName("ix_ClaimsTransactions_BordMonth_BordYear_ClaimStatus_OrderID_ClaimNumber_PolicyNo_ClaimsTransID_CompanyID");

                entity.HasIndex(e => new { e.ClaimsTransId, e.Adjuster, e.Attorney, e.LossAdjusterClaimFileNo, e.AttorneyClaimFileNo, e.PublicAttorneyFirm, e.PublicAdjusterCompany, e.PublicAdjusterClaimFileNo, e.PublicAttorneyClaimFileNo, e.CompanyId, e.ClaimNumber })
                    .HasDatabaseName("ix_ClaimsTransactions_CompanyID_ClaimNumber_includes");

                entity.HasIndex(e => new { e.ContractPeriod, e.DateOfLoss, e.CauseOfLoss, e.ClaimStatus, e.CompanyId, e.BordYear, e.BordMonth, e.ClaimNumber, e.PolicyNo, e.InsuredName, e.ClaimsTransId })
                    .HasDatabaseName("ix_ClaimsTransactions_CompanyID_BordYear_ClaimNumber_PolicyNo_InsuredName_ClaimsTransID_Includes");

                entity.HasIndex(e => new { e.PaidLaeadjuster, e.PaidLaelegal, e.PaidLaeallOther, e.PaidClaimIndemnity, e.PaidClaimProperty, e.PaidClaimBi, e.Subrogation, e.Salvage, e.ThirdPartyAdministratorFee, e.BordMonth, e.BordYear, e.CompanyId, e.ClaimNumber, e.PolicyNo, e.ClaimsTransId })
                    .HasDatabaseName("ix_ClaimsTransactions_BordMonth_BordYear_CompanyID_ClaimNumber_PolicyNo_ClaimsTransID_Includes");

                entity.HasIndex(e => new { e.PaidClaimIndemnity, e.PaidClaimProperty, e.PaidClaimBi, e.Subrogation, e.Salvage, e.ThirdPartyAdministratorFee, e.PaidLaeadjuster, e.PaidLaelegal, e.PaidLaeallOther, e.PaidMedicalPayment, e.PaidCoverageAttorneyFee, e.PaidDefenseAttorneyFee, e.BordMonth, e.BordYear, e.CompanyId, e.ClaimsTransId, e.ClaimNumber, e.PolicyNo })
                    .HasDatabaseName("ix_ClaimsTransactions_BordMonth_BordYear_CompanyID_ClaimsTransID_ClaimNumber_PolicyNo_Includes");

                entity.HasIndex(e => new { e.PolicyEffectiveDate, e.PolicyExpirationDate, e.DateOfLoss, e.CauseOfLoss, e.OutstandingClaimIndemnityReserve, e.OutstandingLaereserve, e.ClaimNumber, e.PolicyNo, e.CompanyId, e.ClaimsTransId, e.OrderId, e.ClaimStatus, e.InsuredName, e.LossState, e.Catnumber, e.LossCounty, e.BordMonth, e.BordYear })
                    .HasDatabaseName("ix_ClaimsTransactions_ClaimNumber_PolicyNo_CompanyID_ClaimsTransID_OrderID_ClaimStatus_InsuredName_LossState_CATNumber_LossCount");

                entity.HasIndex(e => new { e.OutstandingLaereserve, e.ClaimStatus, e.Salvage, e.ThirdPartyAdministratorFee, e.PaidLaeadjuster, e.PaidLaelegal, e.PaidLaeallOther, e.OutstandingClaimIndemnityReserve, e.BordMonth, e.BordYear, e.PaidClaimIndemnity, e.PaidClaimProperty, e.PaidClaimBi, e.Subrogation, e.ClaimNumber, e.PolicyNo, e.ClaimsTransId, e.OrderId, e.ContractPeriod, e.CauseOfLoss })
                    .HasDatabaseName("ix_ClaimsTransactions_ClaimNumber_PolicyNo_ClaimsTransID_OrderID_ContractPeriod_CauseOfLoss_Includes");

                entity.HasIndex(e => new { e.OutstandingLaereserve, e.ClaimStatus, e.Salvage, e.ThirdPartyAdministratorFee, e.PaidLaeadjuster, e.PaidLaelegal, e.PaidLaeallOther, e.OutstandingClaimIndemnityReserve, e.BordMonth, e.BordYear, e.PaidClaimIndemnity, e.PaidClaimProperty, e.PaidClaimBi, e.Subrogation, e.OrderId, e.ClaimsTransId, e.ContractPeriod, e.CauseOfLoss, e.PolicyNo, e.ClaimNumber })
                    .HasDatabaseName("ix_ClaimsTransactions_OrderID_ClaimsTransID_ContractPeriod_CauseOfLoss_PolicyNo_ClaimNumber_Includes");

                entity.HasIndex(e => new { e.OutstandingLaereserve, e.ClaimStatus, e.Salvage, e.ThirdPartyAdministratorFee, e.PaidLaeadjuster, e.PaidLaelegal, e.PaidLaeallOther, e.OutstandingClaimIndemnityReserve, e.BordMonth, e.BordYear, e.PaidClaimIndemnity, e.PaidClaimProperty, e.PaidClaimBi, e.Subrogation, e.PolicyNo, e.ClaimNumber, e.OrderId, e.ClaimsTransId, e.ContractPeriod, e.CauseOfLoss })
                    .HasDatabaseName("ix_ClaimsTransactions_PolicyNo_ClaimNumber_OrderID_ClaimsTransID_ContractPeriod_CauseOfLoss_Includes");

                entity.HasIndex(e => new { e.SubCompanyId, e.BordMonth, e.BordYear, e.ClaimNumber, e.PaidLaeallOther, e.OutstandingClaimIndemnityReserve, e.OutstandingLaereserve, e.PaidClaimBi, e.Subrogation, e.Salvage, e.ThirdPartyAdministratorFee, e.PaidLaeadjuster, e.PaidLaelegal, e.InsuredName, e.PolicyNo, e.DateOfLoss, e.CauseOfLoss, e.PaidClaimIndemnity, e.PaidClaimProperty, e.CompanyId, e.ClaimsTransId })
                    .HasDatabaseName("ix_ClaimsTransactions_CompanyID_ClaimsTransID_Includes");

                entity.Property(e => e.ClaimsTransId).HasColumnName("ClaimsTransID");

                entity.Property(e => e.Adjuster)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Attorney)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.AttorneyClaimFileNo)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AttorneyEmail)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Catnumber)
                    .HasColumnName("CATNumber")
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.CauseOfLoss)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CertificateNumber)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimNumber)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimProcessorSystemName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimStatus)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.ClaimantName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.CoInsurancePenalty).HasColumnType("money");

                entity.Property(e => e.CompanyId).HasColumnName("CompanyID");

                entity.Property(e => e.CompanyNumber)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.DateClaimAcknowledged).HasColumnType("datetime");

                entity.Property(e => e.DateClaimClosed).HasColumnType("datetime");

                entity.Property(e => e.DateClaimMade).HasColumnType("datetime");

                entity.Property(e => e.DateCreated).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.DateOfLoss).HasColumnType("datetime");

                entity.Property(e => e.Deductible).HasColumnType("money");

                entity.Property(e => e.Demand).HasColumnType("money");

                entity.Property(e => e.Denial)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.DiaryDate).HasColumnType("datetime");

                entity.Property(e => e.Doicomplaint).HasColumnName("DOIComplaint");

                entity.Property(e => e.GlobalClaimId).HasColumnName("GlobalClaimID");

                entity.Property(e => e.GlobalMovementId).HasColumnName("GlobalMovementID");

                entity.Property(e => e.GlobalSystemClaimNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.GlukoldClaimNumber)
                    .HasColumnName("GLUKOldClaimNumber")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.HailSize)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.IsocurrencyCode)
                    .HasColumnName("ISOCurrencyCode")
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.LitigationType)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.LossAdjusterClaimFileNo)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LossAdjusterEmail)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LossCounty)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LossInformation).IsUnicode(false);

                entity.Property(e => e.LossState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.MedicareIncurredAmount).HasColumnType("money");

                entity.Property(e => e.MedicareOutcomeofStatusCheck)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.MedicareStatusCheckIndicator)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.MigrationBusinessArea)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MigrationContractRef)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.MigrationOldSystemId).HasColumnName("MigrationOldSystemID");

                entity.Property(e => e.MigrationSectionNumber)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.Notes).IsUnicode(false);

                entity.Property(e => e.OrderId).HasColumnName("OrderID");

                entity.Property(e => e.OriginalClaimsTransId).HasColumnName("OriginalClaimsTransID");

                entity.Property(e => e.OutstandingClaimIndemnityReserve).HasColumnType("money");

                entity.Property(e => e.OutstandingCoverageAttorneyFeeReserve).HasColumnType("money");

                entity.Property(e => e.OutstandingDefenseAttorneyFeeReserve).HasColumnType("money");

                entity.Property(e => e.OutstandingLaereserve)
                    .HasColumnName("OutstandingLAEReserve")
                    .HasColumnType("money");

                entity.Property(e => e.OutstandingMedicalPaymentReserve).HasColumnType("money");

                entity.Property(e => e.OutstandingOtherFeeReserve).HasColumnType("money");

                entity.Property(e => e.OutstandingTpafeeReserve)
                    .HasColumnName("OutstandingTPAFeeReserve")
                    .HasColumnType("money");

                entity.Property(e => e.PaidClaimBi)
                    .HasColumnName("PaidClaimBI")
                    .HasColumnType("money");

                entity.Property(e => e.PaidClaimIndemnity).HasColumnType("money");

                entity.Property(e => e.PaidClaimProperty).HasColumnType("money");

                entity.Property(e => e.PaidCoverageAttorneyFee).HasColumnType("money");

                entity.Property(e => e.PaidDefenseAttorneyFee).HasColumnType("money");

                entity.Property(e => e.PaidLaeadjuster)
                    .HasColumnName("PaidLAEAdjuster")
                    .HasColumnType("money");

                entity.Property(e => e.PaidLaeallOther)
                    .HasColumnName("PaidLAEAllOther")
                    .HasColumnType("money");

                entity.Property(e => e.PaidLaelegal)
                    .HasColumnName("PaidLAELegal")
                    .HasColumnType("money");

                entity.Property(e => e.PaidMedicalPayment).HasColumnType("money");

                entity.Property(e => e.PaidOffBdx)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.PeerReviewDate).HasColumnType("date");

                entity.Property(e => e.PolicyEffectiveDate).HasColumnType("datetime");

                entity.Property(e => e.PolicyExpirationDate).HasColumnType("datetime");

                entity.Property(e => e.PolicyNo)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PublicAdjusterClaimFileNo)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PublicAdjusterCompany)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PublicAdjusterIndividualName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PublicAttorneyClaimFileNo)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PublicAttorneyFirm)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PublicAttorneyIndividualName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RefertoUnderwriter)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Salvage).HasColumnType("money");

                entity.Property(e => e.Sltstate)
                    .HasColumnName("SLTState")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.SubBrokerName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubCompanyId).HasColumnName("SubCompanyID");

                entity.Property(e => e.Subrogation).HasColumnType("money");

                entity.Property(e => e.TempClaimsId).HasColumnName("TempClaimsID");

                entity.Property(e => e.ThirdPartyAdministratorFee).HasColumnType("money");

                entity.Property(e => e.Tpacompany)
                    .HasColumnName("TPACompany")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TpacompanyId).HasColumnName("TPACompanyID");

                entity.Property(e => e.TpafileHandlerEmail)
                    .HasColumnName("TPAFileHandlerEmail")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TpauniqueAgentReference)
                    .HasColumnName("TPAUniqueAgentReference")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.TransactionType)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.TypeofReserve)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.UserCreated)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserModified)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Xlsoffice)
                    .HasColumnName("XLSOffice")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<TempClaimsTransactions>(entity =>
            {
                entity.HasKey(e => e.TempClaimsId);

                entity.HasIndex(e => new { e.BordMonth, e.BordYear })
                    .HasDatabaseName("ix_TempClaimsTransactions_BordPeriod");

                entity.HasIndex(e => new { e.CompanyId, e.Xlsoffice })
                    .HasDatabaseName("ixTempClaimsTransactions_CompanyID_XLSOffice");

                entity.HasIndex(e => new { e.ImportFilename, e.UniqueAgentReference, e.DuplicateFileSeq })
                    .HasDatabaseName("IX_TempClaimsTransactions_ImportFileName_UniqueAgentReference_DuplicateFileSeq");

                entity.HasIndex(e => new { e.OverrideError, e.CorrectedBy, e.IgnoreRecord, e.DuplicateFileSeq, e.ImportFilename, e.UniqueAgentReference, e.RecordError, e.PolicyProcessorSystemName })
                    .HasDatabaseName("ix_TempClaimsTransactions_DuplicateFileSeq_ImportFilename_UniqueAgentReference_RecordError_PolicyProcessorSystemName_Includes");

                entity.HasIndex(e => new { e.OverrideError, e.CompanyId, e.CorrectedBy, e.ClaimNumber, e.TempClaimsId, e.PolicyNo, e.DateOfLoss, e.AccountingEffectiveDate, e.BordYear, e.BordMonth })
                    .HasDatabaseName("ix_TempClaimsTransactions_CompanyID_CorrectedBy_ClaimNumber_TempClaimsID_PolicyNo_DateOfLoss_AccountingEffectiveDate_BordYear_Bo");

                entity.HasIndex(e => new { e.ClaimNumber, e.PolicyNo, e.DateOfLoss, e.OverrideError, e.CorrectedBy, e.IgnoreRecord, e.FormSetId, e.DateErrorChecksFirstRun, e.RecordError, e.DuplicateFileSeq, e.ImportFilename, e.UniqueAgentReference, e.PolicyProcessorSystemName, e.TempClaimsId })
                    .HasDatabaseName("ix_TempClaimsTransactions_RecordError_DuplicateFileSeq_ImportFilename_UniqueAgentReference_PolicyProcessorSystemName_TempClaimsI");

                entity.HasIndex(e => new { e.TempClaimsId, e.ClaimNumber, e.PolicyNo, e.DateOfLoss, e.Corrects, e.FormSetId, e.PolicyProcessorSystemName, e.DateErrorChecksFirstRun, e.CorrectedBy, e.TpacompanyId, e.IgnoreRecord, e.UniqueAgentReference, e.ImportFilename, e.DuplicateFileSeq })
                    .HasDatabaseName("ix_TempClaimsTransactions_TempClaimsID_ClaimNumber_PolicyNo_DateOfLoss_Corrects_FormSetID_PolicyProcessorSystemName_DateErrorChe");

                entity.HasIndex(e => new { e.TransactionType, e.CompanyNumber, e.ClaimNumber, e.ClaimantName, e.InsuredName, e.CertificateNumber, e.PolicyNo, e.PolicyEffectiveDate, e.PolicyExpirationDate, e.DateOfLoss, e.CauseOfLoss, e.Catnumber, e.Sltstate, e.LossState, e.LossCounty, e.PaidClaimIndemnity, e.PaidClaimProperty, e.PaidClaimBi, e.Subrogation, e.Salvage, e.ThirdPartyAdministratorFee, e.PaidLaeadjuster, e.PaidLaelegal, e.PaidLaeallOther, e.OutstandingClaimIndemnityReserve, e.OutstandingLaereserve, e.PaidOffBdx, e.Litigation, e.SubBrokerName, e.Adjuster, e.Attorney, e.IgnoreRecord, e.FormSetId, e.AccountingEffectiveDate, e.DateErrorChecksFirstRun, e.DateClaimMade, e.Denial, e.RefertoUnderwriter, e.MedicareStatusCheckIndicator, e.MedicareOutcomeofStatusCheck, e.MedicareIncurredAmount, e.DateClaimClosed, e.LossLocationNo, e.CoInsurancePenalty, e.Doicomplaint, e.Deductible, e.PartialDenial, e.BelowDeductible, e.LitigationType, e.Demand, e.LossInformation, e.LossAdjusterClaimFileNo, e.LossAdjusterEmail, e.Tpacompany, e.TpafileHandlerEmail, e.AttorneyClaimFileNo, e.AttorneyEmail, e.PublicAdjusterCompany, e.PublicAdjusterClaimFileNo, e.PublicAdjusterIndividualName, e.PublicAttorneyIndividualName, e.PublicAttorneyFirm, e.PublicAttorneyClaimFileNo, e.PaidMedicalPayment, e.TypeofReserve, e.OutstandingTpafeeReserve, e.OutstandingCoverageAttorneyFeeReserve, e.OutstandingDefenseAttorneyFeeReserve, e.OutstandingOtherFeeReserve, e.ClaimProcessorSystemName, e.ClaimProcessorSystemNameEmail, e.PaidCoverageAttorneyFee, e.PaidDefenseAttorneyFee, e.TpauniqueAgentReference, e.DuplicateFileSeq, e.ImportFilename, e.UniqueAgentReference, e.TempClaimsId, e.Corrects })
                    .HasDatabaseName("ix_TempClaimsTransactions_DuplicateFileSeq_ImportFileName_UniqueAgentReference_TempClaimsID_Corrects");

                entity.Property(e => e.TempClaimsId).HasColumnName("TempClaimsID");

                entity.Property(e => e.AccountingEffectiveDate).HasColumnType("datetime");

                entity.Property(e => e.Adjuster)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Attorney)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.AttorneyClaimFileNo)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AttorneyEmail)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BccustomErrorMessage)
                    .HasColumnName("BCCustomErrorMessage")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.BordereauType)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Catnumber)
                    .HasColumnName("CATNumber")
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.CauseOfLoss)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.CdmatchPercentage).HasColumnName("CDMatchPercentage");

                entity.Property(e => e.CertificateNumber)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimNumber)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimProcessorSystemName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimProcessorSystemNameEmail)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClaimStatus)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.ClaimantName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.CoInsurancePenalty).HasColumnType("money");

                entity.Property(e => e.CompanyId).HasColumnName("CompanyID");

                entity.Property(e => e.CompanyNumber)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.ContractRef)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.ContractShare).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.DateClaimAcknowledged).HasColumnType("datetime");

                entity.Property(e => e.DateClaimClosed).HasColumnType("datetime");

                entity.Property(e => e.DateClaimMade).HasColumnType("datetime");

                entity.Property(e => e.DateCreated)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DateErrorChecksFirstRun).HasColumnType("datetime");

                entity.Property(e => e.DateErrorChecksLastRunEnd).HasColumnType("datetime");

                entity.Property(e => e.DateErrorChecksLastRunStart).HasColumnType("datetime");

                entity.Property(e => e.DateImported)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.DateOfLoss).HasColumnType("datetime");

                entity.Property(e => e.DateUpdated).HasColumnType("datetime");

                entity.Property(e => e.Deductible).HasColumnType("money");

                entity.Property(e => e.Demand).HasColumnType("money");

                entity.Property(e => e.Denial)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.DiaryDate).HasColumnType("datetime");

                entity.Property(e => e.DocucorpAllOtherPayment).HasColumnType("money");

                entity.Property(e => e.DocucorpDateUpdated).HasColumnType("datetime");

                entity.Property(e => e.DocucorpImdemnityReserve).HasColumnType("money");

                entity.Property(e => e.DocucorpIndemnityPayment).HasColumnType("money");

                entity.Property(e => e.DocucorpLaeadjusterPayment)
                    .HasColumnName("DocucorpLAEAdjusterPayment")
                    .HasColumnType("money");

                entity.Property(e => e.DocucorpLaelegalPayment)
                    .HasColumnName("DocucorpLAELegalPayment")
                    .HasColumnType("money");

                entity.Property(e => e.DocucorpLaereserve)
                    .HasColumnName("DocucorpLAEReserve")
                    .HasColumnType("money");

                entity.Property(e => e.DocucorpLossZip)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpLossZipPlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.Doicomplaint).HasColumnName("DOIComplaint");

                entity.Property(e => e.FormSetId)
                    .HasColumnName("FormSetID")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.GlobalClaimId).HasColumnName("GlobalClaimID");

                entity.Property(e => e.GlobalMovementId).HasColumnName("GlobalMovementID");

                entity.Property(e => e.GlobalSystemClaimNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.GlukoldClaimNumber)
                    .HasColumnName("GLUKOldClaimNumber")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.HailSize)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.HoldError).HasDefaultValueSql("((0))");

                entity.Property(e => e.ImportFilename)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.IncludedForms).HasColumnType("text");

                entity.Property(e => e.InsuredName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.IsTestData).HasDefaultValueSql("((0))");

                entity.Property(e => e.IsocurrencyCode)
                    .HasColumnName("ISOCurrencyCode")
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.LitigationType)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.LossAdjusterClaimFileNo)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LossAdjusterEmail)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LossCounty)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LossInformation).HasColumnType("varchar(max)");

                entity.Property(e => e.LossState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.MedicareIncurredAmount).HasColumnType("money");

                entity.Property(e => e.MedicareOutcomeofStatusCheck)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.MedicareStatusCheckIndicator)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.MigrationBusinessArea)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MigrationContractRef)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.MigrationOldSystemId).HasColumnName("MigrationOldSystemID");

                entity.Property(e => e.MigrationSectionNumber)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.Notes).HasColumnType("text");

                entity.Property(e => e.OrderId).HasColumnName("OrderID");

                entity.Property(e => e.OutstandingClaimIndemnityReserve).HasColumnType("money");

                entity.Property(e => e.OutstandingCoverageAttorneyFeeReserve).HasColumnType("money");

                entity.Property(e => e.OutstandingDefenseAttorneyFeeReserve).HasColumnType("money");

                entity.Property(e => e.OutstandingLaereserve)
                    .HasColumnName("OutstandingLAEReserve")
                    .HasColumnType("money");

                entity.Property(e => e.OutstandingMedicalPaymentReserve).HasColumnType("money");

                entity.Property(e => e.OutstandingOtherFeeReserve).HasColumnType("money");

                entity.Property(e => e.OutstandingTpafeeReserve)
                    .HasColumnName("OutstandingTPAFeeReserve")
                    .HasColumnType("money");

                entity.Property(e => e.OverrideError).HasDefaultValueSql("((0))");

                entity.Property(e => e.PaidClaimBi)
                    .HasColumnName("PaidClaimBI")
                    .HasColumnType("money");

                entity.Property(e => e.PaidClaimIndemnity).HasColumnType("money");

                entity.Property(e => e.PaidClaimProperty).HasColumnType("money");

                entity.Property(e => e.PaidCoverageAttorneyFee).HasColumnType("money");

                entity.Property(e => e.PaidDefenseAttorneyFee).HasColumnType("money");

                entity.Property(e => e.PaidLaeadjuster)
                    .HasColumnName("PaidLAEAdjuster")
                    .HasColumnType("money");

                entity.Property(e => e.PaidLaeallOther)
                    .HasColumnName("PaidLAEAllOther")
                    .HasColumnType("money");

                entity.Property(e => e.PaidLaelegal)
                    .HasColumnName("PaidLAELegal")
                    .HasColumnType("money");

                entity.Property(e => e.PaidMedicalPayment).HasColumnType("money");

                entity.Property(e => e.PeerReviewDate).HasColumnType("date");

                entity.Property(e => e.PolicyEffectiveDate).HasColumnType("datetime");

                entity.Property(e => e.PolicyExpirationDate).HasColumnType("datetime");

                entity.Property(e => e.PolicyNo)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PolicyProcessorSystemName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PublicAdjusterClaimFileNo)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PublicAdjusterCompany)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PublicAdjusterIndividualName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PublicAttorneyClaimFileNo)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PublicAttorneyFirm)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PublicAttorneyIndividualName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RecordError).HasDefaultValueSql("((0))");

                entity.Property(e => e.RefertoUnderwriter)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Salvage).HasColumnType("money");

                entity.Property(e => e.SectionNumber)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.Sltstate)
                    .HasColumnName("SLTState")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.SubBrokerName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubCompanyId).HasColumnName("SubCompanyID");

                entity.Property(e => e.Subrogation).HasColumnType("money");

                entity.Property(e => e.ThirdPartyAdministratorFee).HasColumnType("money");

                entity.Property(e => e.Tpacompany)
                    .HasColumnName("TPACompany")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TpacompanyId).HasColumnName("TPACompanyID");

                entity.Property(e => e.TpafileHandlerEmail)
                    .HasColumnName("TPAFileHandlerEmail")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.TpauniqueAgentReference)
                    .HasColumnName("TPAUniqueAgentReference")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.TransactionType)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('CLM')");

                entity.Property(e => e.TypeofReserve)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.UniqueAgentReference)
                    .IsRequired()
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.UserCreated)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserModified)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserUpdated)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Xlsoffice)
                    .HasColumnName("XLSOffice")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();
            });
            modelBuilder.Entity<ScenarioZips>(entity =>
            {
                entity.HasKey(e => new { e.Scenario, e.Zip });

                entity.HasIndex(e => new { e.Scenario, e.Tier, e.Zip })
                    .HasDatabaseName("ix_ScenarioZips_Zip_Includes");

                entity.Property(e => e.Zip)
                    .HasMaxLength(5)
                    .IsFixedLength();

                entity.Property(e => e.State)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.ZipPlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TempPolicyTransactionsPremiumOffers>(entity =>
            {
                entity.HasKey(e => e.TempPremiumOfferId)
                    .HasName("PK_TempPolicyTransactions_PricingOptions");

                entity.ToTable("TempPolicyTransactions_PremiumOffers");

                entity.HasIndex(e => e.TempPremiumsId);

                entity.HasIndex(e => new { e.EngineId, e.TempPremiumsId });

                entity.HasIndex(e => new { e.EngineQuoteEnquiryId, e.TempPremiumsId })
                    .HasDatabaseName("ix_TempPolicyTransactions_PremiumOffers_EngineQuoteEnquiryID_TempPremiumsID");

                entity.HasIndex(e => new { e.TempPremiumsId, e.TempPremiumOfferId, e.EngineQuoteEnquiryId })
                    .HasDatabaseName("ix_TempPolicyTransactions_PremiumOffers_TempPremiumsID_TempPremiumOfferID_EngineQuoteEnquiryID");

                entity.HasIndex(e => new { e.PricingEngine, e.EngineVersion, e.PremiumOffer, e.EngineId, e.Currency, e.FormattedClientErrorResponse, e.FullResponseXml, e.Completed, e.Error, e.TempPremiumsId, e.TempPremiumOfferId })
                    .HasDatabaseName("ix_TempPolicyTransactions_PremiumOffers_Completed_Error_TempPremiumsID_TempPremiumOfferID_Includes");

                entity.HasIndex(e => new { e.PricingEngine, e.EngineVersion, e.PremiumOffer, e.EngineId, e.Currency, e.FormattedClientErrorResponse, e.FullResponseXml, e.TempPremiumsId, e.TempPremiumOfferId, e.Completed, e.Error })
                    .HasDatabaseName("ix_TempPolicyTransactions_PremiumOffers_TempPremiumsID_TempPremiumOfferID_Completed_Error_Includes");

                entity.Property(e => e.TempPremiumOfferId).HasColumnName("TempPremiumOfferID");

                entity.Property(e => e.AopdeductibleOption)
                    .HasColumnName("AOPDeductibleOption")
                    .HasColumnType("money");

                entity.Property(e => e.AuthTokenBeginRequest).HasColumnType("datetime");

                entity.Property(e => e.AuthTokenEndRequest).HasColumnType("datetime");

                entity.Property(e => e.AuthTokenLatencyMillisecond).HasComputedColumnSql("(datediff(millisecond,[AuthTokenBeginRequest],[AuthTokenEndRequest]))");

                entity.Property(e => e.AutoGenQte).HasColumnName("AutoGenQTE");

                entity.Property(e => e.AutoGenQterui)
                    .HasColumnName("AutoGenQTERUI")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Completed).HasColumnType("datetime");

                entity.Property(e => e.Created)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Currency)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.EngineId)
                    .HasColumnName("EngineID")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.EngineQuoteEnquiryId)
                    .HasColumnName("EngineQuoteEnquiryID")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.EngineUrlBeginGetRequestStream).HasColumnType("datetime");

                entity.Property(e => e.EngineUrlBeginGetResponse).HasColumnType("datetime");

                entity.Property(e => e.EngineUrlBeginGetResponseStream).HasColumnType("datetime");

                entity.Property(e => e.EngineUrlBeginWriteToRequestStream).HasColumnType("datetime");

                entity.Property(e => e.EngineUrlEndGetRequestStream).HasColumnType("datetime");

                entity.Property(e => e.EngineUrlEndGetResponse).HasColumnType("datetime");

                entity.Property(e => e.EngineUrlEndGetResponseStream).HasColumnType("datetime");

                entity.Property(e => e.EngineUrlEndWriteToRequestStream).HasColumnType("datetime");

                entity.Property(e => e.EngineUrlGetRequestStreamLatencyMillisecond).HasComputedColumnSql("(datediff(millisecond,[EngineUrlBeginGetRequestStream],[EngineUrlEndGetRequestStream]))");

                entity.Property(e => e.EngineUrlGetResponseLatencyMillisecond).HasComputedColumnSql("(datediff(millisecond,[EngineUrlBeginGetResponse],[EngineUrlEndGetResponse]))");

                entity.Property(e => e.EngineUrlGetResponseStreamLatencyMillisecond).HasComputedColumnSql("(datediff(millisecond,[EngineUrlBeginGetResponseStream],[EngineUrlEndGetResponseStream]))");

                entity.Property(e => e.EngineUrlWriteToRequestStreamLatencyMillisecond).HasComputedColumnSql("(datediff(millisecond,[EngineUrlBeginWriteToRequestStream],[EngineUrlEndWriteToRequestStream]))");

                entity.Property(e => e.EngineVersion)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Error).HasColumnType("datetime");

                entity.Property(e => e.ErrorResponse).IsUnicode(false);

                entity.Property(e => e.FormattedClientErrorResponse).HasColumnType("varchar(max)");

                entity.Property(e => e.FullResponseXml)
                    .HasColumnName("FullResponseXML")
                    .HasColumnType("xml");

                entity.Property(e => e.JsondeserializeBegin)
                    .HasColumnName("JSONDeserializeBegin")
                    .HasColumnType("datetime");

                entity.Property(e => e.JsondeserializeEnd)
                    .HasColumnName("JSONDeserializeEnd")
                    .HasColumnType("datetime");

                entity.Property(e => e.JsondeserializeLatencyMillisecond)
                    .HasColumnName("JSONDeserializeLatencyMillisecond")
                    .HasComputedColumnSql("(datediff(millisecond,[JSONDeserializeBegin],[JSONDeserializeEnd]))");

                entity.Property(e => e.JsonserializeBegin)
                    .HasColumnName("JSONSerializeBegin")
                    .HasColumnType("datetime");

                entity.Property(e => e.JsonserializeEnd)
                    .HasColumnName("JSONSerializeEnd")
                    .HasColumnType("datetime");

                entity.Property(e => e.JsonserializeLatencyMillisecond)
                    .HasColumnName("JSONSerializeLatencyMillisecond")
                    .HasComputedColumnSql("(datediff(millisecond,[JSONSerializeBegin],[JSONSerializeEnd]))");

                entity.Property(e => e.Modified)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.PremiumOffer).HasColumnType("money");

                entity.Property(e => e.PresubmissionErrors).IsUnicode(false);

                entity.Property(e => e.PricingEngine)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RatingNarrative).HasColumnType("xml");

                entity.Property(e => e.RatingSpreadSheetId).HasColumnName("RatingSpreadSheetID");

                entity.Property(e => e.Request).IsUnicode(false);

                entity.Property(e => e.TempBuildingsId).HasColumnName("TempBuildingsID");

                entity.Property(e => e.TempLocationsId).HasColumnName("TempLocationsID");

                entity.Property(e => e.TempPremiumsId).HasColumnName("TempPremiumsID");

                entity.Property(e => e.WindDeductibleOption).HasColumnType("money");
            });

            modelBuilder.Entity<Agents>(entity =>
            {
                entity.HasKey(e => e.CompanyId)
                    .HasName("PK_Company");

                entity.HasIndex(e => e.CompanyId)
                    .HasDatabaseName("IX_Agents")
                    .IsUnique();

                entity.HasIndex(e => new { e.CompanyId, e.IsTestAgent })
                    .HasDatabaseName("ix_Agents_CompanyID_IsTestAgent");

                entity.HasIndex(e => new { e.UniqueAgentReference, e.CompanyId })
                    .HasDatabaseName("ix_Agents_UniqueAgentReference_CompanyID");

                entity.HasIndex(e => new { e.CompanyName, e.UniqueAgentReference, e.ShortName, e.CompanyId })
                    .HasDatabaseName("ix_Agents_CompanyID_Includes");

                entity.HasIndex(e => new { e.CompanyId, e.IsTempTablesTesting, e.Bcaimintegration, e.Bcalisintegration, e.UniqueAgentReference })
                    .HasDatabaseName("ix_Agents_UniqueAgentReference_Includes");

                entity.HasIndex(e => new { e.WstriggersEmailSubmissionReport, e.WstriggersEmailSubmissionReportSendUpToDate, e.UniqueAgentReference, e.CompanyId, e.CompanyName })
                    .HasDatabaseName("ix_Agents_UniqueAgentReference_CompanyID_CompanyName_Includes");

                entity.Property(e => e.CompanyId)
                    .HasColumnName("CompanyID")
                    .ValueGeneratedNever();

                entity.Property(e => e.AgentLogo).HasColumnType("image");

                entity.Property(e => e.AgentLogoContentType)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AgentLogoFileName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.AmigagentNo)
                    .HasColumnName("AMIGAgentNo")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.AmigliveDocucorp).HasColumnName("AMIGLiveDocucorp");

                entity.Property(e => e.Amigxlsagent)
                    .HasColumnName("AMIGXLSAgent")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Amsclaims)
                    .HasColumnName("AMSClaims")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Amspremiums)
                    .HasColumnName("AMSPremiums")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Bcaimintegration)
                    .HasColumnName("BCAIMIntegration")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Bcalisintegration)
                    .HasColumnName("BCALISIntegration")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.CompanyName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DefaultAvatar).HasColumnType("image");

                entity.Property(e => e.DefaultAvatarContentType)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.DefaultAvatarFileName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpPdfoptionEnabled)
                    .HasColumnName("DocucorpPDFOptionEnabled")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.DocucorpStatus)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.FormSetIdreversalProcessing)
                    .HasColumnName("FormSetIDReversalProcessing")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.GlobalClientCode)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.GlukclientId).HasColumnName("GLUKClientID");

                entity.Property(e => e.Glukxlsagent)
                    .HasColumnName("GLUKXLSAgent")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.IsClaimsTpa)
                    .HasColumnName("IsClaimsTPA")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IsTestAgent).HasDefaultValueSql("((0))");

                entity.Property(e => e.ManagementSystem)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Notes).IsUnicode(false);

                entity.Property(e => e.OverLimitEscalationEmailAddresses).IsUnicode(false);

                entity.Property(e => e.PolicyPrefix)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.RoofConstructionScheme)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.RoofShapeScheme)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.RtdcloneOpenNotReportedAllowed).HasColumnName("RTDCloneOpenNotReportedAllowed");

                entity.Property(e => e.SendAutomaticEmails).HasDefaultValueSql("((0))");

                entity.Property(e => e.ShortName)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.TpalegacyXlsoffice)
                    .HasColumnName("TPALegacyXLSOffice")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.UniqueAgentReference)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.WstriggersEmailSubmissionReport)
                    .HasColumnName("WSTriggersEmailSubmissionReport")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.WstriggersEmailSubmissionReportSendUpToDate)
                    .HasColumnName("WSTriggersEmailSubmissionReportSendUpToDate")
                    .HasColumnType("datetime");
            });

            modelBuilder.Entity<AgentsContracts>(entity =>
            {
                entity.HasKey(e => new { e.CompanyId, e.BusinessArea, e.ContractRef, e.ContractYear })
                    .HasName("PK_CompanyContracts");

                entity.HasIndex(e => e.BusinessArea)
                    .HasDatabaseName("ix_BusinessArea");

                entity.HasIndex(e => e.CompanyId)
                    .HasDatabaseName("ix_AgentsContracts_CompanyID");

                entity.HasIndex(e => e.ContractRef)
                    .HasDatabaseName("IX_AgentsContracts");

                entity.HasIndex(e => new { e.BusinessArea, e.Gluksection })
                    .HasDatabaseName("ix_AgentsContracts_BusinessArea_GLUKSection");

                entity.HasIndex(e => new { e.IsRealTime, e.ContractRef })
                    .HasDatabaseName("ix_AgentsContracts_IsRealTime_ContractRef");

                entity.HasIndex(e => new { e.MoveToLiveMethodClaims, e.IsUsingMoveToLiveClaims })
                    .HasDatabaseName("ix_AgentsContracts_MoveToLiveMethodClaims_IsUsingMoveToLiveClaims");

                entity.HasIndex(e => new { e.BusinessArea, e.CompanyId, e.ContractRef, e.ContractYear, e.Gluksection })
                    .HasDatabaseName("ix_AgentsContracts_BusinessArea_CompanyID_ContractRef_ContractYear_GLUKSection");

                entity.HasIndex(e => new { e.BusinessArea, e.Description, e.CompanyId, e.ContractRef, e.ContractYear })
                    .HasDatabaseName("ix_AgentsContracts_BusinessArea_Description_CompanyID_ContractRef_ContractYear");

                entity.HasIndex(e => new { e.BusinessArea, e.Rmsmodeled, e.CompanyId, e.ContractYear, e.ContractRef })
                    .HasDatabaseName("ix_AgentsContracts_BusinessArea_RMSModeled_CompanyID_ContractYear_ContractRef");

                entity.HasIndex(e => new { e.ContractYear, e.MoveToLiveMethod, e.CompanyId, e.BusinessArea, e.ContractRef })
                    .HasDatabaseName("ix_AgentsContracts_ContractYear_MoveToLiveMethod_CompanyID_BusinessArea_ContractRef");

                entity.HasIndex(e => new { e.Description, e.BusinessArea, e.CompanyId, e.ContractYear, e.ContractRef })
                    .HasDatabaseName("ix_AgentsContracts_Description_BusinessArea_CompanyID_ContractYear_ContractRef");

                entity.HasIndex(e => new { e.Description, e.BusinessArea, e.ContractRef, e.ContractYear, e.CompanyId })
                    .HasDatabaseName("ix_AgentsContracts_BusinessArea_ContractRef_ContractYear_CompanyID_Includes");

                entity.HasIndex(e => new { e.Description, e.ContractRef, e.CompanyId, e.ContractYear, e.BusinessArea })
                    .HasDatabaseName("ix_AgentsContracts_ContractRef_CompanyID_ContractYear_BusinessArea_Includes");

                entity.HasIndex(e => new { e.PropertyLimit, e.AllowedOverPercentageEndorsement, e.ContractYear, e.CompanyId, e.Description })
                    .HasDatabaseName("ix_AgentsContracts_ContractYear_CompanyID_Description_Includes");

                entity.HasIndex(e => new { e.BusinessArea, e.AgentCommission, e.Bccommission, e.ContractYear, e.ContractRef, e.CompanyId })
                    .HasDatabaseName("ix_AgentsContracts_ContractYear_ContractRef_CompanyID_Includes");

                entity.HasIndex(e => new { e.ContractEffectiveDate, e.ContractExpirationDate, e.CompanyId, e.BusinessArea, e.ContractYear, e.ContractRef })
                    .HasDatabaseName("ix_AgentsContracts_CompanyID_BusinessArea_ContractYear_ContractRef_Includes");

                entity.HasIndex(e => new { e.GlobalPolicyRef, e.SubmissionType, e.ContractYear, e.CompanyId, e.BusinessArea, e.ContractRef })
                    .HasDatabaseName("ix_AgentsContracts_ContractYear_CompanyID_BusinessArea_ContractRef_Includes");

                entity.HasIndex(e => new { e.LiabilityLimit, e.LiabilityAggLimit, e.OverLimitErrorPercentage, e.CompanyId, e.ContractYear, e.ContractRef })
                    .HasDatabaseName("ix_AgentsContracts_CompanyID_ContractYear_ContractRef_Includes");

                entity.HasIndex(e => new { e.RealTimeModelingEnabled, e.BusinessArea, e.CompanyId, e.ContractYear, e.ContractRef, e.RealTimeModelingPriority })
                    .HasDatabaseName("ix_AgentsContracts_RealTimeModelingEnabled_BusinessArea_CompanyID_ContractYear_ContractRef_RealTimeModelingPriority");

                entity.HasIndex(e => new { e.RealTimeModelingPriority, e.RealTimeModelingEnabled, e.BusinessArea, e.CompanyId, e.ContractYear, e.ContractRef })
                    .HasDatabaseName("ix_AgentsContracts_RealTimeModelingPriority_RealTimeModelingEnabled_BusinessArea_CompanyID_ContractYear_ContractRef");

                entity.HasIndex(e => new { e.Description, e.Gluksection, e.Bccommission, e.CompanyId, e.ContractYear, e.ContractRef, e.BusinessArea })
                    .HasDatabaseName("ix_AgentsContracts_CompanyID_ContractYear_ContractRef_BusinessArea_Includes");

                entity.HasIndex(e => new { e.PropertyLimit, e.MinimumPercentageShare, e.MinimumPercentageShareApplies, e.MinimumAccessContractB, e.AllowedOverPercentageEndorsement, e.ContractYear, e.CompanyId, e.ContractRef, e.Description })
                    .HasDatabaseName("ix_AgentsContracts_ContractYear_CompanyID_ContractRef_Description_Includes");

                entity.HasIndex(e => new { e.CompanyId, e.ContractYear, e.Active, e.PropertyLimit, e.MinimumPercentageShare, e.MinimumPercentageShareApplies, e.MinimumAccessContractB, e.AllowedOverPercentageEndorsement, e.ContractRef, e.Description })
                    .HasDatabaseName("ix_AgentsContracts_ContractRef_Description_Includes");

                entity.HasIndex(e => new { e.ContractRef, e.AgentCommission, e.Bccommission, e.ContractEffectiveDate, e.ContractExpirationDate, e.AutoCalculateCommission, e.AgentCanVaryCommission, e.WrittenAllowed, e.LiabilityLimit, e.LiabilityAggLimit, e.OverLimitErrorPercentage, e.PropertyLimitOver, e.CompanyId, e.ContractYear })
                    .HasDatabaseName("ix_AgentsContracts_CompanyID_ContractYear_Includes");

                entity.Property(e => e.CompanyId).HasColumnName("CompanyID");

                entity.Property(e => e.BusinessArea)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ContractRef)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.AccountCurrentSignOffEnabled).HasDefaultValueSql("((0))");

                entity.Property(e => e.AgentCommission).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.AgentsSystemKnowsContractAs)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AllowedOverPercentageEndorsement).HasColumnType("decimal(5, 3)");

                entity.Property(e => e.AnyOneCombinationLimit).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.AnyOneEventCatTerminalLimit).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.AnyOneLossLimit).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.AnyOneUnitLimit).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.Bccommission)
                    .HasColumnName("BCCommission")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.CalcActualNetLossRatio).HasColumnType("money");

                entity.Property(e => e.CalcAllTotalAggregate).HasColumnType("money");

                entity.Property(e => e.CalcCurrentOutstanding).HasColumnType("money");

                entity.Property(e => e.CalcFloodTotalAggregate).HasColumnType("money");

                entity.Property(e => e.CalcGwpitoDate)
                    .HasColumnName("CalcGWPIToDate")
                    .HasColumnType("money");

                entity.Property(e => e.CalcIncurred).HasColumnType("money");

                entity.Property(e => e.CalcNwpitoDate)
                    .HasColumnName("CalcNWPIToDate")
                    .HasColumnType("money");

                entity.Property(e => e.CalcPaidToDateClaims).HasColumnType("money");

                entity.Property(e => e.CalcQuakeTotalAggregate).HasColumnType("money");

                entity.Property(e => e.CalcTotalAggregateLimitInclusiveExWind).HasColumnType("money");

                entity.Property(e => e.CalcWindTotalAggregate).HasColumnType("money");

                entity.Property(e => e.CatPremium)
                    .HasColumnName("CatPremium%")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.ClaimsProcessingLogic)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ContractEffectiveDate).HasColumnType("datetime");

                entity.Property(e => e.ContractExpirationDate).HasColumnType("datetime");

                entity.Property(e => e.Cpllimit)
                    .HasColumnName("CPLLimit")
                    .HasColumnType("numeric(18, 0)");

                entity.Property(e => e.DateUpdated).HasColumnType("datetime");

                entity.Property(e => e.DefaultConstructionCodeScheme)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.DefaultOccupancyScheme)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Description)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.EqbriskCode)
                    .HasColumnName("EQBRiskCode")
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Filename).HasMaxLength(255);

                entity.Property(e => e.GlobalPolicyRef)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Glukcobcode)
                    .HasColumnName("GLUKCOBCode")
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.GlukcontractXlsletter)
                    .HasColumnName("GLUKContractXLSLetter")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Gluksection)
                    .HasColumnName("GLUKSection")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.GrossPremiumRiskLimit).HasColumnType("money");

                entity.Property(e => e.Gwpi)
                    .HasColumnName("GWPI")
                    .HasColumnType("money");

                entity.Property(e => e.HasAccurateLocationData).HasDefaultValueSql("((1))");

                entity.Property(e => e.IsLegacyBdx)
                    .HasColumnName("IsLegacyBDX")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.IsRealTime).HasDefaultValueSql("((0))");

                entity.Property(e => e.IsTempTablesTesting).HasDefaultValueSql("((0))");

                entity.Property(e => e.IsUsingMoveToLive).HasDefaultValueSql("((0))");

                entity.Property(e => e.IsUsingMoveToLiveClaims).HasDefaultValueSql("((0))");

                entity.Property(e => e.LiabilityActualProfitCommissiontoBc)
                    .HasColumnName("LiabilityActualProfitCommissiontoBC")
                    .HasColumnType("money");

                entity.Property(e => e.LiabilityActualProfitCommissiontoMga)
                    .HasColumnName("LiabilityActualProfitCommissiontoMGA")
                    .HasColumnType("money");

                entity.Property(e => e.LiabilityAggLimit).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.LiabilityAnnualGwpilimit)
                    .HasColumnName("LiabilityAnnualGWPILimit")
                    .HasColumnType("money");

                entity.Property(e => e.LiabilityBcprofitCommissionOfMgapc)
                    .HasColumnName("LiabilityBCProfitCommission%ofMGAPC")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.LiabilityEstimatedGpi)
                    .HasColumnName("LiabilityEstimatedGPI")
                    .HasColumnType("money");

                entity.Property(e => e.LiabilityEstimatedGrossLossRatio).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.LiabilityEstimatedNetLossRatio).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.LiabilityEstimatedNetProfit).HasColumnType("money");

                entity.Property(e => e.LiabilityEstimatedNpi)
                    .HasColumnName("LiabilityEstimatedNPI")
                    .HasColumnType("money");

                entity.Property(e => e.LiabilityEstimatedOfNpipayableasPc)
                    .HasColumnName("LiabilityEstimated%ofNPIPayableasPC")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.LiabilityEstimatedProfitCommissiontoBc)
                    .HasColumnName("LiabilityEstimatedProfitCommissiontoBC")
                    .HasColumnType("money");

                entity.Property(e => e.LiabilityEstimatedProfitCommissiontoMga)
                    .HasColumnName("LiabilityEstimatedProfitCommissiontoMGA")
                    .HasColumnType("money");

                entity.Property(e => e.LiabilityEstimatedUltimateNetProfit).HasColumnType("money");

                entity.Property(e => e.LiabilityLimit).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.LiabilityMgaprofitCommissionPayback)
                    .HasColumnName("LiabilityMGAProfitCommission%Payback")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.LiabilityPatternId).HasColumnName("LiabilityPatternID");

                entity.Property(e => e.LiabilityPaysPcbelow)
                    .HasColumnName("LiabilityPaysPCBelow")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.LiabilityPcdeferredBelow)
                    .HasColumnName("LiabilityPCDeferredBelow")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.LiabilityRiskCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.MandatoryAccountingEffectiveDate).HasDefaultValueSql("((0))");

                entity.Property(e => e.MinimumAccessContractB).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.MinimumAccessContractBnew)
                    .HasColumnName("MinimumAccessContractBNEW")
                    .HasColumnType("numeric(18, 0)");

                entity.Property(e => e.MinimumPercentageShare).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.MoveGlobalAccountingFiguresOver).HasDefaultValueSql("((0))");

                entity.Property(e => e.MoveGlobalClaimFiguresOver).HasDefaultValueSql("((0))");

                entity.Property(e => e.MrcatLossEstimate)
                    .HasColumnName("MRCatLossEstimate%")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.MrliabilityAttritionPremium)
                    .HasColumnName("MRLiabilityAttritionPremium%")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.MrliabilityAttritionalBreakEvenGlr)
                    .HasColumnName("MRLiabilityAttritionalBreakEvenGLR")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.MrliabilityBreakEvenGlr)
                    .HasColumnName("MRLiabilityBreakEvenGLR")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.MrliabilityEstimatedAttritionalGlr)
                    .HasColumnName("MRLiabilityEstimatedAttritionalGLR")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.MrliabilityEstimatedGlr)
                    .HasColumnName("MRLiabilityEstimatedGLR")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.MrliabilityEstimatedValueAdded)
                    .HasColumnName("MRLiabilityEstimatedValueAdded")
                    .HasMaxLength(10)
                    .IsFixedLength();

                entity.Property(e => e.MrliabilityRollingRenewOther)
                    .HasColumnName("MRLiabilityRollingRenewOther%")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.MrpropertyAttritionPremium)
                    .HasColumnName("MRPropertyAttritionPremium%")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.MrpropertyAttritionalBreakEvenGlr)
                    .HasColumnName("MRPropertyAttritionalBreakEvenGLR")
                    .HasColumnType("decimal(6, 2)");

                entity.Property(e => e.MrpropertyBreakEvenGlr)
                    .HasColumnName("MRPropertyBreakEvenGLR")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.MrpropertyEstimatedAttritionalGlr)
                    .HasColumnName("MRPropertyEstimatedAttritionalGLR")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.MrpropertyEstimatedExCatGlr)
                    .HasColumnName("MRPropertyEstimatedExCatGLR")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.MrpropertyEstimatedGlr)
                    .HasColumnName("MRPropertyEstimatedGLR")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.MrpropertyEstimatedValueAdded)
                    .HasColumnName("MRPropertyEstimatedValueAdded")
                    .HasColumnType("money");

                entity.Property(e => e.MrpropertyRollingRenewOther)
                    .HasColumnName("MRPropertyRollingRenewOther%")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.NonHsbequipmentBreakdown)
                    .HasColumnName("NonHSBEquipmentBreakdown")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.Notes).HasColumnType("text");

                entity.Property(e => e.Oldsection)
                    .HasColumnName("oldsection")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OverLimitErrorPercentage).HasColumnType("decimal(8, 5)");

                entity.Property(e => e.Pdf).HasColumnName("PDF");

                entity.Property(e => e.PolicyIssuance)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ProcessEndasExt)
                    .HasColumnName("ProcessENDasEXT")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.ProcessingLogic)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PropertyActualProfitCommissiontoBc)
                    .HasColumnName("PropertyActualProfitCommissiontoBC")
                    .HasColumnType("money");

                entity.Property(e => e.PropertyActualProfitCommissiontoMga)
                    .HasColumnName("PropertyActualProfitCommissiontoMGA")
                    .HasColumnType("money");

                entity.Property(e => e.PropertyAnnualGwpilimit)
                    .HasColumnName("PropertyAnnualGWPILimit")
                    .HasColumnType("money");

                entity.Property(e => e.PropertyBcprofitCommissionOfMgapc)
                    .HasColumnName("PropertyBCProfitCommission%ofMGAPC")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.PropertyEstimatedGpi)
                    .HasColumnName("PropertyEstimatedGPI")
                    .HasColumnType("money");

                entity.Property(e => e.PropertyEstimatedGrossLossRatio).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.PropertyEstimatedNetLossRatio).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.PropertyEstimatedNetProfit).HasColumnType("money");

                entity.Property(e => e.PropertyEstimatedNpi)
                    .HasColumnName("PropertyEstimatedNPI")
                    .HasColumnType("money");

                entity.Property(e => e.PropertyEstimatedOfNpipayableasPc)
                    .HasColumnName("PropertyEstimated%ofNPIPayableasPC")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.PropertyEstimatedProfitCommissiontoBc)
                    .HasColumnName("PropertyEstimatedProfitCommissiontoBC")
                    .HasColumnType("money");

                entity.Property(e => e.PropertyEstimatedProfitCommissiontoMga)
                    .HasColumnName("PropertyEstimatedProfitCommissiontoMGA")
                    .HasColumnType("money");

                entity.Property(e => e.PropertyEstimatedUltimateNetProfit).HasColumnType("money");

                entity.Property(e => e.PropertyLimit).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.PropertyLimitOver).HasColumnType("numeric(18, 0)");

                entity.Property(e => e.PropertyMgaprofitCommissionPayback)
                    .HasColumnName("PropertyMGAProfitCommission%Payback")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.PropertyPatternId).HasColumnName("PropertyPatternID");

                entity.Property(e => e.PropertyPaysPcbelow)
                    .HasColumnName("PropertyPaysPCBelow")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.PropertyPcdeferredBelow)
                    .HasColumnName("PropertyPCDeferredBelow")
                    .HasColumnType("decimal(5, 2)");

                entity.Property(e => e.PropertyRiskCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.RealTimeModelingEnabled).HasDefaultValueSql("((0))");

                entity.Property(e => e.Rmsmodeled).HasColumnName("RMSModeled");

                entity.Property(e => e.ShowInAccountCurrent).HasDefaultValueSql("((1))");

                entity.Property(e => e.Subclientid).HasColumnName("subclientid");

                entity.Property(e => e.SubmissionType)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.SubmissionTypeClaims)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.SubmissionTypeScheme)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubmissionTypeSchemeClaims)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.ThirdPartyComm).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.ThirdPartyCommBasis)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.TransitionTo).HasMaxLength(250);

                entity.Property(e => e.TriariskCode)
                    .HasColumnName("TRIARiskCode")
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.UserUpdated)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.WarningPercentage).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.Wca)
                    .HasColumnName("WCA")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<AgentsWebLoginAttempts>(entity =>
            {
                entity.HasKey(e => new { e.Username, e.LoginDate });

                entity.Property(e => e.Username)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.LoginDate).HasColumnType("datetime");

                entity.Property(e => e.Password)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ScreenRes)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Success).HasDefaultValueSql("((0))");

                entity.Property(e => e.UserAgent)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.UserHostAddress)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.UserHostName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.HasOne(d => d.UsernameNavigation)
                    .WithMany(p => p.AgentsWebLoginAttempts)
                    .HasForeignKey(d => d.Username)
                    .HasConstraintName("FK_AgentsWebLoginAttempts_AgentsWebUsers");
            });

            modelBuilder.Entity<AgentsWebRoles>(entity =>
            {
                entity.HasKey(e => e.RoleName);

                entity.Property(e => e.RoleName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.AgentManageable).HasDefaultValueSql("((0))");

                entity.Property(e => e.DefaultRole).HasDefaultValueSql("((0))");

                entity.Property(e => e.Description)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<AgentsWebUsers>(entity =>
            {
                entity.HasKey(e => e.Username);

                entity.HasIndex(e => new { e.PolicyProcessorSystemName, e.CompanyId })
                    .HasDatabaseName("ix_AgentsWebUsers_CompanyID_Includes");

                entity.HasIndex(e => new { e.Email, e.EmailAttachSubmissionReport, e.EmailDoNotShowSuccess, e.EmailUserSubmissionReport, e.CompanyId, e.EmailFilesAfterDate, e.EmailAllRecordsOnSubmissionReport, e.PolicyProcessorSystemName, e.EmailJustPolicyProcessorSystemNameRecords, e.Username })
                    .HasDatabaseName("ix_AgentsWebUsers_EmailUserSubmissionReport_CompanyID_EmailFilesAfterDate_EmailAllRecordsOnSubmissionReport_PolicyProcessorSyste");

                entity.Property(e => e.Username)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.AgentManageable)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.ClaimProcessorSystemName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.CompanyId).HasColumnName("CompanyID");

                entity.Property(e => e.CreationDate)
                    .HasColumnName("creationDate")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasColumnName("email")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.EmailDateLastSent).HasColumnType("datetime");

                entity.Property(e => e.EmailDoNotShowSuccess).HasDefaultValueSql("((0))");

                entity.Property(e => e.EmailFilesAfterDate).HasColumnType("datetime");

                entity.Property(e => e.FailedPasswordAttemptCount)
                    .HasColumnName("failedPasswordAttemptCount")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.FailedPasswordAttemptWindowStart)
                    .HasColumnName("failedPasswordAttemptWindowStart")
                    .HasColumnType("datetime");

                entity.Property(e => e.FtpserverAccess)
                    .HasColumnName("FTPServerAccess")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.FullName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.HashEncPassword).IsUnicode(false);

                entity.Property(e => e.LastActivityDate)
                    .HasColumnName("lastActivityDate")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.LastLockedOutDate)
                    .HasColumnName("lastLockedOutDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.LastLoginDate)
                    .HasColumnName("lastLoginDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.LastPasswordChangedDate)
                    .HasColumnName("lastPasswordChangedDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.MustChangePasswordnextLogin)
                    .IsRequired()
                    .HasColumnName("mustChangePasswordnextLogin")
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.Password)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PolicyProcessorSystemName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.TableauUsername)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.UserKey).HasDefaultValueSql("(newid())");

                entity.Property(e => e.Wsaccess)
                    .HasColumnName("WSAccess")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.WsaccessAllowMultiClientUploads)
                    .HasColumnName("WSAccessAllowMultiClientUploads")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.WsheartBeatAlertLastTriggeredDate)
                    .HasColumnName("WSHeartBeatAlertLastTriggeredDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.WsheartBeatAlertNoContactAfterXhours).HasColumnName("WSHeartBeatAlertNoContactAfterXHours");

                entity.Property(e => e.WslastAccess)
                    .HasColumnName("WSLastAccess")
                    .HasColumnType("datetime");

                entity.Property(e => e.WslastHeartBeat)
                    .HasColumnName("WSLastHeartBeat")
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("((0))");

                entity.Property(e => e.WslastUpload)
                    .HasColumnName("WSLastUpload")
                    .HasColumnType("datetime");

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.AgentsWebUsers)
                    .HasForeignKey(d => d.CompanyId)
                    .HasConstraintName("FK_AgentsWebUsers_Agents");
            });

            modelBuilder.Entity<AgentsWebUsersAllowedContracts>(entity =>
            {
                entity.HasKey(e => new { e.Username, e.CompanyId, e.BusinessArea, e.ContractRef, e.ContractYear });

                entity.ToTable("AgentsWebUsers_AllowedContracts");

                entity.Property(e => e.Username)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.CompanyId).HasColumnName("CompanyID");

                entity.Property(e => e.BusinessArea)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ContractRef)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.HasOne(d => d.UsernameNavigation)
                    .WithMany(p => p.AgentsWebUsersAllowedContracts)
                    .HasForeignKey(d => d.Username)
                    .HasConstraintName("FK_AgentsWebUsers_AllowedContracts_AgentsWebUsers");
            });

            modelBuilder.Entity<AgentsWebUsersEmailerFileTypes>(entity =>
            {
                entity.HasKey(e => new { e.Username, e.Filetype });

                entity.ToTable("AgentsWebUsers_EmailerFileTypes");

                entity.Property(e => e.Username)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Filetype)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.HasOne(d => d.UsernameNavigation)
                    .WithMany(p => p.AgentsWebUsersEmailerFileTypes)
                    .HasForeignKey(d => d.Username)
                    .HasConstraintName("FK_AgentsWebUsers_EmailerFileTypes_AgentsWebUsers");
            });

            modelBuilder.Entity<AgentsWebUsersProfiles>(entity =>
            {
                entity.HasKey(e => e.UniqueId)
                    .HasName("PK_AgentsWebUsersProfilesData");

                entity.Property(e => e.UniqueId).HasColumnName("UniqueID");

                entity.Property(e => e.LastUpdatedDate).HasColumnType("datetime");

                entity.Property(e => e.PropertyNames)
                    .IsRequired()
                    .HasColumnType("ntext");

                entity.Property(e => e.PropertyValuesBinary)
                    .IsRequired()
                    .HasColumnType("image");

                entity.Property(e => e.PropertyValuesString)
                    .IsRequired()
                    .HasColumnType("ntext");

                entity.Property(e => e.Username)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.HasOne(d => d.UsernameNavigation)
                    .WithMany(p => p.AgentsWebUsersProfiles)
                    .HasForeignKey(d => d.Username)
                    .HasConstraintName("FK_AgentsWebUsersProfiles_AgentsWebUsers");
            });

            modelBuilder.Entity<AgentsWebUsersReportsPermissions>(entity =>
            {
                entity.HasKey(e => new { e.Username, e.ReportId })
                    .HasName("PK_AgentWebReportsPermissions");

                entity.Property(e => e.Username)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.ReportId).HasColumnName("ReportID");

                entity.HasOne(d => d.Report)
                    .WithMany(p => p.AgentsWebUsersReportsPermissions)
                    .HasForeignKey(d => d.ReportId)
                    .HasConstraintName("FK_AgentsWebUsersReportsPermissions_Reports");

                entity.HasOne(d => d.UsernameNavigation)
                    .WithMany(p => p.AgentsWebUsersReportsPermissions)
                    .HasForeignKey(d => d.Username)
                    .HasConstraintName("FK_AgentsWebReportsPermissions_AgentsWebUsers");
            });

            modelBuilder.Entity<AgentsWebUsersRoleMembership>(entity =>
            {
                entity.HasKey(e => new { e.Username, e.RoleName });

                entity.Property(e => e.Username)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.RoleName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.RoleNameNavigation)
                    .WithMany(p => p.AgentsWebUsersRoleMembership)
                    .HasForeignKey(d => d.RoleName)
                    .HasConstraintName("FK_AgentsWebUsersRoleMembership_AgentsWebRoles");

                entity.HasOne(d => d.UsernameNavigation)
                    .WithMany(p => p.AgentsWebUsersRoleMembership)
                    .HasForeignKey(d => d.Username)
                    .HasConstraintName("FK_AgentsWebUsersRoleMembership_AgentsWebUsers");
            });

            modelBuilder.Entity<ArchiveTempPolicyTransactions>(entity =>
            {
                entity.HasKey(e => e.TempPremiumsId);

                entity.HasIndex(e => e.CompanyId);

                entity.HasIndex(e => e.ImportFilename);

                entity.HasIndex(e => e.PolicyNo);

                entity.HasIndex(e => new { e.DateImported, e.TempPremiumsId })
                    .HasDatabaseName("_dta_index_ArchiveTempPolicyTransactions_7_1204407560__K2_136");

                entity.HasIndex(e => new { e.PolicyNo, e.UniqueAgentReference, e.CompanyId })
                    .HasDatabaseName("_dta_index_ArchiveTempPolicyTransactions_8_1204407560__K6_K7_18");

                entity.HasIndex(e => new { e.PolicyNo, e.CompanyId, e.TempPremiumsId, e.UniqueAgentReference })
                    .HasDatabaseName("_dta_index_ArchiveTempPolicyTransactions_8_1204407560__K7_K2_K6_18");

                entity.HasIndex(e => new { e.PolicyNo, e.CorrectedBy, e.FormSetId, e.TempPremiumsId })
                    .HasDatabaseName("ix_ArchiveTempPolicyTransactions_PolicyNo_CorrectedBy_FormSetID_TempPremiumsID");

                entity.HasIndex(e => new { e.TransactionType, e.ImportFilename, e.TempPremiumsId, e.DuplicateFileSeq, e.UniqueAgentReference })
                    .HasDatabaseName("ix_ArchiveTempPolicyTransactions_ImportFilename_TempClaimsID_DuplicateFileSeq_UniqueAgentReference");

                entity.Property(e => e.TempPremiumsId)
                    .HasColumnName("TempPremiumsID")
                    .ValueGeneratedNever();

                entity.Property(e => e.AccountCurrentSignedOff).HasColumnType("datetime");

                entity.Property(e => e.AccountingEffectiveDate).HasColumnType("datetime");

                entity.Property(e => e.AllOther).HasColumnType("money");

                entity.Property(e => e.AmigclassOfBusinessCode)
                    .HasColumnName("AMIGClassOfBusinessCode")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.AmigcontractAsplitPercentage).HasColumnName("AMIGContractASplitPercentage");

                entity.Property(e => e.AmigcontractBsplitPercentage).HasColumnName("AMIGContractBSplitPercentage");

                entity.Property(e => e.AnimalLiablityCoverage).HasColumnType("money");

                entity.Property(e => e.Aopdeductible)
                    .HasColumnName("AOPDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.ArchiveDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.AttachmentPoint).HasColumnType("money");

                entity.Property(e => e.Bccommission)
                    .HasColumnName("BCCommission")
                    .HasColumnType("money");

                entity.Property(e => e.BccustomErrorMessage)
                    .HasColumnName("BCCustomErrorMessage")
                    .IsUnicode(false);

                entity.Property(e => e.BodilyInjuryByAccidentLimit).HasColumnType("money");

                entity.Property(e => e.BodilyInjuryByDiseaseAggregateLimit).HasColumnType("money");

                entity.Property(e => e.BodilyInjuryByDiseaseEachEmployeeLimit).HasColumnType("money");

                entity.Property(e => e.BordereauType)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.BusinessArea)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CalcEquipmentBreakDownPremium).HasColumnType("money");

                entity.Property(e => e.CalcHomeSystemsProtectionPremium).HasColumnType("money");

                entity.Property(e => e.CalcIdentityTheftRecoveryPremium).HasColumnType("money");

                entity.Property(e => e.CalcServiceLinePremium).HasColumnType("money");

                entity.Property(e => e.Catdeductible)
                    .HasColumnName("CATDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.CdmatchPercentage).HasColumnName("CDMatchPercentage");

                entity.Property(e => e.CedingCoNameRetailAgent)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.CertificateNumber)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.ChangeDescription).IsUnicode(false);

                entity.Property(e => e.CoInsurancePercentage).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.Commission).HasColumnType("money");

                entity.Property(e => e.CompanyId).HasColumnName("CompanyID");

                entity.Property(e => e.CompanyNumber)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.ConstructionCode)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ConstructionCodeScheme)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ContractRef)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.ContractShare).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.CoverageForm).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.CrimeDeductible).HasColumnType("money");

                entity.Property(e => e.CrimeLimit).HasColumnType("money");

                entity.Property(e => e.CrimePremium).HasColumnType("money");

                entity.Property(e => e.CrimeRate).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.CyberLiabilityLimit).HasColumnType("money");

                entity.Property(e => e.CyberLiabilityPremium).HasColumnType("money");

                entity.Property(e => e.DateCreated).HasColumnType("datetime");

                entity.Property(e => e.DateErrorChecksFirstRun).HasColumnType("datetime");

                entity.Property(e => e.DateErrorChecksLastRunEnd).HasColumnType("datetime");

                entity.Property(e => e.DateErrorChecksLastRunStart).HasColumnType("datetime");

                entity.Property(e => e.DateImported).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.DateOfLastLoss).HasColumnType("date");

                entity.Property(e => e.DateUpdated).HasColumnType("datetime");

                entity.Property(e => e.DocEndRevisedPropLimit)
                    .HasColumnName("DocEND_RevisedPropLimit")
                    .HasColumnType("money");

                entity.Property(e => e.DocEndTotalLiability)
                    .HasColumnName("DocEND_TotalLiability")
                    .HasColumnType("money");

                entity.Property(e => e.DocEndTotalProperty)
                    .HasColumnName("DocEND_TotalProperty")
                    .HasColumnType("money");

                entity.Property(e => e.DocEndTotalTerror)
                    .HasColumnName("DocEND_TotalTerror")
                    .HasColumnType("money");

                entity.Property(e => e.DocucorpAgentAddr)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpAgentCity)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpAgentName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpAgentState)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpAgentZip)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpAgentZipPlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpDamagePremRented)
                    .HasColumnName("DOCUCORP_DAMAGE_PREM_RENTED")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpMedExpenseLmt)
                    .HasColumnName("DOCUCORP_MED_EXPENSE_LMT")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpPersonalAndAdvertising)
                    .HasColumnName("DOCUCORP_PERSONAL_AND_ADVERTISING")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpProductCompletedOper)
                    .HasColumnName("DOCUCORP_PRODUCT_COMPLETED_OPER")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpTransCode)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.DqicoreScore)
                    .HasColumnName("DQICoreScore")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DqiquakeScore)
                    .HasColumnName("DQIQuakeScore")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DqiwindScore)
                    .HasColumnName("DQIWindScore")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.EffectiveDate).HasColumnType("datetime");

                entity.Property(e => e.Ellimit)
                    .HasColumnName("ELLimit")
                    .HasColumnType("money");

                entity.Property(e => e.Elpremium)
                    .HasColumnName("ELPremium")
                    .HasColumnType("money");

                entity.Property(e => e.EndorsementNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EngineQuoteEnquiryId)
                    .HasColumnName("EngineQuoteEnquiryID")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.EqappendagesandOrnamentation).HasColumnName("EQAppendagesandOrnamentation");

                entity.Property(e => e.EqbaseIsolation).HasColumnName("EQBaseIsolation");

                entity.Property(e => e.EqcladdingType).HasColumnName("EQCladdingType");

                entity.Property(e => e.EqconstructionQuality).HasColumnName("EQConstructionQuality");

                entity.Property(e => e.EqcrippleWalls).HasColumnName("EQCrippleWalls");

                entity.Property(e => e.EqengineeredFoundation).HasColumnName("EQEngineeredFoundation");

                entity.Property(e => e.EqequipmentSupportMaintenance).HasColumnName("EQEquipmentSupportMaintenance");

                entity.Property(e => e.EqframeBolted).HasColumnName("EQFrameBolted");

                entity.Property(e => e.EqmechanicalandElectricalEquipmentEarthquakeBracing).HasColumnName("EQMechanicalandElectricalEquipmentEarthquakeBracing");

                entity.Property(e => e.EqplanIrregularity).HasColumnName("EQPlanIrregularity");

                entity.Property(e => e.Eqpounding).HasColumnName("EQPounding");

                entity.Property(e => e.EqshortColumnCondition).HasColumnName("EQShortColumnCondition");

                entity.Property(e => e.EqsoftStory).HasColumnName("EQSoftStory");

                entity.Property(e => e.EqsprinklerLeakageCoverageFlag)
                    .HasColumnName("EQSprinklerLeakageCoverageFlag")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.EqsprinklerLeakageSusceptibility).HasColumnName("EQSprinklerLeakageSusceptibility");

                entity.Property(e => e.EqsprinklerType).HasColumnName("EQSprinklerType");

                entity.Property(e => e.EqstructuralUpgrade).HasColumnName("EQStructuralUpgrade");

                entity.Property(e => e.EqtiltUpRetrofit).HasColumnName("EQTiltUpRetrofit");

                entity.Property(e => e.EquipmentBreakdown)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.EquipmentBreakdownPremium).HasColumnType("money");

                entity.Property(e => e.EqunreinforcedMasonryPartitionsorChimneys).HasColumnName("EQUnreinforcedMasonryPartitionsorChimneys");

                entity.Property(e => e.EqunreinforcedMasonryRetrofit).HasColumnName("EQUnreinforcedMasonryRetrofit");

                entity.Property(e => e.EqverticalIrregularity).HasColumnName("EQVerticalIrregularity");

                entity.Property(e => e.ExpirationDate).HasColumnType("datetime");

                entity.Property(e => e.ExpiringPolicyNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ExtendedLiabilityRentedLocationsFamilies)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ExtendedLiabilityToRentedLocationsAmount).HasColumnType("money");

                entity.Property(e => e.FirstFloorHeightAboveGround).HasColumnType("decimal(3, 1)");

                entity.Property(e => e.FlfoundationType).HasColumnName("FLFoundationType");

                entity.Property(e => e.FloodDeductible).HasColumnType("money");

                entity.Property(e => e.FloodLimit).HasColumnType("money");

                entity.Property(e => e.FloodZone)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.ForDebugRequestPricingEngineVersion)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FormSetId)
                    .HasColumnName("FormSetID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FullTermEndorsementPremium).HasColumnType("money");

                entity.Property(e => e.GlaggregateLimit)
                    .HasColumnName("GLAggregateLimit")
                    .HasColumnType("money");

                entity.Property(e => e.GlobalEndorsementId).HasColumnName("GlobalEndorsementID");

                entity.Property(e => e.GlobalPolicyId).HasColumnName("GlobalPolicyID");

                entity.Property(e => e.GlukbppLimit)
                    .HasColumnName("GLUKBppLimit")
                    .HasColumnType("money");

                entity.Property(e => e.GlukbrokasureTransactionNumber).HasColumnName("GLUKBrokasureTransactionNumber");

                entity.Property(e => e.GlukbusinessIncome)
                    .HasColumnName("GLUKBusinessIncome")
                    .HasColumnType("money");

                entity.Property(e => e.Glukcpllimit)
                    .HasColumnName("GLUKCPLLimit")
                    .HasColumnType("money");

                entity.Property(e => e.Glukcplpremium)
                    .HasColumnName("GLUKCPLPremium")
                    .HasColumnType("money");

                entity.Property(e => e.GlukdistanceFromSaltWater)
                    .HasColumnName("GLUKDistanceFromSaltWater")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.GlukfireDeductible)
                    .HasColumnName("GLUKFireDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukfireIncluded)
                    .HasColumnName("GLUKFireIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukfloodIncluded)
                    .HasColumnName("GLUKFloodIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukhailDeductible)
                    .HasColumnName("GLUKHailDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukhailIncluded)
                    .HasColumnName("GLUKHailIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukinHouseEndorsementNumber).HasColumnName("GLUKInHouseEndorsementNumber");

                entity.Property(e => e.GlukpaymentBasis)
                    .HasColumnName("GLUKPaymentBasis")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukquakeIncluded)
                    .HasColumnName("GLUKQuakeIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GluksltbrokerId).HasColumnName("GLUKSLTBrokerID");

                entity.Property(e => e.GlukspareText)
                    .HasColumnName("GLUKSpareText")
                    .IsUnicode(false);

                entity.Property(e => e.Glukwcapremium)
                    .HasColumnName("GLUKWCAPremium")
                    .HasColumnType("money");

                entity.Property(e => e.GlukwindIncluded)
                    .HasColumnName("GLUKWindIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukwindstormDeductible)
                    .HasColumnName("GLUKWindstormDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukzonePerilsId).HasColumnName("GLUKZonePerilsID");

                entity.Property(e => e.GoogleElevation).HasColumnName("GOOGLE_Elevation");

                entity.Property(e => e.GoogleElevationResolution).HasColumnName("GOOGLE_Elevation_Resolution");

                entity.Property(e => e.GoogleGeoCodeDate)
                    .HasColumnName("GOOGLE_GeoCodeDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.GoogleLocationType)
                    .HasColumnName("GOOGLE_LOCATION_TYPE")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.GoogleX).HasColumnName("GOOGLE_X");

                entity.Property(e => e.GoogleY).HasColumnName("GOOGLE_Y");

                entity.Property(e => e.GrossPremium).HasColumnType("money");

                entity.Property(e => e.HeatingLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.HereonPercentage).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.HistoricTiv1yearPrior)
                    .HasColumnName("HistoricTIV1YearPrior")
                    .HasColumnType("money");

                entity.Property(e => e.HistoricTiv2yearPrior)
                    .HasColumnName("HistoricTIV2YearPrior")
                    .HasColumnType("money");

                entity.Property(e => e.HistoricTiv3yearPrior)
                    .HasColumnName("HistoricTIV3YearPrior")
                    .HasColumnType("money");

                entity.Property(e => e.HomeSystemsProtectionPremium).HasColumnType("money");

                entity.Property(e => e.IdentityTheftRecovery)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.IdentityTheftRecoveryPremium).HasColumnType("money");

                entity.Property(e => e.ImportFilename)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Impremium)
                    .HasColumnName("IMPremium")
                    .HasColumnType("money");

                entity.Property(e => e.ImpremiumPolicyWide)
                    .HasColumnName("IMPremiumPolicyWide")
                    .HasColumnType("money");

                entity.Property(e => e.InHomeBusinessCoverageBusinessName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.InHomeBusinessCoverageGrossReceipts).HasColumnType("money");

                entity.Property(e => e.InHomeBusinessCoverageTypeOfBusiness)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.IncludedForms).IsUnicode(false);

                entity.Property(e => e.InlandMarineFloodLimitPolicyWide).HasColumnType("money");

                entity.Property(e => e.InlandMarineLimit).HasColumnType("money");

                entity.Property(e => e.InlandMarineLimitPolicyWide).HasColumnType("money");

                entity.Property(e => e.InlandMarineQuakeLimitPolicyWide).HasColumnType("money");

                entity.Property(e => e.InlandMarineWindLimitPolicyWide).HasColumnType("money");

                entity.Property(e => e.InsuredCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCountryCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCountryScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCounty)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredDoingBusinessAs)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredEntityId)
                    .HasColumnName("InsuredEntityID")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredEntityType)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.InsuredName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredStreet)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredZipCodePlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.InvoiceNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.IsocurrencyCode)
                    .HasColumnName("ISOCurrencyCode")
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Isoglclass)
                    .HasColumnName("ISOGLClass")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.IsopropertyCode)
                    .HasColumnName("ISOPropertyCode")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.LiabilityDeductible).HasColumnType("money");

                entity.Property(e => e.LiabilityLimit).HasColumnType("money");

                entity.Property(e => e.LiabilityPremium).HasColumnType("money");

                entity.Property(e => e.LimitBuildingCoverageA).HasColumnType("money");

                entity.Property(e => e.LimitBusinessInterruptionCoverageD).HasColumnType("money");

                entity.Property(e => e.LimitContentsCoverageC).HasColumnType("money");

                entity.Property(e => e.LimitCoverageE).HasColumnType("money");

                entity.Property(e => e.LimitFirearms).HasColumnType("money");

                entity.Property(e => e.LimitJewellry).HasColumnType("money");

                entity.Property(e => e.LimitMoneyBanknotes).HasColumnType("money");

                entity.Property(e => e.LimitOtherCoverageB).HasColumnType("money");

                entity.Property(e => e.LimitPortableElectronicDevices).HasColumnType("money");

                entity.Property(e => e.LimitResidenceBurglary).HasColumnType("money");

                entity.Property(e => e.LimitSecurities).HasColumnType("money");

                entity.Property(e => e.LimitSilverware).HasColumnType("money");

                entity.Property(e => e.LossAssessmentCoverage).HasColumnType("money");

                entity.Property(e => e.MailingCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MailingCountryCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.MailingCountryScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.MailingCounty)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MailingState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.MailingStreet)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.MailingZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.MailingZipCodePlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ManualCheckedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ManualCheckedDate).HasColumnType("datetime");

                entity.Property(e => e.ManualCheckedNotes).IsUnicode(false);

                entity.Property(e => e.MedicalExpensesLimit).HasColumnType("money");

                entity.Property(e => e.MgaquoteId)
                    .HasColumnName("MGAQuoteID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MgaquoteVersion)
                    .HasColumnName("MGAQuoteVersion")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MgasubmissionId)
                    .HasColumnName("MGASubmissionID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MigrationOldSystemId).HasColumnName("MigrationOldSystemID");

                entity.Property(e => e.MinFloodDeductible).HasColumnType("money");

                entity.Property(e => e.MinHailHurricaneDeductible).HasColumnType("money");

                entity.Property(e => e.MinNamedStormDeductible).HasColumnType("money");

                entity.Property(e => e.MinQuakeDeductible).HasColumnType("money");

                entity.Property(e => e.MinimumCrimeAdjustmentPremium).HasColumnType("money");

                entity.Property(e => e.MinimumPropertyAdjustmentPremium).HasColumnType("money");

                entity.Property(e => e.MiscProfessionalLiabilityLimit).HasColumnType("money");

                entity.Property(e => e.MiscProfessionalLiabilityPremium).HasColumnType("money");

                entity.Property(e => e.ModifierMarketPriceAdjustment).HasColumnType("decimal(5, 4)");

                entity.Property(e => e.ModifierUnderwriterPriceAdjustment).HasColumnType("decimal(10, 8)");

                entity.Property(e => e.MrAdditionalElevation).HasColumnName("MR_Additional_ELEVATION");

                entity.Property(e => e.MrAdditionalPopulation).HasColumnName("MR_Additional_POPULATION");

                entity.Property(e => e.MrCity)
                    .HasColumnName("MR_CITY")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCoordind).HasColumnName("MR_COORDIND");

                entity.Property(e => e.MrCrestaHighresId)
                    .HasColumnName("MR_CRESTA_HIGHRES_ID")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaHighresName)
                    .HasColumnName("MR_CRESTA_HIGHRES_NAME")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaLowresId)
                    .HasColumnName("MR_CRESTA_LOWRES_ID")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaLowresName)
                    .HasColumnName("MR_CRESTA_LOWRES_NAME")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaid)
                    .HasColumnName("MR_CRESTAID")
                    .HasMaxLength(255);

                entity.Property(e => e.MrCrestaname)
                    .HasColumnName("MR_CRESTANAME")
                    .HasMaxLength(255);

                entity.Property(e => e.MrDistanceToCoast).HasColumnName("MR_DISTANCE_TO_COAST");

                entity.Property(e => e.MrDistanceToFault).HasColumnName("MR_DISTANCE_TO_FAULT");

                entity.Property(e => e.MrErrAdditional)
                    .HasColumnName("MR_ERR_Additional")
                    .HasMaxLength(150);

                entity.Property(e => e.MrErrCresta)
                    .HasColumnName("MR_ERR_CRESTA")
                    .HasMaxLength(255);

                entity.Property(e => e.MrErrCrestaHighres)
                    .HasColumnName("MR_ERR_CRESTA_HIGHRES")
                    .HasMaxLength(150);

                entity.Property(e => e.MrErrCrestaLowres)
                    .HasColumnName("MR_ERR_CRESTA_LOWRES")
                    .HasMaxLength(150);

                entity.Property(e => e.MrErrGcd)
                    .HasColumnName("MR_ERR_GCD")
                    .HasMaxLength(255);

                entity.Property(e => e.MrErrHazard)
                    .HasColumnName("MR_ERR_Hazard")
                    .HasMaxLength(255);

                entity.Property(e => e.MrErrRiverflood).HasColumnName("MR_ERR_RIVERFLOOD");

                entity.Property(e => e.MrGeoCodeDate)
                    .HasColumnName("MR_GeoCodeDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.MrGeozoneType)
                    .HasColumnName("MR_GEOZONE_TYPE")
                    .HasMaxLength(150);

                entity.Property(e => e.MrHazardEarthquake).HasColumnName("MR_Hazard_EARTHQUAKE");

                entity.Property(e => e.MrHazardExtratropicalstorm).HasColumnName("MR_Hazard_EXTRATROPICALSTORM");

                entity.Property(e => e.MrHazardFlashflood).HasColumnName("MR_Hazard_FLASHFLOOD");

                entity.Property(e => e.MrHazardHailstorm).HasColumnName("MR_Hazard_HAILSTORM");

                entity.Property(e => e.MrHazardLightning).HasColumnName("MR_Hazard_LIGHTNING");

                entity.Property(e => e.MrHazardStormsurge).HasColumnName("MR_Hazard_STORMSURGE");

                entity.Property(e => e.MrHazardTcyclone).HasColumnName("MR_Hazard_TCYCLONE");

                entity.Property(e => e.MrHazardTornado).HasColumnName("MR_Hazard_TORNADO");

                entity.Property(e => e.MrHazardTropicalcyclone).HasColumnName("MR_Hazard_TROPICALCYCLONE");

                entity.Property(e => e.MrHazardTsunami).HasColumnName("MR_Hazard_TSUNAMI");

                entity.Property(e => e.MrHazardVolcano).HasColumnName("MR_Hazard_VOLCANO");

                entity.Property(e => e.MrHazardWildfire).HasColumnName("MR_Hazard_WILDFIRE");

                entity.Property(e => e.MrHazardWstorm).HasColumnName("MR_Hazard_WSTORM");

                entity.Property(e => e.MrHnr)
                    .HasColumnName("MR_HNR")
                    .HasMaxLength(150);

                entity.Property(e => e.MrIso3)
                    .HasColumnName("MR_ISO3")
                    .HasMaxLength(150);

                entity.Property(e => e.MrQualind).HasColumnName("MR_QUALIND");

                entity.Property(e => e.MrRiskIndex).HasColumnName("MR_RiskIndex");

                entity.Property(e => e.MrRiskIndexEq).HasColumnName("MR_RiskIndexEq");

                entity.Property(e => e.MrRiskIndexFl).HasColumnName("MR_RiskIndexFl");

                entity.Property(e => e.MrRiskIndexSt).HasColumnName("MR_RiskIndexST");

                entity.Property(e => e.MrRiskScore).HasColumnName("MR_RiskScore");

                entity.Property(e => e.MrRiskScoreEq).HasColumnName("MR_RiskScoreEq");

                entity.Property(e => e.MrRiskScoreFl).HasColumnName("MR_RiskScoreFl");

                entity.Property(e => e.MrRiskScoreSt).HasColumnName("MR_RiskScoreST");

                entity.Property(e => e.MrRiverfloodRiverflood).HasColumnName("MR_RIVERFLOOD_RIVERFLOOD");

                entity.Property(e => e.MrSoil).HasColumnName("MR_SOIL");

                entity.Property(e => e.MrStr)
                    .HasColumnName("MR_STR")
                    .HasMaxLength(150);

                entity.Property(e => e.MrX).HasColumnName("MR_X");

                entity.Property(e => e.MrY).HasColumnName("MR_Y");

                entity.Property(e => e.MrZip)
                    .HasColumnName("MR_ZIP")
                    .HasMaxLength(150);

                entity.Property(e => e.Naic)
                    .HasColumnName("NAIC")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.NetPremium).HasColumnType("money");

                entity.Property(e => e.Notes).IsUnicode(false);

                entity.Property(e => e.OccupancyCode)
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.OccupancyScheme)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.OrderId).HasColumnName("OrderID");

                entity.Property(e => e.OriginalAccountingEffectiveDate).HasColumnType("datetime");

                entity.Property(e => e.ParentRui)
                    .HasColumnName("ParentRUI")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Payable)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.Pdfattachment)
                    .HasColumnName("PDFAttachment")
                    .HasColumnType("image");

                entity.Property(e => e.PdfattachmentFileName)
                    .HasColumnName("PDFAttachmentFileName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.PersonalAccidentPremium).HasColumnType("money");

                entity.Property(e => e.PersonalInjuryCoverage).HasColumnType("money");

                entity.Property(e => e.PlacementType).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.PlcommercialIndicator)
                    .HasColumnName("PLCommercialIndicator")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Pllimit)
                    .HasColumnName("PLLimit")
                    .HasColumnType("money");

                entity.Property(e => e.Plpremium)
                    .HasColumnName("PLPremium")
                    .HasColumnType("money");

                entity.Property(e => e.PlumbingLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.PolicyFee).HasColumnType("money");

                entity.Property(e => e.PolicyNo)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PolicyProcessorSystemName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.PremiumBasis)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.PremiumBasisValue).HasColumnType("money");

                entity.Property(e => e.PricingEngineId)
                    .HasColumnName("PricingEngineID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ProductsCompletedOperationsPremium).HasColumnType("money");

                entity.Property(e => e.PropertyLimit).HasColumnType("money");

                entity.Property(e => e.PropertyLimitB).HasColumnType("money");

                entity.Property(e => e.PropertyPremium).HasColumnType("money");

                entity.Property(e => e.PropertyPremiumB).HasColumnType("money");

                entity.Property(e => e.ProtectionClass)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Protections)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.QuakeDeductible).HasColumnType("money");

                entity.Property(e => e.QuakeLimit).HasColumnType("money");

                entity.Property(e => e.Rate).HasColumnType("decimal(7, 4)");

                entity.Property(e => e.RateAllOther).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.RateProductsCompletedOperations).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.RatingSessionId)
                    .HasColumnName("RatingSessionID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RetroActiveDate).HasColumnType("datetime");

                entity.Property(e => e.Rms17completeDate)
                    .HasColumnName("RMS17CompleteDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.Rms17geoCompleteDate)
                    .HasColumnName("RMS17GeoCompleteDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.Rms17geoSubmitDate)
                    .HasColumnName("RMS17GeoSubmitDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.Rms17pickupDate)
                    .HasColumnName("RMS17PickupDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.Rms17submitDate)
                    .HasColumnName("RMS17SubmitDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.RmscompleteDate)
                    .HasColumnName("RMSCompleteDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.RmsgeoCompleteDate)
                    .HasColumnName("RMSGeoCompleteDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.RmsgeoSubmitDate)
                    .HasColumnName("RMSGeoSubmitDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.RmspickupDate)
                    .HasColumnName("RMSPickupDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.RmsproductVersion)
                    .HasColumnName("RMSProductVersion")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.RmspurePremiumQuake)
                    .HasColumnName("RMSPurePremiumQuake")
                    .HasColumnType("money");

                entity.Property(e => e.RmspurePremiumScs)
                    .HasColumnName("RMSPurePremiumSCS")
                    .HasColumnType("money");

                entity.Property(e => e.RmspurePremiumWind)
                    .HasColumnName("RMSPurePremiumWind")
                    .HasColumnType("money");

                entity.Property(e => e.RmspurePremiumWinterStorm)
                    .HasColumnName("RMSPurePremiumWinterStorm")
                    .HasColumnType("money");

                entity.Property(e => e.RmsrunDate)
                    .HasColumnName("RMSRunDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.RmssubmitDate)
                    .HasColumnName("RMSSubmitDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.RolledBackBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RolledBackDate).HasColumnType("datetime");

                entity.Property(e => e.RoofConstructionCode).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.RoofConstructionScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.RoofLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.RoofShapeCode).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.RoofShapeScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.SectionNumber)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.ServiceLinePremium).HasColumnType("money");

                entity.Property(e => e.SizeofLayer).HasColumnType("money");

                entity.Property(e => e.SltbrokerAddress)
                    .HasColumnName("SLTBrokerAddress")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SltbrokerName)
                    .HasColumnName("SLTBrokerName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SltbrokerNumber)
                    .HasColumnName("SLTBrokerNumber")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Sltstate)
                    .HasColumnName("SLTState")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.SpreadSheetRatersCompleteDate).HasColumnType("datetime");

                entity.Property(e => e.Squarefootage).HasColumnType("decimal(7, 0)");

                entity.Property(e => e.StructuresRentedOffPremisesCoverage)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.StructuresRentedOnPremisesCoverage)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SubCompanyId).HasColumnName("SubCompanyID");

                entity.Property(e => e.SubCoverageCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerCity)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerCounty)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerState)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerStreet)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerZipCode)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerZipCodePlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.SurplusLinesTransactionNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SurveyFees).HasColumnType("money");

                entity.Property(e => e.TaxFilingState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.TerritoriesCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TerrorismPremium).HasColumnType("money");

                entity.Property(e => e.Tivfgu)
                    .HasColumnName("TIVFGU")
                    .HasColumnType("money");

                entity.Property(e => e.TotalInsurancePremiumTax).HasColumnType("money");

                entity.Property(e => e.TotalPropertyLimit).HasColumnType("money");

                entity.Property(e => e.TotalPropertyPremium).HasColumnType("money");

                entity.Property(e => e.TransactionType)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Triprapremium)
                    .HasColumnName("TRIPRAPremium")
                    .HasColumnType("money");

                entity.Property(e => e.UnderwriterApprovedNotes).IsUnicode(false);

                entity.Property(e => e.UnderwriterName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.UniqueAgentReference)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.UserCreated)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserModified)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserUpdated)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.WindHailHurricaneDeductible).HasColumnType("money");

                entity.Property(e => e.WindHailHurricaneDeductibleNamedStorm).HasColumnType("money");

                entity.Property(e => e.WindLimit).HasColumnType("money");

                entity.Property(e => e.WiringLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.Xlsoffice)
                    .HasColumnName("XLSOffice")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.YearBuilt).HasColumnType("decimal(4, 0)");
            });

            modelBuilder.Entity<ArchiveTempPolicyTransactionsContracts>(entity =>
            {
                entity.HasKey(e => new { e.TempPremiumsId, e.CompanyId, e.BusinessArea, e.ContractRef, e.ContractYear });

                entity.ToTable("ArchiveTempPolicyTransactions_Contracts");

                entity.HasIndex(e => e.TempPremiumsId)
                    .HasDatabaseName("ix_ArchiveTempPolicyTransactions_Contracts_TempPremiumsID");

                entity.Property(e => e.TempPremiumsId).HasColumnName("TempPremiumsID");

                entity.Property(e => e.CompanyId).HasColumnName("CompanyID");

                entity.Property(e => e.BusinessArea)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ContractRef)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.Bccommission)
                    .HasColumnName("BCCommission")
                    .HasColumnType("money");

                entity.Property(e => e.BccommissionPercentage)
                    .HasColumnName("BCCommissionPercentage")
                    .HasColumnType("decimal(6, 3)");

                entity.Property(e => e.Commission).HasColumnType("money");

                entity.Property(e => e.CommissionPercentage).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.ContractShare).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.EquipmentBreakdownShare).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.GrossPremium).HasColumnType("money");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Idold).HasColumnName("IDOld");

                entity.Property(e => e.LiabilityShare).HasColumnType("decimal(6, 3)");

                entity.HasOne(d => d.TempPremiums)
                    .WithMany(p => p.ArchiveTempPolicyTransactionsContracts)
                    .HasForeignKey(d => d.TempPremiumsId)
                    .HasConstraintName("FK_ArchiveTempPolicyTransactions_Contracts_ArchiveTempPolicyTransactions");
            });

            modelBuilder.Entity<ArchiveTempPolicyTransactionsLocations>(entity =>
            {
                entity.HasKey(e => e.TempLocationsId);

                entity.ToTable("ArchiveTempPolicyTransactions_Locations");

                entity.HasIndex(e => new { e.TempPremiumsId, e.LocationNumber, e.InsuredStreet, e.InsuredCity, e.InsuredCounty, e.InsuredState, e.InsuredZipCode, e.TotalPropertyLimit })
                    .HasDatabaseName("ix_ArchiveTempPolicyTransactions_Locations_TempPremiumsID_LocationNumber_InsuredStreet_InsuredCity_InsuredCounty_InsuredState_In");

                entity.Property(e => e.TempLocationsId)
                    .HasColumnName("TempLocationsID")
                    .ValueGeneratedNever();

                entity.Property(e => e.AllOther).HasColumnType("money");

                entity.Property(e => e.AlternateHeatSourceCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.AmigclassOfBusinessCode)
                    .HasColumnName("AMIGClassOfBusinessCode")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Aopdeductible)
                    .HasColumnName("AOPDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.BalboaBankCertNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.BalboaBankName)
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.BalboaGrossAdjustedPremium).HasColumnType("money");

                entity.Property(e => e.BalboaGrossPaidPremium).HasColumnType("money");

                entity.Property(e => e.BalboaGrossReturnPremium).HasColumnType("money");

                entity.Property(e => e.BalboaTier)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BasementType)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.BccustomErrorMessage)
                    .HasColumnName("BCCustomErrorMessage")
                    .IsUnicode(false);

                entity.Property(e => e.BordereauType)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.BuildingCoverageAvaluationBasis)
                    .HasColumnName("BuildingCoverageAValuationBasis")
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.BuildingNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CalcEquipmentBreakDownPremium).HasColumnType("money");

                entity.Property(e => e.CalcHomeSystemsProtectionPremium).HasColumnType("money");

                entity.Property(e => e.CalcServiceLinePremium).HasColumnType("money");

                entity.Property(e => e.Catdeductible)
                    .HasColumnName("CATDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.CdmatchPercentage).HasColumnName("CDMatchPercentage");

                entity.Property(e => e.CoInsurancePercentage).HasColumnType("decimal(5, 3)");

                entity.Property(e => e.ConstructionCode)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ConstructionCodeScheme)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ContentsCoverageCvaluationBasis)
                    .HasColumnName("ContentsCoverageCValuationBasis")
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.CrimeDeductible).HasColumnType("money");

                entity.Property(e => e.CrimeLimit).HasColumnType("money");

                entity.Property(e => e.CrimePremium).HasColumnType("money");

                entity.Property(e => e.CrimeRate).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.DateCreated).HasColumnType("datetime");

                entity.Property(e => e.DateErrorChecksFirstRun).HasColumnType("datetime");

                entity.Property(e => e.DateErrorChecksLastRunEnd).HasColumnType("datetime");

                entity.Property(e => e.DateErrorChecksLastRunStart).HasColumnType("datetime");

                entity.Property(e => e.DateImported).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.DateUpdated).HasColumnType("datetime");

                entity.Property(e => e.DocEndRevisedPropLimit)
                    .HasColumnName("DocEND_RevisedPropLimit")
                    .HasColumnType("money");

                entity.Property(e => e.DocEndTotalLiability)
                    .HasColumnName("DocEND_TotalLiability")
                    .HasColumnType("money");

                entity.Property(e => e.DocEndTotalProperty)
                    .HasColumnName("DocEND_TotalProperty")
                    .HasColumnType("money");

                entity.Property(e => e.DocEndTotalTerror)
                    .HasColumnName("DocEND_TotalTerror")
                    .HasColumnType("money");

                entity.Property(e => e.DocucorpTransCode)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.DqicoreScore)
                    .HasColumnName("DQICoreScore")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DqiquakeScore)
                    .HasColumnName("DQIQuakeScore")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DqiwindScore)
                    .HasColumnName("DQIWindScore")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.Ellimit)
                    .HasColumnName("ELLimit")
                    .HasColumnType("money");

                entity.Property(e => e.Elpremium)
                    .HasColumnName("ELPremium")
                    .HasColumnType("money");

                entity.Property(e => e.EqappendagesandOrnamentation).HasColumnName("EQAppendagesandOrnamentation");

                entity.Property(e => e.EqbaseIsolation).HasColumnName("EQBaseIsolation");

                entity.Property(e => e.EqcladdingType).HasColumnName("EQCladdingType");

                entity.Property(e => e.EqconstructionQuality).HasColumnName("EQConstructionQuality");

                entity.Property(e => e.EqcrippleWalls).HasColumnName("EQCrippleWalls");

                entity.Property(e => e.EqengineeredFoundation).HasColumnName("EQEngineeredFoundation");

                entity.Property(e => e.EqequipmentSupportMaintenance).HasColumnName("EQEquipmentSupportMaintenance");

                entity.Property(e => e.EqframeBolted).HasColumnName("EQFrameBolted");

                entity.Property(e => e.EqmechanicalandElectricalEquipmentEarthquakeBracing).HasColumnName("EQMechanicalandElectricalEquipmentEarthquakeBracing");

                entity.Property(e => e.EqplanIrregularity).HasColumnName("EQPlanIrregularity");

                entity.Property(e => e.Eqpounding).HasColumnName("EQPounding");

                entity.Property(e => e.EqshortColumnCondition).HasColumnName("EQShortColumnCondition");

                entity.Property(e => e.EqsoftStory).HasColumnName("EQSoftStory");

                entity.Property(e => e.EqsprinklerLeakageCoverageFlag)
                    .HasColumnName("EQSprinklerLeakageCoverageFlag")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.EqsprinklerLeakageSusceptibility).HasColumnName("EQSprinklerLeakageSusceptibility");

                entity.Property(e => e.EqsprinklerType).HasColumnName("EQSprinklerType");

                entity.Property(e => e.EqstructuralUpgrade).HasColumnName("EQStructuralUpgrade");

                entity.Property(e => e.EqtiltUpRetrofit).HasColumnName("EQTiltUpRetrofit");

                entity.Property(e => e.EquipmentBreakdown)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.EquipmentBreakdownPremium).HasColumnType("money");

                entity.Property(e => e.EqunreinforcedMasonryPartitionsorChimneys).HasColumnName("EQUnreinforcedMasonryPartitionsorChimneys");

                entity.Property(e => e.EqunreinforcedMasonryRetrofit).HasColumnName("EQUnreinforcedMasonryRetrofit");

                entity.Property(e => e.EqverticalIrregularity).HasColumnName("EQVerticalIrregularity");

                entity.Property(e => e.ExtendedReplacementCostCoverage).HasColumnType("money");

                entity.Property(e => e.ExteriorPaintUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.FirstFloorHeightAboveGround).HasColumnType("decimal(3, 1)");

                entity.Property(e => e.FlfoundationType).HasColumnName("FLFoundationType");

                entity.Property(e => e.FloodDeductible).HasColumnType("money");

                entity.Property(e => e.FloodLimit).HasColumnType("money");

                entity.Property(e => e.FloodZone)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.GlaggregateLimit)
                    .HasColumnName("GLAggregateLimit")
                    .HasColumnType("money");

                entity.Property(e => e.Glukbideductible)
                    .HasColumnName("GLUKBIDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukbppLimit)
                    .HasColumnName("GLUKBppLimit")
                    .HasColumnType("money");

                entity.Property(e => e.GlukbuildingDeductible)
                    .HasColumnName("GLUKBuildingDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukbuildingsLimit)
                    .HasColumnName("GLUKBuildingsLimit")
                    .HasColumnType("money");

                entity.Property(e => e.GlukbusinessIncome)
                    .HasColumnName("GLUKBusinessIncome")
                    .HasColumnType("money");

                entity.Property(e => e.GlukcontentsDeductible)
                    .HasColumnName("GLUKContentsDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukdeductibleScheme)
                    .HasColumnName("GLUKDeductibleScheme")
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukdistanceFromSaltWater)
                    .HasColumnName("GLUKDistanceFromSaltWater")
                    .HasMaxLength(50);

                entity.Property(e => e.GlukfireDeductible)
                    .HasColumnName("GLUKFireDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukfireIncluded)
                    .HasColumnName("GLUKFireIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukfloodIncluded)
                    .HasColumnName("GLUKFloodIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukhailDeductible)
                    .HasColumnName("GLUKHailDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukhailIncluded)
                    .HasColumnName("GLUKHailIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukquakeIncluded)
                    .HasColumnName("GLUKQuakeIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GluksltbrokerAddress)
                    .HasColumnName("GLUKSLTBrokerAddress")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.GluksltbrokerId).HasColumnName("GLUKSLTBrokerID");

                entity.Property(e => e.GluksltbrokerName)
                    .HasColumnName("GLUKSLTBrokerName")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.GluksltbrokerState)
                    .HasColumnName("GLUKSLTBrokerState")
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GluksltbrokerTaxNumber)
                    .HasColumnName("GLUKSLTBrokerTaxNumber")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.GlukwindIncluded)
                    .HasColumnName("GLUKWindIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukwindstormDeductible)
                    .HasColumnName("GLUKWindstormDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukzonePerilsId).HasColumnName("GLUKZonePerilsID");

                entity.Property(e => e.GoogleElevation).HasColumnName("GOOGLE_Elevation");

                entity.Property(e => e.GoogleElevationResolution).HasColumnName("GOOGLE_Elevation_Resolution");

                entity.Property(e => e.GoogleGeoCodeDate)
                    .HasColumnName("GOOGLE_GeoCodeDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.GoogleLocationType)
                    .HasColumnName("GOOGLE_LOCATION_TYPE")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.GoogleX).HasColumnName("GOOGLE_X");

                entity.Property(e => e.GoogleY).HasColumnName("GOOGLE_Y");

                entity.Property(e => e.GrossPremium).HasColumnType("money");

                entity.Property(e => e.HeatingLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.HomeSystemsProtection)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.HomeSystemsProtectionPremium).HasColumnType("money");

                entity.Property(e => e.Impremium)
                    .HasColumnName("IMPremium")
                    .HasColumnType("money");

                entity.Property(e => e.InlandMarineLimit).HasColumnType("money");

                entity.Property(e => e.InsuredCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCountryCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCountryScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCounty)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredStreet)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredZipCodePlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.Isoglclass)
                    .HasColumnName("ISOGLClass")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.IsopropertyCode)
                    .HasColumnName("ISOPropertyCode")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.LiabilityDeductible).HasColumnType("money");

                entity.Property(e => e.LiabilityLimit).HasColumnType("money");

                entity.Property(e => e.LiabilityPremium).HasColumnType("money");

                entity.Property(e => e.LimitBuildingCoverageA).HasColumnType("money");

                entity.Property(e => e.LimitBusinessInterruptionCoverageD).HasColumnType("money");

                entity.Property(e => e.LimitContentsCoverageC).HasColumnType("money");

                entity.Property(e => e.LimitCoverageE).HasColumnType("money");

                entity.Property(e => e.LimitOtherCoverageB).HasColumnType("money");

                entity.Property(e => e.LimitResidenceBurglary).HasColumnType("money");

                entity.Property(e => e.LocationNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LocationTransactionType)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.MgadistanceToCoastMiles).HasColumnName("MGADistanceToCoastMiles");

                entity.Property(e => e.Mgalatitude).HasColumnName("MGALatitude");

                entity.Property(e => e.Mgalongitude).HasColumnName("MGALongitude");

                entity.Property(e => e.MoldSublimitCoverage).HasColumnType("money");

                entity.Property(e => e.MrAdditionalElevation).HasColumnName("MR_Additional_ELEVATION");

                entity.Property(e => e.MrAdditionalPopulation).HasColumnName("MR_Additional_POPULATION");

                entity.Property(e => e.MrCity)
                    .HasColumnName("MR_CITY")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCoordind).HasColumnName("MR_COORDIND");

                entity.Property(e => e.MrCrestaHighresId)
                    .HasColumnName("MR_CRESTA_HIGHRES_ID")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaHighresName)
                    .HasColumnName("MR_CRESTA_HIGHRES_NAME")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaLowresId)
                    .HasColumnName("MR_CRESTA_LOWRES_ID")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaLowresName)
                    .HasColumnName("MR_CRESTA_LOWRES_NAME")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaid)
                    .HasColumnName("MR_CRESTAID")
                    .HasMaxLength(255);

                entity.Property(e => e.MrCrestaname)
                    .HasColumnName("MR_CRESTANAME")
                    .HasMaxLength(255);

                entity.Property(e => e.MrDistanceToCoast).HasColumnName("MR_DISTANCE_TO_COAST");

                entity.Property(e => e.MrDistanceToFault).HasColumnName("MR_DISTANCE_TO_FAULT");

                entity.Property(e => e.MrErrAdditional)
                    .HasColumnName("MR_ERR_Additional")
                    .HasMaxLength(150);

                entity.Property(e => e.MrErrCresta)
                    .HasColumnName("MR_ERR_CRESTA")
                    .HasMaxLength(255);

                entity.Property(e => e.MrErrCrestaHighres)
                    .HasColumnName("MR_ERR_CRESTA_HIGHRES")
                    .HasMaxLength(150);

                entity.Property(e => e.MrErrCrestaLowres)
                    .HasColumnName("MR_ERR_CRESTA_LOWRES")
                    .HasMaxLength(150);

                entity.Property(e => e.MrErrGcd)
                    .HasColumnName("MR_ERR_GCD")
                    .HasMaxLength(255);

                entity.Property(e => e.MrErrHazard)
                    .HasColumnName("MR_ERR_Hazard")
                    .HasMaxLength(255);

                entity.Property(e => e.MrErrRiverflood).HasColumnName("MR_ERR_RIVERFLOOD");

                entity.Property(e => e.MrGeoCodeDate)
                    .HasColumnName("MR_GeoCodeDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.MrGeozoneType)
                    .HasColumnName("MR_GEOZONE_TYPE")
                    .HasMaxLength(150);

                entity.Property(e => e.MrHazardEarthquake).HasColumnName("MR_Hazard_EARTHQUAKE");

                entity.Property(e => e.MrHazardExtratropicalstorm).HasColumnName("MR_Hazard_EXTRATROPICALSTORM");

                entity.Property(e => e.MrHazardFlashflood).HasColumnName("MR_Hazard_FLASHFLOOD");

                entity.Property(e => e.MrHazardHailstorm).HasColumnName("MR_Hazard_HAILSTORM");

                entity.Property(e => e.MrHazardLightning).HasColumnName("MR_Hazard_LIGHTNING");

                entity.Property(e => e.MrHazardStormsurge).HasColumnName("MR_Hazard_STORMSURGE");

                entity.Property(e => e.MrHazardTcyclone).HasColumnName("MR_Hazard_TCYCLONE");

                entity.Property(e => e.MrHazardTornado).HasColumnName("MR_Hazard_TORNADO");

                entity.Property(e => e.MrHazardTropicalcyclone).HasColumnName("MR_Hazard_TROPICALCYCLONE");

                entity.Property(e => e.MrHazardTsunami).HasColumnName("MR_Hazard_TSUNAMI");

                entity.Property(e => e.MrHazardVolcano).HasColumnName("MR_Hazard_VOLCANO");

                entity.Property(e => e.MrHazardWildfire).HasColumnName("MR_Hazard_WILDFIRE");

                entity.Property(e => e.MrHazardWstorm).HasColumnName("MR_Hazard_WSTORM");

                entity.Property(e => e.MrHnr)
                    .HasColumnName("MR_HNR")
                    .HasMaxLength(150);

                entity.Property(e => e.MrIso3)
                    .HasColumnName("MR_ISO3")
                    .HasMaxLength(150);

                entity.Property(e => e.MrQualind).HasColumnName("MR_QUALIND");

                entity.Property(e => e.MrRiskIndex).HasColumnName("MR_RiskIndex");

                entity.Property(e => e.MrRiskIndexEq).HasColumnName("MR_RiskIndexEq");

                entity.Property(e => e.MrRiskIndexFl).HasColumnName("MR_RiskIndexFl");

                entity.Property(e => e.MrRiskIndexSt).HasColumnName("MR_RiskIndexST");

                entity.Property(e => e.MrRiskScore).HasColumnName("MR_RiskScore");

                entity.Property(e => e.MrRiskScoreEq).HasColumnName("MR_RiskScoreEq");

                entity.Property(e => e.MrRiskScoreFl).HasColumnName("MR_RiskScoreFl");

                entity.Property(e => e.MrRiskScoreSt).HasColumnName("MR_RiskScoreST");

                entity.Property(e => e.MrRiverfloodRiverflood).HasColumnName("MR_RIVERFLOOD_RIVERFLOOD");

                entity.Property(e => e.MrSoil).HasColumnName("MR_SOIL");

                entity.Property(e => e.MrStr)
                    .HasColumnName("MR_STR")
                    .HasMaxLength(150);

                entity.Property(e => e.MrX).HasColumnName("MR_X");

                entity.Property(e => e.MrY).HasColumnName("MR_Y");

                entity.Property(e => e.MrZip)
                    .HasColumnName("MR_ZIP")
                    .HasMaxLength(150);

                entity.Property(e => e.Notes).IsUnicode(false);

                entity.Property(e => e.OccupancyCode)
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.OccupancyScheme)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OpeningProtectionTypesCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.OpeningProtectionsCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.OrdinanceOrLawCoverage).HasColumnType("money");

                entity.Property(e => e.PersonalAccidentPremium).HasColumnType("money");

                entity.Property(e => e.Pllimit)
                    .HasColumnName("PLLimit")
                    .HasColumnType("money");

                entity.Property(e => e.Plpremium)
                    .HasColumnName("PLPremium")
                    .HasColumnType("money");

                entity.Property(e => e.PlumbingLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.PremiumBasis)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.PremiumBasisValue).HasColumnType("money");

                entity.Property(e => e.PrimaryFlood)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.PrimaryHeatSourceCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.ProductsCompletedOperationsPremium).HasColumnType("money");

                entity.Property(e => e.PropertyLimit).HasColumnType("money");

                entity.Property(e => e.PropertyLimitB).HasColumnType("money");

                entity.Property(e => e.PropertyPremium).HasColumnType("money");

                entity.Property(e => e.PropertyPremiumB).HasColumnType("money");

                entity.Property(e => e.ProtectionClass)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Protections)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.QuakeDeductible).HasColumnType("money");

                entity.Property(e => e.QuakeLimit).HasColumnType("money");

                entity.Property(e => e.Rate).HasColumnType("decimal(5, 3)");

                entity.Property(e => e.RateAllOther).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.RateProductsCompletedOperations).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.RentalTerm)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.Rmsbasefloodelevation).HasColumnName("RMSBASEFLOODELEVATION");

                entity.Property(e => e.Rmsbizone).HasColumnName("RMSBIZONE");

                entity.Property(e => e.Rmsbuildingelevation).HasColumnName("RMSBUILDINGELEVATION");

                entity.Property(e => e.RmsfloodElevation).HasColumnName("RMSFloodELEVATION");

                entity.Property(e => e.RmsfloodFloodway)
                    .HasColumnName("RMSFloodFLOODWAY")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.RmsfloodFlzone)
                    .HasColumnName("RMSFloodFLZONE")
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.RmsgeoResolutionCode).HasColumnName("RMSGeoResolutionCode");

                entity.Property(e => e.RmshazardGeoLookupDate)
                    .HasColumnName("RMSHazardGeoLookupDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.RmsnfipRate).HasColumnName("RMSNFIP_RATE");

                entity.Property(e => e.Rmsnfipyear).HasColumnName("RMSNFIPYEAR");

                entity.Property(e => e.RmsquakeBizone).HasColumnName("RMSQuakeBIZONE");

                entity.Property(e => e.RmsquakeLandslide).HasColumnName("RMSQuakeLANDSLIDE");

                entity.Property(e => e.RmsquakeLiquefact).HasColumnName("RMSQuakeLIQUEFACT");

                entity.Property(e => e.RmsquakeSoilperiod).HasColumnName("RMSQuakeSOILPERIOD");

                entity.Property(e => e.RmsquakeSoilthickness).HasColumnName("RMSQuakeSOILTHICKNESS");

                entity.Property(e => e.RmsquakeSoiltype).HasColumnName("RMSQuakeSOILTYPE");

                entity.Property(e => e.Rmsspecialfloodhazardarea)
                    .HasColumnName("RMSSPECIALFLOODHAZARDAREA")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Rmswfaccess).HasColumnName("RMSWFACCESS");

                entity.Property(e => e.Rmswfareadesc).HasColumnName("RMSWFAREADESC");

                entity.Property(e => e.Rmswfhazard).HasColumnName("RMSWFHAZARD");

                entity.Property(e => e.Rmswflochist).HasColumnName("RMSWFLOCHIST");

                entity.Property(e => e.Rmswfnearhist).HasColumnName("RMSWFNEARHIST");

                entity.Property(e => e.Rmswfspeccond)
                    .HasColumnName("RMSWFSPECCOND")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Rmswfsurffuel)
                    .HasColumnName("RMSWFSURFFUEL")
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.Rmswfsuscept).HasColumnName("RMSWFSUSCEPT");

                entity.Property(e => e.Rmswfthreat).HasColumnName("RMSWFTHREAT");

                entity.Property(e => e.RmswindDistcoast).HasColumnName("RMSWindDISTCOAST");

                entity.Property(e => e.RmswindElevation).HasColumnName("RMSWindELEVATION");

                entity.Property(e => e.RmswindManrough).HasColumnName("RMSWindMANROUGH");

                entity.Property(e => e.RmswindNatrough).HasColumnName("RMSWindNATROUGH");

                entity.Property(e => e.Rmswindpool).HasColumnName("RMSWINDPOOL");

                entity.Property(e => e.RoofAnchorCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.RoofConstructionCode).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.RoofConstructionScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.RoofCoverageValuationBasis)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.RoofLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.RoofShapeCode).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.RoofShapeScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.RoofSheathingCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.ScreenedEnclosureCoverage).HasColumnType("money");

                entity.Property(e => e.ServiceLine)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.ServiceLinePremium).HasColumnType("money");

                entity.Property(e => e.SinkholeCoverage).HasColumnType("money");

                entity.Property(e => e.SltbrokerAddress)
                    .HasColumnName("SLTBrokerAddress")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SltbrokerName)
                    .HasColumnName("SLTBrokerName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SltbrokerNumber)
                    .HasColumnName("SLTBrokerNumber")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Sltstate)
                    .HasColumnName("SLTState")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Squarefootage).HasColumnType("decimal(7, 0)");

                entity.Property(e => e.SubCoverageCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TaxFilingState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.TempPremiumsId).HasColumnName("TempPremiumsID");

                entity.Property(e => e.TerritoriesCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TerrorismPremium).HasColumnType("money");

                entity.Property(e => e.Tivfgu)
                    .HasColumnName("TIVFGU")
                    .HasColumnType("money");

                entity.Property(e => e.TotalPropertyLimit).HasColumnType("money");

                entity.Property(e => e.TotalPropertyPremium).HasColumnType("money");

                entity.Property(e => e.Triprapremium)
                    .HasColumnName("TRIPRAPremium")
                    .HasColumnType("money");

                entity.Property(e => e.TypeOfHeatingUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfPlumbingUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfRoofingUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfWiringUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.UserCreated)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserModified)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserUpdated)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.WaterSewageBackupCoverage).HasColumnType("money");

                entity.Property(e => e.WindHailHurricaneDeductible).HasColumnType("money");

                entity.Property(e => e.WindHailHurricaneDeductibleNamedStorm).HasColumnType("money");

                entity.Property(e => e.WindLimit).HasColumnType("money");

                entity.Property(e => e.WiringLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.YearBuilt).HasColumnType("decimal(4, 0)");

                entity.HasOne(d => d.TempPremiums)
                    .WithMany(p => p.ArchiveTempPolicyTransactionsLocations)
                    .HasForeignKey(d => d.TempPremiumsId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("FK_ArchiveTempPolicyTransactions_Locations_ArchiveTempPolicyTransactions");
            });

            modelBuilder.Entity<Bdxlog>(entity =>
            {
                entity.HasKey(e => new { e.BusinessArea, e.CompanyId, e.BordYear, e.BordMonth, e.ContractYear, e.ContractRef });

                entity.ToTable("BDXLog");

                entity.HasIndex(e => new { e.MoveToLiveDate, e.MoveToLiveAttempted, e.BusinessArea, e.AccountCurrentSignedOff })
                    .HasDatabaseName("ix_BDXLog_MoveToLiveDate_MoveToLiveAttempted_BusinessArea_AccountCurrentSignedOff");

                entity.HasIndex(e => new { e.AccountCurrentSignedOff, e.BordYear, e.BordMonth, e.BusinessArea, e.CompanyId, e.ContractYear, e.ContractRef })
                    .HasDatabaseName("_dta_index_BDXLog_7_1341403998__K5_K6_K2_K1_K4_K3_22");

                entity.HasIndex(e => new { e.CompanyId, e.ContractRef, e.ContractYear, e.BordYear, e.BordMonth, e.MoveToLiveDate, e.MoveToLiveAttempted, e.BusinessArea, e.AccountCurrentSignedOff })
                    .HasDatabaseName("ix_BDXLog_BordYear_BordMonth_MoveToLiveDate_MoveToLiveAttempted_BusinessArea_AccountCurrentSignedOff_includes");

                entity.HasIndex(e => new { e.BordYear, e.BordMonth, e.BdxfirstImported, e.GrossPremium, e.Commission, e.Bccommission, e.GrossPremiumError, e.NoRecordsError, e.Bdxrecieved, e.ProcessedBy, e.NillBdx, e.MoveToLiveDate, e.IntoGlobal, e.AccountCurrentSignedOff, e.AccountCurrentSignedOffBy, e.ContractYear, e.CompanyId, e.BusinessArea, e.ContractRef })
                    .HasDatabaseName("ix_BDXLog_ContractYear_CompanyID_BusinessArea_ContractRef_Includes");

                entity.HasIndex(e => new { e.BdxfirstImported, e.GrossPremium, e.Commission, e.Bccommission, e.GrossPremiumError, e.NoRecords, e.NoRecordsError, e.ErrorsAdvised, e.ResponseRecieved, e.ProcessedBy, e.MoveToLiveDate, e.IntoGlobal, e.Comments, e.AccountCurrentSignedOff, e.AccountCurrentSignedOffBy, e.MoveToLiveAttempted, e.AccountCurrentSignedOffClaims, e.AccountCurrentSignedOffByClaims, e.Override, e.MoveToLiveAttemptedClaims, e.AccountCurrentClaimsSignedOffByTpacompanyId, e.MovedToLiveUser, e.BordYear, e.BordMonth, e.Bdxrecieved, e.NillBdx })
                    .HasDatabaseName("ix_BDXLog_BordYear_BordMonth_BDXRecieved_NillBdx_includes");

                entity.Property(e => e.BusinessArea)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CompanyId).HasColumnName("CompanyID");

                entity.Property(e => e.ContractRef)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.AccountCurrentClaimsSignedOffByTpacompanyId).HasColumnName("AccountCurrentClaimsSignedOffByTPACompanyID");

                entity.Property(e => e.AccountCurrentSignedOff).HasColumnType("datetime");

                entity.Property(e => e.AccountCurrentSignedOffBy)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.AccountCurrentSignedOffByClaims)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.AccountCurrentSignedOffClaims).HasColumnType("datetime");

                entity.Property(e => e.Bccommission)
                    .HasColumnName("BCCommission")
                    .HasColumnType("money");

                entity.Property(e => e.BdxfirstImported)
                    .HasColumnName("BDXFirstImported")
                    .HasColumnType("datetime");

                entity.Property(e => e.Bdxrecieved)
                    .HasColumnName("BDXRecieved")
                    .HasColumnType("datetime");

                entity.Property(e => e.Comments).HasColumnType("varchar(max)");

                entity.Property(e => e.Commission).HasColumnType("money");

                entity.Property(e => e.ErrorsAdvised).HasColumnType("datetime");

                entity.Property(e => e.GrossPremium).HasColumnType("money");

                entity.Property(e => e.GrossPremiumError).HasColumnType("money");

                entity.Property(e => e.IntoGlobal).HasColumnType("datetime");

                entity.Property(e => e.MoveToLiveAttempted).HasColumnType("datetime");

                entity.Property(e => e.MoveToLiveAttemptedClaims).HasColumnType("datetime");

                entity.Property(e => e.MoveToLiveDate).HasColumnType("datetime");

                entity.Property(e => e.MovedToLiveUser)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Override).HasDefaultValueSql("((0))");

                entity.Property(e => e.ProcessedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ResponseRecieved).HasColumnType("datetime");
            });

            modelBuilder.Entity<BordMonthYear>(entity =>
            {
                entity.HasKey(e => new { e.BordYear, e.BordMonth });

                entity.Property(e => e.ClosedAaic).HasColumnName("Closed_AAIC");

                entity.Property(e => e.ClosedAaicBy)
                    .HasColumnName("Closed_AAIC_By")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClosedAaicDate)
                    .HasColumnName("Closed_AAIC_Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.ClosedAmig).HasColumnName("Closed_Amig");

                entity.Property(e => e.ClosedAmigBy)
                    .HasColumnName("Closed_Amig_By")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClosedAmigDate)
                    .HasColumnName("Closed_Amig_Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.ClosedGluk).HasColumnName("Closed_Gluk");

                entity.Property(e => e.ClosedGlukBy)
                    .HasColumnName("Closed_Gluk_By")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClosedGlukDate)
                    .HasColumnName("Closed_Gluk_Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.ClosedGlukInhouse).HasColumnName("Closed_Gluk_Inhouse");

                entity.Property(e => e.ClosedGlukInhouseBy)
                    .HasColumnName("Closed_Gluk_Inhouse_By")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClosedGlukInhouseDate)
                    .HasColumnName("Closed_Gluk_Inhouse_Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.ClosedIronShore).HasColumnName("Closed_IronShore");

                entity.Property(e => e.ClosedIronShoreBy)
                    .HasColumnName("Closed_IronShore_By")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClosedIronShoreDate)
                    .HasColumnName("Closed_IronShore_Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.ClosedLloyds).HasColumnName("Closed_Lloyds");

                entity.Property(e => e.ClosedLloydsBy)
                    .HasColumnName("Closed_Lloyds_By")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClosedLloydsDate)
                    .HasColumnName("Closed_Lloyds_Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.ClosedPeslic).HasColumnName("Closed_PESLIC");

                entity.Property(e => e.ClosedPeslicBy)
                    .HasColumnName("Closed_PESLIC_By")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ClosedPeslicDate)
                    .HasColumnName("Closed_PESLIC_Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.CurrentMonthGluk).HasColumnName("CurrentMonth_Gluk");

                entity.Property(e => e.DateUpdated).HasColumnType("datetime");

                entity.Property(e => e.EditingUnlocked).HasDefaultValueSql("((0))");

                entity.Property(e => e.EditingUnlockedReason).IsUnicode(false);

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.UserUpdated)
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<BridgeFileServer>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.ClientIp)
                    .HasColumnName("ClientIP")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DateDeleted).HasColumnType("datetime");

                entity.Property(e => e.DateUploaded).HasColumnType("datetime");

                entity.Property(e => e.DeletedBy)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.HasOne(d => d.Company)
                    .WithMany(p => p.BridgeFileServer)
                    .HasForeignKey(d => d.CompanyId)
                    .HasConstraintName("FK__BridgeFil__Compa__28E2F130");

                entity.HasOne(d => d.Directory)
                    .WithMany(p => p.BridgeFileServer)
                    .HasForeignKey(d => d.DirectoryId)
                    .HasConstraintName("FK__BridgeFil__Direc__75ED5D0F");

                entity.HasOne(d => d.UserNameNavigation)
                    .WithMany(p => p.BridgeFileServer)
                    .HasForeignKey(d => d.UserName)
                    .HasConstraintName("FK_BridgeFileServer_AgentsWebUsers");
            });

            modelBuilder.Entity<BridgeFileServerDirectory>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Directory)
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<BridgeFileServerDirectoryPermissions>(entity =>
            {
                entity.HasKey(e => new { e.DirectoryId, e.Username });

                entity.Property(e => e.Username)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.HasOne(d => d.Directory)
                    .WithMany(p => p.BridgeFileServerDirectoryPermissions)
                    .HasForeignKey(d => d.DirectoryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__BridgeFil__Direc__7405149D");

                entity.HasOne(d => d.UsernameNavigation)
                    .WithMany(p => p.BridgeFileServerDirectoryPermissions)
                    .HasForeignKey(d => d.Username)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__BridgeFil__Usern__74F938D6");
            });

            modelBuilder.Entity<ConstructionCodeScheme>(entity =>
            {
                entity.HasKey(e => e.ConstructionCodeScheme1);

                entity.Property(e => e.ConstructionCodeScheme1)
                    .HasColumnName("ConstructionCodeScheme")
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ConstructionCodes>(entity =>
            {
                entity.HasKey(e => new { e.ConstructionCodeScheme, e.ConstructionCode });

                entity.HasIndex(e => e.ConstructionCodeScheme)
                    .HasDatabaseName("ix_ConstructionCodes_ConstructionCodeScheme");

                entity.Property(e => e.ConstructionCodeScheme)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ConstructionCode)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.Amigequivalent)
                    .HasColumnName("AMIGEquivalent")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Description).IsUnicode(false);

                entity.Property(e => e.EquivalentRmscode)
                    .HasColumnName("EquivalentRMSCode")
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.GlobalMappingField)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.Glukequivalent)
                    .HasColumnName("GLUKEquivalent")
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.IsofireEquivalent)
                    .HasColumnName("ISOFireEquivalent")
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.MunichReEquivalent)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.HasOne(d => d.ConstructionCodeSchemeNavigation)
                    .WithMany(p => p.ConstructionCodes)
                    .HasForeignKey(d => d.ConstructionCodeScheme)
                    .HasConstraintName("FK_ConstructionCodes_ConstructionCodeScheme");
            });

            modelBuilder.Entity<LogImportedFiles>(entity =>
            {
                entity.HasKey(e => new { e.ImportFilename, e.DuplicateFileSeq, e.UniqueAgentReference })
                    .IsClustered(false);

                entity.HasIndex(e => e.DateAgentAdvised);

                entity.HasIndex(e => new { e.ImportFilename, e.DuplicateFileSeq })
                    .HasDatabaseName("IX_LogImportedFiles");

                entity.HasIndex(e => new { e.UniqueAgentReference, e.DateAgentAdvised, e.DateImported })
                    .HasDatabaseName("ix_LogImportedFiles_UniqueAgentReference_DateAgentAdvised_DateImported");

                entity.HasIndex(e => new { e.UniqueAgentReference, e.DateImported, e.DateAgentAdvised })
                    .HasDatabaseName("ix_LogImportedFiles_UniqueAgentReference_DateImported_DateAgentAdvised");

                entity.HasIndex(e => new { e.WsticketId, e.ImportFilename, e.UniqueAgentReference, e.DuplicateFileSeq })
                    .HasDatabaseName("ix_LogImportedFiles_WSTicketID_ImportFilename_UniqueAgentReference_DuplicateFileSeq");

                entity.HasIndex(e => new { e.UniqueAgentReference, e.ImportFilename, e.DuplicateFileSeq, e.DateAgentAdvised, e.DateImported })
                    .HasDatabaseName("ix_LogImportedFiles_UniqueAgentReference_ImportFilename_DuplicateFileSeq_DateAgentAdvised_DateImported");

                entity.HasIndex(e => new { e.DatePostImportStart, e.DatePostImportEnd, e.WsticketId, e.DuplicateFileSeq, e.ImportFilename, e.UniqueAgentReference })
                    .HasDatabaseName("ix_LogImportedFiles_WSTicketID_DuplicateFileSeq_ImportFilename_UniqueAgentReference");

                entity.HasIndex(e => new { e.TpauniqueAgentReference, e.DateAgentAdvised, e.DateImported, e.UniqueAgentReference, e.DuplicateFileSeq, e.ImportFilename })
                    .HasDatabaseName("ix_LogImportedFiles_TPAUniqueAgentReference_DateAgentAdvised_DateImported_UniqueAgentReference_DuplicateFileSeq_ImportFilename");

                entity.HasIndex(e => new { e.ImportFilename, e.DuplicateFileSeq, e.UniqueAgentReference, e.DateAgentAdvised, e.TpauniqueAgentReference, e.DateImported, e.DateCheckPremiumsRun, e.DateCheckLocationsRun, e.DateCheckClaimsRun, e.DatePostImportEnd })
                    .HasDatabaseName("IX_DateImported_DateCheckPremiumsRun_DateCheckLocationsRun_DateCheckClaimsRun_DatePostImportEnd_Includes");

                entity.Property(e => e.ImportFilename)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.UniqueAgentReference)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.Contract)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.DateAgentAdvised).HasColumnType("datetime");

                entity.Property(e => e.DateCheckClaimsRun).HasColumnType("datetime");

                entity.Property(e => e.DateCheckLocationsRun).HasColumnType("datetime");

                entity.Property(e => e.DateCheckPremiumsRun).HasColumnType("datetime");

                entity.Property(e => e.DateCorrectionDetectorLocationsRun).HasColumnType("datetime");

                entity.Property(e => e.DateCorrectionDetectorPremiumsRun).HasColumnType("datetime");

                entity.Property(e => e.DateImported).HasColumnType("datetime");

                entity.Property(e => e.DatePostImportEnd).HasColumnType("datetime");

                entity.Property(e => e.DatePostImportStart).HasColumnType("datetime");

                entity.Property(e => e.FileTypeId).HasColumnName("FileTypeID");

                entity.Property(e => e.GlukenteredDateFrom)
                    .HasColumnName("GLUKEnteredDateFrom")
                    .HasColumnType("date");

                entity.Property(e => e.GlukenteredDateTo)
                    .HasColumnName("GLUKEnteredDateTo")
                    .HasColumnType("date");

                entity.Property(e => e.ImportFileDate).HasColumnType("datetime");

                entity.Property(e => e.PickedUpFrom)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.PostImportProcessingTimeMillisecond).HasComputedColumnSql("(datediff(millisecond,[DatePostImportStart],[DatePostImportEnd]))");

                entity.Property(e => e.SavedTo)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Section)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.TpauniqueAgentReference)
                    .HasColumnName("TPAUniqueAgentReference")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.WsticketId).HasColumnName("WSTicketID");

                entity.HasOne(d => d.Wsticket)
                    .WithMany(p => p.LogImportedFiles)
                    .HasForeignKey(d => d.WsticketId)
                    .OnDelete(DeleteBehavior.SetNull)
                    .HasConstraintName("FK_LogImportedFiles_LogImportedFilesWS");
            });

            modelBuilder.Entity<LogImportedFilesWs>(entity =>
            {
                entity.HasKey(e => e.WsticketId)
                    .IsClustered(false);

                entity.ToTable("LogImportedFilesWS");

                entity.HasIndex(e => e.ClientFileName)
                    .HasDatabaseName("ix_LogImportedFilesWS_ClientFileName");

                entity.HasIndex(e => e.TicketRequestDate)
                    .HasDatabaseName("ix_LogImportedFilesWS_TicketRequestDate");

                entity.HasIndex(e => new { e.ClientFileName, e.UniqueAgentReference })
                    .HasDatabaseName("ix_LogImportedFilesWS_ClientFileName_UniqueAgentReference");

                entity.HasIndex(e => new { e.FileStatus, e.FileSaved });

                entity.HasIndex(e => new { e.TicketRequestDate, e.WsticketId })
                    .HasDatabaseName("ix_LogImportedFilesWS_TicketRequestDate_WSTicketID");

                entity.Property(e => e.WsticketId)
                    .HasColumnName("WSTicketID")
                    .ValueGeneratedNever();

                entity.Property(e => e.ClientFileName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.FileContents).HasColumnType("image");

                entity.Property(e => e.FileSavedDate).HasColumnType("datetime");

                entity.Property(e => e.PreXsltfileName)
                    .HasColumnName("PreXSLTFileName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.ProcessingLog).IsUnicode(false);

                entity.Property(e => e.ProcessingLogClient).IsUnicode(false);

                entity.Property(e => e.ProcessingStartDate).HasColumnType("datetime");

                entity.Property(e => e.ProcessingTimeMillisecond).HasComputedColumnSql("(datediff(millisecond,[TicketRequestDate],[TicketEndProcessingDate]))");

                entity.Property(e => e.TicketEndProcessingDate).HasColumnType("datetime");

                entity.Property(e => e.TicketRequestDate)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.UniqueAgentReference)
                    .IsRequired()
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.Username)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.XsltfallBackTransformationUsed).HasColumnName("XSLTFallBackTransformationUsed");
            });

            modelBuilder.Entity<Occupancy>(entity =>
            {
                entity.HasKey(e => new { e.OccupancyScheme, e.OccupancyCode });

                entity.HasIndex(e => new { e.RmsmodelOccupancy, e.OccupancyScheme, e.OccupancyCode })
                    .HasDatabaseName("ix_Occupancy_RMSModelOccupancy_OccupancyScheme_OccupancyCode");

                entity.Property(e => e.OccupancyScheme)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.OccupancyCode)
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.AmigclassOfBusinessCode)
                    .HasColumnName("AMIGClassOfBusinessCode")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Description).IsUnicode(false);

                entity.Property(e => e.EquivalentAtccode)
                    .HasColumnName("EquivalentATCCode")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EquivalentGlukoccupancy)
                    .HasColumnName("EquivalentGLUKOccupancy")
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.EquivalentIsopropCode)
                    .HasColumnName("EquivalentISOPropCode")
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.EquivalentRmscode)
                    .HasColumnName("EquivalentRMSCode")
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.Gdprpii).HasColumnName("GDPRPII");

                entity.Property(e => e.MunichReEquivalent)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.RmsmodelOccupancy)
                    .HasColumnName("RMSModelOccupancy")
                    .HasDefaultValueSql("((1))");

                entity.HasOne(d => d.OccupancySchemeNavigation)
                    .WithMany(p => p.Occupancy)
                    .HasForeignKey(d => d.OccupancyScheme)
                    .HasConstraintName("FK_Occupancy_OccupancyScheme");
            });

            modelBuilder.Entity<OccupancyScheme>(entity =>
            {
                entity.HasKey(e => e.OccupancyScheme1);

                entity.Property(e => e.OccupancyScheme1)
                    .HasColumnName("OccupancyScheme")
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<PolicyTransactions>(entity =>
            {
                entity.HasKey(e => e.TransId);

                entity.HasIndex(e => e.CompanyId)
                    .HasDatabaseName("ix_PolicyTransactions_CompanyId");

                entity.HasIndex(e => e.FormSetId)
                    .HasDatabaseName("ix_PolicyTransactions_FormSetID");

                entity.HasIndex(e => e.GlobalEndorsementId)
                    .HasDatabaseName("ix_PolicyTransactions_GlobalEndorsementID");

                entity.HasIndex(e => e.GlobalPolicyId)
                    .HasDatabaseName("ix_PolicyTransactions_GlobalPolicyID");

                entity.HasIndex(e => e.TempPremiumsId);

                entity.HasIndex(e => e.TransactionType)
                    .HasDatabaseName("ix_PolicyTransactions_TransactionType");

                entity.HasIndex(e => new { e.BordMonth, e.BordYear })
                    .HasDatabaseName("IX_BordMonth_BordYear");

                entity.HasIndex(e => new { e.BordYear, e.BordMonth })
                    .HasDatabaseName("ix_PolicyTransactions_BordPeriod");

                entity.HasIndex(e => new { e.CompanyId, e.PolicyNo })
                    .HasDatabaseName("IX_PolicyTransactions_PolicyNo_CompanyID");

                entity.HasIndex(e => new { e.OrderId, e.TransactionType })
                    .HasDatabaseName("ix_PolicyTransactions_OrderID_TransactionType");

                entity.HasIndex(e => new { e.PolicyNo, e.TransactionType });

                entity.HasIndex(e => new { e.TransId, e.PolicyNo })
                    .HasDatabaseName("ix_PolicyTransactions_TransID_PolicyNo");

                entity.HasIndex(e => new { e.TransactionType, e.GlobalPolicyId })
                    .HasDatabaseName("ix_PolicyTransactions_TransactionType_GlobalPolicyID");

                entity.HasIndex(e => new { e.CompanyId, e.InsuredState, e.TransId })
                    .HasDatabaseName("ix_PolicyTransactions_CompanyID_InsuredState_TransID");

                entity.HasIndex(e => new { e.CompanyId, e.TransId, e.InsuredState })
                    .HasDatabaseName("ix_PolicyTransactions_CompanyID_TransID_InsuredState");

                entity.HasIndex(e => new { e.PolicyNo, e.TransactionType, e.TransId })
                    .HasDatabaseName("ix_PolicyTransactions_TransactionType_TransID_Includes");

                entity.HasIndex(e => new { e.TransId, e.CompanyId, e.PolicyNo })
                    .HasDatabaseName("ix_PolicyTransactions_TransID_CompanyID_PolicyNo");

                entity.HasIndex(e => new { e.TransactionType, e.PolicyNo, e.CompanyId })
                    .HasDatabaseName("ix_PolicyTransactions_TransactionType_PolicyNo_CompanyID");

                entity.HasIndex(e => new { e.CompanyId, e.MigrationBusinessArea, e.MigrationContractRef, e.ContractPeriod });

                entity.HasIndex(e => new { e.CompanyId, e.TransId, e.BordYear, e.BordMonth })
                    .HasDatabaseName("ix_PolicyTransactions_CompanyID_TransID_BordYear_BordMonth");

                entity.HasIndex(e => new { e.GrossPremium, e.TempPremiumsId, e.TransId, e.CompanyId })
                    .HasDatabaseName("ix_PolicyTransactions_TempPremiumsID_TransID_CompanyID_Includes");

                entity.HasIndex(e => new { e.NumberofLocations, e.PolicyNo, e.CompanyId, e.TransId })
                    .HasDatabaseName("ix_PolicyTransactions_PolicyNo_CompanyID_TransID_Includes");

                entity.HasIndex(e => new { e.PolicyNo, e.TransactionType, e.TransId, e.PlacementType })
                    .HasDatabaseName("ix_PolicyTransactions_PolicyNo_TransactionType_TransID_PlacementType");

                entity.HasIndex(e => new { e.TransId, e.CompanyId, e.TransactionType, e.PolicyNo })
                    .HasDatabaseName("ix_PolicyTransactions_TransID_CompanyId_TransactionType_PolicyNo");

                entity.HasIndex(e => new { e.WindLimit, e.TransactionType, e.TempPremiumsId, e.PolicyNo })
                    .HasDatabaseName("ix_PolicyTransactions_TransactionType_TempPremiumsID_PolicyNo_Includes");

                entity.HasIndex(e => new { e.EffectiveDate, e.TransactionType, e.TransId, e.CompanyId, e.PolicyNo })
                    .HasDatabaseName("ix_PolicyTransactions_TransactionType_TransID_CompanyID_PolicyNo_Includes");

                entity.HasIndex(e => new { e.ExpirationDate, e.PolicyNo, e.BordYear, e.BordMonth, e.TransId })
                    .HasDatabaseName("ix_PolicyTransactions_PolicyNo_BordYear_BordMonth_TransID_Includes");

                entity.HasIndex(e => new { e.GrossPremium, e.BordYear, e.BordMonth, e.MigrationBusinessArea, e.TransId })
                    .HasDatabaseName("ix_PolicyTransactions_BordYear_BordMonth_MigrationBusinessArea_TransID_Includes");

                entity.HasIndex(e => new { e.PolicyNo, e.BordMonth, e.BordYear, e.TransId, e.TempPremiumsId })
                    .HasDatabaseName("ix_PolicyTransactions_BordMonth_Bordyear_TransID_TempPremiumsID");

                entity.HasIndex(e => new { e.PolicyNo, e.TransId, e.BordYear, e.BordMonth, e.TransactionType })
                    .HasDatabaseName("ix_PolicyTransactions_PolicyNo_TransID_BordYear_BordMonth_TransactionType");

                entity.HasIndex(e => new { e.PropertyLimit, e.CompanyId, e.PolicyNo, e.TransactionType, e.TransId })
                    .HasDatabaseName("ix_PolicyTransactions_CompanyID_PolicyNo_TransactionType_TransID_Includes");

                entity.HasIndex(e => new { e.RmsrunDate, e.TransId, e.OccupancyCode, e.OccupancyScheme, e.CompanyId })
                    .HasDatabaseName("ix_PolicyTransactions_TransID_OccupancyCode_OccupancyScheme_CompanyID_Includes");

                entity.HasIndex(e => new { e.TransId, e.PolicyNo, e.CompanyId, e.BordYear, e.BordMonth })
                    .HasDatabaseName("ix_PolicyTransactions_TransID_PolicyNo_CompanyID_BordYear_BordMonth");

                entity.HasIndex(e => new { e.TransactionType, e.PolicyNo, e.CompanyId, e.EffectiveDate, e.ExpirationDate })
                    .HasDatabaseName("ix_PolicyTransactions_TransactionType_PolicyNo_CompanyID_EffectiveDate_ExpirationDate");

                entity.HasIndex(e => new { e.TransactionType, e.PolicyNo, e.CompanyId, e.TransId, e.FormSetId })
                    .HasDatabaseName("ix_PolicyTransactions_TransactionType_PolicyNo_CompanyID_TransID_FormSetID");

                entity.HasIndex(e => new { e.TransactionType, e.PolicyNo, e.CompanyId, e.TransId, e.InvoiceNumber })
                    .HasDatabaseName("ix_PolicyTransactions_TransactionType_PolicyNo_CompanyID_TransID_InvoiceNumber");

                entity.HasIndex(e => new { e.BordMonth, e.BordYear, e.LiabilityPremium, e.ContractPeriod, e.TransId, e.PolicyNo })
                    .HasDatabaseName("ix_PolicyTransactions_ContractPeriod_TransID_PolicyNo_Includes");

                entity.HasIndex(e => new { e.PolicyNo, e.Triprapremium, e.LiabilityPremium, e.CrimePremium, e.BordYear, e.BordMonth, e.TransId })
                    .HasDatabaseName("ix_PolicyTransactions_BordYear_BordMonth_TransID_Includes");

                entity.HasIndex(e => new { e.BordMonth, e.BordYear, e.PolicyNo, e.EffectiveDate, e.InsuredState, e.PropertyPremium, e.CompanyId, e.TransId })
                    .HasDatabaseName("ix_PolicyTransactions_CompanyID_TransID_Includes");

                entity.HasIndex(e => new { e.RmsrunDate, e.TransactionType, e.QuakeLimit, e.TransId, e.WindLimit, e.CompanyId, e.OccupancyCode, e.OccupancyScheme })
                    .HasDatabaseName("ix_PolicyTransactions_TransactionType_QuakeLimit_TransID_WindLimit_CompanyID_OccupancyCode_OccupancyScheme_Includes");

                entity.HasIndex(e => new { e.GrossPremium, e.Commission, e.Bccommission, e.CompanyId, e.TransId, e.PolicyNo, e.EffectiveDate, e.ExpirationDate, e.ContractPeriod })
                    .HasDatabaseName("ix_PolicyTransactions_CompanyID_TransID_PolicyNo_EffectiveDate_ExpirationDate_ContractPeriod_Includes");

                entity.HasIndex(e => new { e.InsuredName, e.PolicyNo, e.InsuredZipCode, e.TotalPropertyLimit, e.LiabilityLimit, e.CompanyId, e.ExpirationDate, e.TransactionType, e.TransId })
                    .HasDatabaseName("ix_PolicyTransactions_CompanyID_ExpirationDate_TransactionType_TransID_Includes");

                entity.HasIndex(e => new { e.TransId, e.InsuredCity, e.InsuredCounty, e.InsuredState, e.InsuredZipCode, e.InsuredCountryScheme, e.InsuredCountryCode, e.GoogleX, e.GoogleY, e.InsuredStreet })
                    .HasDatabaseName("ix_PolicyTransactions_GeoGoogle");

                entity.HasIndex(e => new { e.TransId, e.InsuredStreet, e.InsuredCity, e.InsuredCounty, e.InsuredState, e.InsuredZipCode, e.InsuredCountryScheme, e.InsuredCountryCode, e.MrY, e.MrX })
                    .HasDatabaseName("ix_PolicyTransactions_GeoMR");

                entity.HasIndex(e => new { e.GrossPremium, e.EquipmentBreakdownPremium, e.TerrorismPremium, e.Triprapremium, e.LiabilityPremium, e.CalcEquipmentBreakDownPremium, e.CrimePremium, e.PolicyNo, e.CompanyId, e.TransId, e.TransactionType })
                    .HasDatabaseName("ix_PolicyTransactions_PolicyNo_CompanyID_TransID_TransactionType_Includes");

                entity.HasIndex(e => new { e.ExpiringPolicyNumber, e.HereonPercentage, e.Tivfgu, e.LiabilityPremium, e.TransactionType, e.CompanyId, e.TransId, e.PolicyNo, e.EffectiveDate, e.ExpirationDate, e.InsuredName, e.GrossPremium, e.PropertyPremium, e.PropertyLimit })
                    .HasDatabaseName("ix_PolicyTransactions_TransactionType_CompanyID_TransID_PolicyNo_EffectiveDate_ExpirationDate_InsuredName_GrossPremium_PropertyP");

                entity.HasIndex(e => new { e.PolicyNo, e.CompanyId, e.TransId, e.TransactionType, e.EffectiveDate, e.ExpirationDate, e.GrossPremium, e.PropertyLimit, e.PropertyLimitB, e.CompanyNumber, e.Commission, e.Bccommission, e.PropertyPremium, e.PropertyPremiumB, e.Triprapremium, e.LiabilityPremium })
                    .HasDatabaseName("ix_PolicyTransactions_PolicyNo_CompanyID_TransID_TransactionType_EffectiveDate_ExpirationDate_GrossPremium_PropertyLimit_Propert");

                entity.HasIndex(e => new { e.InsuredName, e.ExpirationDate, e.InsuredStreet, e.InsuredCity, e.InsuredZipCode, e.TotalPropertyPremium, e.TotalPropertyLimit, e.LiabilityPremium, e.LiabilityLimit, e.TransactionType, e.PolicyNo, e.CompanyId, e.InsuredState, e.TransId, e.EffectiveDate, e.BordYear, e.BordMonth })
                    .HasDatabaseName("ix_PolicyTransactions_TransactionType_PolicyNo_CompanyID_InsuredState_TransID_EffectiveDate_BordYear_BordMonth_Includes");

                entity.HasIndex(e => new { e.InsuredZipCode, e.TotalPropertyPremium, e.TotalPropertyLimit, e.LiabilityPremium, e.LiabilityLimit, e.InsuredName, e.ExpirationDate, e.InsuredStreet, e.InsuredCity, e.PolicyNo, e.TransId, e.BordMonth, e.BordYear, e.CompanyId, e.InsuredState, e.TransactionType, e.EffectiveDate })
                    .HasDatabaseName("ix_PolicyTransactions_PolicyNo_TransID_BordMonth_BordYear_CompanyID_InsuredState_TransactionType_EffectiveDate_Includes");

                entity.HasIndex(e => new { e.QuakeDeductible, e.FloodLimit, e.FloodDeductible, e.MrX, e.MrY, e.TotalPropertyLimit, e.Aopdeductible, e.WindLimit, e.WindHailHurricaneDeductible, e.Catdeductible, e.QuakeLimit, e.InsuredStreet, e.InsuredCity, e.InsuredCounty, e.InsuredState, e.InsuredZipCode, e.NumberofLocations, e.PolicyNo, e.CompanyId, e.EffectiveDate, e.ExpirationDate, e.TransId, e.TransactionType })
                    .HasDatabaseName("ix_PolicyTransactions_PolicyNo_CompanyID_EffectiveDate_ExpirationDate_TransID_TransactionType");

                entity.HasIndex(e => new { e.QuakeDeductible, e.FloodLimit, e.FloodDeductible, e.MrX, e.MrY, e.TotalPropertyLimit, e.Aopdeductible, e.WindLimit, e.WindHailHurricaneDeductible, e.Catdeductible, e.QuakeLimit, e.InsuredStreet, e.InsuredCity, e.InsuredCounty, e.InsuredState, e.InsuredZipCode, e.NumberofLocations, e.TransactionType, e.CompanyId, e.EffectiveDate, e.ExpirationDate, e.TransId, e.PolicyNo })
                    .HasDatabaseName("ix_PolicyTransactions_TransactionType_CompanyID_EffectiveDate_ExpirationDate_TransID_PolicyNo");

                entity.HasIndex(e => new { e.CompanyId, e.InsuredName, e.PlacementType, e.InsuredStreet, e.InsuredCity, e.Triprapremium, e.Tivfgu, e.AttachmentPoint, e.SizeofLayer, e.Catdeductible, e.QuakeLimit, e.QuakeDeductible, e.FloodLimit, e.FloodDeductible, e.TerrorismPremium, e.LimitBusinessInterruptionCoverageD, e.LimitOtherCoverageB, e.Aopdeductible, e.WindLimit, e.WindHailHurricaneDeductible, e.WindHailHurricaneDeductibleNamedStorm, e.HeatingLastUpdated, e.GrossPremium, e.TotalPropertyPremium, e.TotalPropertyLimit, e.LimitBuildingCoverageA, e.LimitContentsCoverageC, e.FloodZone, e.RoofConstructionCode, e.RoofShapeCode, e.RoofLastUpdated, e.WiringLastUpdated, e.PlumbingLastUpdated, e.OccupancyCode, e.ConstructionCodeScheme, e.ConstructionCode, e.YearBuilt, e.NumberofStories, e.Squarefootage, e.InsuredCounty, e.InsuredState, e.InsuredZipCode, e.InsuredCountryScheme, e.InsuredCountryCode, e.OccupancyScheme, e.PolicyNo, e.EffectiveDate, e.TransId, e.BordYear, e.BordMonth, e.TransactionType, e.ExpirationDate })
                    .HasDatabaseName("ix_PolicyTransactions_PolicyNo_EffectiveDate_TransID_BordYear_BordMonth_TransactionType_ExpirationDate");

                entity.HasIndex(e => new { e.Triprapremium, e.Tivfgu, e.AttachmentPoint, e.SizeofLayer, e.Catdeductible, e.QuakeLimit, e.QuakeDeductible, e.FloodLimit, e.FloodDeductible, e.TerrorismPremium, e.LimitBusinessInterruptionCoverageD, e.LimitOtherCoverageB, e.Aopdeductible, e.WindLimit, e.WindHailHurricaneDeductible, e.WindHailHurricaneDeductibleNamedStorm, e.HeatingLastUpdated, e.GrossPremium, e.TotalPropertyPremium, e.TotalPropertyLimit, e.LimitBuildingCoverageA, e.LimitContentsCoverageC, e.FloodZone, e.RoofConstructionCode, e.RoofShapeCode, e.RoofLastUpdated, e.WiringLastUpdated, e.PlumbingLastUpdated, e.OccupancyCode, e.ConstructionCodeScheme, e.ConstructionCode, e.YearBuilt, e.NumberofStories, e.Squarefootage, e.InsuredCounty, e.InsuredState, e.InsuredZipCode, e.InsuredCountryScheme, e.InsuredCountryCode, e.OccupancyScheme, e.InsuredName, e.PlacementType, e.InsuredStreet, e.InsuredCity, e.TransId, e.PolicyNo, e.CompanyId, e.TransactionType, e.EffectiveDate, e.ExpirationDate, e.BordYear, e.BordMonth })
                    .HasDatabaseName("ix_PolicyTransactions_TransID_PolicyNo_CompanyID_TransactionType_EffectiveDate_ExpirationDate_BordYear_BordMonth");

                entity.Property(e => e.TransId).HasColumnName("TransID");

                entity.Property(e => e.AccountingEffectiveDate).HasColumnType("datetime");

                entity.Property(e => e.AdditionalNamedInsured)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.AllOther).HasColumnType("money");

                entity.Property(e => e.AmigclassOfBusinessCode)
                    .HasColumnName("AMIGClassOfBusinessCode")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.AnimalLiablityCoverage).HasColumnType("money");

                entity.Property(e => e.Aopdeductible)
                    .HasColumnName("AOPDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.AttachmentPoint).HasColumnType("money");

                entity.Property(e => e.Bccommission)
                    .HasColumnName("BCCommission")
                    .HasColumnType("money");

                entity.Property(e => e.BodilyInjuryByAccidentLimit).HasColumnType("money");

                entity.Property(e => e.BodilyInjuryByDiseaseAggregateLimit).HasColumnType("money");

                entity.Property(e => e.BodilyInjuryByDiseaseEachEmployeeLimit).HasColumnType("money");

                entity.Property(e => e.CalcEquipmentBreakDownPremium).HasColumnType("money");

                entity.Property(e => e.CalcHomeSystemsProtectionPremium).HasColumnType("money");

                entity.Property(e => e.CalcIdentityTheftRecoveryPremium).HasColumnType("money");

                entity.Property(e => e.CalcServiceLinePremium).HasColumnType("money");

                entity.Property(e => e.Catdeductible)
                    .HasColumnName("CATDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.CedingCoNameRetailAgent)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.CertificateNumber)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.CoInsurancePercentage).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.Commission).HasColumnType("money");

                entity.Property(e => e.CompanyId).HasColumnName("CompanyID");

                entity.Property(e => e.CompanyNumber)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.ConstructionCode)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ConstructionCodeScheme)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.CoverageForm).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.CrimeDeductible).HasColumnType("money");

                entity.Property(e => e.CrimeLimit).HasColumnType("money");

                entity.Property(e => e.CrimePremium).HasColumnType("money");

                entity.Property(e => e.CrimeRate).HasColumnType("decimal(18, 0)");

                entity.Property(e => e.CyberLiabilityLimit).HasColumnType("money");

                entity.Property(e => e.CyberLiabilityPremium).HasColumnType("money");

                entity.Property(e => e.DateCreated).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.DateOfLastLoss).HasColumnType("date");

                entity.Property(e => e.DqicoreScore)
                    .HasColumnName("DQICoreScore")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DqiquakeScore)
                    .HasColumnName("DQIQuakeScore")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DqiwindScore)
                    .HasColumnName("DQIWindScore")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.EffectiveDate).HasColumnType("datetime");

                entity.Property(e => e.Ellimit)
                    .HasColumnName("ELLimit")
                    .HasColumnType("money");

                entity.Property(e => e.Elpremium)
                    .HasColumnName("ELPremium")
                    .HasColumnType("money");

                entity.Property(e => e.EndorsementNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EngineQuoteEnquiryId)
                    .HasColumnName("EngineQuoteEnquiryID")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.EqappendagesandOrnamentation).HasColumnName("EQAppendagesandOrnamentation");

                entity.Property(e => e.EqbaseIsolation).HasColumnName("EQBaseIsolation");

                entity.Property(e => e.EqcladdingType).HasColumnName("EQCladdingType");

                entity.Property(e => e.EqconstructionQuality).HasColumnName("EQConstructionQuality");

                entity.Property(e => e.EqcrippleWalls).HasColumnName("EQCrippleWalls");

                entity.Property(e => e.EqengineeredFoundation).HasColumnName("EQEngineeredFoundation");

                entity.Property(e => e.EqequipmentSupportMaintenance).HasColumnName("EQEquipmentSupportMaintenance");

                entity.Property(e => e.EqframeBolted).HasColumnName("EQFrameBolted");

                entity.Property(e => e.EqmechanicalandElectricalEquipmentEarthquakeBracing).HasColumnName("EQMechanicalandElectricalEquipmentEarthquakeBracing");

                entity.Property(e => e.EqplanIrregularity).HasColumnName("EQPlanIrregularity");

                entity.Property(e => e.Eqpounding).HasColumnName("EQPounding");

                entity.Property(e => e.EqshortColumnCondition).HasColumnName("EQShortColumnCondition");

                entity.Property(e => e.EqsoftStory).HasColumnName("EQSoftStory");

                entity.Property(e => e.EqsprinklerLeakageCoverageFlag)
                    .HasColumnName("EQSprinklerLeakageCoverageFlag")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.EqsprinklerLeakageSusceptibility).HasColumnName("EQSprinklerLeakageSusceptibility");

                entity.Property(e => e.EqsprinklerType).HasColumnName("EQSprinklerType");

                entity.Property(e => e.EqstructuralUpgrade).HasColumnName("EQStructuralUpgrade");

                entity.Property(e => e.EqtiltUpRetrofit).HasColumnName("EQTiltUpRetrofit");

                entity.Property(e => e.EquipmentBreakdown)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.EquipmentBreakdownPremium).HasColumnType("money");

                entity.Property(e => e.EqunreinforcedMasonryPartitionsorChimneys).HasColumnName("EQUnreinforcedMasonryPartitionsorChimneys");

                entity.Property(e => e.EqunreinforcedMasonryRetrofit).HasColumnName("EQUnreinforcedMasonryRetrofit");

                entity.Property(e => e.EqverticalIrregularity).HasColumnName("EQVerticalIrregularity");

                entity.Property(e => e.ExpirationDate).HasColumnType("datetime");

                entity.Property(e => e.ExpiringPolicyNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ExtendedLiabilityRentedLocationsFamilies)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ExtendedLiabilityToRentedLocationsAmount).HasColumnType("money");

                entity.Property(e => e.FirstFloorHeightAboveGround).HasColumnType("decimal(3, 1)");

                entity.Property(e => e.FlfoundationType).HasColumnName("FLFoundationType");

                entity.Property(e => e.FloodDeductible).HasColumnType("money");

                entity.Property(e => e.FloodLimit).HasColumnType("money");

                entity.Property(e => e.FloodZone)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.ForDebugRequestPricingEngineVersion)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FormSetId)
                    .HasColumnName("FormSetID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FullTermEndorsementPremium).HasColumnType("money");

                entity.Property(e => e.GeoCodeInsuredAddressText).HasComputedColumnSql("([GeoCodeInsuredAddress].[STAsText]())");

                entity.Property(e => e.GlaggregateLimit)
                    .HasColumnName("GLAggregateLimit")
                    .HasColumnType("money");

                entity.Property(e => e.GlobalEndorsementId).HasColumnName("GlobalEndorsementID");

                entity.Property(e => e.GlobalPolicyId).HasColumnName("GlobalPolicyID");

                entity.Property(e => e.GlukapprovedBy)
                    .HasColumnName("GLUKApprovedBy")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.GlukapprovedDate)
                    .HasColumnName("GLUKApprovedDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.GlukbppLimit)
                    .HasColumnName("GLUKBppLimit")
                    .HasColumnType("money");

                entity.Property(e => e.GlukbrokasureTransactionNumber).HasColumnName("GLUKBrokasureTransactionNumber");

                entity.Property(e => e.GlukbusinessIncome)
                    .HasColumnName("GLUKBusinessIncome")
                    .HasColumnType("money");

                entity.Property(e => e.GlukchangeDescription)
                    .HasColumnName("GLUKChangeDescription")
                    .IsUnicode(false);

                entity.Property(e => e.Glukcpllimit)
                    .HasColumnName("GLUKCPLLimit")
                    .HasColumnType("money");

                entity.Property(e => e.Glukcplpremium)
                    .HasColumnName("GLUKCPLPremium")
                    .HasColumnType("money");

                entity.Property(e => e.GlukdistanceFromSaltWater)
                    .HasColumnName("GLUKDistanceFromSaltWater")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.GlukfireDeductible)
                    .HasColumnName("GLUKFireDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukfireIncluded)
                    .HasColumnName("GLUKFireIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukfloodIncluded)
                    .HasColumnName("GLUKFloodIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukhailDeductible)
                    .HasColumnName("GLUKHailDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukhailIncluded)
                    .HasColumnName("GLUKHailIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukinHouseEndorsementNumber).HasColumnName("GLUKInHouseEndorsementNumber");

                entity.Property(e => e.GlukpaymentBasis)
                    .HasColumnName("GLUKPaymentBasis")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukquakeIncluded)
                    .HasColumnName("GLUKQuakeIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GluksltbrokerId).HasColumnName("GLUKSLTBrokerID");

                entity.Property(e => e.GlukspareText)
                    .HasColumnName("GLUKSpareText")
                    .IsUnicode(false);

                entity.Property(e => e.Glukwcapremium)
                    .HasColumnName("GLUKWCAPremium")
                    .HasColumnType("money");

                entity.Property(e => e.GlukwindIncluded)
                    .HasColumnName("GLUKWindIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukwindstormDeductible)
                    .HasColumnName("GLUKWindstormDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukzonePerilsId).HasColumnName("GLUKZonePerilsID");

                entity.Property(e => e.GoogleElevation).HasColumnName("GOOGLE_Elevation");

                entity.Property(e => e.GoogleElevationResolution).HasColumnName("GOOGLE_Elevation_Resolution");

                entity.Property(e => e.GoogleGeoCodeDate)
                    .HasColumnName("GOOGLE_GeoCodeDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.GoogleLocationType)
                    .HasColumnName("GOOGLE_LOCATION_TYPE")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.GoogleX).HasColumnName("GOOGLE_X");

                entity.Property(e => e.GoogleY).HasColumnName("GOOGLE_Y");

                entity.Property(e => e.GrossPremium).HasColumnType("money");

                entity.Property(e => e.HeatingLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.HereonPercentage).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.HistoricTiv1yearPrior)
                    .HasColumnName("HistoricTIV1YearPrior")
                    .HasColumnType("money");

                entity.Property(e => e.HistoricTiv2yearPrior)
                    .HasColumnName("HistoricTIV2YearPrior")
                    .HasColumnType("money");

                entity.Property(e => e.HistoricTiv3yearPrior)
                    .HasColumnName("HistoricTIV3YearPrior")
                    .HasColumnType("money");

                entity.Property(e => e.HomeSystemsProtectionPremium).HasColumnType("money");

                entity.Property(e => e.IdentityTheftRecovery)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.IdentityTheftRecoveryPremium).HasColumnType("money");

                entity.Property(e => e.Impremium)
                    .HasColumnName("IMPremium")
                    .HasColumnType("money");

                entity.Property(e => e.ImpremiumPolicyWide)
                    .HasColumnName("IMPremiumPolicyWide")
                    .HasColumnType("money");

                entity.Property(e => e.InHomeBusinessCoverageBusinessName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.InHomeBusinessCoverageGrossReceipts).HasColumnType("money");

                entity.Property(e => e.InHomeBusinessCoverageTypeOfBusiness)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.IncludedForms).IsUnicode(false);

                entity.Property(e => e.InlandMarineFloodLimitPolicyWide).HasColumnType("money");

                entity.Property(e => e.InlandMarineLimit).HasColumnType("money");

                entity.Property(e => e.InlandMarineLimitPolicyWide).HasColumnType("money");

                entity.Property(e => e.InlandMarineQuakeLimitPolicyWide).HasColumnType("money");

                entity.Property(e => e.InlandMarineWindLimitPolicyWide).HasColumnType("money");

                entity.Property(e => e.InsuredAddressText)
                    .HasMaxLength(375)
                    .IsUnicode(false)
                    .HasComputedColumnSql("((((((((([InsuredStreet]+',')+[InsuredCity])+',')+isnull([InsuredCounty]+',',''))+[InsuredState])+',')+[InsuredZipCode])+',')+isnull([InsuredCountryCode],'USA'))");

                entity.Property(e => e.InsuredCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCountryCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCountryScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCounty)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredDoingBusinessAs)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredEntityId)
                    .HasColumnName("InsuredEntityID")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredEntityType)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.InsuredName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredStreet)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredZipCodePlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.InvoiceNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.IsocurrencyCode)
                    .HasColumnName("ISOCurrencyCode")
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Isoglclass)
                    .HasColumnName("ISOGLClass")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.IsopropertyCode)
                    .HasColumnName("ISOPropertyCode")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.LiabilityDeductible).HasColumnType("money");

                entity.Property(e => e.LiabilityLimit).HasColumnType("money");

                entity.Property(e => e.LiabilityPremium).HasColumnType("money");

                entity.Property(e => e.LimitBuildingCoverageA).HasColumnType("money");

                entity.Property(e => e.LimitBusinessInterruptionCoverageD).HasColumnType("money");

                //entity.Property(e => e.LimitCamerasHo2303)
                //    .HasColumnName("LimitCameras_HO2303")
                //    .HasColumnType("money");

                //entity.Property(e => e.LimitCoinCollectionsHo2303)
                //    .HasColumnName("LimitCoinCollections_HO2303")
                //    .HasColumnType("money");

                entity.Property(e => e.LimitContentsCoverageC).HasColumnType("money");

                entity.Property(e => e.LimitCoverageE).HasColumnType("money");

                //entity.Property(e => e.LimitFineArtsExclBreakageHo2303)
                //    .HasColumnName("LimitFineArtsExclBreakage_HO2303")
                //    .HasColumnType("money");

                //entity.Property(e => e.LimitFineArtsInclBreakageHo2303)
                //    .HasColumnName("LimitFineArtsInclBreakage_HO2303")
                //    .HasColumnType("money");

                entity.Property(e => e.LimitFirearms).HasColumnType("money");

                //entity.Property(e => e.LimitFursHo2303)
                //    .HasColumnName("LimitFurs_HO2303")
                //    .HasColumnType("money");

                //entity.Property(e => e.LimitGolfingEquipmentHo2303)
                //    .HasColumnName("LimitGolfingEquipment_HO2303")
                //    .HasColumnType("money");

                //entity.Property(e => e.LimitIdentityFraud).HasColumnType("money");

                 entity.Property(e => e.LimitJewellry).HasColumnType("money");

                //entity.Property(e => e.LimitJewelryHo2303)
                //    .HasColumnName("LimitJewelry_HO2303")
                //    .HasColumnType("money");

                entity.Property(e => e.LimitMoneyBanknotes).HasColumnType("money");

                //entity.Property(e => e.LimitMusicalInstrumentsHo2303)
                //    .HasColumnName("LimitMusicalInstruments_HO2303")
                //    .HasColumnType("money");

                entity.Property(e => e.LimitOtherCoverageB).HasColumnType("money");

                entity.Property(e => e.LimitPortableElectronicDevices).HasColumnType("money");

                entity.Property(e => e.LimitResidenceBurglary).HasColumnType("money");

                entity.Property(e => e.LimitSecurities).HasColumnType("money");

                entity.Property(e => e.LimitSilverware).HasColumnType("money");

                //entity.Property(e => e.LimitSilverwareHo2303)
                //    .HasColumnName("LimitSilverware_HO2303")
                //    .HasColumnType("money");

                //entity.Property(e => e.LimitStampCollectionsHo2303)
                //    .HasColumnName("LimitStampCollections_HO2303")
                //    .HasColumnType("money");

                entity.Property(e => e.LossAssessmentCoverage).HasColumnType("money");

                entity.Property(e => e.MailingCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MailingCountryCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.MailingCountryScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.MailingCounty)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MailingState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.MailingStreet)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.MailingZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.MailingZipCodePlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ManualCheckedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ManualCheckedDate).HasColumnType("datetime");

                entity.Property(e => e.ManualCheckedNotes).IsUnicode(false);

                entity.Property(e => e.MedicalExpensesLimit).HasColumnType("money");

                entity.Property(e => e.MgaquoteId)
                    .HasColumnName("MGAQuoteID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MgaquoteVersion)
                    .HasColumnName("MGAQuoteVersion")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MgasubmissionId)
                    .HasColumnName("MGASubmissionID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MigrationBusinessArea)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MigrationContractRef)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.MigrationOldSystemId).HasColumnName("MigrationOldSystemID");

                entity.Property(e => e.MigrationSectionNumber)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.MinFloodDeductible).HasColumnType("money");

                entity.Property(e => e.MinHailHurricaneDeductible).HasColumnType("money");

                entity.Property(e => e.MinNamedStormDeductible).HasColumnType("money");

                entity.Property(e => e.MinQuakeDeductible).HasColumnType("money");

                entity.Property(e => e.MiscProfessionalLiabilityLimit).HasColumnType("money");

                entity.Property(e => e.MiscProfessionalLiabilityPremium).HasColumnType("money");

                entity.Property(e => e.ModifierMarketPriceAdjustment).HasColumnType("decimal(5, 4)");

                entity.Property(e => e.ModifierUnderwriterPriceAdjustment).HasColumnType("decimal(10, 8)");

                entity.Property(e => e.MrAdditionalElevation).HasColumnName("MR_Additional_ELEVATION");

                entity.Property(e => e.MrAdditionalPopulation).HasColumnName("MR_Additional_POPULATION");

                entity.Property(e => e.MrCity)
                    .HasColumnName("MR_CITY")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCoordind).HasColumnName("MR_COORDIND");

                entity.Property(e => e.MrCrestaHighresId)
                    .HasColumnName("MR_CRESTA_HIGHRES_ID")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaHighresName)
                    .HasColumnName("MR_CRESTA_HIGHRES_NAME")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaLowresId)
                    .HasColumnName("MR_CRESTA_LOWRES_ID")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaLowresName)
                    .HasColumnName("MR_CRESTA_LOWRES_NAME")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaid)
                    .HasColumnName("MR_CRESTAID")
                    .HasMaxLength(255);

                entity.Property(e => e.MrCrestaname)
                    .HasColumnName("MR_CRESTANAME")
                    .HasMaxLength(255);

                entity.Property(e => e.MrDistanceToCoast).HasColumnName("MR_DISTANCE_TO_COAST");

                entity.Property(e => e.MrDistanceToFault).HasColumnName("MR_DISTANCE_TO_FAULT");

                entity.Property(e => e.MrErrAdditional)
                    .HasColumnName("MR_ERR_Additional")
                    .HasMaxLength(150);

                entity.Property(e => e.MrErrCresta)
                    .HasColumnName("MR_ERR_CRESTA")
                    .HasMaxLength(255);

                entity.Property(e => e.MrErrCrestaHighres)
                    .HasColumnName("MR_ERR_CRESTA_HIGHRES")
                    .HasMaxLength(150);

                entity.Property(e => e.MrErrCrestaLowres)
                    .HasColumnName("MR_ERR_CRESTA_LOWRES")
                    .HasMaxLength(150);

                entity.Property(e => e.MrErrGcd)
                    .HasColumnName("MR_ERR_GCD")
                    .HasMaxLength(255);

                entity.Property(e => e.MrErrHazard)
                    .HasColumnName("MR_ERR_Hazard")
                    .HasMaxLength(255);

                entity.Property(e => e.MrErrRiverflood).HasColumnName("MR_ERR_RIVERFLOOD");

                entity.Property(e => e.MrGeoCodeDate)
                    .HasColumnName("MR_GeoCodeDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.MrGeozoneType)
                    .HasColumnName("MR_GEOZONE_TYPE")
                    .HasMaxLength(150);

                entity.Property(e => e.MrHazardEarthquake).HasColumnName("MR_Hazard_EARTHQUAKE");

                entity.Property(e => e.MrHazardExtratropicalstorm).HasColumnName("MR_Hazard_EXTRATROPICALSTORM");

                entity.Property(e => e.MrHazardFlashflood).HasColumnName("MR_Hazard_FLASHFLOOD");

                entity.Property(e => e.MrHazardHailstorm).HasColumnName("MR_Hazard_HAILSTORM");

                entity.Property(e => e.MrHazardLightning).HasColumnName("MR_Hazard_LIGHTNING");

                entity.Property(e => e.MrHazardStormsurge).HasColumnName("MR_Hazard_STORMSURGE");

                entity.Property(e => e.MrHazardTcyclone).HasColumnName("MR_Hazard_TCYCLONE");

                entity.Property(e => e.MrHazardTornado).HasColumnName("MR_Hazard_TORNADO");

                entity.Property(e => e.MrHazardTropicalcyclone).HasColumnName("MR_Hazard_TROPICALCYCLONE");

                entity.Property(e => e.MrHazardTsunami).HasColumnName("MR_Hazard_TSUNAMI");

                entity.Property(e => e.MrHazardVolcano).HasColumnName("MR_Hazard_VOLCANO");

                entity.Property(e => e.MrHazardWildfire).HasColumnName("MR_Hazard_WILDFIRE");

                entity.Property(e => e.MrHazardWstorm).HasColumnName("MR_Hazard_WSTORM");

                entity.Property(e => e.MrHnr)
                    .HasColumnName("MR_HNR")
                    .HasMaxLength(150);

                entity.Property(e => e.MrIso3)
                    .HasColumnName("MR_ISO3")
                    .HasMaxLength(150);

                entity.Property(e => e.MrQualind).HasColumnName("MR_QUALIND");

                entity.Property(e => e.MrRiskIndex).HasColumnName("MR_RiskIndex");

                entity.Property(e => e.MrRiskIndexEq).HasColumnName("MR_RiskIndexEq");

                entity.Property(e => e.MrRiskIndexFl).HasColumnName("MR_RiskIndexFl");

                entity.Property(e => e.MrRiskIndexSt).HasColumnName("MR_RiskIndexST");

                entity.Property(e => e.MrRiskScore).HasColumnName("MR_RiskScore");

                entity.Property(e => e.MrRiskScoreEq).HasColumnName("MR_RiskScoreEq");

                entity.Property(e => e.MrRiskScoreFl).HasColumnName("MR_RiskScoreFl");

                entity.Property(e => e.MrRiskScoreSt).HasColumnName("MR_RiskScoreST");

                entity.Property(e => e.MrRiverfloodRiverflood).HasColumnName("MR_RIVERFLOOD_RIVERFLOOD");

                entity.Property(e => e.MrSoil).HasColumnName("MR_SOIL");

                entity.Property(e => e.MrStr)
                    .HasColumnName("MR_STR")
                    .HasMaxLength(150);

                entity.Property(e => e.MrX).HasColumnName("MR_X");

                entity.Property(e => e.MrY).HasColumnName("MR_Y");

                entity.Property(e => e.MrZip)
                    .HasColumnName("MR_ZIP")
                    .HasMaxLength(150);

                entity.Property(e => e.Naic)
                    .HasColumnName("NAIC")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.NetPremium).HasColumnType("money");

                entity.Property(e => e.Notes).IsUnicode(false);

                entity.Property(e => e.OccupancyCode)
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.OccupancyScheme)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.OrderId).HasColumnName("OrderID");

                entity.Property(e => e.OriginalTransId).HasColumnName("OriginalTransID");

                entity.Property(e => e.ParentRui)
                    .HasColumnName("ParentRUI")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Payable)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.PersonalAccidentPremium).HasColumnType("money");

                entity.Property(e => e.PersonalInjuryCoverage).HasColumnType("money");

                entity.Property(e => e.PlacementType).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.PlcommercialIndicator)
                    .HasColumnName("PLCommercialIndicator")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Pllimit)
                    .HasColumnName("PLLimit")
                    .HasColumnType("money");

                entity.Property(e => e.Plpremium)
                    .HasColumnName("PLPremium")
                    .HasColumnType("money");

                entity.Property(e => e.PlumbingLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.PolicyFee).HasColumnType("money");

                entity.Property(e => e.PolicyNo)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PolicyProcessorSystemName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.PremiumBasis)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.PremiumBasisValue).HasColumnType("money");

                entity.Property(e => e.PricingEngineId)
                    .HasColumnName("PricingEngineID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ProductsCompletedOperationsPremium).HasColumnType("money");

                entity.Property(e => e.PropertyLimit).HasColumnType("money");

                entity.Property(e => e.PropertyLimitB).HasColumnType("money");

                entity.Property(e => e.PropertyPremium).HasColumnType("money");

                entity.Property(e => e.PropertyPremiumB).HasColumnType("money");

                entity.Property(e => e.ProtectionClass)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Protections)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.QuakeDeductible).HasColumnType("money");

                entity.Property(e => e.QuakeLimit).HasColumnType("money");

                entity.Property(e => e.Rate).HasColumnType("decimal(12, 8)");

                entity.Property(e => e.RateAllOther).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.RateProductsCompletedOperations).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.RatingSessionId)
                    .HasColumnName("RatingSessionID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RetroActiveDate).HasColumnType("datetime");

                entity.Property(e => e.Rms17completeDate)
                    .HasColumnName("RMS17CompleteDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.Rms17geoCompleteDate)
                    .HasColumnName("RMS17GeoCompleteDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.Rms17pickupDate)
                    .HasColumnName("RMS17PickupDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.RmserrorDate)
                    .HasColumnName("RMSErrorDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.RmspickupDate)
                    .HasColumnName("RMSPickupDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.RmsproductVersion)
                    .HasColumnName("RMSProductVersion")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.RmspurePremiumQuake)
                    .HasColumnName("RMSPurePremiumQuake")
                    .HasColumnType("money");

                entity.Property(e => e.RmspurePremiumScs)
                    .HasColumnName("RMSPurePremiumSCS")
                    .HasColumnType("money");

                entity.Property(e => e.RmspurePremiumWind)
                    .HasColumnName("RMSPurePremiumWind")
                    .HasColumnType("money");

                entity.Property(e => e.RmspurePremiumWinterStorm)
                    .HasColumnName("RMSPurePremiumWinterStorm")
                    .HasColumnType("money");

                entity.Property(e => e.RmsrunDate)
                    .HasColumnName("RMSRunDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.RoofConstructionCode).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.RoofConstructionScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.RoofLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.RoofShapeCode).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.RoofShapeScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.ServiceLinePremium).HasColumnType("money");

                entity.Property(e => e.SizeofLayer).HasColumnType("money");

                entity.Property(e => e.SltbrokerAddress)
                    .HasColumnName("SLTBrokerAddress")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SltbrokerName)
                    .HasColumnName("SLTBrokerName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SltbrokerNumber)
                    .HasColumnName("SLTBrokerNumber")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Sltstate)
                    .HasColumnName("SLTState")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Squarefootage).HasColumnType("decimal(7, 0)");

                entity.Property(e => e.StructuresRentedOffPremisesCoverage)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.StructuresRentedOnPremisesCoverage)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SubCompanyId).HasColumnName("SubCompanyID");

                entity.Property(e => e.SubCoverageCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerCity)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerCounty)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerState)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerStreet)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerZipCode)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerZipCodePlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.SurplusLinesTransactionNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SurveyFees).HasColumnType("money");

                entity.Property(e => e.TempPremiumsId).HasColumnName("TempPremiumsID");

                entity.Property(e => e.TerritoriesCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TerrorismPremium).HasColumnType("money");

                entity.Property(e => e.Tivfgu)
                    .HasColumnName("TIVFGU")
                    .HasColumnType("money");

                entity.Property(e => e.TotalInsurancePremiumTax).HasColumnType("money");

                entity.Property(e => e.TotalPropertyLimit).HasColumnType("money");

                entity.Property(e => e.TotalPropertyPremium).HasColumnType("money");

                entity.Property(e => e.TransactionType)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Triprapremium)
                    .HasColumnName("TRIPRAPremium")
                    .HasColumnType("money");

                entity.Property(e => e.UnderwriterApprovedNotes).IsUnicode(false);

                entity.Property(e => e.UnderwriterName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.UnderwriterPremiumOffer).HasColumnType("money");

                entity.Property(e => e.UserCreated)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserModified)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.WindHailHurricaneDeductible).HasColumnType("money");

                entity.Property(e => e.WindHailHurricaneDeductibleNamedStorm).HasColumnType("money");

                entity.Property(e => e.WindLimit).HasColumnType("money");

                entity.Property(e => e.WiringLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.Xlsoffice)
                    .HasColumnName("XLSOffice")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.YearBuilt).HasColumnType("decimal(4, 0)");
            });

            modelBuilder.Entity<PolicyTransactionsContracts>(entity =>
            {
                entity.HasKey(e => new { e.TransId, e.CompanyId, e.BusinessArea, e.ContractRef, e.ContractYear })
                    .HasName("PK_PolicyTransactionsContracts");

                entity.ToTable("PolicyTransactions_Contracts");

                entity.HasIndex(e => new { e.BusinessArea, e.TransId })
                    .HasDatabaseName("ix_PolicyTransactions_Contracts_BusinessArea_TransID");

                entity.HasIndex(e => new { e.TransId, e.BusinessArea })
                    .HasDatabaseName("ix_PolicyTransactions_Contracts_TransID_BusinessArea");

                entity.HasIndex(e => new { e.CompanyId, e.ContractYear, e.ContractRef })
                    .HasDatabaseName("ix_PolicyTransactions_Contracts_CompanyID_ContractYear_ContractRef");

                entity.HasIndex(e => new { e.ContractRef, e.ContractYear, e.TransId })
                    .HasDatabaseName("ix_PolicyTransactions_Contracts_ContractRef_ContractYear_TransID");

                entity.HasIndex(e => new { e.BusinessArea, e.CompanyId, e.ContractYear, e.ContractRef })
                    .HasDatabaseName("ix_PolicyTransactions_Contracts_BusinessArea_CompanyID_ContractYear_ContractRef");

                entity.HasIndex(e => new { e.ContractShare, e.TransId, e.ContractRef, e.BusinessArea })
                    .HasDatabaseName("ix_PolicyTransactions_Contracts_TransID_ContractRef_BusinessArea_Includes");

                entity.HasIndex(e => new { e.TransId, e.BusinessArea, e.CompanyId, e.ContractYear, e.ContractRef })
                    .HasDatabaseName("ix_PolicyTransactions_Contracts_TransID_BusinessArea_CompanyID_ContractYear_ContractRef");

                entity.HasIndex(e => new { e.BusinessArea, e.ContractShare, e.LiabilityShare, e.Commission, e.ContractRef, e.TransId })
                    .HasDatabaseName("ix_PolicyTransactions_Contracts_ContractRef_TransID_Includes");

                entity.HasIndex(e => new { e.CompanyId, e.BusinessArea, e.ContractRef, e.ContractYear, e.ContractShare, e.TransId })
                    .HasDatabaseName("ix_PolicyTransactions_Contracts_TransID_Includes");

                entity.HasIndex(e => new { e.ContractShare, e.LiabilityShare, e.BusinessArea, e.TransId, e.CompanyId, e.ContractRef, e.ContractYear })
                    .HasDatabaseName("ix_PolicyTransactions_Contracts_BusinessArea_TransID_CompanyID_ContractRef_ContractYear_Includes");

                entity.HasIndex(e => new { e.ContractShare, e.LiabilityShare, e.TransId, e.CompanyId, e.ContractRef, e.ContractYear, e.BusinessArea })
                    .HasDatabaseName("ix_PolicyTransactions_Contracts_TransID_CompanyID_ContractRef_ContractYear_BusinessArea_Includes");

                entity.Property(e => e.TransId).HasColumnName("TransID");

                entity.Property(e => e.CompanyId).HasColumnName("CompanyID");

                entity.Property(e => e.BusinessArea)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ContractRef)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.Bccommission)
                    .HasColumnName("BCCommission")
                    .HasColumnType("money");

                entity.Property(e => e.BccommissionPercentage)
                    .HasColumnName("BCCommissionPercentage")
                    .HasColumnType("decimal(6, 3)");

                entity.Property(e => e.Commission).HasColumnType("money");

                entity.Property(e => e.CommissionPercentage).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.ContractShare).HasDefaultValueSql("((0))");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.EquipmentBreakdownShare).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.GrossPremium).HasColumnType("money");

                entity.Property(e => e.LiabilityShare).HasDefaultValueSql("((0))");

                entity.Property(e => e.Notes).IsUnicode(false);

                entity.Property(e => e.UserModified)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.Trans)
                    .WithMany(p => p.PolicyTransactionsContracts)
                    .HasForeignKey(d => d.TransId)
                    .HasConstraintName("FK_PolicyTransactionsContracts_PolicyTransactions");

                entity.HasOne(d => d.AgentsContracts)
                    .WithMany(p => p.PolicyTransactionsContracts)
                    .HasForeignKey(d => new { d.CompanyId, d.BusinessArea, d.ContractRef, d.ContractYear })
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PolicyTransactionsContracts_AgentsContracts");
            });

            modelBuilder.Entity<PolicyTransactionsLocations>(entity =>
            {
                entity.HasKey(e => e.LocId)
                    .HasName("PK_PolicyTransactionsLocations");

                entity.ToTable("PolicyTransactions_Locations");

                entity.HasIndex(e => new { e.LocId, e.TempLocationsId })
                    .HasDatabaseName("ix_PolicyTransactions_Locations_TempLocationsID_includes");

                entity.HasIndex(e => new { e.TransId, e.LocationNumber })
                    .HasDatabaseName("ix_PolicyTransactions_Locations_TransID_LocationNumber");

                entity.HasIndex(e => new { e.WindLimit, e.TransId })
                    .HasDatabaseName("ix_PolicyTransactions_Locations_TransID_Includes");

                entity.HasIndex(e => new { e.LocationNumber, e.LocationTransactionType, e.TransId, e.LocId })
                    .HasDatabaseName("ix_PolicyTransactions_Locations_LocationNumber_LocationTransactionType_TransID_LocID");

                entity.HasIndex(e => new { e.LocId, e.InsuredStreet, e.GoogleX, e.GoogleY, e.InsuredCity, e.InsuredCounty, e.InsuredState, e.InsuredZipCode, e.InsuredCountryScheme, e.InsuredCountryCode })
                    .HasDatabaseName("ix_PolicyTransactions_Locations_GOOGLE_X_GOOGLE_Y_InsuredCity_InsuredCounty_InsuredState_InsuredZipCode_InsuredCountryScheme_Ins");

                entity.HasIndex(e => new { e.LocId, e.MrX, e.MrY, e.InsuredStreet, e.TransId, e.InsuredCity, e.InsuredCounty, e.InsuredState, e.InsuredZipCode, e.InsuredCountryScheme, e.InsuredCountryCode })
                    .HasDatabaseName("ix_PolicyTransactions_Locations_MR_X_MR_Y_InsuredStreet_TransID_InsuredCity_InsuredCounty_InsuredState_InsuredZipCode_InsuredCou");

                entity.HasIndex(e => new { e.LocationNumber, e.InsuredStreet, e.InsuredCity, e.InsuredZipCode, e.TotalPropertyPremium, e.TotalPropertyLimit, e.LiabilityPremium, e.LiabilityLimit, e.LocId, e.InsuredState, e.TransId })
                    .HasDatabaseName("ix_PolicyTransactions_Locations_LocID_InsuredState_TransID_Includes");

                entity.Property(e => e.LocId).HasColumnName("LocID");

                entity.Property(e => e.AllOther).HasColumnType("money");

                entity.Property(e => e.AlternateHeatSourceCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.AmigclassOfBusinessCode)
                    .HasColumnName("AMIGClassOfBusinessCode")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Aopdeductible)
                    .HasColumnName("AOPDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.BasementType)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.BuildingCoverageAvaluationBasis)
                    .HasColumnName("BuildingCoverageAValuationBasis")
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.BuildingNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CalcEquipmentBreakDownPremium).HasColumnType("money");

                entity.Property(e => e.CalcHomeSystemsProtectionPremium).HasColumnType("money");

                entity.Property(e => e.CalcServiceLinePremium).HasColumnType("money");

                entity.Property(e => e.Catdeductible)
                    .HasColumnName("CATDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.CoInsurancePercentage).HasColumnType("decimal(5, 3)");

                entity.Property(e => e.ConstructionCode)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ConstructionCodeScheme)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ContentsCoverageCvaluationBasis)
                    .HasColumnName("ContentsCoverageCValuationBasis")
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.CrimeDeductible).HasColumnType("money");

                entity.Property(e => e.CrimeLimit).HasColumnType("money");

                entity.Property(e => e.CrimePremium).HasColumnType("money");

                entity.Property(e => e.CrimeRate).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.DateCreated).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.DqicoreScore)
                    .HasColumnName("DQICoreScore")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DqiquakeScore)
                    .HasColumnName("DQIQuakeScore")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DqiwindScore)
                    .HasColumnName("DQIWindScore")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.Ellimit)
                    .HasColumnName("ELLimit")
                    .HasColumnType("money");

                entity.Property(e => e.Elpremium)
                    .HasColumnName("ELPremium")
                    .HasColumnType("money");

                entity.Property(e => e.EqappendagesandOrnamentation).HasColumnName("EQAppendagesandOrnamentation");

                entity.Property(e => e.EqbaseIsolation).HasColumnName("EQBaseIsolation");

                entity.Property(e => e.EqcladdingType).HasColumnName("EQCladdingType");

                entity.Property(e => e.EqconstructionQuality).HasColumnName("EQConstructionQuality");

                entity.Property(e => e.EqcrippleWalls).HasColumnName("EQCrippleWalls");

                entity.Property(e => e.EqengineeredFoundation).HasColumnName("EQEngineeredFoundation");

                entity.Property(e => e.EqequipmentSupportMaintenance).HasColumnName("EQEquipmentSupportMaintenance");

                entity.Property(e => e.EqframeBolted).HasColumnName("EQFrameBolted");

                entity.Property(e => e.EqmechanicalandElectricalEquipmentEarthquakeBracing).HasColumnName("EQMechanicalandElectricalEquipmentEarthquakeBracing");

                entity.Property(e => e.EqplanIrregularity).HasColumnName("EQPlanIrregularity");

                entity.Property(e => e.Eqpounding).HasColumnName("EQPounding");

                entity.Property(e => e.EqshortColumnCondition).HasColumnName("EQShortColumnCondition");

                entity.Property(e => e.EqsoftStory).HasColumnName("EQSoftStory");

                entity.Property(e => e.EqsprinklerLeakageCoverageFlag)
                    .HasColumnName("EQSprinklerLeakageCoverageFlag")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.EqsprinklerLeakageSusceptibility).HasColumnName("EQSprinklerLeakageSusceptibility");

                entity.Property(e => e.EqsprinklerType).HasColumnName("EQSprinklerType");

                entity.Property(e => e.EqstructuralUpgrade).HasColumnName("EQStructuralUpgrade");

                entity.Property(e => e.EqtiltUpRetrofit).HasColumnName("EQTiltUpRetrofit");

                entity.Property(e => e.EquipmentBreakdown)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.EquipmentBreakdownPremium).HasColumnType("money");

                entity.Property(e => e.EqunreinforcedMasonryPartitionsorChimneys).HasColumnName("EQUnreinforcedMasonryPartitionsorChimneys");

                entity.Property(e => e.EqunreinforcedMasonryRetrofit).HasColumnName("EQUnreinforcedMasonryRetrofit");

                entity.Property(e => e.EqverticalIrregularity).HasColumnName("EQVerticalIrregularity");

                entity.Property(e => e.ExtendedReplacementCostCoverage).HasColumnType("money");

                entity.Property(e => e.ExteriorPaintUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.FirstFloorHeightAboveGround).HasColumnType("decimal(3, 1)");

                entity.Property(e => e.FlfoundationType).HasColumnName("FLFoundationType");

                entity.Property(e => e.FloodDeductible).HasColumnType("money");

                entity.Property(e => e.FloodLimit).HasColumnType("money");

                entity.Property(e => e.FloodZone)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.GeoCodeInsuredAddressText).HasComputedColumnSql("([GeoCodeInsuredAddress].[STAsText]())");

                entity.Property(e => e.GlaggregateLimit)
                    .HasColumnName("GLAggregateLimit")
                    .HasColumnType("money");

                entity.Property(e => e.GlukbalboaGrossAdjustedPremium)
                    .HasColumnName("GLUKBalboaGrossAdjustedPremium")
                    .HasColumnType("money");

                entity.Property(e => e.GlukbalboaGrossPaidPremium)
                    .HasColumnName("GLUKBalboaGrossPaidPremium")
                    .HasColumnType("money");

                entity.Property(e => e.GlukbalboaGrossReturnPremium)
                    .HasColumnName("GLUKBalboaGrossReturnPremium")
                    .HasColumnType("money");

                entity.Property(e => e.GlukbalboaTier)
                    .HasColumnName("GLUKBalboaTier")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.GlukbankCertNumber)
                    .HasColumnName("GLUKBankCertNumber")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.GlukbankName)
                    .HasColumnName("GLUKBankName")
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.Glukbideductible)
                    .HasColumnName("GLUKBIDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukbppLimit)
                    .HasColumnName("GLUKBppLimit")
                    .HasColumnType("money");

                entity.Property(e => e.GlukbuildingDeductible)
                    .HasColumnName("GLUKBuildingDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukbusinessIncome)
                    .HasColumnName("GLUKBusinessIncome")
                    .HasColumnType("money");

                entity.Property(e => e.GlukcontentsDeductible)
                    .HasColumnName("GLUKContentsDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukdeductibleScheme)
                    .HasColumnName("GLUKDeductibleScheme")
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukdistanceFromSaltWater)
                    .HasColumnName("GLUKDistanceFromSaltWater")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.GlukfireDeductible)
                    .HasColumnName("GLUKFireDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukfireIncluded)
                    .HasColumnName("GLUKFireIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukfloodIncluded)
                    .HasColumnName("GLUKFloodIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukhailDeductible)
                    .HasColumnName("GLUKHailDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukhailIncluded)
                    .HasColumnName("GLUKHailIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukquakeIncluded)
                    .HasColumnName("GLUKQuakeIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GluksltbrokerAddress)
                    .HasColumnName("GLUKSLTBrokerAddress")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.GluksltbrokerId).HasColumnName("GLUKSLTBrokerID");

                entity.Property(e => e.GluksltbrokerName)
                    .HasColumnName("GLUKSLTBrokerName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.GluksltbrokerState)
                    .HasColumnName("GLUKSLTBrokerState")
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GluksltbrokerTaxNumber)
                    .HasColumnName("GLUKSLTBrokerTaxNumber")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.GlukspareText)
                    .HasColumnName("GLUKSpareText")
                    .HasColumnType("varchar(max)");

                entity.Property(e => e.GlukwindIncluded)
                    .HasColumnName("GLUKWindIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukwindstormDeductible)
                    .HasColumnName("GLUKWindstormDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukzonePerilsId).HasColumnName("GLUKZonePerilsID");

                entity.Property(e => e.GoogleElevation).HasColumnName("GOOGLE_Elevation");

                entity.Property(e => e.GoogleElevationResolution).HasColumnName("GOOGLE_Elevation_Resolution");

                entity.Property(e => e.GoogleGeoCodeDate)
                    .HasColumnName("GOOGLE_GeoCodeDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.GoogleLocationType)
                    .HasColumnName("GOOGLE_LOCATION_TYPE")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.GoogleX).HasColumnName("GOOGLE_X");

                entity.Property(e => e.GoogleY).HasColumnName("GOOGLE_Y");

                entity.Property(e => e.GrossPremium).HasColumnType("money");

                entity.Property(e => e.HeatingLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.HomeSystemsProtection)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.HomeSystemsProtectionPremium).HasColumnType("money");

                entity.Property(e => e.Impremium)
                    .HasColumnName("IMPremium")
                    .HasColumnType("money");

                entity.Property(e => e.InlandMarineLimit).HasColumnType("money");

                entity.Property(e => e.InsuredAddressText)
                    .HasMaxLength(620)
                    .IsUnicode(false)
                    .HasComputedColumnSql("((((((((([InsuredStreet]+',')+[InsuredCity])+',')+isnull([InsuredCounty]+',',''))+[InsuredState])+',')+[InsuredZipCode])+',')+isnull([InsuredCountryCode],'USA'))");

                entity.Property(e => e.InsuredCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCountryCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCountryScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCounty)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredStreet)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredZipCodePlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.Isoglclass)
                    .HasColumnName("ISOGLClass")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.IsopropertyCode)
                    .HasColumnName("ISOPropertyCode")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.LiabilityDeductible).HasColumnType("money");

                entity.Property(e => e.LiabilityLimit).HasColumnType("money");

                entity.Property(e => e.LiabilityPremium).HasColumnType("money");

                entity.Property(e => e.LimitBuildingCoverageA).HasColumnType("money");

                entity.Property(e => e.LimitBusinessInterruptionCoverageD).HasColumnType("money");

                entity.Property(e => e.LimitContentsCoverageC).HasColumnType("money");

                entity.Property(e => e.LimitCoverageE).HasColumnType("money");

                entity.Property(e => e.LimitOtherCoverageB).HasColumnType("money");

                entity.Property(e => e.LimitResidenceBurglary).HasColumnType("money");

                entity.Property(e => e.LocationNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LocationTransactionType)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.MgadistanceToCoastMiles).HasColumnName("MGADistanceToCoastMiles");

                entity.Property(e => e.Mgalatitude).HasColumnName("MGALatitude");

                entity.Property(e => e.Mgalongitude).HasColumnName("MGALongitude");

                entity.Property(e => e.MoldSublimitCoverage).HasColumnType("money");

                entity.Property(e => e.MrAdditionalElevation).HasColumnName("MR_Additional_ELEVATION");

                entity.Property(e => e.MrAdditionalPopulation).HasColumnName("MR_Additional_POPULATION");

                entity.Property(e => e.MrCity)
                    .HasColumnName("MR_CITY")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCoordind).HasColumnName("MR_COORDIND");

                entity.Property(e => e.MrCrestaHighresId)
                    .HasColumnName("MR_CRESTA_HIGHRES_ID")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaHighresName)
                    .HasColumnName("MR_CRESTA_HIGHRES_NAME")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaLowresId)
                    .HasColumnName("MR_CRESTA_LOWRES_ID")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaLowresName)
                    .HasColumnName("MR_CRESTA_LOWRES_NAME")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaid)
                    .HasColumnName("MR_CRESTAID")
                    .HasMaxLength(255);

                entity.Property(e => e.MrCrestaname)
                    .HasColumnName("MR_CRESTANAME")
                    .HasMaxLength(255);

                entity.Property(e => e.MrDistanceToCoast).HasColumnName("MR_DISTANCE_TO_COAST");

                entity.Property(e => e.MrDistanceToFault).HasColumnName("MR_DISTANCE_TO_FAULT");

                entity.Property(e => e.MrErrAdditional)
                    .HasColumnName("MR_ERR_Additional")
                    .HasMaxLength(150);

                entity.Property(e => e.MrErrCresta)
                    .HasColumnName("MR_ERR_CRESTA")
                    .HasMaxLength(255);

                entity.Property(e => e.MrErrCrestaHighres)
                    .HasColumnName("MR_ERR_CRESTA_HIGHRES")
                    .HasMaxLength(150);

                entity.Property(e => e.MrErrCrestaLowres)
                    .HasColumnName("MR_ERR_CRESTA_LOWRES")
                    .HasMaxLength(150);

                entity.Property(e => e.MrErrGcd)
                    .HasColumnName("MR_ERR_GCD")
                    .HasMaxLength(255);

                entity.Property(e => e.MrErrHazard)
                    .HasColumnName("MR_ERR_Hazard")
                    .HasMaxLength(255);

                entity.Property(e => e.MrErrRiverflood).HasColumnName("MR_ERR_RIVERFLOOD");

                entity.Property(e => e.MrGeoCodeDate)
                    .HasColumnName("MR_GeoCodeDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.MrGeozoneType)
                    .HasColumnName("MR_GEOZONE_TYPE")
                    .HasMaxLength(150);

                entity.Property(e => e.MrHazardEarthquake).HasColumnName("MR_Hazard_EARTHQUAKE");

                entity.Property(e => e.MrHazardExtratropicalstorm).HasColumnName("MR_Hazard_EXTRATROPICALSTORM");

                entity.Property(e => e.MrHazardFlashflood).HasColumnName("MR_Hazard_FLASHFLOOD");

                entity.Property(e => e.MrHazardHailstorm).HasColumnName("MR_Hazard_HAILSTORM");

                entity.Property(e => e.MrHazardLightning).HasColumnName("MR_Hazard_LIGHTNING");

                entity.Property(e => e.MrHazardStormsurge).HasColumnName("MR_Hazard_STORMSURGE");

                entity.Property(e => e.MrHazardTcyclone).HasColumnName("MR_Hazard_TCYCLONE");

                entity.Property(e => e.MrHazardTornado).HasColumnName("MR_Hazard_TORNADO");

                entity.Property(e => e.MrHazardTropicalcyclone).HasColumnName("MR_Hazard_TROPICALCYCLONE");

                entity.Property(e => e.MrHazardTsunami).HasColumnName("MR_Hazard_TSUNAMI");

                entity.Property(e => e.MrHazardVolcano).HasColumnName("MR_Hazard_VOLCANO");

                entity.Property(e => e.MrHazardWildfire).HasColumnName("MR_Hazard_WILDFIRE");

                entity.Property(e => e.MrHazardWstorm).HasColumnName("MR_Hazard_WSTORM");

                entity.Property(e => e.MrHnr)
                    .HasColumnName("MR_HNR")
                    .HasMaxLength(150);

                entity.Property(e => e.MrIso3)
                    .HasColumnName("MR_ISO3")
                    .HasMaxLength(150);

                entity.Property(e => e.MrQualind).HasColumnName("MR_QUALIND");

                entity.Property(e => e.MrRiskIndex).HasColumnName("MR_RiskIndex");

                entity.Property(e => e.MrRiskIndexEq).HasColumnName("MR_RiskIndexEq");

                entity.Property(e => e.MrRiskIndexFl).HasColumnName("MR_RiskIndexFl");

                entity.Property(e => e.MrRiskIndexSt).HasColumnName("MR_RiskIndexST");

                entity.Property(e => e.MrRiskScore).HasColumnName("MR_RiskScore");

                entity.Property(e => e.MrRiskScoreEq).HasColumnName("MR_RiskScoreEq");

                entity.Property(e => e.MrRiskScoreFl).HasColumnName("MR_RiskScoreFl");

                entity.Property(e => e.MrRiskScoreSt).HasColumnName("MR_RiskScoreST");

                entity.Property(e => e.MrRiverfloodRiverflood).HasColumnName("MR_RIVERFLOOD_RIVERFLOOD");

                entity.Property(e => e.MrSoil).HasColumnName("MR_SOIL");

                entity.Property(e => e.MrStr)
                    .HasColumnName("MR_STR")
                    .HasMaxLength(150);

                entity.Property(e => e.MrX).HasColumnName("MR_X");

                entity.Property(e => e.MrY).HasColumnName("MR_Y");

                entity.Property(e => e.MrZip)
                    .HasColumnName("MR_ZIP")
                    .HasMaxLength(150);

                entity.Property(e => e.Notes).HasColumnType("varchar(max)");

                entity.Property(e => e.OccupancyCode)
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.OccupancyScheme)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OpeningProtectionTypesCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.OpeningProtectionsCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.OrderId).HasColumnName("OrderID");

                entity.Property(e => e.OrdinanceOrLawCoverage).HasColumnType("money");

                entity.Property(e => e.OriginalLocId).HasColumnName("OriginalLocID");

                entity.Property(e => e.PersonalAccidentPremium).HasColumnType("money");

                entity.Property(e => e.Pllimit)
                    .HasColumnName("PLLimit")
                    .HasColumnType("money");

                entity.Property(e => e.Plpremium)
                    .HasColumnName("PLPremium")
                    .HasColumnType("money");

                entity.Property(e => e.PlumbingLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.PremiumBasis)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.PremiumBasisValue).HasColumnType("money");

                entity.Property(e => e.PrimaryFlood)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.PrimaryHeatSourceCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.ProductsCompletedOperationsPremium).HasColumnType("money");

                entity.Property(e => e.PropertyLimit).HasColumnType("money");

                entity.Property(e => e.PropertyLimitB).HasColumnType("money");

                entity.Property(e => e.PropertyPremium).HasColumnType("money");

                entity.Property(e => e.PropertyPremiumB).HasColumnType("money");

                entity.Property(e => e.ProtectionClass)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Protections)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.QuakeDeductible).HasColumnType("money");

                entity.Property(e => e.QuakeLimit).HasColumnType("money");

                entity.Property(e => e.Rate).HasColumnType("decimal(5, 3)");

                entity.Property(e => e.RateAllOther).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.RateProductsCompletedOperations).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.RentalTerm)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.Rmsbasefloodelevation).HasColumnName("RMSBASEFLOODELEVATION");

                entity.Property(e => e.Rmsbizone).HasColumnName("RMSBIZONE");

                entity.Property(e => e.Rmsbuildingelevation).HasColumnName("RMSBUILDINGELEVATION");

                entity.Property(e => e.RmsfloodElevation).HasColumnName("RMSFloodELEVATION");

                entity.Property(e => e.RmsfloodFloodway)
                    .HasColumnName("RMSFloodFLOODWAY")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.RmsfloodFlzone)
                    .HasColumnName("RMSFloodFLZONE")
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.RmsgeoResolutionCode).HasColumnName("RMSGeoResolutionCode");

                entity.Property(e => e.RmsnfipRate).HasColumnName("RMSNFIP_RATE");

                entity.Property(e => e.Rmsnfipyear).HasColumnName("RMSNFIPYEAR");

                entity.Property(e => e.RmsquakeBizone).HasColumnName("RMSQuakeBIZONE");

                entity.Property(e => e.RmsquakeLandslide).HasColumnName("RMSQuakeLANDSLIDE");

                entity.Property(e => e.RmsquakeLiquefact).HasColumnName("RMSQuakeLIQUEFACT");

                entity.Property(e => e.RmsquakeSoilperiod).HasColumnName("RMSQuakeSOILPERIOD");

                entity.Property(e => e.RmsquakeSoilthickness).HasColumnName("RMSQuakeSOILTHICKNESS");

                entity.Property(e => e.RmsquakeSoiltype).HasColumnName("RMSQuakeSOILTYPE");

                entity.Property(e => e.Rmsspecialfloodhazardarea)
                    .HasColumnName("RMSSPECIALFLOODHAZARDAREA")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Rmswfaccess).HasColumnName("RMSWFACCESS");

                entity.Property(e => e.Rmswfareadesc).HasColumnName("RMSWFAREADESC");

                entity.Property(e => e.Rmswfhazard).HasColumnName("RMSWFHAZARD");

                entity.Property(e => e.Rmswflochist).HasColumnName("RMSWFLOCHIST");

                entity.Property(e => e.Rmswfnearhist).HasColumnName("RMSWFNEARHIST");

                entity.Property(e => e.Rmswfspeccond)
                    .HasColumnName("RMSWFSPECCOND")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Rmswfsurffuel)
                    .HasColumnName("RMSWFSURFFUEL")
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.Rmswfsuscept).HasColumnName("RMSWFSUSCEPT");

                entity.Property(e => e.Rmswfthreat).HasColumnName("RMSWFTHREAT");

                entity.Property(e => e.RmswindDistcoast).HasColumnName("RMSWindDISTCOAST");

                entity.Property(e => e.RmswindElevation).HasColumnName("RMSWindELEVATION");

                entity.Property(e => e.RmswindManrough).HasColumnName("RMSWindMANROUGH");

                entity.Property(e => e.RmswindNatrough).HasColumnName("RMSWindNATROUGH");

                entity.Property(e => e.Rmswindpool).HasColumnName("RMSWINDPOOL");

                entity.Property(e => e.RoofAnchorCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.RoofConstructionCode).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.RoofConstructionScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.RoofCoverageValuationBasis)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.RoofLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.RoofShapeCode).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.RoofShapeScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.RoofSheathingCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.ScreenedEnclosureCoverage).HasColumnType("money");

                entity.Property(e => e.ServiceLine)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.ServiceLinePremium).HasColumnType("money");

                entity.Property(e => e.SinkholeCoverage).HasColumnType("money");

                entity.Property(e => e.SltbrokerAddress)
                    .HasColumnName("SLTBrokerAddress")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SltbrokerName)
                    .HasColumnName("SLTBrokerName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SltbrokerNumber)
                    .HasColumnName("SLTBrokerNumber")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Sltstate)
                    .HasColumnName("SLTState")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Squarefootage).HasColumnType("decimal(7, 0)");

                entity.Property(e => e.SubCoverageCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TempLocationsId).HasColumnName("TempLocationsID");

                entity.Property(e => e.TerritoriesCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TerrorismPremium).HasColumnType("money");

                entity.Property(e => e.Tivfgu)
                    .HasColumnName("TIVFGU")
                    .HasColumnType("money");

                entity.Property(e => e.TotalPropertyLimit).HasColumnType("money");

                entity.Property(e => e.TotalPropertyPremium).HasColumnType("money");

                entity.Property(e => e.TransId).HasColumnName("TransID");

                entity.Property(e => e.Triprapremium)
                    .HasColumnName("TRIPRAPremium")
                    .HasColumnType("money");

                entity.Property(e => e.TypeOfHeatingUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfPlumbingUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfRoofingUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfWiringUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.UserCreated)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserModified)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.WaterSewageBackupCoverage).HasColumnType("money");

                entity.Property(e => e.WindHailHurricaneDeductible).HasColumnType("money");

                entity.Property(e => e.WindHailHurricaneDeductibleNamedStorm).HasColumnType("money");

                entity.Property(e => e.WindLimit).HasColumnType("money");

                entity.Property(e => e.WiringLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.YearBuilt).HasColumnType("decimal(4, 0)");

                entity.HasOne(d => d.Trans)
                    .WithMany(p => p.PolicyTransactionsLocations)
                    .HasForeignKey(d => d.TransId)
                    .HasConstraintName("FK_PolicyTransactions_Locations_PolicyTransactions");
            });

            modelBuilder.Entity<PolicyTransactionsLocationsBuildings>(entity =>
            {
                entity.HasKey(e => e.BuildingsId);

                entity.ToTable("PolicyTransactions_Locations_Buildings");

                entity.Property(e => e.BuildingsId).HasColumnName("BuildingsID");

                entity.Property(e => e.AlternateHeatSourceCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Aopdeductible)
                    .HasColumnName("AOPDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.BasementType)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.BuildingCoverageAvaluationBasis)
                    .HasColumnName("BuildingCoverageAValuationBasis")
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.BuildingNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CalcEquipmentBreakDownPremium).HasColumnType("money");

                entity.Property(e => e.CalcHomeSystemsProtectionPremium).HasColumnType("money");

                entity.Property(e => e.CalcServiceLinePremium).HasColumnType("money");

                entity.Property(e => e.Catdeductible)
                    .HasColumnName("CATDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.ConstructionCode)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ConstructionCodeScheme)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ContentsCoverageCvaluationBasis)
                    .HasColumnName("ContentsCoverageCValuationBasis")
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.CoverageBvaluationBasis)
                    .HasColumnName("CoverageBValuationBasis")
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.CrimeDeductible).HasColumnType("money");

                entity.Property(e => e.CrimeLimit).HasColumnType("money");

                entity.Property(e => e.CrimePremium).HasColumnType("money");

                entity.Property(e => e.CrimeRate).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.DqicoreScore)
                    .HasColumnName("DQICoreScore")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DqiquakeScore)
                    .HasColumnName("DQIQuakeScore")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DqiwindScore)
                    .HasColumnName("DQIWindScore")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DwellingType)
                    .HasMaxLength(12)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.EqappendagesandOrnamentation).HasColumnName("EQAppendagesandOrnamentation");

                entity.Property(e => e.EqbaseIsolation).HasColumnName("EQBaseIsolation");

                entity.Property(e => e.EqcladdingType).HasColumnName("EQCladdingType");

                entity.Property(e => e.EqconstructionQuality).HasColumnName("EQConstructionQuality");

                entity.Property(e => e.EqcrippleWalls).HasColumnName("EQCrippleWalls");

                entity.Property(e => e.EqengineeredFoundation).HasColumnName("EQEngineeredFoundation");

                entity.Property(e => e.EqequipmentSupportMaintenance).HasColumnName("EQEquipmentSupportMaintenance");

                entity.Property(e => e.EqframeBolted).HasColumnName("EQFrameBolted");

                entity.Property(e => e.EqmechanicalandElectricalEquipmentEarthquakeBracing).HasColumnName("EQMechanicalandElectricalEquipmentEarthquakeBracing");

                entity.Property(e => e.EqplanIrregularity).HasColumnName("EQPlanIrregularity");

                entity.Property(e => e.Eqpounding).HasColumnName("EQPounding");

                entity.Property(e => e.EqshortColumnCondition).HasColumnName("EQShortColumnCondition");

                entity.Property(e => e.EqsoftStory).HasColumnName("EQSoftStory");

                entity.Property(e => e.EqsprinklerLeakageCoverageFlag)
                    .HasColumnName("EQSprinklerLeakageCoverageFlag")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.EqsprinklerLeakageSusceptibility).HasColumnName("EQSprinklerLeakageSusceptibility");

                entity.Property(e => e.EqsprinklerType).HasColumnName("EQSprinklerType");

                entity.Property(e => e.EqstructuralUpgrade).HasColumnName("EQStructuralUpgrade");

                entity.Property(e => e.EqtiltUpRetrofit).HasColumnName("EQTiltUpRetrofit");

                entity.Property(e => e.EquipmentBreakdown)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.EquipmentBreakdownPremium).HasColumnType("money");

                entity.Property(e => e.EqunreinforcedMasonryPartitionsorChimneys).HasColumnName("EQUnreinforcedMasonryPartitionsorChimneys");

                entity.Property(e => e.EqunreinforcedMasonryRetrofit).HasColumnName("EQUnreinforcedMasonryRetrofit");

                entity.Property(e => e.EqverticalIrregularity).HasColumnName("EQVerticalIrregularity");

                entity.Property(e => e.ExtendedReplacementCostCoverage).HasColumnType("money");

                entity.Property(e => e.FirstFloorHeightAboveGround).HasColumnType("decimal(3, 1)");

                entity.Property(e => e.FlfoundationType).HasColumnName("FLFoundationType");

                entity.Property(e => e.FloodDeductible).HasColumnType("money");

                entity.Property(e => e.FloodLimit).HasColumnType("money");

                entity.Property(e => e.FloodZone)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.GoogleElevation).HasColumnName("GOOGLE_Elevation");

                entity.Property(e => e.GoogleElevationResolution).HasColumnName("GOOGLE_Elevation_Resolution");

                entity.Property(e => e.GoogleGeoCodeDate)
                    .HasColumnName("GOOGLE_GeoCodeDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.GoogleLocationType)
                    .HasColumnName("GOOGLE_LOCATION_TYPE")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.GoogleX).HasColumnName("GOOGLE_X");

                entity.Property(e => e.GoogleY).HasColumnName("GOOGLE_Y");

                entity.Property(e => e.GrossPremium).HasColumnType("money");

                entity.Property(e => e.HeatingLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.HomeSystemsProtection)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.HomeSystemsProtectionPremium).HasColumnType("money");

                entity.Property(e => e.Impremium)
                    .HasColumnName("IMPremium")
                    .HasColumnType("money");

                entity.Property(e => e.InlandMarineLimit).HasColumnType("money");

                entity.Property(e => e.InsuredCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCountryCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCountryScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCounty)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredStreet)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredZipCodePlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.IsopropertyCode)
                    .HasColumnName("ISOPropertyCode")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.LimitAboveGroundTanks).HasColumnType("money");

                entity.Property(e => e.LimitAttachedSigns).HasColumnType("money");

                entity.Property(e => e.LimitBuildingCoverageA).HasColumnType("money");

                entity.Property(e => e.LimitBusinessInterruptionCoverageD).HasColumnType("money");

                entity.Property(e => e.LimitCanopies).HasColumnType("money");

                entity.Property(e => e.LimitContentsCoverageC).HasColumnType("money");

                entity.Property(e => e.LimitCoverageE).HasColumnType("money");

                entity.Property(e => e.LimitDetachedSigns).HasColumnType("money");

                entity.Property(e => e.LimitFence).HasColumnType("money");

                entity.Property(e => e.LimitFixturesPlaygroundEquipment).HasColumnType("money");

                entity.Property(e => e.LimitLightPoles).HasColumnType("money");

                entity.Property(e => e.LimitOtherCoverageB).HasColumnType("money");

                entity.Property(e => e.LimitOutdoorTreesandShrubs).HasColumnType("money");

                entity.Property(e => e.LimitPoolsJacuzziesSpas).HasColumnType("money");

                entity.Property(e => e.LimitPumps).HasColumnType("money");

                entity.Property(e => e.LimitResidenceBurglary).HasColumnType("money");

                entity.Property(e => e.LimitTenantGlass).HasColumnType("money");

                entity.Property(e => e.LocId).HasColumnName("LocID");

                entity.Property(e => e.MgadistanceToCoastMiles).HasColumnName("MGADistanceToCoastMiles");

                entity.Property(e => e.Mgalatitude).HasColumnName("MGALatitude");

                entity.Property(e => e.Mgalongitude).HasColumnName("MGALongitude");

                entity.Property(e => e.MoldSublimitCoverage).HasColumnType("money");

                entity.Property(e => e.MrAdditionalElevation).HasColumnName("MR_Additional_ELEVATION");

                entity.Property(e => e.MrAdditionalPopulation).HasColumnName("MR_Additional_POPULATION");

                entity.Property(e => e.MrCity)
                    .HasColumnName("MR_CITY")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCoordind).HasColumnName("MR_COORDIND");

                entity.Property(e => e.MrCrestaHighresId)
                    .HasColumnName("MR_CRESTA_HIGHRES_ID")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaHighresName)
                    .HasColumnName("MR_CRESTA_HIGHRES_NAME")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaLowresId)
                    .HasColumnName("MR_CRESTA_LOWRES_ID")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaLowresName)
                    .HasColumnName("MR_CRESTA_LOWRES_NAME")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaid)
                    .HasColumnName("MR_CRESTAID")
                    .HasMaxLength(255);

                entity.Property(e => e.MrCrestaname)
                    .HasColumnName("MR_CRESTANAME")
                    .HasMaxLength(255);

                entity.Property(e => e.MrDistanceToCoast).HasColumnName("MR_DISTANCE_TO_COAST");

                entity.Property(e => e.MrDistanceToFault).HasColumnName("MR_DISTANCE_TO_FAULT");

                entity.Property(e => e.MrErrAdditional)
                    .HasColumnName("MR_ERR_Additional")
                    .HasMaxLength(150);

                entity.Property(e => e.MrErrCresta)
                    .HasColumnName("MR_ERR_CRESTA")
                    .HasMaxLength(255);

                entity.Property(e => e.MrErrCrestaHighres)
                    .HasColumnName("MR_ERR_CRESTA_HIGHRES")
                    .HasMaxLength(150);

                entity.Property(e => e.MrErrCrestaLowres)
                    .HasColumnName("MR_ERR_CRESTA_LOWRES")
                    .HasMaxLength(150);

                entity.Property(e => e.MrErrGcd)
                    .HasColumnName("MR_ERR_GCD")
                    .HasMaxLength(255);

                entity.Property(e => e.MrErrHazard)
                    .HasColumnName("MR_ERR_Hazard")
                    .HasMaxLength(255);

                entity.Property(e => e.MrErrRiverflood).HasColumnName("MR_ERR_RIVERFLOOD");

                entity.Property(e => e.MrGeoCodeDate)
                    .HasColumnName("MR_GeoCodeDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.MrGeozoneType)
                    .HasColumnName("MR_GEOZONE_TYPE")
                    .HasMaxLength(150);

                entity.Property(e => e.MrHazardEarthquake).HasColumnName("MR_Hazard_EARTHQUAKE");

                entity.Property(e => e.MrHazardExtratropicalstorm).HasColumnName("MR_Hazard_EXTRATROPICALSTORM");

                entity.Property(e => e.MrHazardFlashflood).HasColumnName("MR_Hazard_FLASHFLOOD");

                entity.Property(e => e.MrHazardHailstorm).HasColumnName("MR_Hazard_HAILSTORM");

                entity.Property(e => e.MrHazardLightning).HasColumnName("MR_Hazard_LIGHTNING");

                entity.Property(e => e.MrHazardStormsurge).HasColumnName("MR_Hazard_STORMSURGE");

                entity.Property(e => e.MrHazardTcyclone).HasColumnName("MR_Hazard_TCYCLONE");

                entity.Property(e => e.MrHazardTornado).HasColumnName("MR_Hazard_TORNADO");

                entity.Property(e => e.MrHazardTropicalcyclone).HasColumnName("MR_Hazard_TROPICALCYCLONE");

                entity.Property(e => e.MrHazardTsunami).HasColumnName("MR_Hazard_TSUNAMI");

                entity.Property(e => e.MrHazardVolcano).HasColumnName("MR_Hazard_VOLCANO");

                entity.Property(e => e.MrHazardWildfire).HasColumnName("MR_Hazard_WILDFIRE");

                entity.Property(e => e.MrHazardWstorm).HasColumnName("MR_Hazard_WSTORM");

                entity.Property(e => e.MrHnr)
                    .HasColumnName("MR_HNR")
                    .HasMaxLength(150);

                entity.Property(e => e.MrIso3)
                    .HasColumnName("MR_ISO3")
                    .HasMaxLength(150);

                entity.Property(e => e.MrQualind).HasColumnName("MR_QUALIND");

                entity.Property(e => e.MrRiskIndex).HasColumnName("MR_RiskIndex");

                entity.Property(e => e.MrRiskIndexEq).HasColumnName("MR_RiskIndexEq");

                entity.Property(e => e.MrRiskIndexFl).HasColumnName("MR_RiskIndexFl");

                entity.Property(e => e.MrRiskIndexSt).HasColumnName("MR_RiskIndexST");

                entity.Property(e => e.MrRiskScore).HasColumnName("MR_RiskScore");

                entity.Property(e => e.MrRiskScoreEq).HasColumnName("MR_RiskScoreEq");

                entity.Property(e => e.MrRiskScoreFl).HasColumnName("MR_RiskScoreFl");

                entity.Property(e => e.MrRiskScoreSt).HasColumnName("MR_RiskScoreST");

                entity.Property(e => e.MrRiverfloodRiverflood).HasColumnName("MR_RIVERFLOOD_RIVERFLOOD");

                entity.Property(e => e.MrSoil).HasColumnName("MR_SOIL");

                entity.Property(e => e.MrStr)
                    .HasColumnName("MR_STR")
                    .HasMaxLength(150);

                entity.Property(e => e.MrX).HasColumnName("MR_X");

                entity.Property(e => e.MrY).HasColumnName("MR_Y");

                entity.Property(e => e.MrZip)
                    .HasColumnName("MR_ZIP")
                    .HasMaxLength(150);

                entity.Property(e => e.Notes).IsUnicode(false);

                entity.Property(e => e.OccupancyCode)
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.OccupancyScheme)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OpeningProtectionTypesCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.OpeningProtectionsCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.OrdinanceOrLawCoverage).HasColumnType("money");

                entity.Property(e => e.PlumbingLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.PrimaryFlood)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.PrimaryHeatSourceCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.PropertyLimit).HasColumnType("money");

                entity.Property(e => e.PropertyLimitB).HasColumnType("money");

                entity.Property(e => e.PropertyPremium).HasColumnType("money");

                entity.Property(e => e.PropertyPremiumB).HasColumnType("money");

                entity.Property(e => e.ProtectionClass)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Protections)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.QuakeDeductible).HasColumnType("money");

                entity.Property(e => e.QuakeLimit).HasColumnType("money");

                entity.Property(e => e.Rate).HasColumnType("decimal(5, 3)");

                entity.Property(e => e.RentalTerm)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.RoofAnchorCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.RoofConstructionCode).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.RoofConstructionScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.RoofCoverageValuationBasis)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.RoofLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.RoofShapeCode).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.RoofShapeScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.RoofSheathingCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.ScreenedEnclosureCoverage).HasColumnType("money");

                entity.Property(e => e.ServiceLine)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.ServiceLinePremium).HasColumnType("money");

                entity.Property(e => e.SinkholeCoverage).HasColumnType("money");

                entity.Property(e => e.Squarefootage).HasColumnType("decimal(7, 0)");

                entity.Property(e => e.TempBuildingsId).HasColumnName("TempBuildingsID");

                entity.Property(e => e.TerrorismPremium).HasColumnType("money");

                entity.Property(e => e.Tivfgu)
                    .HasColumnName("TIVFGU")
                    .HasColumnType("money");

                entity.Property(e => e.TotalPropertyLimit).HasColumnType("money");

                entity.Property(e => e.TotalPropertyPremium).HasColumnType("money");

                entity.Property(e => e.Triprapremium)
                    .HasColumnName("TRIPRAPremium")
                    .HasColumnType("money");

                entity.Property(e => e.TypeOfHeatingUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfPlumbingUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfRoofingUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfWiringUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.WaterSewageBackupCoverage).HasColumnType("money");

                entity.Property(e => e.WindHailHurricaneDeductible).HasColumnType("money");

                entity.Property(e => e.WindHailHurricaneDeductibleNamedStorm).HasColumnType("money");

                entity.Property(e => e.WindLimit).HasColumnType("money");

                entity.Property(e => e.WiringLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.YearBuilt).HasColumnType("decimal(4, 0)");

                entity.HasOne(d => d.Loc)
                    .WithMany(p => p.PolicyTransactionsLocationsBuildings)
                    .HasForeignKey(d => d.LocId)
                    .HasConstraintName("FK_PolicyTransactions_Locations_Buildings_PolicyTransactions_Locations");
            });

            modelBuilder.Entity<PolicyTransactionsLocationsIsoglclassProfessionalLiabilityLawyers>(entity =>
            {
                entity.ToTable("PolicyTransactions_Locations_ISOGLClass_ProfessionalLiability_Lawyers");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.AnnualStatementLob)
                    .IsRequired()
                    .HasColumnName("AnnualStatementLOB")
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('172')");

                entity.Property(e => e.AreaOfPracticeId).HasColumnName("AreaOfPracticeID");

                entity.Property(e => e.AreaOfPracticePercentage).HasDefaultValueSql("((1000))");

                entity.Property(e => e.AverageCaseSize).HasColumnType("money");

                entity.Property(e => e.CoverageEffectiveDate).HasColumnType("datetime");

                entity.Property(e => e.CoverageExpirationDate).HasColumnType("datetime");

                entity.Property(e => e.Cspsubline)
                    .IsRequired()
                    .HasColumnName("CSPSubline")
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('317')");

                entity.Property(e => e.Deductible).HasColumnType("money");

                entity.Property(e => e.DefenseCostDeductible).HasColumnType("money");

                entity.Property(e => e.DefenseCostLimit).HasColumnType("money");

                entity.Property(e => e.DeleteCode)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.ExposureRatingBasis).HasDefaultValueSql("((75))");

                entity.Property(e => e.ExtendedReportingPeriodDate).HasColumnType("datetime");

                entity.Property(e => e.FirmRevenue).HasColumnType("money");

                entity.Property(e => e.Isoglclass)
                    .HasColumnName("ISOGLClass")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Limit).HasColumnType("money");

                entity.Property(e => e.LocId).HasColumnName("LocID");

                entity.Property(e => e.MaximumCaseSize).HasColumnType("money");

                entity.Property(e => e.PolicyAggregateLimit).HasColumnType("money");

                entity.Property(e => e.Premium).HasColumnType("money");

                entity.Property(e => e.RateDepartureLcm)
                    .HasColumnName("RateDepartureLCM")
                    .HasDefaultValueSql("((100))");

                entity.Property(e => e.RateModificationFactor).HasDefaultValueSql("((100))");

                entity.Property(e => e.RatingId).HasColumnName("RatingID");

                entity.Property(e => e.RetroActiveDate).HasColumnType("datetime");

                entity.Property(e => e.SubCoverageCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TermPremium).HasColumnType("money");

                entity.Property(e => e.TerritoriesCode)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('999')");

               
                entity.HasOne(d => d.Loc)
                    .WithMany(p => p.PolicyTransactionsLocationsIsoglclassProfessionalLiabilityLawyers)
                    .HasForeignKey(d => d.LocId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("FK__PolicyTra__LocID__01456EE2");

            });

            modelBuilder.Entity<PolicyTransactionsLocationsTaxesFeesSurcharges>(entity =>
            {
                entity.ToTable("PolicyTransactions_Locations_TaxesFeesSurcharges");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Code)
                    .IsRequired()
                    .HasMaxLength(2);

                entity.Property(e => e.LocId).HasColumnName("LocID");

                entity.Property(e => e.Tfsamount)
                    .HasColumnName("TFSAmount")
                    .HasColumnType("money");

                entity.Property(e => e.Tfsdescription)
                    .HasColumnName("TFSDescription")
                    .HasMaxLength(255);

                entity.Property(e => e.Tfstype)
                    .IsRequired()
                    .HasColumnName("TFSType")
                    .HasMaxLength(1);

                entity.HasOne(d => d.Loc)
                    .WithMany(p => p.PolicyTransactionsLocationsTaxesFeesSurcharges)
                    .HasForeignKey(d => d.LocId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__PolicyTra__LocID__158171B9");
            });

            modelBuilder.Entity<ReportCategories>(entity =>
            {
                entity.HasKey(e => e.ReportCategoryId);

                entity.Property(e => e.ReportCategoryId).HasColumnName("ReportCategoryID");

                entity.Property(e => e.CategoryName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ShowInMenu).HasDefaultValueSql("((1))");
            });

            modelBuilder.Entity<Reports>(entity =>
            {
                entity.HasKey(e => e.ReportId);

                entity.Property(e => e.ReportId).HasColumnName("ReportID");

                entity.Property(e => e.DefaultReport).HasDefaultValueSql("((1))");

                entity.Property(e => e.ReportCategoryId).HasColumnName("ReportCategoryID");

                entity.Property(e => e.ReportName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ReportPath)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.ReportingServicesPathEbridge)
                    .HasColumnName("ReportingServicesPathEBridge")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.ReportingServicesPathIbridge)
                    .HasColumnName("ReportingServicesPathIBridge")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.ShowInMenu).HasDefaultValueSql("((1))");

                entity.HasOne(d => d.ReportCategory)
                    .WithMany(p => p.Reports)
                    .HasForeignKey(d => d.ReportCategoryId)
                    .HasConstraintName("FK_Reports_ReportCategories");
            });

            modelBuilder.Entity<TempPolicyTransactions>(entity =>
            {
                entity.HasKey(e => e.TempPremiumsId)
                    .HasName("PK_TempPremiumsTransactions");

                entity.HasIndex(e => e.CompanyId)
                    .HasDatabaseName("ix_TempPolicyTransactions_CompanyID");

                entity.HasIndex(e => e.CorrectedBy)
                    .HasDatabaseName("ix_TempPolicyTransactions_CorrectedBy");

                entity.HasIndex(e => e.Corrects)
                    .HasDatabaseName("ix_TempPolicyTransactions_Corrects");

                entity.HasIndex(e => e.FormSetId)
                    .HasDatabaseName("ix_TempPolicyTransactions_FormSetID");

                entity.HasIndex(e => e.ImportFilename)
                    .HasDatabaseName("ix_TempPolicyTransactions_ImportFilename");

                entity.HasIndex(e => new { e.CompanyId, e.InsuredEntityId })
                    .HasDatabaseName("ix_TempPolicyTransactions_CompanyID_InsuredEntityID");

                entity.HasIndex(e => new { e.CompanyId, e.ParentRui })
                    .HasDatabaseName("ix_TempPolicyTransactions_ParentRUI");

                entity.HasIndex(e => new { e.TempPremiumsId, e.PolicyNo })
                    .HasDatabaseName("ix_TempPolicyTransactions_TempPremiumsID_PolicyNo");

                entity.HasIndex(e => new { e.TempPremiumsId, e.TransactionType })
                    .HasDatabaseName("ix_TempPolicyTransactions_TempPremiumsID_TransactionType");

                entity.HasIndex(e => new { e.CompanyId, e.ImportFilename, e.TempPremiumsId })
                    .HasDatabaseName("ix_TempPolicyTransactions_ImportFilename_TempPremiumsID_Includes");

                entity.HasIndex(e => new { e.CorrectedBy, e.IgnoreRecord, e.ImportFilename })
                    .HasDatabaseName("ix_TempPolicyTransactions_CorrectedBy_IgnoreRecord_ImportFilename");

                entity.HasIndex(e => new { e.CorrectedBy, e.TempPremiumsId, e.Corrects })
                    .HasDatabaseName("ix_TempPolicyTransactions_CorrectedBy_TempPremiumsID_Corrects");

                entity.HasIndex(e => new { e.PolicyNo, e.CompanyId, e.UniqueAgentReference })
                    .HasDatabaseName("ix_TempPolicyTransactions_CompanyID_UniqueAgentReference_Includes");

                entity.HasIndex(e => new { e.PolicyNo, e.TransactionType, e.TempPremiumsId })
                    .HasDatabaseName("ix_TempPolicyTransactions_PolicyNo_TransactionType_TempPremiumsID");

                entity.HasIndex(e => new { e.TempPremiumsId, e.CompanyId, e.TransactionType })
                    .HasDatabaseName("ix_TempPolicyTransactions_TempPremiumsID_CompanyID_TransactionType");

                entity.HasIndex(e => new { e.TempPremiumsId, e.PolicyNo, e.TransactionType })
                    .HasDatabaseName("ix_TempPolicyTransactions_TempPremiumsID_PolicyNo_TransactionType");

                entity.HasIndex(e => new { e.CompanyId, e.CorrectedBy, e.AccountingEffectiveDate, e.TempPremiumsId })
                    .HasDatabaseName("ix_TempPolicyTransactions_CompanyID_CorrectedBy_AccountingEffectiveDate_TempPremiumsID");

                entity.HasIndex(e => new { e.CompanyId, e.TempPremiumsId, e.PolicyNo, e.TransactionType })
                    .HasDatabaseName("ix_TempPolicyTransactions_CompanyID_TempPremiumsID_PolicyNo_TransactionType");

                entity.HasIndex(e => new { e.ExpirationDate, e.PolicyNo, e.CompanyId, e.TempPremiumsId })
                    .HasDatabaseName("ix_TempPolicyTransactions_PolicyNo_CompanyID_TempPremiumsID_Includes");

                entity.HasIndex(e => new { e.PolicyNo, e.CompanyId, e.TempPremiumsId, e.UniqueAgentReference })
                    .HasDatabaseName("ix_TempPolicyTransactions_CompanyID_TempPremiumsID_UniqueAgentReference_Includes");

                entity.HasIndex(e => new { e.PolicyNo, e.TransactionType, e.TempPremiumsId, e.EffectiveDate })
                    .HasDatabaseName("ix_TempPolicyTransactions_PolicyNo_TransactionType_TempPremiumsID_EffectiveDate");

                entity.HasIndex(e => new { e.TempPremiumsId, e.ImportFilename, e.DuplicateFileSeq, e.UniqueAgentReference })
                    .HasDatabaseName("ix_TempPolicyTransactions_TempPremiumsID_ImportFilename_DuplicateFileSeq_UniqueAgentReference");

                entity.HasIndex(e => new { e.TempPremiumsId, e.PolicyNo, e.CompanyId, e.TransactionType })
                    .HasDatabaseName("ix_TempPolicyTransactions_TempPremiumsID_PolicyNo_CompanyID_TransactionType");

                entity.HasIndex(e => new { e.CorrectedBy, e.RmscompleteDate, e.PolicyNo, e.RmssubmitDate, e.TransactionType })
                    .HasDatabaseName("ix_CorrectedBy_RMSCompleteDatePolicyNo_RMSSubmitDate_TransactionType");

                entity.HasIndex(e => new { e.FormSetId, e.TempPremiumsId, e.CompanyId, e.InsuredEntityId, e.TransactionType })
                    .HasDatabaseName("ix_TempPolicyTransactions_TempPremiumsID_CompanyID_InsuredEntityID_TransactionType");

                entity.HasIndex(e => new { e.GlobalEndorsementId, e.GlobalPolicyId, e.CompanyId, e.AccountingEffectiveDate, e.TempPremiumsId })
                    .HasDatabaseName("ix_TempPolicyTransactions_GlobalEndorsementID_GlobalPolicyID_CompanyID_AccountingEffectiveDate_TempPremiumsID");

                entity.HasIndex(e => new { e.PlacementType, e.MoveToLiveSeqNo, e.PolicyNo, e.CompanyId, e.TempPremiumsId })
                    .HasDatabaseName("ix_TempPolicyTransactions_MoveToLiveSeqNo_PolicyNo_CompanyID_TempPremiumsID_Includes");

                entity.HasIndex(e => new { e.RmscompleteDate, e.CompanyId, e.TransactionType, e.PolicyNo, e.RmssubmitDate })
                    .HasDatabaseName("ix_TempPolicyTransactions_RMSCompleteDate_CompanyID_TransactionType_PolicyNo_RMSSubmitDate");

                entity.HasIndex(e => new { e.RmsgeoCompleteDate, e.CompanyId, e.TransactionType, e.PolicyNo, e.RmsgeoSubmitDate })
                    .HasDatabaseName("ix_TempPolicyTransactions_RMSGeoCompleteDate_CompanyID_TransactionType_PolicyNo_RMSGeoSubmitDate");

                entity.HasIndex(e => new { e.TempPremiumsId, e.CompanyId, e.ContractRef, e.TransactionType, e.EffectiveDate })
                    .HasDatabaseName("ix_TempPolicyTransactions_TempPremiumsID_CompanyID_ContractRef_TransactionType_EffectiveDate");

                entity.HasIndex(e => new { e.TransactionType, e.GlobalPolicyId, e.CompanyId, e.AccountingEffectiveDate, e.TempPremiumsId })
                    .HasDatabaseName("ix_TempPolicyTransactions_TransactionType_GlobalPolicyID_CompanyID_AccountingEffectiveDate_TempPremiumsID");

                entity.HasIndex(e => new { e.TransactionType, e.ParentRui, e.EngineQuoteEnquiryId, e.CompanyId, e.InsuredEntityId })
                    .HasDatabaseName("ix_TempPolicyTransactions_TransactionType_ParentRUI_EngineQuoteEnquiryID_CompanyID_InsuredEntityID");

                entity.HasIndex(e => new { e.CorrectedBy, e.RmssubmitDate, e.RmsgeoCompleteDate, e.TransactionType, e.PolicyNo, e.RmsgeoSubmitDate })
                    .HasDatabaseName("IX_CorrectedBy_RMSSubmitDate_RMSGeoCompleteDate_TransactionType_PolicyNo_RMSGeoSubmitDate");

                entity.HasIndex(e => new { e.FormSetId, e.CorrectedBy, e.PolicyNo, e.TempPremiumsId, e.TransactionType, e.CompanyId })
                    .HasDatabaseName("ix_TempPolicyTransactions_CorrectedBy_PolicyNo_TempPremiumsID_TransactionType_CompanyID_Includes");

                entity.HasIndex(e => new { e.PolicyNo, e.CompanyId, e.MoveToLiveSeqNo, e.BordYear, e.BordMonth, e.TempPremiumsId })
                    .HasDatabaseName("ix_TempPolicyTransactions_PolicyNo_CompanyID_MoveToLiveSeqNo_BordYear_BordMonth_TempPremiumsID");

                entity.HasIndex(e => new { e.PolicyNo, e.TempPremiumsId, e.TransactionType, e.IgnoreRecord, e.DuplicateRecord, e.CorrectedBy })
                    .HasDatabaseName("ix_TempPolicyTransactions_PolicyNo_TempPremiumsID_TransactionType_IgnoreRecord_DuplicateRecord_CorrectedBy");

                entity.HasIndex(e => new { e.Rms17submitDate, e.Rms17geoCompleteDate, e.CompanyId, e.TransactionType, e.PolicyNo, e.Rms17geoSubmitDate })
                    .HasDatabaseName("IX_RMS17SubmitDate_RMS17GeoCompleteDate_CompanyID_TransactionType_PolicyNo_RMS17GeoSubmitDate");

                entity.HasIndex(e => new { e.TransactionType, e.TempPremiumsId, e.CompanyId, e.ImportFilename, e.DuplicateFileSeq, e.UniqueAgentReference })
                    .HasDatabaseName("ix_TempPolicyTransactions_TransactionType_TempPremiumsID_CompanyID_ImportFilename_DuplicateFileSeq_UniqueAgentReference");

                entity.HasIndex(e => new { e.MoveToLiveSeqNo, e.TransactionType, e.GlobalPolicyId, e.CompanyId, e.AccountingEffectiveDate, e.InHouseHold, e.TempPremiumsId })
                    .HasDatabaseName("ix_TempPolicyTransactions_TransactionType_GlobalPolicyID_CompanyID_AccountingEffectiveDate_InHouseHold_TempPremiumsID_Includes");

                entity.HasIndex(e => new { e.WindLimit, e.QuakeLimit, e.Rms17completeDate, e.CompanyId, e.TransactionType, e.PolicyNo, e.Rms17submitDate })
                    .HasDatabaseName("IX_RMS17CompleteDate_CompanyID_TransactionType_PolicyNo_RMS17SubmitDate_Includes");

                entity.HasIndex(e => new { e.ImportFilename, e.DuplicateFileSeq, e.UniqueAgentReference, e.ParentRui, e.TransactionType, e.CompanyId, e.InsuredEntityId, e.EngineQuoteEnquiryId })
                    .HasDatabaseName("ix_TempPolicyTransactions_Transactiontype_CompanyID_InsuredEntityID_EngineQuoteEnquiryID");

                entity.HasIndex(e => new { e.PlacementType, e.PolicyNo, e.TempPremiumsId, e.CorrectedBy, e.IgnoreRecord, e.DuplicateRecord, e.MoveToLiveSeqNo, e.CompanyId })
                    .HasDatabaseName("ix_TempPolicyTransactions_PolicyNo_TempPremiumsID_CorrectedBy_IgnoreRecord_DuplicateRecord_MoveToLiveSeqNo_CompanyID_Includes");

                entity.HasIndex(e => new { e.TransactionType, e.InsuredZipCode, e.CompanyId, e.TempPremiumsId, e.PolicyNo, e.InsuredName, e.EffectiveDate, e.ExpirationDate })
                    .HasDatabaseName("ix_TempPolicyTransactions_TransactionType_InsuredZipCode_CompanyID_TempPremiumsID_PolicyNo_InsuredName_EffectiveDate_ExpirationD");

                entity.HasIndex(e => new { e.GrossPremium, e.RecordError, e.IgnoreRecord, e.TempPremiumsId, e.EffectiveDate, e.AccountingEffectiveDate, e.BordMonth, e.CorrectedBy, e.BordYear, e.CompanyId })
                    .HasDatabaseName("ix_TempPolicyTransactions_TempPremiumsID_EffectiveDate_AccountingEffectiveDate_BordMonth_CorrectedBy_BordYear_CompanyID_Includes");

                entity.HasIndex(e => new { e.TempPremiumsId, e.CorrectedBy, e.TransactionType, e.IsTestData, e.InHouseHold, e.RecordError, e.IgnoreRecord, e.CompanyId, e.ImportFilename, e.RmscompleteDate })
                    .HasDatabaseName("ix_TempPolicyTransactions_TempPremiumsID_CorrectedBy_TransactionType_IsTestData_InHouseHold_RecordError_IgnoreRecord_CompanyID_I");

                entity.HasIndex(e => new { e.TempPremiumsId, e.InsuredCity, e.InsuredCounty, e.InsuredState, e.InsuredZipCode, e.InsuredCountryScheme, e.InsuredCountryCode, e.GoogleX, e.GoogleY, e.InsuredStreet })
                    .HasDatabaseName("ix_TempPolicyTransactions_GeoGoogle");

                entity.HasIndex(e => new { e.TransactionType, e.RmscompleteDate, e.RmssubmitDate, e.RmsgeoCompleteDate, e.CompanyId, e.TempPremiumsId, e.PolicyNo, e.InsuredName, e.RmsgeoSubmitDate, e.UserCreated })
                    .HasDatabaseName("ix_TempPolicyTransactions_TransactionType_RMSCompleteDate_RMSSubmitDate_RMSGeoCompleteDate_CompanyID_TempPremiumsID_PolicyNo_Ins");

                entity.HasIndex(e => new { e.InsuredCity, e.InsuredCounty, e.InsuredState, e.InsuredCountryScheme, e.InsuredCountryCode, e.MrX, e.MrY, e.TransactionType, e.InsuredStreet, e.InsuredZipCode, e.QuoteType })
                    .HasDatabaseName("IX_MR_X_MR_Y_TransactionType_InsuredStreet_InsuredZipCode_QuoteType_Includes");

                entity.HasIndex(e => new { e.InsuredName, e.PolicyNo, e.UserCreated, e.TransactionType, e.QuoteType, e.CorrectedBy, e.DateImported, e.RecordError, e.TempPremiumsId, e.CompanyId, e.SubCompanyId })
                    .HasDatabaseName("ix_TempPolicyTransactions_TransactionType_QuoteType_CorrectedBy_DateImported_RecordError_TempPremiumsID_CompanyID_SubCompanyID_I");

                entity.HasIndex(e => new { e.InsuredStreet, e.InsuredCity, e.InsuredCounty, e.InsuredState, e.InsuredZipCode, e.InsuredCountryScheme, e.InsuredCountryCode, e.MrX, e.TransactionType, e.MrY, e.TempPremiumsId })
                    .HasDatabaseName("ix_TempPolicyTransactions_GeoMR");

                entity.HasIndex(e => new { e.InsuredStreet, e.MrY, e.MrX, e.TransactionType, e.TempPremiumsId, e.CompanyId, e.InsuredCity, e.InsuredCounty, e.InsuredState, e.InsuredZipCode, e.InsuredCountryScheme, e.InsuredCountryCode })
                    .HasDatabaseName("ix_TempPolicyTransactions_MR_Y_MR_X_TransactionType_TempPremiumsID_CompanyID_InsuredCity_InsuredCounty_InsuredState_InsuredZipCo");

                entity.HasIndex(e => new { e.ImportFilename, e.DuplicateFileSeq, e.TransactionType, e.InsuredName, e.PolicyNo, e.EffectiveDate, e.RecordError, e.OverrideError, e.Corrects, e.CorrectedBy, e.IgnoreRecord, e.DateErrorChecksFirstRun, e.PolicyProcessorSystemName, e.UniqueAgentReference })
                    .HasDatabaseName("ixTempPolicyTransactions_UniqueAgentReference");

                entity.HasIndex(e => new { e.TempPremiumsId, e.CompanyId, e.InsuredName, e.PolicyNo, e.RecordError, e.SubCompanyId, e.UserCreated, e.MrX, e.CorrectedBy, e.QuoteType, e.TransactionType, e.TotalPropertyLimit, e.RmsgeoSubmitDate, e.RmsgeoCompleteDate })
                    .HasDatabaseName("ix_TempPolicyTransactions_CorrectedBy_QuoteType_TransactionType_TotalPropertyLimit_RMSGeoSubmitDate_RMSGeoCompleteDate_includes");

                entity.HasIndex(e => new { e.TempPremiumsId, e.ImportFilename, e.PolicyNo, e.OccupancyScheme, e.OccupancyCode, e.WindLimit, e.QuakeLimit, e.RecordError, e.IgnoreRecord, e.DateImported, e.AccountingEffectiveDate, e.IsTestData, e.InHouseHold, e.CorrectedBy, e.RmscompleteDate, e.CompanyId, e.TransactionType })
                    .HasDatabaseName("ix_TempPolicyTransactions_CorrectedBy_RMSCompleteDate_CompanyID_TransactionType_includes");

                entity.HasIndex(e => new { e.ImportFilename, e.DuplicateFileSeq, e.UniqueAgentReference, e.PolicyNo, e.OccupancyScheme, e.OccupancyCode, e.WindLimit, e.QuakeLimit, e.RecordError, e.IgnoreRecord, e.DateImported, e.AccountingEffectiveDate, e.IsTestData, e.InHouseHold, e.CorrectedBy, e.Rms17completeDate, e.CompanyId, e.TransactionType })
                    .HasDatabaseName("IX_CorrectedBy_RMS17CompleteDate_CompanyID_TransactionType_Includes");

                entity.Property(e => e.TempPremiumsId).HasColumnName("TempPremiumsID");

                entity.Property(e => e.AccountCurrentSignedOff).HasColumnType("datetime");

                entity.Property(e => e.AccountingEffectiveDate).HasColumnType("datetime");

                entity.Property(e => e.AllOther).HasColumnType("money");

                entity.Property(e => e.AmigclassOfBusinessCode)
                    .HasColumnName("AMIGClassOfBusinessCode")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.AmigcontractAsplitPercentage).HasColumnName("AMIGContractASplitPercentage");

                entity.Property(e => e.AmigcontractBsplitPercentage).HasColumnName("AMIGContractBSplitPercentage");

                entity.Property(e => e.AnimalLiablityCoverage).HasColumnType("money");

                entity.Property(e => e.Aopdeductible)
                    .HasColumnName("AOPDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.AttachmentPoint).HasColumnType("money");

                entity.Property(e => e.Bccommission)
                    .HasColumnName("BCCommission")
                    .HasColumnType("money");

                entity.Property(e => e.BccustomErrorMessage)
                    .HasColumnName("BCCustomErrorMessage")
                    .IsUnicode(false);

                entity.Property(e => e.BodilyInjuryByAccidentLimit).HasColumnType("money");

                entity.Property(e => e.BodilyInjuryByDiseaseAggregateLimit).HasColumnType("money");

                entity.Property(e => e.BodilyInjuryByDiseaseEachEmployeeLimit).HasColumnType("money");

                entity.Property(e => e.BordereauType)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.BusinessArea)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CalcEquipmentBreakDownPremium).HasColumnType("money");

                entity.Property(e => e.CalcHomeSystemsProtectionPremium).HasColumnType("money");

                entity.Property(e => e.CalcIdentityTheftRecoveryPremium).HasColumnType("money");

                entity.Property(e => e.CalcServiceLinePremium).HasColumnType("money");

                entity.Property(e => e.Catdeductible)
                    .HasColumnName("CATDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.CdmatchPercentage).HasColumnName("CDMatchPercentage");

                entity.Property(e => e.CedingCoNameRetailAgent)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.CertificateNumber)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.ChangeDescription).IsUnicode(false);

                entity.Property(e => e.CheckOnly).HasDefaultValueSql("((0))");

                entity.Property(e => e.CoInsurancePercentage).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.Commission).HasColumnType("money");

                entity.Property(e => e.CompanyId).HasColumnName("CompanyID");

                entity.Property(e => e.CompanyNumber)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.ConstructionCode)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ConstructionCodeScheme)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.ContractRef)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.ContractShare).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.CoverageForm).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.CrimeDeductible).HasColumnType("money");

                entity.Property(e => e.CrimeLimit).HasColumnType("money");

                entity.Property(e => e.CrimePremium).HasColumnType("money");

                entity.Property(e => e.CrimeRate).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.CyberLiabilityLimit).HasColumnType("money");

                entity.Property(e => e.CyberLiabilityPremium).HasColumnType("money");

                entity.Property(e => e.DateCreated)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DateErrorChecksFirstRun).HasColumnType("datetime");

                entity.Property(e => e.DateErrorChecksLastRunEnd).HasColumnType("datetime");

                entity.Property(e => e.DateErrorChecksLastRunStart).HasColumnType("datetime");

                entity.Property(e => e.DateImported)
                    .HasColumnType("datetime")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.DateOfLastLoss).HasColumnType("date");

                entity.Property(e => e.DateUpdated).HasColumnType("datetime");

                entity.Property(e => e.DocEndRevisedPropLimit)
                    .HasColumnName("DocEND_RevisedPropLimit")
                    .HasColumnType("money");

                entity.Property(e => e.DocEndTotalLiability)
                    .HasColumnName("DocEND_TotalLiability")
                    .HasColumnType("money");

                entity.Property(e => e.DocEndTotalProperty)
                    .HasColumnName("DocEND_TotalProperty")
                    .HasColumnType("money");

                entity.Property(e => e.DocEndTotalTerror)
                    .HasColumnName("DocEND_TotalTerror")
                    .HasColumnType("money");

                entity.Property(e => e.DocucorpAgentAddr)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpAgentCity)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpAgentName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpAgentState)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpAgentZip)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpAgentZipPlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpDamagePremRented)
                    .HasColumnName("DOCUCORP_DAMAGE_PREM_RENTED")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpMedExpenseLmt)
                    .HasColumnName("DOCUCORP_MED_EXPENSE_LMT")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpPersonalAndAdvertising)
                    .HasColumnName("DOCUCORP_PERSONAL_AND_ADVERTISING")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpProductCompletedOper)
                    .HasColumnName("DOCUCORP_PRODUCT_COMPLETED_OPER")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.DocucorpTransCode)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.DqicoreScore)
                    .HasColumnName("DQICoreScore")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DqiquakeScore)
                    .HasColumnName("DQIQuakeScore")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DqiwindScore)
                    .HasColumnName("DQIWindScore")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DuplicateFileSeq).HasDefaultValueSql("((0))");

                entity.Property(e => e.DuplicateRecord).HasDefaultValueSql("((0))");

                entity.Property(e => e.EffectiveDate).HasColumnType("datetime");

                entity.Property(e => e.Ellimit)
                    .HasColumnName("ELLimit")
                    .HasColumnType("money");

                entity.Property(e => e.Elpremium)
                    .HasColumnName("ELPremium")
                    .HasColumnType("money");

                entity.Property(e => e.EndorsementNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.EngineQuoteEnquiryId)
                    .HasColumnName("EngineQuoteEnquiryID")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.EqappendagesandOrnamentation).HasColumnName("EQAppendagesandOrnamentation");

                entity.Property(e => e.EqbaseIsolation).HasColumnName("EQBaseIsolation");

                entity.Property(e => e.EqcladdingType).HasColumnName("EQCladdingType");

                entity.Property(e => e.EqconstructionQuality).HasColumnName("EQConstructionQuality");

                entity.Property(e => e.EqcrippleWalls).HasColumnName("EQCrippleWalls");

                entity.Property(e => e.EqengineeredFoundation).HasColumnName("EQEngineeredFoundation");

                entity.Property(e => e.EqequipmentSupportMaintenance).HasColumnName("EQEquipmentSupportMaintenance");

                entity.Property(e => e.EqframeBolted).HasColumnName("EQFrameBolted");

                entity.Property(e => e.EqmechanicalandElectricalEquipmentEarthquakeBracing).HasColumnName("EQMechanicalandElectricalEquipmentEarthquakeBracing");

                entity.Property(e => e.EqplanIrregularity).HasColumnName("EQPlanIrregularity");

                entity.Property(e => e.Eqpounding).HasColumnName("EQPounding");

                entity.Property(e => e.EqshortColumnCondition).HasColumnName("EQShortColumnCondition");

                entity.Property(e => e.EqsoftStory).HasColumnName("EQSoftStory");

                entity.Property(e => e.EqsprinklerLeakageCoverageFlag)
                    .HasColumnName("EQSprinklerLeakageCoverageFlag")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.EqsprinklerLeakageSusceptibility).HasColumnName("EQSprinklerLeakageSusceptibility");

                entity.Property(e => e.EqsprinklerType).HasColumnName("EQSprinklerType");

                entity.Property(e => e.EqstructuralUpgrade).HasColumnName("EQStructuralUpgrade");

                entity.Property(e => e.EqtiltUpRetrofit).HasColumnName("EQTiltUpRetrofit");

                entity.Property(e => e.EquipmentBreakdown)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.EquipmentBreakdownPremium).HasColumnType("money");

                entity.Property(e => e.EqunreinforcedMasonryPartitionsorChimneys).HasColumnName("EQUnreinforcedMasonryPartitionsorChimneys");

                entity.Property(e => e.EqunreinforcedMasonryRetrofit).HasColumnName("EQUnreinforcedMasonryRetrofit");

                entity.Property(e => e.EqverticalIrregularity).HasColumnName("EQVerticalIrregularity");

                entity.Property(e => e.ExpirationDate).HasColumnType("datetime");

                entity.Property(e => e.ExpiringPolicyNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ExtendedLiabilityRentedLocationsFamilies)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ExtendedLiabilityToRentedLocationsAmount).HasColumnType("money");

                entity.Property(e => e.FirstFloorHeightAboveGround).HasColumnType("decimal(3, 1)");

                entity.Property(e => e.FlfoundationType).HasColumnName("FLFoundationType");

                entity.Property(e => e.FloodDeductible).HasColumnType("money");

                entity.Property(e => e.FloodLimit).HasColumnType("money");

                entity.Property(e => e.FloodZone)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.ForDebugRequestPricingEngineVersion)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FormSetId)
                    .HasColumnName("FormSetID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FullTermEndorsementPremium).HasColumnType("money");

                entity.Property(e => e.GlaggregateLimit)
                    .HasColumnName("GLAggregateLimit")
                    .HasColumnType("money");

                entity.Property(e => e.GlobalEndorsementId).HasColumnName("GlobalEndorsementID");

                entity.Property(e => e.GlobalPolicyId).HasColumnName("GlobalPolicyID");

                entity.Property(e => e.GlukbppLimit)
                    .HasColumnName("GLUKBppLimit")
                    .HasColumnType("money");

                entity.Property(e => e.GlukbrokasureTransactionNumber).HasColumnName("GLUKBrokasureTransactionNumber");

                entity.Property(e => e.GlukbusinessIncome)
                    .HasColumnName("GLUKBusinessIncome")
                    .HasColumnType("money");

                entity.Property(e => e.Glukcpllimit)
                    .HasColumnName("GLUKCPLLimit")
                    .HasColumnType("money");

                entity.Property(e => e.Glukcplpremium)
                    .HasColumnName("GLUKCPLPremium")
                    .HasColumnType("money");

                entity.Property(e => e.GlukdistanceFromSaltWater)
                    .HasColumnName("GLUKDistanceFromSaltWater")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.GlukfireDeductible)
                    .HasColumnName("GLUKFireDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukfireIncluded)
                    .HasColumnName("GLUKFireIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukfloodIncluded)
                    .HasColumnName("GLUKFloodIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukhailDeductible)
                    .HasColumnName("GLUKHailDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukhailIncluded)
                    .HasColumnName("GLUKHailIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukinHouseEndorsementNumber).HasColumnName("GLUKInHouseEndorsementNumber");

                entity.Property(e => e.GlukpaymentBasis)
                    .HasColumnName("GLUKPaymentBasis")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukquakeIncluded)
                    .HasColumnName("GLUKQuakeIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GluksltbrokerId).HasColumnName("GLUKSLTBrokerID");

                entity.Property(e => e.GlukspareText)
                    .HasColumnName("GLUKSpareText")
                    .IsUnicode(false);

                entity.Property(e => e.Glukwcapremium)
                    .HasColumnName("GLUKWCAPremium")
                    .HasColumnType("money");

                entity.Property(e => e.GlukwindIncluded)
                    .HasColumnName("GLUKWindIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukwindstormDeductible)
                    .HasColumnName("GLUKWindstormDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukzonePerilsId).HasColumnName("GLUKZonePerilsID");

                entity.Property(e => e.GoogleElevation).HasColumnName("GOOGLE_Elevation");

                entity.Property(e => e.GoogleElevationResolution).HasColumnName("GOOGLE_Elevation_Resolution");

                entity.Property(e => e.GoogleGeoCodeDate)
                    .HasColumnName("GOOGLE_GeoCodeDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.GoogleLocationType)
                    .HasColumnName("GOOGLE_LOCATION_TYPE")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.GoogleX).HasColumnName("GOOGLE_X");

                entity.Property(e => e.GoogleY).HasColumnName("GOOGLE_Y");

                entity.Property(e => e.GrossPremium).HasColumnType("money");

                entity.Property(e => e.HeatingLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.HereonPercentage).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.HistoricTiv1yearPrior)
                    .HasColumnName("HistoricTIV1YearPrior")
                    .HasColumnType("money");

                entity.Property(e => e.HistoricTiv2yearPrior)
                    .HasColumnName("HistoricTIV2YearPrior")
                    .HasColumnType("money");

                entity.Property(e => e.HistoricTiv3yearPrior)
                    .HasColumnName("HistoricTIV3YearPrior")
                    .HasColumnType("money");

                entity.Property(e => e.HoldError).HasDefaultValueSql("((0))");

                entity.Property(e => e.HomeSystemsProtectionPremium).HasColumnType("money");

                entity.Property(e => e.IdentityTheftRecovery)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.IdentityTheftRecoveryPremium).HasColumnType("money");

                entity.Property(e => e.IgnoreRecord).HasDefaultValueSql("((0))");

                entity.Property(e => e.ImportFilename)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Impremium)
                    .HasColumnName("IMPremium")
                    .HasColumnType("money");

                entity.Property(e => e.ImpremiumPolicyWide)
                    .HasColumnName("IMPremiumPolicyWide")
                    .HasColumnType("money");

                entity.Property(e => e.InHomeBusinessCoverageBusinessName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.InHomeBusinessCoverageGrossReceipts).HasColumnType("money");

                entity.Property(e => e.InHomeBusinessCoverageTypeOfBusiness)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.InHouseHold).HasDefaultValueSql("((0))");

                entity.Property(e => e.IncludedForms).IsUnicode(false);

                entity.Property(e => e.InlandMarineFloodLimitPolicyWide).HasColumnType("money");

                entity.Property(e => e.InlandMarineLimit).HasColumnType("money");

                entity.Property(e => e.InlandMarineLimitPolicyWide).HasColumnType("money");

                entity.Property(e => e.InlandMarineQuakeLimitPolicyWide).HasColumnType("money");

                entity.Property(e => e.InlandMarineWindLimitPolicyWide).HasColumnType("money");

                entity.Property(e => e.InsuredCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCountryCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCountryScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCounty)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredDoingBusinessAs)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredEntityId)
                    .HasColumnName("InsuredEntityID")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredEntityType)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.InsuredName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredStreet)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredZipCodePlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.InvoiceNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.IsTestData).HasDefaultValueSql("((0))");

                entity.Property(e => e.IsocurrencyCode)
                    .HasColumnName("ISOCurrencyCode")
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Isoglclass)
                    .HasColumnName("ISOGLClass")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.IsopropertyCode)
                    .HasColumnName("ISOPropertyCode")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.LiabilityDeductible).HasColumnType("money");

                entity.Property(e => e.LiabilityLimit).HasColumnType("money");

                entity.Property(e => e.LiabilityPremium).HasColumnType("money");

                entity.Property(e => e.LimitBuildingCoverageA).HasColumnType("money");

                entity.Property(e => e.LimitBusinessInterruptionCoverageD).HasColumnType("money");

                entity.Property(e => e.LimitContentsCoverageC).HasColumnType("money");

                entity.Property(e => e.LimitCoverageE).HasColumnType("money");

                entity.Property(e => e.LimitFirearms).HasColumnType("money");

                entity.Property(e => e.LimitJewellry).HasColumnType("money");

                entity.Property(e => e.LimitMoneyBanknotes).HasColumnType("money");

                entity.Property(e => e.LimitOtherCoverageB).HasColumnType("money");

                entity.Property(e => e.LimitPortableElectronicDevices).HasColumnType("money");

                entity.Property(e => e.LimitResidenceBurglary).HasColumnType("money");

                entity.Property(e => e.LimitSecurities).HasColumnType("money");

                entity.Property(e => e.LimitSilverware).HasColumnType("money");

                entity.Property(e => e.LossAssessmentCoverage).HasColumnType("money");

                entity.Property(e => e.MailingCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MailingCountryCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.MailingCountryScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.MailingCounty)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MailingState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.MailingStreet)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.MailingZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.MailingZipCodePlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ManualCheckedBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ManualCheckedDate).HasColumnType("datetime");

                entity.Property(e => e.ManualCheckedNotes).IsUnicode(false);

                entity.Property(e => e.MedicalExpensesLimit).HasColumnType("money");

                entity.Property(e => e.MgaquoteId)
                    .HasColumnName("MGAQuoteID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MgaquoteVersion)
                    .HasColumnName("MGAQuoteVersion")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MgasubmissionId)
                    .HasColumnName("MGASubmissionID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MigrationOldSystemId).HasColumnName("MigrationOldSystemID");

                entity.Property(e => e.MinFloodDeductible).HasColumnType("money");

                entity.Property(e => e.MinHailHurricaneDeductible).HasColumnType("money");

                entity.Property(e => e.MinNamedStormDeductible).HasColumnType("money");

                entity.Property(e => e.MinQuakeDeductible).HasColumnType("money");

                entity.Property(e => e.MinimumCrimeAdjustmentPremium).HasColumnType("money");

                entity.Property(e => e.MinimumPropertyAdjustmentPremium).HasColumnType("money");

                entity.Property(e => e.MiscProfessionalLiabilityLimit).HasColumnType("money");

                entity.Property(e => e.MiscProfessionalLiabilityPremium).HasColumnType("money");

                entity.Property(e => e.ModifierMarketPriceAdjustment).HasColumnType("decimal(5, 4)");

                entity.Property(e => e.ModifierUnderwriterPriceAdjustment).HasColumnType("decimal(10, 8)");

                entity.Property(e => e.MrAdditionalElevation).HasColumnName("MR_Additional_ELEVATION");

                entity.Property(e => e.MrAdditionalPopulation).HasColumnName("MR_Additional_POPULATION");

                entity.Property(e => e.MrCity)
                    .HasColumnName("MR_CITY")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCoordind).HasColumnName("MR_COORDIND");

                entity.Property(e => e.MrCrestaHighresId)
                    .HasColumnName("MR_CRESTA_HIGHRES_ID")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaHighresName)
                    .HasColumnName("MR_CRESTA_HIGHRES_NAME")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaLowresId)
                    .HasColumnName("MR_CRESTA_LOWRES_ID")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaLowresName)
                    .HasColumnName("MR_CRESTA_LOWRES_NAME")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaid)
                    .HasColumnName("MR_CRESTAID")
                    .HasMaxLength(255);

                entity.Property(e => e.MrCrestaname)
                    .HasColumnName("MR_CRESTANAME")
                    .HasMaxLength(255);

                entity.Property(e => e.MrDistanceToCoast).HasColumnName("MR_DISTANCE_TO_COAST");

                entity.Property(e => e.MrDistanceToFault).HasColumnName("MR_DISTANCE_TO_FAULT");

                entity.Property(e => e.MrErrAdditional)
                    .HasColumnName("MR_ERR_Additional")
                    .HasMaxLength(150);

                entity.Property(e => e.MrErrCresta)
                    .HasColumnName("MR_ERR_CRESTA")
                    .HasMaxLength(255);

                entity.Property(e => e.MrErrCrestaHighres)
                    .HasColumnName("MR_ERR_CRESTA_HIGHRES")
                    .HasMaxLength(150);

                entity.Property(e => e.MrErrCrestaLowres)
                    .HasColumnName("MR_ERR_CRESTA_LOWRES")
                    .HasMaxLength(150);

                entity.Property(e => e.MrErrGcd)
                    .HasColumnName("MR_ERR_GCD")
                    .HasMaxLength(255);

                entity.Property(e => e.MrErrHazard)
                    .HasColumnName("MR_ERR_Hazard")
                    .HasMaxLength(255);

                entity.Property(e => e.MrErrRiverflood).HasColumnName("MR_ERR_RIVERFLOOD");

                entity.Property(e => e.MrGeoCodeDate)
                    .HasColumnName("MR_GeoCodeDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.MrGeozoneType)
                    .HasColumnName("MR_GEOZONE_TYPE")
                    .HasMaxLength(150);

                entity.Property(e => e.MrHazardEarthquake).HasColumnName("MR_Hazard_EARTHQUAKE");

                entity.Property(e => e.MrHazardExtratropicalstorm).HasColumnName("MR_Hazard_EXTRATROPICALSTORM");

                entity.Property(e => e.MrHazardFlashflood).HasColumnName("MR_Hazard_FLASHFLOOD");

                entity.Property(e => e.MrHazardHailstorm).HasColumnName("MR_Hazard_HAILSTORM");

                entity.Property(e => e.MrHazardLightning).HasColumnName("MR_Hazard_LIGHTNING");

                entity.Property(e => e.MrHazardStormsurge).HasColumnName("MR_Hazard_STORMSURGE");

                entity.Property(e => e.MrHazardTcyclone).HasColumnName("MR_Hazard_TCYCLONE");

                entity.Property(e => e.MrHazardTornado).HasColumnName("MR_Hazard_TORNADO");

                entity.Property(e => e.MrHazardTropicalcyclone).HasColumnName("MR_Hazard_TROPICALCYCLONE");

                entity.Property(e => e.MrHazardTsunami).HasColumnName("MR_Hazard_TSUNAMI");

                entity.Property(e => e.MrHazardVolcano).HasColumnName("MR_Hazard_VOLCANO");

                entity.Property(e => e.MrHazardWildfire).HasColumnName("MR_Hazard_WILDFIRE");

                entity.Property(e => e.MrHazardWstorm).HasColumnName("MR_Hazard_WSTORM");

                entity.Property(e => e.MrHnr)
                    .HasColumnName("MR_HNR")
                    .HasMaxLength(150);

                entity.Property(e => e.MrIso3)
                    .HasColumnName("MR_ISO3")
                    .HasMaxLength(150);

                entity.Property(e => e.MrQualind).HasColumnName("MR_QUALIND");

                entity.Property(e => e.MrRiskIndex).HasColumnName("MR_RiskIndex");

                entity.Property(e => e.MrRiskIndexEq).HasColumnName("MR_RiskIndexEq");

                entity.Property(e => e.MrRiskIndexFl).HasColumnName("MR_RiskIndexFl");

                entity.Property(e => e.MrRiskIndexSt).HasColumnName("MR_RiskIndexST");

                entity.Property(e => e.MrRiskScore).HasColumnName("MR_RiskScore");

                entity.Property(e => e.MrRiskScoreEq).HasColumnName("MR_RiskScoreEq");

                entity.Property(e => e.MrRiskScoreFl).HasColumnName("MR_RiskScoreFl");

                entity.Property(e => e.MrRiskScoreSt).HasColumnName("MR_RiskScoreST");

                entity.Property(e => e.MrRiverfloodRiverflood).HasColumnName("MR_RIVERFLOOD_RIVERFLOOD");

                entity.Property(e => e.MrSoil).HasColumnName("MR_SOIL");

                entity.Property(e => e.MrStr)
                    .HasColumnName("MR_STR")
                    .HasMaxLength(150);

                entity.Property(e => e.MrX).HasColumnName("MR_X");

                entity.Property(e => e.MrY).HasColumnName("MR_Y");

                entity.Property(e => e.MrZip)
                    .HasColumnName("MR_ZIP")
                    .HasMaxLength(150);

                entity.Property(e => e.Naic)
                    .HasColumnName("NAIC")
                    .HasMaxLength(11)
                    .IsUnicode(false);

                entity.Property(e => e.NetPremium).HasColumnType("money");

                entity.Property(e => e.Notes).IsUnicode(false);

                entity.Property(e => e.OccupancyCode)
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.OccupancyScheme)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.OrderId).HasColumnName("OrderID");

                entity.Property(e => e.OriginalAccountingEffectiveDate).HasColumnType("datetime");

                entity.Property(e => e.ParentRui)
                    .HasColumnName("ParentRUI")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Payable)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.Pdfattachment)
                    .HasColumnName("PDFAttachment")
                    .HasColumnType("image");

                entity.Property(e => e.PdfattachmentFileName)
                    .HasColumnName("PDFAttachmentFileName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.PersonalAccidentPremium).HasColumnType("money");

                entity.Property(e => e.PersonalInjuryCoverage).HasColumnType("money");

                entity.Property(e => e.PlacementType).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.PlcommercialIndicator)
                    .HasColumnName("PLCommercialIndicator")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Pllimit)
                    .HasColumnName("PLLimit")
                    .HasColumnType("money");

                entity.Property(e => e.Plpremium)
                    .HasColumnName("PLPremium")
                    .HasColumnType("money");

                entity.Property(e => e.PlumbingLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.PolicyFee).HasColumnType("money");

                entity.Property(e => e.PolicyNo)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PolicyProcessorSystemName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.PremiumBasis)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.PremiumBasisValue).HasColumnType("money");

                entity.Property(e => e.PricingEngineId)
                    .HasColumnName("PricingEngineID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ProductsCompletedOperationsPremium).HasColumnType("money");

                entity.Property(e => e.PropertyLimit).HasColumnType("money");

                entity.Property(e => e.PropertyLimitB).HasColumnType("money");

                entity.Property(e => e.PropertyPremium).HasColumnType("money");

                entity.Property(e => e.PropertyPremiumB).HasColumnType("money");

                entity.Property(e => e.ProtectionClass)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Protections)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.QuakeDeductible).HasColumnType("money");

                entity.Property(e => e.QuakeLimit).HasColumnType("money");

                entity.Property(e => e.Rate).HasColumnType("decimal(7, 4)");

                entity.Property(e => e.RateAllOther).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.RateProductsCompletedOperations).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.RatingSessionId)
                    .HasColumnName("RatingSessionID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RecordError).HasDefaultValueSql("((1))");

                entity.Property(e => e.RetroActiveDate).HasColumnType("datetime");

                entity.Property(e => e.Rms17completeDate)
                    .HasColumnName("RMS17CompleteDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.Rms17geoCompleteDate)
                    .HasColumnName("RMS17GeoCompleteDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.Rms17geoSubmitDate)
                    .HasColumnName("RMS17GeoSubmitDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.Rms17pickupDate)
                    .HasColumnName("RMS17PickupDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.Rms17submitDate)
                    .HasColumnName("RMS17SubmitDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.RmscompleteDate)
                    .HasColumnName("RMSCompleteDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.RmsgeoCompleteDate)
                    .HasColumnName("RMSGeoCompleteDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.RmsgeoSubmitDate)
                    .HasColumnName("RMSGeoSubmitDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.RmspickupDate)
                    .HasColumnName("RMSPickupDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.RmsproductVersion)
                    .HasColumnName("RMSProductVersion")
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.RmspurePremiumQuake)
                    .HasColumnName("RMSPurePremiumQuake")
                    .HasColumnType("money");

                entity.Property(e => e.RmspurePremiumScs)
                    .HasColumnName("RMSPurePremiumSCS")
                    .HasColumnType("money");

                entity.Property(e => e.RmspurePremiumWind)
                    .HasColumnName("RMSPurePremiumWind")
                    .HasColumnType("money");

                entity.Property(e => e.RmspurePremiumWinterStorm)
                    .HasColumnName("RMSPurePremiumWinterStorm")
                    .HasColumnType("money");

                entity.Property(e => e.RmsrunDate)
                    .HasColumnName("RMSRunDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.RmssubmitDate)
                    .HasColumnName("RMSSubmitDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.RolledBackBy)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.RolledBackDate).HasColumnType("datetime");

                entity.Property(e => e.RoofConstructionCode).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.RoofConstructionScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.RoofLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.RoofShapeCode).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.RoofShapeScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.SectionNumber)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.ServiceLinePremium).HasColumnType("money");

                entity.Property(e => e.SizeofLayer).HasColumnType("money");

                entity.Property(e => e.SltbrokerAddress)
                    .HasColumnName("SLTBrokerAddress")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SltbrokerName)
                    .HasColumnName("SLTBrokerName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SltbrokerNumber)
                    .HasColumnName("SLTBrokerNumber")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Sltstate)
                    .HasColumnName("SLTState")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.SpreadSheetRatersCompleteDate).HasColumnType("datetime");

                entity.Property(e => e.Squarefootage).HasColumnType("decimal(7, 0)");

                entity.Property(e => e.StructuresRentedOffPremisesCoverage)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.StructuresRentedOnPremisesCoverage)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.SubCompanyId).HasColumnName("SubCompanyID");

                entity.Property(e => e.SubCoverageCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerCity)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerCounty)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerState)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerStreet)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerZipCode)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SubProducerZipCodePlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.SurplusLinesTransactionNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.SurveyFees).HasColumnType("money");

                entity.Property(e => e.TaxFilingState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.TerritoriesCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TerrorismPremium).HasColumnType("money");

                entity.Property(e => e.Tivfgu)
                    .HasColumnName("TIVFGU")
                    .HasColumnType("money");

                entity.Property(e => e.TotalInsurancePremiumTax).HasColumnType("money");

                entity.Property(e => e.TotalPropertyLimit).HasColumnType("money");

                entity.Property(e => e.TotalPropertyPremium).HasColumnType("money");

                entity.Property(e => e.TransactionType)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Triprapremium)
                    .HasColumnName("TRIPRAPremium")
                    .HasColumnType("money");

                entity.Property(e => e.UnderwriterApprovedNotes).IsUnicode(false);

                entity.Property(e => e.UnderwriterName)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.UniqueAgentReference)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.UserCreated)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasDefaultValueSql("(right(suser_sname(),len(suser_sname())-charindex('\\',suser_sname())))");

                entity.Property(e => e.UserModified)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserUpdated)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.WindHailHurricaneDeductible).HasColumnType("money");

                entity.Property(e => e.WindHailHurricaneDeductibleNamedStorm).HasColumnType("money");

                entity.Property(e => e.WindLimit).HasColumnType("money");

                entity.Property(e => e.WiringLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.Xlsoffice)
                    .HasColumnName("XLSOffice")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.YearBuilt).HasColumnType("decimal(4, 0)");
                entity.Property(e => e.TargetedRate).HasColumnType("decimal(10, 8)");

                entity.HasOne(d => d.LogImportedFiles)
                    .WithMany(p => p.TempPolicyTransactions)
                    .HasForeignKey(d => new { d.ImportFilename, d.DuplicateFileSeq, d.UniqueAgentReference })
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("FK_TempPolicyTransactions_LogImportedFiles");
            });

            modelBuilder.Entity<TempPolicyTransactionsContracts>(entity =>
            {
                entity.HasKey(e => new { e.TempPremiumsId, e.CompanyId, e.BusinessArea, e.ContractRef, e.ContractYear })
                    .HasName("PK_TempPolicyTransactions_Contracts_ID");

                entity.ToTable("TempPolicyTransactions_Contracts");

                entity.HasIndex(e => e.Id)
                    .HasDatabaseName("IX_ID");

                entity.HasIndex(e => e.TempPremiumsId)
                    .HasDatabaseName("ix_TempPolicyTransactions_Contracts_TempPremiumsID");

                entity.HasIndex(e => new { e.TempPremiumsId, e.BusinessArea })
                    .HasDatabaseName("ix_TempPolicyTransactions_Contracts_TempPremiumsID_BusinessArea");

                entity.HasIndex(e => new { e.TempPremiumsId, e.ContractRef });

                entity.HasIndex(e => new { e.ContractRef, e.CompanyId, e.TempPremiumsId })
                    .HasDatabaseName("ix_TempPolicyTransactions_Contracts_ContractRef_CompanyID_TempPremiumsID");

                entity.HasIndex(e => new { e.ContractShare, e.LiabilityShare, e.BusinessArea, e.CompanyId })
                    .HasDatabaseName("ix_TempPolicyTransactions_Contracts_BusinessArea_CompanyID_Includes");

                entity.HasIndex(e => new { e.ContractShare, e.LiabilityShare, e.TempPremiumsId, e.CompanyId, e.BusinessArea })
                    .HasDatabaseName("ix_TempPolicyTransactions_Contracts_TempPremiumsID_CompanyID_BusinessArea_Includes");

                entity.HasIndex(e => new { e.ContractShare, e.LiabilityShare, e.BusinessArea, e.ContractRef, e.ContractYear, e.CompanyId, e.TempPremiumsId })
                    .HasDatabaseName("ix_TempPolicyTransactions_Contracts_BusinessArea_ContractRef_ContractYear_CompanyID_TempPremiumsID_Includes");

                entity.HasIndex(e => new { e.ContractShare, e.LiabilityShare, e.Commission, e.Bccommission, e.CompanyId, e.BusinessArea, e.ContractRef, e.ContractYear })
                    .HasDatabaseName("IX_CompanyID_BusinessArea_ContractRef_ContractYear_Includes");

                entity.HasIndex(e => new { e.Idold, e.ContractShare, e.LiabilityShare, e.TempPremiumsId, e.ContractRef, e.ContractYear, e.CompanyId, e.BusinessArea })
                    .HasDatabaseName("ix_TempPolicyTransactions_Contracts_TempPremiumsID_ContractRef_ContractYear_CompanyID_BusinessArea_Includes");

                entity.HasIndex(e => new { e.CompanyId, e.BusinessArea, e.ContractRef, e.ContractYear, e.ContractShare, e.LiabilityShare, e.GrossPremium, e.Commission, e.Bccommission, e.TempPremiumsId, e.Id })
                    .HasDatabaseName("ix_TempPolicyTransactions_Contracts_TempPremiumsID_ID_Includes");

                entity.Property(e => e.TempPremiumsId).HasColumnName("TempPremiumsID");

                entity.Property(e => e.CompanyId).HasColumnName("CompanyID");

                entity.Property(e => e.BusinessArea)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ContractRef)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.Bccommission)
                    .HasColumnName("BCCommission")
                    .HasColumnType("money");

                entity.Property(e => e.BccommissionPercentage)
                    .HasColumnName("BCCommissionPercentage")
                    .HasColumnType("decimal(6, 3)");

                entity.Property(e => e.Commission).HasColumnType("money");

                entity.Property(e => e.CommissionPercentage).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.ContractShare).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.EquipmentBreakdownShare).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.GrossPremium).HasColumnType("money");

                entity.Property(e => e.Id)
                    .HasColumnName("ID")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.Idold).HasColumnName("IDold");

                entity.Property(e => e.LiabilityShare).HasColumnType("decimal(6, 3)");

                entity.HasOne(d => d.TempPremiums)
                    .WithMany(p => p.TempPolicyTransactionsContracts)
                    .HasForeignKey(d => d.TempPremiumsId)
                    .HasConstraintName("FK_TempPolicyTransactions_Contracts_TempPolicyTransactions");
            });

            modelBuilder.Entity<TempPolicyTransactionsLocations>(entity =>
            {
                entity.HasKey(e => e.TempLocationsId)
                    .HasName("PK_TempPremiumsTransactionsLocations");

                entity.ToTable("TempPolicyTransactions_Locations");

                entity.HasIndex(e => e.TempPremiumsId)
                    .HasDatabaseName("ix_TempPolicyTransactions_Locations_TempPremiumsID");

                entity.HasIndex(e => new { e.TempPremiumsId, e.BuildingNumber })
                    .HasDatabaseName("ix_TempPolicyTransactions_Locations_TempPremiumsID_BuildingNumber");

                entity.HasIndex(e => new { e.TempPremiumsId, e.DocucorpFloodIncluded })
                    .HasDatabaseName("ix_TempPolicyTransactions_Locations_TempPremiumsID_DocucorpFloodIncluded");

                entity.HasIndex(e => new { e.TempPremiumsId, e.DocucorpQuakeIncluded })
                    .HasDatabaseName("ix_TempPolicyTransactions_Locations_TempPremiumsID_DocucorpQuakeIncluded");

                entity.HasIndex(e => new { e.TempPremiumsId, e.DocucorpWindIncluded })
                    .HasDatabaseName("ix_TempPolicyTransactions_Locations_TempPremiumsID_DocucorpWindIncluded");

                entity.HasIndex(e => new { e.RmshazardGeoLookupDate, e.TempPremiumsId, e.TempLocationsId })
                    .HasDatabaseName("ix_TempPolicyTransactions_Locations_RMSHazardGeoLookupDate_TempPremiumsID_TempLocationsID");

                entity.HasIndex(e => new { e.TempPremiumsId, e.TempLocationsId, e.LiabilityLimit })
                    .HasDatabaseName("ix_TempPolicyTransactions_Locations_TempPremiumsID_TempLocationsID_LiabilityLimit");

                entity.HasIndex(e => new { e.GlaggregateLimit, e.TempLocationsId, e.TempPremiumsId, e.LiabilityLimit })
                    .HasDatabaseName("ix_TempPolicyTransactions_Locations_TempLocationsID_TempPremiumsID_LiabilityLimit_Includes");

                entity.HasIndex(e => new { e.MrX, e.MrY, e.InsuredStreet, e.InsuredZipCode })
                    .HasDatabaseName("IX_MR_X_MR_Y_InsuredStreet_InsuredZipCode");

                entity.HasIndex(e => new { e.TempLocationsId, e.PropertyLimit, e.TempPremiumsId, e.TotalPropertyLimit })
                    .HasDatabaseName("ix_TempPolicyTransactions_Locations_TempPremiumsID_TotalPropertyLimit_Includes");

                entity.HasIndex(e => new { e.LimitBuildingCoverageA, e.LimitContentsCoverageC, e.LimitBusinessInterruptionCoverageD, e.TempPremiumsId, e.TempLocationsId })
                    .HasDatabaseName("ix_TempPolicyTransactions_Locations_TempPremiumsID_TempLocationsID_Includes");

                entity.HasIndex(e => new { e.LocationNumber, e.TempLocationsId, e.CorrectedBy, e.LocationTransactionType, e.IgnoreRecord, e.TempPremiumsId })
                    .HasDatabaseName("ix_TempPolicyTransactions_Locations_LocationNumber_TempLocationsID_CorrectedBy_LocationTransactionType_IgnoreRecord_TempPremiums");

                entity.HasIndex(e => new { e.LocationNumber, e.LocationTransactionType, e.InsuredStreet, e.DateErrorChecksFirstRun, e.TempPremiumsId, e.TempLocationsId, e.Corrects })
                    .HasDatabaseName("ix_TempPolicyTransactions_Locations_TempPremiumsID_TempLocationsID_Corrects_Includes");

                entity.HasIndex(e => new { e.TempPremiumsId, e.LocationNumber, e.InsuredStreet, e.InsuredCity, e.InsuredCounty, e.InsuredState, e.InsuredZipCode, e.TotalPropertyLimit })
                    .HasDatabaseName("ix_TempPolicyTransactions_Locations_TempPremiumsID_LocationNumber_InsuredStreet_InsuredCity_InsuredCounty_InsuredState_InsuredZi");

                entity.HasIndex(e => new { e.TempLocationsId, e.InsuredCity, e.InsuredCounty, e.InsuredState, e.InsuredZipCode, e.InsuredCountryScheme, e.InsuredCountryCode, e.GoogleY, e.GoogleX, e.InsuredStreet })
                    .HasDatabaseName("ix_TempPolicyTransactions_Locations_GeoGoogle");

                entity.HasIndex(e => new { e.TempLocationsId, e.InsuredStreet, e.InsuredCity, e.InsuredCounty, e.InsuredState, e.InsuredZipCode, e.InsuredCountryScheme, e.InsuredCountryCode, e.MrX, e.MrY, e.TempPremiumsId })
                    .HasDatabaseName("ix_TempPolicyTransactions_Locations_GeoMR");

                entity.Property(e => e.TempLocationsId).HasColumnName("TempLocationsID");

                entity.Property(e => e.AllOther).HasColumnType("money");

                entity.Property(e => e.AlternateHeatSourceCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.AmigclassOfBusinessCode)
                    .HasColumnName("AMIGClassOfBusinessCode")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Aopdeductible)
                    .HasColumnName("AOPDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.BalboaBankCertNumber)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.BalboaBankName)
                    .HasMaxLength(150)
                    .IsUnicode(false);

                entity.Property(e => e.BalboaGrossAdjustedPremium).HasColumnType("money");

                entity.Property(e => e.BalboaGrossPaidPremium).HasColumnType("money");

                entity.Property(e => e.BalboaGrossReturnPremium).HasColumnType("money");

                entity.Property(e => e.BalboaTier)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BasementType)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.BccustomErrorMessage)
                    .HasColumnName("BCCustomErrorMessage")
                    .IsUnicode(false);

                entity.Property(e => e.BordereauType)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.BuildingCoverageAvaluationBasis)
                    .HasColumnName("BuildingCoverageAValuationBasis")
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.BuildingNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.CalcEquipmentBreakDownPremium).HasColumnType("money");

                entity.Property(e => e.CalcHomeSystemsProtectionPremium).HasColumnType("money");

                entity.Property(e => e.CalcServiceLinePremium).HasColumnType("money");

                entity.Property(e => e.Catdeductible)
                    .HasColumnName("CATDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.CdmatchPercentage).HasColumnName("CDMatchPercentage");

                entity.Property(e => e.CoInsurancePercentage).HasColumnType("decimal(5, 2)");

                entity.Property(e => e.ConstructionCode)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.ConstructionCodeScheme)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.ContentsCoverageCvaluationBasis)
                    .HasColumnName("ContentsCoverageCValuationBasis")
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.CrimeDeductible).HasColumnType("money");

                entity.Property(e => e.CrimeLimit).HasColumnType("money");

                entity.Property(e => e.CrimePremium).HasColumnType("money");

                entity.Property(e => e.CrimeRate).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.DateCreated).HasColumnType("datetime");

                entity.Property(e => e.DateErrorChecksFirstRun).HasColumnType("datetime");

                entity.Property(e => e.DateErrorChecksLastRunEnd).HasColumnType("datetime");

                entity.Property(e => e.DateErrorChecksLastRunStart).HasColumnType("datetime");

                entity.Property(e => e.DateImported).HasColumnType("datetime");

                entity.Property(e => e.DateModified).HasColumnType("datetime");

                entity.Property(e => e.DateUpdated).HasColumnType("datetime");

                entity.Property(e => e.DocEndRevisedPropLimit)
                    .HasColumnName("DocEND_RevisedPropLimit")
                    .HasColumnType("money");

                entity.Property(e => e.DocEndTotalLiability)
                    .HasColumnName("DocEND_TotalLiability")
                    .HasColumnType("money");

                entity.Property(e => e.DocEndTotalProperty)
                    .HasColumnName("DocEND_TotalProperty")
                    .HasColumnType("money");

                entity.Property(e => e.DocEndTotalTerror)
                    .HasColumnName("DocEND_TotalTerror")
                    .HasColumnType("money");

                entity.Property(e => e.DocucorpTransCode)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.DqicoreScore)
                    .HasColumnName("DQICoreScore")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DqiquakeScore)
                    .HasColumnName("DQIQuakeScore")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.DqiwindScore)
                    .HasColumnName("DQIWindScore")
                    .HasColumnType("decimal(6, 4)");

                entity.Property(e => e.Ellimit)
                    .HasColumnName("ELLimit")
                    .HasColumnType("money");

                entity.Property(e => e.Elpremium)
                    .HasColumnName("ELPremium")
                    .HasColumnType("money");

                entity.Property(e => e.EqappendagesandOrnamentation).HasColumnName("EQAppendagesandOrnamentation");

                entity.Property(e => e.EqbaseIsolation).HasColumnName("EQBaseIsolation");

                entity.Property(e => e.EqcladdingType).HasColumnName("EQCladdingType");

                entity.Property(e => e.EqconstructionQuality).HasColumnName("EQConstructionQuality");

                entity.Property(e => e.EqcrippleWalls).HasColumnName("EQCrippleWalls");

                entity.Property(e => e.EqengineeredFoundation).HasColumnName("EQEngineeredFoundation");

                entity.Property(e => e.EqequipmentSupportMaintenance).HasColumnName("EQEquipmentSupportMaintenance");

                entity.Property(e => e.EqframeBolted).HasColumnName("EQFrameBolted");

                entity.Property(e => e.EqmechanicalandElectricalEquipmentEarthquakeBracing).HasColumnName("EQMechanicalandElectricalEquipmentEarthquakeBracing");

                entity.Property(e => e.EqplanIrregularity).HasColumnName("EQPlanIrregularity");

                entity.Property(e => e.Eqpounding).HasColumnName("EQPounding");

                entity.Property(e => e.EqshortColumnCondition).HasColumnName("EQShortColumnCondition");

                entity.Property(e => e.EqsoftStory).HasColumnName("EQSoftStory");

                entity.Property(e => e.EqsprinklerLeakageCoverageFlag)
                    .HasColumnName("EQSprinklerLeakageCoverageFlag")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.EqsprinklerLeakageSusceptibility).HasColumnName("EQSprinklerLeakageSusceptibility");

                entity.Property(e => e.EqsprinklerType).HasColumnName("EQSprinklerType");

                entity.Property(e => e.EqstructuralUpgrade).HasColumnName("EQStructuralUpgrade");

                entity.Property(e => e.EqtiltUpRetrofit).HasColumnName("EQTiltUpRetrofit");

                entity.Property(e => e.EquipmentBreakdown)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.EquipmentBreakdownPremium).HasColumnType("money");

                entity.Property(e => e.EqunreinforcedMasonryPartitionsorChimneys).HasColumnName("EQUnreinforcedMasonryPartitionsorChimneys");

                entity.Property(e => e.EqunreinforcedMasonryRetrofit).HasColumnName("EQUnreinforcedMasonryRetrofit");

                entity.Property(e => e.EqverticalIrregularity).HasColumnName("EQVerticalIrregularity");

                entity.Property(e => e.ExtendedReplacementCostCoverage).HasColumnType("money");

                entity.Property(e => e.ExteriorPaintUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.FirstFloorHeightAboveGround).HasColumnType("decimal(3, 1)");

                entity.Property(e => e.FlfoundationType).HasColumnName("FLFoundationType");

                entity.Property(e => e.FloodDeductible).HasColumnType("money");

                entity.Property(e => e.FloodLimit).HasColumnType("money");

                entity.Property(e => e.FloodZone)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.GlaggregateLimit)
                    .HasColumnName("GLAggregateLimit")
                    .HasColumnType("money");

                entity.Property(e => e.Glukbideductible)
                    .HasColumnName("GLUKBIDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukbppLimit)
                    .HasColumnName("GLUKBppLimit")
                    .HasColumnType("money");

                entity.Property(e => e.GlukbuildingDeductible)
                    .HasColumnName("GLUKBuildingDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukbuildingsLimit)
                    .HasColumnName("GLUKBuildingsLimit")
                    .HasColumnType("money");

                entity.Property(e => e.GlukbusinessIncome)
                    .HasColumnName("GLUKBusinessIncome")
                    .HasColumnType("money");

                entity.Property(e => e.GlukcontentsDeductible)
                    .HasColumnName("GLUKContentsDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukdeductibleScheme)
                    .HasColumnName("GLUKDeductibleScheme")
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukdistanceFromSaltWater)
                    .HasColumnName("GLUKDistanceFromSaltWater")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.GlukfireDeductible)
                    .HasColumnName("GLUKFireDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukfireIncluded)
                    .HasColumnName("GLUKFireIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukfloodIncluded)
                    .HasColumnName("GLUKFloodIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukhailDeductible)
                    .HasColumnName("GLUKHailDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukhailIncluded)
                    .HasColumnName("GLUKHailIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukquakeIncluded)
                    .HasColumnName("GLUKQuakeIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GluksltbrokerAddress)
                    .HasColumnName("GLUKSLTBrokerAddress")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.GluksltbrokerId).HasColumnName("GLUKSLTBrokerID");

                entity.Property(e => e.GluksltbrokerName)
                    .HasColumnName("GLUKSLTBrokerName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.GluksltbrokerState)
                    .HasColumnName("GLUKSLTBrokerState")
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GluksltbrokerTaxNumber)
                    .HasColumnName("GLUKSLTBrokerTaxNumber")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.GlukwindIncluded)
                    .HasColumnName("GLUKWindIncluded")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GlukwindstormDeductible)
                    .HasColumnName("GLUKWindstormDeductible")
                    .HasColumnType("money");

                entity.Property(e => e.GlukzonePerilsId).HasColumnName("GLUKZonePerilsID");

                entity.Property(e => e.GoogleElevation).HasColumnName("GOOGLE_Elevation");

                entity.Property(e => e.GoogleElevationResolution).HasColumnName("GOOGLE_Elevation_Resolution");

                entity.Property(e => e.GoogleGeoCodeDate)
                    .HasColumnName("GOOGLE_GeoCodeDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.GoogleLocationType)
                    .HasColumnName("GOOGLE_LOCATION_TYPE")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.GoogleX).HasColumnName("GOOGLE_X");

                entity.Property(e => e.GoogleY).HasColumnName("GOOGLE_Y");

                entity.Property(e => e.GrossPremium).HasColumnType("money");

                entity.Property(e => e.HeatingLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.HomeSystemsProtection)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.HomeSystemsProtectionPremium).HasColumnType("money");

                entity.Property(e => e.Impremium)
                    .HasColumnName("IMPremium")
                    .HasColumnType("money");

                entity.Property(e => e.InlandMarineLimit).HasColumnType("money");

                entity.Property(e => e.InsuredCity)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCountryCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCountryScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredCounty)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredStreet)
                    .HasMaxLength(500)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.InsuredZipCodePlusFour)
                    .HasMaxLength(4)
                    .IsUnicode(false);

                entity.Property(e => e.Isoglclass)
                    .HasColumnName("ISOGLClass")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.IsopropertyCode)
                    .HasColumnName("ISOPropertyCode")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.LiabilityDeductible).HasColumnType("money");

                entity.Property(e => e.LiabilityLimit).HasColumnType("money");

                entity.Property(e => e.LiabilityPremium).HasColumnType("money");

                entity.Property(e => e.LimitBuildingCoverageA).HasColumnType("money");

                entity.Property(e => e.LimitBusinessInterruptionCoverageD).HasColumnType("money");

                entity.Property(e => e.LimitContentsCoverageC).HasColumnType("money");

                entity.Property(e => e.LimitCoverageE).HasColumnType("money");

                entity.Property(e => e.LimitOtherCoverageB).HasColumnType("money");

                entity.Property(e => e.LimitResidenceBurglary).HasColumnType("money");

                entity.Property(e => e.LocationNumber)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LocationTransactionType)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.MgadistanceToCoastMiles).HasColumnName("MGADistanceToCoastMiles");

                entity.Property(e => e.Mgalatitude).HasColumnName("MGALatitude");

                entity.Property(e => e.Mgalongitude).HasColumnName("MGALongitude");

                entity.Property(e => e.MoldSublimitCoverage).HasColumnType("money");

                entity.Property(e => e.MrAdditionalElevation).HasColumnName("MR_Additional_ELEVATION");

                entity.Property(e => e.MrAdditionalPopulation).HasColumnName("MR_Additional_POPULATION");

                entity.Property(e => e.MrCity)
                    .HasColumnName("MR_CITY")
                    .HasMaxLength(150);

                entity.Property(e => e.TargetedRate).HasColumnType("decimal(10, 8)");

                entity.Property(e => e.MrCoordind).HasColumnName("MR_COORDIND");

                entity.Property(e => e.MrCrestaHighresId)
                    .HasColumnName("MR_CRESTA_HIGHRES_ID")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaHighresName)
                    .HasColumnName("MR_CRESTA_HIGHRES_NAME")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaLowresId)
                    .HasColumnName("MR_CRESTA_LOWRES_ID")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaLowresName)
                    .HasColumnName("MR_CRESTA_LOWRES_NAME")
                    .HasMaxLength(150);

                entity.Property(e => e.MrCrestaid)
                    .HasColumnName("MR_CRESTAID")
                    .HasMaxLength(255);

                entity.Property(e => e.MrCrestaname)
                    .HasColumnName("MR_CRESTANAME")
                    .HasMaxLength(255);

                entity.Property(e => e.MrDistanceToCoast).HasColumnName("MR_DISTANCE_TO_COAST");

                entity.Property(e => e.MrDistanceToFault).HasColumnName("MR_DISTANCE_TO_FAULT");

                entity.Property(e => e.MrErrAdditional)
                    .HasColumnName("MR_ERR_Additional")
                    .HasMaxLength(150);

                entity.Property(e => e.MrErrCresta)
                    .HasColumnName("MR_ERR_CRESTA")
                    .HasMaxLength(255);

                entity.Property(e => e.MrErrCrestaHighres)
                    .HasColumnName("MR_ERR_CRESTA_HIGHRES")
                    .HasMaxLength(150);

                entity.Property(e => e.MrErrCrestaLowres)
                    .HasColumnName("MR_ERR_CRESTA_LOWRES")
                    .HasMaxLength(150);

                entity.Property(e => e.MrErrGcd)
                    .HasColumnName("MR_ERR_GCD")
                    .HasMaxLength(255);

                entity.Property(e => e.MrErrHazard)
                    .HasColumnName("MR_ERR_Hazard")
                    .HasMaxLength(255);

                entity.Property(e => e.MrErrRiverflood).HasColumnName("MR_ERR_RIVERFLOOD");

                entity.Property(e => e.MrGeoCodeDate)
                    .HasColumnName("MR_GeoCodeDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.MrGeozoneType)
                    .HasColumnName("MR_GEOZONE_TYPE")
                    .HasMaxLength(150);

                entity.Property(e => e.MrHazardEarthquake).HasColumnName("MR_Hazard_EARTHQUAKE");

                entity.Property(e => e.MrHazardExtratropicalstorm).HasColumnName("MR_Hazard_EXTRATROPICALSTORM");

                entity.Property(e => e.MrHazardFlashflood).HasColumnName("MR_Hazard_FLASHFLOOD");

                entity.Property(e => e.MrHazardHailstorm).HasColumnName("MR_Hazard_HAILSTORM");

                entity.Property(e => e.MrHazardLightning).HasColumnName("MR_Hazard_LIGHTNING");

                entity.Property(e => e.MrHazardStormsurge).HasColumnName("MR_Hazard_STORMSURGE");

                entity.Property(e => e.MrHazardTcyclone).HasColumnName("MR_Hazard_TCYCLONE");

                entity.Property(e => e.MrHazardTornado).HasColumnName("MR_Hazard_TORNADO");

                entity.Property(e => e.MrHazardTropicalcyclone).HasColumnName("MR_Hazard_TROPICALCYCLONE");

                entity.Property(e => e.MrHazardTsunami).HasColumnName("MR_Hazard_TSUNAMI");

                entity.Property(e => e.MrHazardVolcano).HasColumnName("MR_Hazard_VOLCANO");

                entity.Property(e => e.MrHazardWildfire).HasColumnName("MR_Hazard_WILDFIRE");

                entity.Property(e => e.MrHazardWstorm).HasColumnName("MR_Hazard_WSTORM");

                entity.Property(e => e.MrHnr)
                    .HasColumnName("MR_HNR")
                    .HasMaxLength(150);

                entity.Property(e => e.MrIso3)
                    .HasColumnName("MR_ISO3")
                    .HasMaxLength(150);

                entity.Property(e => e.MrQualind).HasColumnName("MR_QUALIND");

                entity.Property(e => e.MrRiskIndex).HasColumnName("MR_RiskIndex");

                entity.Property(e => e.MrRiskIndexEq).HasColumnName("MR_RiskIndexEq");

                entity.Property(e => e.MrRiskIndexFl).HasColumnName("MR_RiskIndexFl");

                entity.Property(e => e.MrRiskIndexSt).HasColumnName("MR_RiskIndexST");

                entity.Property(e => e.MrRiskScore).HasColumnName("MR_RiskScore");

                entity.Property(e => e.MrRiskScoreEq).HasColumnName("MR_RiskScoreEq");

                entity.Property(e => e.MrRiskScoreFl).HasColumnName("MR_RiskScoreFl");

                entity.Property(e => e.MrRiskScoreSt).HasColumnName("MR_RiskScoreST");

                entity.Property(e => e.MrRiverfloodRiverflood).HasColumnName("MR_RIVERFLOOD_RIVERFLOOD");

                entity.Property(e => e.MrSoil).HasColumnName("MR_SOIL");

                entity.Property(e => e.MrStr)
                    .HasColumnName("MR_STR")
                    .HasMaxLength(150);

                entity.Property(e => e.MrX).HasColumnName("MR_X");

                entity.Property(e => e.MrY).HasColumnName("MR_Y");

                entity.Property(e => e.MrZip)
                    .HasColumnName("MR_ZIP")
                    .HasMaxLength(150);

                entity.Property(e => e.Notes).IsUnicode(false);

                entity.Property(e => e.OccupancyCode)
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.OccupancyScheme)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.OpeningProtectionTypesCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.OpeningProtectionsCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.OrdinanceOrLawCoverage).HasColumnType("money");

                entity.Property(e => e.PersonalAccidentPremium).HasColumnType("money");

                entity.Property(e => e.Pllimit)
                    .HasColumnName("PLLimit")
                    .HasColumnType("money");

                entity.Property(e => e.Plpremium)
                    .HasColumnName("PLPremium")
                    .HasColumnType("money");

                entity.Property(e => e.PlumbingLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.PremiumBasis)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.PremiumBasisValue).HasColumnType("money");

                entity.Property(e => e.PrimaryFlood)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.PrimaryHeatSourceCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.ProductsCompletedOperationsPremium).HasColumnType("money");

                entity.Property(e => e.PropertyLimit).HasColumnType("money");

                entity.Property(e => e.PropertyLimitB).HasColumnType("money");

                entity.Property(e => e.PropertyPremium).HasColumnType("money");

                entity.Property(e => e.PropertyPremiumB).HasColumnType("money");

                entity.Property(e => e.ProtectionClass)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Protections)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.QuakeDeductible).HasColumnType("money");

                entity.Property(e => e.QuakeLimit).HasColumnType("money");

                entity.Property(e => e.Rate).HasColumnType("decimal(5, 3)");

                entity.Property(e => e.RateAllOther).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.RateProductsCompletedOperations).HasColumnType("decimal(6, 3)");

                entity.Property(e => e.RentalTerm)
                    .HasMaxLength(12)
                    .IsUnicode(false);

                entity.Property(e => e.Rmsbasefloodelevation).HasColumnName("RMSBASEFLOODELEVATION");

                entity.Property(e => e.Rmsbizone).HasColumnName("RMSBIZONE");

                entity.Property(e => e.Rmsbuildingelevation).HasColumnName("RMSBUILDINGELEVATION");

                entity.Property(e => e.RmsfloodElevation).HasColumnName("RMSFloodELEVATION");

                entity.Property(e => e.RmsfloodFloodway)
                    .HasColumnName("RMSFloodFLOODWAY")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.RmsfloodFlzone)
                    .HasColumnName("RMSFloodFLZONE")
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.RmsgeoResolutionCode).HasColumnName("RMSGeoResolutionCode");

                entity.Property(e => e.RmshazardGeoLookupDate)
                    .HasColumnName("RMSHazardGeoLookupDate")
                    .HasColumnType("datetime");

                entity.Property(e => e.RmsnfipRate).HasColumnName("RMSNFIP_RATE");

                entity.Property(e => e.Rmsnfipyear).HasColumnName("RMSNFIPYEAR");

                entity.Property(e => e.RmsquakeBizone).HasColumnName("RMSQuakeBIZONE");

                entity.Property(e => e.RmsquakeLandslide).HasColumnName("RMSQuakeLANDSLIDE");

                entity.Property(e => e.RmsquakeLiquefact).HasColumnName("RMSQuakeLIQUEFACT");

                entity.Property(e => e.RmsquakeSoilperiod).HasColumnName("RMSQuakeSOILPERIOD");

                entity.Property(e => e.RmsquakeSoilthickness).HasColumnName("RMSQuakeSOILTHICKNESS");

                entity.Property(e => e.RmsquakeSoiltype).HasColumnName("RMSQuakeSOILTYPE");

                entity.Property(e => e.Rmsspecialfloodhazardarea)
                    .HasColumnName("RMSSPECIALFLOODHAZARDAREA")
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Rmswfaccess).HasColumnName("RMSWFACCESS");

                entity.Property(e => e.Rmswfareadesc).HasColumnName("RMSWFAREADESC");

                entity.Property(e => e.Rmswfhazard).HasColumnName("RMSWFHAZARD");

                entity.Property(e => e.Rmswflochist).HasColumnName("RMSWFLOCHIST");

                entity.Property(e => e.Rmswfnearhist).HasColumnName("RMSWFNEARHIST");

                entity.Property(e => e.Rmswfspeccond)
                    .HasColumnName("RMSWFSPECCOND")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Rmswfsurffuel)
                    .HasColumnName("RMSWFSURFFUEL")
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.Rmswfsuscept).HasColumnName("RMSWFSUSCEPT");

                entity.Property(e => e.Rmswfthreat).HasColumnName("RMSWFTHREAT");

                entity.Property(e => e.RmswindDistcoast).HasColumnName("RMSWindDISTCOAST");

                entity.Property(e => e.RmswindElevation).HasColumnName("RMSWindELEVATION");

                entity.Property(e => e.RmswindManrough).HasColumnName("RMSWindMANROUGH");

                entity.Property(e => e.RmswindNatrough).HasColumnName("RMSWindNATROUGH");

                entity.Property(e => e.Rmswindpool).HasColumnName("RMSWINDPOOL");

                entity.Property(e => e.RoofAnchorCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.RoofConstructionCode).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.RoofConstructionScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.RoofCoverageValuationBasis)
                    .HasMaxLength(3)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.RoofLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.RoofShapeCode).HasColumnType("decimal(2, 0)");

                entity.Property(e => e.RoofShapeScheme)
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.RoofSheathingCode)
                    .HasMaxLength(2)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.ScreenedEnclosureCoverage).HasColumnType("money");

                entity.Property(e => e.ServiceLine)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.ServiceLinePremium).HasColumnType("money");

                entity.Property(e => e.SinkholeCoverage).HasColumnType("money");

                entity.Property(e => e.SltbrokerAddress)
                    .HasColumnName("SLTBrokerAddress")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SltbrokerName)
                    .HasColumnName("SLTBrokerName")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SltbrokerNumber)
                    .HasColumnName("SLTBrokerNumber")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Sltstate)
                    .HasColumnName("SLTState")
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.Squarefootage).HasColumnType("decimal(7, 0)");

                entity.Property(e => e.SubCoverageCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TaxFilingState)
                    .HasMaxLength(2)
                    .IsUnicode(false);

                entity.Property(e => e.TempPremiumsId).HasColumnName("TempPremiumsID");

                entity.Property(e => e.TerritoriesCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TerrorismPremium).HasColumnType("money");

                entity.Property(e => e.Tivfgu)
                    .HasColumnName("TIVFGU")
                    .HasColumnType("money");

                entity.Property(e => e.TotalPropertyLimit).HasColumnType("money");

                entity.Property(e => e.TotalPropertyPremium).HasColumnType("money");

                entity.Property(e => e.Triprapremium)
                    .HasColumnName("TRIPRAPremium")
                    .HasColumnType("money");

                entity.Property(e => e.TypeOfHeatingUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfPlumbingUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfRoofingUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.TypeOfWiringUpdates)
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.UserCreated)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserModified)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserUpdated)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.WaterSewageBackupCoverage).HasColumnType("money");

                entity.Property(e => e.WindHailHurricaneDeductible).HasColumnType("money");

                entity.Property(e => e.WindHailHurricaneDeductibleNamedStorm).HasColumnType("money");

                entity.Property(e => e.WindLimit).HasColumnType("money");

                entity.Property(e => e.WiringLastUpdated).HasColumnType("decimal(4, 0)");

                entity.Property(e => e.YearBuilt).HasColumnType("decimal(4, 0)");

                entity.HasOne(d => d.TempPremiums)
                    .WithMany(p => p.TempPolicyTransactionsLocations)
                    .HasForeignKey(d => d.TempPremiumsId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .HasConstraintName("FK_TempPremiumsTransactionsLocations_TempPremiumsTransactions");


            });

            modelBuilder.Entity<VwPolicyTransactionsLocationsIsoglclassProfessionalLiabilityLawyersIsyClRollup>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("vw_PolicyTransactions_Locations_ISOGLClass_ProfessionalLiability_Lawyers_ISyCL_Rollup");

                entity.Property(e => e.AnnualStatementLob)
                    .IsRequired()
                    .HasColumnName("AnnualStatementLOB")
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.AreaOfPracticeId).HasColumnName("AreaOfPracticeID");

                entity.Property(e => e.AverageCaseSize).HasColumnType("money");

                entity.Property(e => e.CoverageEffectiveDate).HasColumnType("datetime");

                entity.Property(e => e.CoverageExpirationDate).HasColumnType("datetime");

                entity.Property(e => e.Cspsubline)
                    .IsRequired()
                    .HasColumnName("CSPSubline")
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.Deductible).HasColumnType("money");

                entity.Property(e => e.DefenseCostDeductible).HasColumnType("money");

                entity.Property(e => e.DefenseCostLimit).HasColumnType("money");

                entity.Property(e => e.DeleteCode)
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.ExtendedReportingPeriodDate).HasColumnType("datetime");

                entity.Property(e => e.FirmRevenue).HasColumnType("money");

                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Isoglclass)
                    .HasColumnName("ISOGLClass")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.Limit).HasColumnType("money");

                entity.Property(e => e.LocId).HasColumnName("LocID");

                entity.Property(e => e.MaximumCaseSize).HasColumnType("money");

                entity.Property(e => e.PolicyAggregateLimit).HasColumnType("money");

                entity.Property(e => e.Premium).HasColumnType("money");

                entity.Property(e => e.RateDepartureLcm).HasColumnName("RateDepartureLCM");

                entity.Property(e => e.RatingId).HasColumnName("RatingID");

                entity.Property(e => e.RetroActiveDate).HasColumnType("datetime");

                entity.Property(e => e.SubCoverageCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);

                entity.Property(e => e.TermPremium).HasColumnType("money");

                entity.Property(e => e.TerritoriesCode)
                    .IsRequired()
                    .HasMaxLength(3)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
