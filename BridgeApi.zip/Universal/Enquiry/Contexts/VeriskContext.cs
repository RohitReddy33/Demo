﻿using BridgeApi.Enquiry.Models.Entities;
using Microsoft.EntityFrameworkCore;

namespace BridgeApi.Enquiry.Contexts
{
    public class VeriskContext : DbContext
    {
        public VeriskContext(DbContextOptions<VeriskContext> options) : base(options)
        { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Zillow>().HasNoKey();
            modelBuilder.Entity<VeriskEnhanceData>().HasNoKey();
        }
    }
}
