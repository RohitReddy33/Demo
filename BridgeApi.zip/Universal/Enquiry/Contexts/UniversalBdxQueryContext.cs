﻿using BridgeApi.Enquiry.Models.Entities;
using Microsoft.EntityFrameworkCore;

namespace BridgeApi.Enquiry.Contexts
{
    public class UniversalBdxQueryContext : DbContext
    {
        public UniversalBdxQueryContext(DbContextOptions<UniversalBdxQueryContext> options) : base(options)
        { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<RTMContract>().HasNoKey();
            modelBuilder.Entity<RTMLossHistory>().HasNoKey();
            modelBuilder.Entity<SearchNearByResult>().HasNoKey();
            modelBuilder.Entity<SearchEnquiryFromPrevious>().HasNoKey();
            modelBuilder.Entity<DataFetchTempResult>().HasNoKey();
            modelBuilder.Entity<BDXLogContractMonthlyTotal>().HasNoKey();
            modelBuilder.Entity<BDXLogTotals>().HasNoKey();
        }
    }
}
