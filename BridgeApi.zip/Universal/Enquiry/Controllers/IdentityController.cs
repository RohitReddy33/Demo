﻿using System;
using System.Collections.Generic;
using System.Linq;
using BridgeApi.Constants;
using BridgeApi.Enquiry.Models.DataTransferObjects;
using BridgeApi.Enquiry.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BridgeApi.Enquiry.Controllers
{
    [ApiExplorerSettings(IgnoreApi = true)]
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Policy = PolicyConstants.IdentityPolicy)]
    public class IdentityController : ControllerBase
    {
        private readonly IIdentityService _identityService;

        public IdentityController(IIdentityService identityService)
        {
            _identityService = identityService;
        }

        [HttpGet]
        [Route("Environment")]
        public ActionResult<string> GetEnvironment()
        {
            var environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
            return Ok(environment);
        }

        [HttpGet]
        [Route("WebUser")]
        public ActionResult<WebUserDTO> GetWebUser(string emailAddress)
        {
            var webUserDTO = _identityService.GetWebUser(emailAddress);
            return Ok(webUserDTO);
        }

        [HttpGet]
        [Route("WebAgents")]
        public ActionResult<List<AgentsDTO>> GetWebAgents()
        {
            var agents = _identityService.GetWebAgents();
            return Ok(agents);
        }

        [HttpGet]
        [Route("Users")]
        public ActionResult<UserDTO> GetUsers()
        {
            var users = _identityService.GetUsers();
            return Ok(users);
        }

        [HttpPut]
        [Route("User")]
        public ActionResult SaveUser(UserDTO user)
        {
            _identityService.UpsertUser(user);
            return Ok();
        }

        [HttpDelete]
        [Route("User")]
        public ActionResult DeleteUser(string username)
        {
            _identityService.DeleteUser(username);
            return Ok();
        }

        [HttpGet]
        [Route("Claims")]
        public ActionResult<List<Claim>> GetClaims(string username)
        {
            var user = _identityService.GetUsers().FirstOrDefault(x => x.Username == username);
            if (user == null)
            {
                return Ok();
            } 
            return Ok(user.Claims);
        }

        [HttpPut]
        [Route("Claim")]
        public ActionResult UpsertClaim(string username, Claim claim)
        {
            _identityService.UpsertClaim(username, claim);
            return Ok();
        }

        [HttpDelete]
        [Route("Claim")]
        public ActionResult DeleteClaim(string username, string id)
        {
            _identityService.DeleteClaim(username, id);
            return Ok();
        }
    }
}