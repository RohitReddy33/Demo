﻿using BridgeApi.Enquiry.Models.DataTransferObjects;
using BridgeApi.Enquiry.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace BridgeApi.Enquiry.Controllers
{
    [ApiExplorerSettings(IgnoreApi = true)]
    [EnableCors("AllowSpecificOrigins")]
    [Authorize]
    [Route("api/bdxlog")]
    [ApiController]
    public class BDXLogController : ControllerBase
    {
        private readonly IBDXLogService _bdxLogService;

        public BDXLogController(IBDXLogService bdxLogService)
        {
            _bdxLogService = bdxLogService;
        }

        [HttpGet]
        [Route("ContractMonthlyTotals")]
        public IActionResult GetContractMonthlyTotal(string businessArea, int companyID, string contractRef, string bordPeriod)
        {
            var bdxLogContractMonthlyTotal = _bdxLogService.GetContractMonthlyTotal(businessArea, companyID, contractRef, bordPeriod);
            return Ok(bdxLogContractMonthlyTotal);
        }

        [HttpGet]
        [Route("BordMonthYears")]
        public IActionResult GetBordMonthYears()
        {
            var bordMonthYears = _bdxLogService.GetBordMonthYears();
            return Ok(bordMonthYears);
        }

        [HttpPut]
        [Route("UpdateBDXLog")]
        public IActionResult UpdateBDXLog(BDXLogDTO contractDTO)
        {
            _bdxLogService.UpdateBDXLog(contractDTO);
            return Ok();
        }

        [HttpGet]
        [Route("BDXLogCurrentStandings")]
        public IActionResult GetBDXLogCurrentStandings() 
        {
            var bdxLogCurrentStandings = _bdxLogService.GetBDXLogCurrentStandings();
            return Ok(bdxLogCurrentStandings);
        }

    }
}