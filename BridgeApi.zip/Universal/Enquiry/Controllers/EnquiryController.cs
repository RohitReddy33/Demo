﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BridgeApi.Constants;
using BridgeApi.Enquiry.Models.DataTransferObjects;
using BridgeApi.Enquiry.Models.Entities;
using BridgeApi.Enquiry.Services;
using BridgeApi.Hazards.Domain;
using BridgeApi.Hazards.Repository;
using BridgeApi.Hazards.Services;
using BridgeApi.Models.DataTransferObjects;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Nest;
using Serilog.Context;
using Address = BridgeApi.Enquiry.Models.Entities.Address;
using Hazard = BridgeApi.Hazards.Domain.Perils.Hazard;

namespace BridgeApi.Enquiry.Controllers
{
    [ApiExplorerSettings(IgnoreApi = true)]
    [Route("api/enquiry")]
    [EnableCors("AllowSpecificOrigins")]
    [Authorize]
    [Authorize(Policy = PolicyConstants.PropertyUnderwritingToolPolicy)]
    [ApiController]
    public class EnquiryController : ControllerBase
    {
        private readonly IEnquiryService _enquiryService;
        private readonly IVeriskService _veriskService;
        private readonly IGooglePlacesService _googlePlacesService;
        private readonly IAuthorizationService _authorizationService;
        private readonly ILogger<EnquiryController> _logger;
        private IHazardService _hazardService;
        private readonly IDataikuService _dataikuService;

        public EnquiryController(IEnquiryService enquiryService, IVeriskService veriskService, IGooglePlacesService googlePlacesService, 
            IAuthorizationService authorizationService, ILogger<EnquiryController> logger, IHazardService hazardService, IDataikuService dataikuService)
        {
            _enquiryService = enquiryService;
            _veriskService = veriskService;
            _googlePlacesService = googlePlacesService;
            _authorizationService = authorizationService;
            _hazardService = hazardService;
            _logger = logger;
            _dataikuService = dataikuService;
        }

        [HttpPost]
        [Route("GeoCoordinate")]
        public ActionResult<GeoCoordinateDTO> GetGeoCoordinate(AddressDTO address)
        {
            var geoCoordinate = _enquiryService.GetGeoCoordinate(address);

            using (LogContext.PushProperty("RequestPath", Request.Path))
            using (LogContext.PushProperty("RequestQueryString", Request.QueryString))
            using (LogContext.PushProperty("Username", User.Identity.Name))
            using (LogContext.PushProperty("Address", address.ToString()))
            using (LogContext.PushProperty("location", new GeoLocation(geoCoordinate.Latitude, geoCoordinate.Longitude)))
            {
                _logger.LogInformation("Fetched geocoordinate");
            }

            return Ok(geoCoordinate);
        }

        [HttpPost]
        [Route("NewEnquiryPolicy")]
        public ActionResult<NewEnquiryPolicyResultDTO> AddNewEnquiryPolicy(NewEnquiryPolicyDTO newEnquiryPolicyDTO)
        {
            newEnquiryPolicyDTO.ContractYear ??= DateTime.Now.Year.ToString();
            newEnquiryPolicyDTO.PolicyProcessorSystemName ??= User.Identity.Name.Split("\\").Last();
            var newEnquiryPolicyResult = _enquiryService.AddNewEnquiryPolicy(newEnquiryPolicyDTO);
            return Ok(newEnquiryPolicyResult);
        }

        [HttpPost]
        [Route("NewEnquiryPolicyLocation")]
        public ActionResult AddNewEnquiryPolicyLocation(NewEnquiryPolicyLocationDTO newEnquiryPolicyLocationDTO)
        {
            _enquiryService.AddNewEnquiryPolicyLocation(newEnquiryPolicyLocationDTO);
            return Ok();
        }

        [HttpGet]
        [Route("GeoCodeInsuredAddress")]
        public ActionResult<object> GetGeoCodeInsuredAddress(double latitude, double longitude)
        {
            var geography = _enquiryService.GetGeoCodeInsuredAddress(latitude, longitude);
            return Ok(geography);
        }

        [HttpGet]
        [Route("RTMLocation")]
        public async Task<ActionResult<HazardDTO>> GetRTMLocation(int premiumsId, int showingLocationNumber)
        {
            var companyId = _enquiryService.GetCompanyIdFromTempPremiums(premiumsId);
            var authorizationResult = await _authorizationService.AuthorizeAsync(User, companyId.ToString(), PolicyConstants.SameCompanyPolicy);
            if (authorizationResult.Succeeded != true) return Forbid();

            var combinedHazardDTO = _enquiryService.GetRTMLocation(premiumsId, showingLocationNumber);
            return Ok(combinedHazardDTO);
        }

        [HttpGet]
        [Route("TIVFTGU")]
        public async Task<ActionResult<TotalInsuredValueFromGroundUpResult>> GetTIVFTGU(int tempPremiumsId)
        {
            var companyId = _enquiryService.GetCompanyIdFromTempPremiums(tempPremiumsId);
            var authorizationResult = await _authorizationService.AuthorizeAsync(User, companyId.ToString(), PolicyConstants.SameCompanyPolicy);
            if (authorizationResult.Succeeded != true) return Forbid();

            var tivftgu = _enquiryService.CalculateTotalInsuredValueFromGroundUp(tempPremiumsId).Total();
            return Ok(tivftgu);
        }

        [HttpGet]
        [Route("HazardScores")]
        public async Task<ActionResult<HazardDTO>> GetHazardScores(int premiumsId, int showingLocationNumber)
        {
            var companyId = _enquiryService.GetCompanyIdFromTempPremiums(premiumsId);
            var authorizationResult = await _authorizationService.AuthorizeAsync(User, companyId.ToString(), PolicyConstants.SameCompanyPolicy);
            if (authorizationResult.Succeeded != true) return Forbid();

            var hazardScoreDtos = _enquiryService.GetHazardScores(premiumsId, showingLocationNumber);
            return Ok(hazardScoreDtos);
        } 

        [HttpGet]
        [Route("RMSHazards")]
        public async Task<ActionResult<HazardDTO>> GetRMSHazards(int premiumsId, int showingLocationNumber)
        {
            var companyId = _enquiryService.GetCompanyIdFromTempPremiums(premiumsId);
            var authorizationResult = await _authorizationService.AuthorizeAsync(User, companyId.ToString(), PolicyConstants.SameCompanyPolicy);
            if (authorizationResult.Succeeded != true) return Forbid();

            var rmsHazardDtos = _enquiryService.GetRMSHazards(premiumsId, showingLocationNumber);
            return Ok(rmsHazardDtos);
        }

        [HttpGet]
        [Route("RTMContractUsage")]
        public async Task<ActionResult<List<RTMContractDTO>>> GetRTMContractUsage(string insuredZipCode, int companyId)
        {
            var authorizationResult = await _authorizationService.AuthorizeAsync(User, companyId.ToString(), PolicyConstants.SameCompanyPolicy);
            if (authorizationResult.Succeeded != true) return Forbid();

            var rtmContracts = _enquiryService.GetRTMContractUsage(insuredZipCode, companyId).ToList();
            return Ok(rtmContracts);
        }

        [HttpGet]
        [Route("RTMLossHistory")]
        public async Task<ActionResult<List<RTMLossHistoryDTO>>> GetRTMLossHistory(string insuredStreet, string insuredZipCode, int companyId)
        {
            var authorizationResult = await _authorizationService.AuthorizeAsync(User, companyId.ToString(), PolicyConstants.SameCompanyPolicy);
            if (authorizationResult.Succeeded != true) return Forbid();

            var rtmLossHistories = _enquiryService.GetRTMLossHistory(insuredStreet, insuredZipCode, companyId).ToList();
            return Ok(rtmLossHistories);
        }

        [HttpPost]
        [Route("RTMSearchNearByParameterized")]
        public ActionResult<List<SearchNearByResultDTO>> GetRTMSearchNearByParameterized(AreaSearchCriteriaDTO areaSearchCriteriaDTO)
        {
            var searchNearByResults = _enquiryService.GetRTMSearchNearByParameterized(areaSearchCriteriaDTO);
            return Ok(searchNearByResults);
        }

        [HttpGet]
        [Route("RTMSearchEnquiryFromPrevious")]
        public async Task<ActionResult<HazardDTO>> GetRTMSearchEnquiryFromPrevious(string searchKey, string companyId)
        {
            var authorizationResult = await _authorizationService.AuthorizeAsync(User, companyId, PolicyConstants.SameCompanyPolicy);
            if (authorizationResult.Succeeded != true) return Forbid();

            var searchEnquiresFromPrevious = _enquiryService.GetRTMSearchEnquiryFromPrevious(searchKey, companyId);
            return Ok(searchEnquiresFromPrevious);
        }

        [HttpGet]
        [Route("RTMSearchEnquiryFromPreviousByPolicyNumber")]
        public async Task<ActionResult<HazardDTO>> GetRTMSearchEnquiryFromPreviousByPolicyNumber(string policyNumber, string companyId)
        {
            var authorizationResult = await _authorizationService.AuthorizeAsync(User, companyId, PolicyConstants.SameCompanyPolicy);
            if (authorizationResult.Succeeded != true) return Forbid();
            var searchEnquiresFromPrevious = _enquiryService.GetRTMSearchEnquiryFromPreviousByPolicyNumber(policyNumber, companyId);
            return Ok(searchEnquiresFromPrevious);
        }

        [HttpGet]
        [Route("RTMSearchEnquiryFromPreviousByName")]
        public async Task<ActionResult<HazardDTO>> GetRTMSearchEnquiryFromPreviousByName(string name, string companyId)
        {
            var authorizationResult = await _authorizationService.AuthorizeAsync(User, companyId, PolicyConstants.SameCompanyPolicy);
            if (authorizationResult.Succeeded != true) return Forbid();

            var searchEnquiresFromPrevious = _enquiryService.GetRTMSearchEnquiryFromPreviousByName(name, companyId);
            return Ok(searchEnquiresFromPrevious);
        }

        [HttpGet]
        [Route("GetMaxLocationNumber")]
        public async Task<ActionResult<string>> GetMaxLocationNumber(string tempPremiumsId)
        {
            var companyId = _enquiryService.GetCompanyIdFromTempPremiums(long.Parse(tempPremiumsId));
            var authorizationResult = await _authorizationService.AuthorizeAsync(User, companyId.ToString(), PolicyConstants.SameCompanyPolicy);
            if (authorizationResult.Succeeded != true) return Forbid();

            var maxLocationNumber = _enquiryService.GetMaxLocationNumber(long.Parse(tempPremiumsId));
            return Ok(maxLocationNumber);
        }

        [HttpPost]
        [Route("GetZillow")]
        public ActionResult<List<ZillowDTO>> GetZillow(VeriskEnquiryDTO veriskEnquiryDTO)
        {
            var zillowDTOs = _veriskService.GetZillow(veriskEnquiryDTO);
            return Ok(zillowDTOs);
        }

        [HttpPost]
        [Route("EnhanceData")]
        public ActionResult<VeriskEnhanceData> GetEnhanceData(VeriskEnquiryDTO veriskEnquiryDTO)
        {
            var veriskEnhanceData = _veriskService.GetEnhanceData(veriskEnquiryDTO);
            return Ok(veriskEnhanceData);
        }

        [HttpGet]
        [Route("DropDowns")]
        public async Task<ActionResult<CombinedDropDownItemDTO>> GetDropDowns(string companyId, string businessArea)
        {
            var authorizationResult = await _authorizationService.AuthorizeAsync(User, companyId, PolicyConstants.SameCompanyPolicy);
            if (authorizationResult.Succeeded != true) return Forbid();

            var combinedDropDownItemDTO =_enquiryService.GetDropDowns(companyId, businessArea);
            return Ok(combinedDropDownItemDTO);
        }

        [HttpGet]
        [Route("ContractDropDowns")]
        public async Task<ActionResult<List<ContractDropDownDTO>>> GetContractDropDowns(string companyId, string businessArea)
        {
            var authorizationResult = await _authorizationService.AuthorizeAsync(User, companyId, PolicyConstants.SameCompanyPolicy);
            if (authorizationResult.Succeeded != true) return Forbid();

            var contractDropDownsDTO = _enquiryService.GetContractDropDowns(companyId, businessArea);
            return Ok(contractDropDownsDTO);
        }

        [HttpPost]
        [Route("SaveQuote")]
        public ActionResult SaveQuote(RiskDetailsDTO riskDetailsDTO)
        {
            var username = User.Identity.Name.Split("\\").Last();
            _enquiryService.UpdateQuote(riskDetailsDTO, username);
            return Ok();
        }

        [HttpGet]
        [Route("KickOffModelling")]
        public async Task<ActionResult> KickOffModelling(string tempPremiumsId)
        {
            var companyId = _enquiryService.GetCompanyIdFromTempPremiums(long.Parse(tempPremiumsId));
            var authorizationResult = await _authorizationService.AuthorizeAsync(User, companyId.ToString(), PolicyConstants.SameCompanyPolicy);
            if (authorizationResult.Succeeded != true) return Forbid();

            _enquiryService.KickOffModelling(long.Parse(tempPremiumsId));
            return Ok();
        }

        [HttpGet]
        [Route("KickOffHazards")]
        public async Task<ActionResult> KickOffHazards(string tempPremiumsId)
        {
            var companyId = _enquiryService.GetCompanyIdFromTempPremiums(long.Parse(tempPremiumsId));
            var authorizationResult = await _authorizationService.AuthorizeAsync(User, companyId.ToString(), PolicyConstants.SameCompanyPolicy);
            if (authorizationResult.Succeeded != true) return Forbid();

            _enquiryService.KickOffHazards(long.Parse(tempPremiumsId));
            return Ok();
        }

        [HttpGet]
        [Route("OccupancyCodes")]
        public ActionResult<List<OccupancyDTO>> GetOccupancyCodes(string occupancyScheme = "ISOPROP")
        {
            var occupanciesDTO = _enquiryService.GetOccupancyCodes(occupancyScheme);
            return Ok(occupanciesDTO);
        }

        [HttpGet]
        [Route("ConstructionCodes")]
        public ActionResult<List<ConstructionCodeDTO>> GetConstructionCodes(string constructionCodeScheme = "ISOFIRE")
        {
            var constructionCodesDTO = _enquiryService.GetConstructionCodes(constructionCodeScheme);
            return Ok(constructionCodesDTO);
        }

        [HttpGet]
        [Route("GoogleAutocomplete")]
        public async Task<ActionResult<GoogleAutocompleteResultDTO>> GetGoogleAutocompleteAsync(string userInput)
        {
            var googleAutocompleteResults = await _googlePlacesService.GetAutocompleteAsync(userInput);
            googleAutocompleteResults.SetItemTypes();
            return Ok(googleAutocompleteResults);
        }

        [HttpGet]
        [Route("GooglePlace")]
        public async Task<ActionResult<object>> GetGooglePlaceByIdAsync(string placeId)
        {
            var googlePlaceResult = await _googlePlacesService.GetPlace(placeId);
            return Ok(googlePlaceResult);
        }


        [HttpGet]
        [Route("DataFetchTemp")]
        public async Task<ActionResult<List<DataFetchTempResult>>> GetDataFetchTemp(string tempPremiumsId, string companyId, string locationNumber, bool includeIgnored)
        {
            var authorizationResult = await _authorizationService.AuthorizeAsync(User, companyId, PolicyConstants.SameCompanyPolicy);
            if (authorizationResult.Succeeded != true) return Forbid();

            var dataFetchTempResults = _enquiryService.DataFetchTemp(tempPremiumsId, companyId, locationNumber, includeIgnored);
            return Ok(dataFetchTempResults);
        }

        [HttpDelete]
        [Route("DeleteLocation")]
        public async Task<ActionResult<List<DataFetchTempResult>>> DeleteLocation(string tempPremiumsId, string locationNumber)
        {
            var companyId = _enquiryService.GetCompanyIdFromTempPremiums(long.Parse(tempPremiumsId));
            var authorizationResult = await _authorizationService.AuthorizeAsync(User, companyId.ToString(), PolicyConstants.SameCompanyPolicy);
            if (authorizationResult.Succeeded != true) return Forbid();

            _enquiryService.DeleteLocation(tempPremiumsId, locationNumber);
            return Ok();
        }

        [HttpPost]
        [Route("Hazards")]
        public async Task<ActionResult<List<Hazard>>> GetHazards(HazardRequest hazardRequest)
        {
            var internalAuthorizationResult = await _authorizationService.AuthorizeAsync(User, PolicyConstants.InternalPolicy);

            if (internalAuthorizationResult.Succeeded)
            {
                var hazards = await _hazardService.GetHazards(hazardRequest);
                return Ok(hazards);
            }
            var hazardsObfuscated = await _hazardService.GetHazardsObfuscated(hazardRequest);
            return Ok(hazardsObfuscated);
        }

        [HttpPost]
        [Route("HazardsFromAddress")]
        public async Task<ActionResult<List<Hazard>>> GetHazards(Hazards.Domain.Address address)
        {
            var internalAuthorizationResult = await _authorizationService.AuthorizeAsync(User, PolicyConstants.InternalPolicy);

            if (internalAuthorizationResult.Succeeded)
            {
                var hazards = await _hazardService.GetHazards(address);
                return Ok(hazards);
            }

            var hazardsObfuscated = await _hazardService.GetHazardsObfuscated(address);
            return Ok(hazardsObfuscated);
        }
        [HttpPost]
        [Route("HazardsTable")]
        public async Task<ActionResult<List<HazardsTable>>> GetHazardsTable(Hazards.Domain.Address address)
        {
            var internalAuthorizationResult = await _authorizationService.AuthorizeAsync(User, PolicyConstants.InternalPolicy);

            if (internalAuthorizationResult.Succeeded)
            {
                var hazardsTable = await _hazardService.GetHazardsTable(address);
                return Ok(hazardsTable);
            }

            var hazardsTableObfuscated = await _hazardService.GetHazardsTableObfuscated(address);
            return Ok(hazardsTableObfuscated);
        }

        [HttpPost]
        [Route("GeoCode")]
        public async Task<ActionResult<List<GeoCodeResponse>>> GetGeoCode(Hazards.Domain.Address address)
        {
            var internalAuthorizationResult = await _authorizationService.AuthorizeAsync(User, PolicyConstants.InternalPolicy);

            if (internalAuthorizationResult.Succeeded)
            {
                var geoCode = await _hazardService.GetGeoCode(address);
                return Ok(geoCode);
            }
            var geoCodeObfuscated = await _hazardService.GetGeoCodeObfuscated(address);
            return Ok(geoCodeObfuscated);
        }

        [HttpGet]
        [Route("TargetedRate")]
        public async Task<ActionResult<object>> GetTargetedRate(string tempPremiumsId)
        {
            var targetedRate = await _dataikuService.GetTargetedRate(long.Parse(tempPremiumsId));
            return Ok(targetedRate);
        }
    }
}