﻿using BridgeApi.DataEnrichment.Interfaces;
using System;
using System.Security.Cryptography;
using AutoMapper;
using System.Collections.Generic;
using BridgeApi.DataEnrichment.Entities;
using System.Linq;
using BridgeApi.LawyersProfessionalLiabilities.Domain;
using BridgeApi.Enquiry.Models.Entities;
using Newtonsoft.Json.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using BridgeApi.Hazards.Domain;
using Newtonsoft.Json;

namespace BridgeApi.DataEnrichment.Services
{
    public partial class InternalValuationResponse : IInternalValuationResponse
    {
        //public int Id { get; set; }
        public string Bcref { get; set; }
        public DateTime RecordCreatedOn { get; set; }
        public decimal? CalculatedValue { get; set; }
        public string Street { get; set; }
        public string City { get; set; }
        public string County { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public string CountryCode { get; set; }
        public int? YearBuilt { get; set; }
        public int? SquareFootage { get; set; }
        public string ProviderUniqueName { get; set; }
        public string ProviderRef { get; set; }

        public List<(string, string)> AllValues { get; set; }
        //public List<object> AllValues { get; set; }
        //public Dictionary<string, string> AllValues { get; set; }
        //public List<FieldValueItem> AllValues {  get; set; }
        public List<(string, string)> ErrorMessages { get; set; }

        public ValuationMetaData MetaData { get; set; }

        public static InternalValuationResponse FromDataEnrichment(DataEnrichment.Entities.DataEnrichmentQuery dataEnrichment, UniversalBdxdbContext dbContext)
        {
            AutoMapper.Mapper mapper = new Mapper(new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<DataEnrichment.Entities.DataEnrichmentQuery, InternalValuationResponse>()
                    .ForMember(dest => dest.ProviderUniqueName, opt => opt.MapFrom((source, destination, member) =>
                    {
                        List<string> items = (from p in dbContext.DataEnrichmentProviders
                                              where p.ProviderId == source.ProviderId
                                              select p.UniqueName).ToList();

                        if (items.Count != 1)
                            throw new Exception($"Error mapping, items count {items.Count}");
                        else
                            return items[0];
                    }))
                    .ForMember(dest => dest.AllValues, opt => opt.MapFrom((source, destination) =>
                    {
                        //Dictionary<string, string> allValues = new Dictionary<string, string>();

                        //foreach (DataEnrichmentFieldValue item in source.DataEnrichmentFieldValues)
                        //    allValues.Add(item.FieldName, item.FieldValue);

                        //return allValues;

                        //List<FieldValueItem> allValues = new List<FieldValueItem>();

                        //foreach (DataEnrichmentFieldValue item in source.DataEnrichmentFieldValues)
                        //    allValues.Add(new FieldValueItem{ Name = item.FieldName, Value = item.FieldValue});

                        //return allValues;

                        List<(string, string)> allValues = new List<(string, string)>();

                        foreach (DataEnrichmentFieldValue item in source.DataEnrichmentFieldValues)
                            allValues.Add((item.FieldName, item.FieldValue));

                        //List<object> allValues = new List<object>();

                        //foreach (DataEnrichmentFieldValue item in source.DataEnrichmentFieldValues)
                        //    allValues.Add(new { item.FieldName, item.FieldValue });


                        return allValues;
                    }));
                //.ForMember(dest => dest.ProviderRef, opt => opt.MapFrom(s => s.ExternalProviderRef));
            }));

            InternalValuationResponse response = mapper.Map<InternalValuationResponse>(dataEnrichment);

            return response;
        }
    }

    public class ValueTupleConverter : System.Text.Json.Serialization.JsonConverter<(string, string)>
    {
        public override (string, string) Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            throw new NotImplementedException();
            //(string, string) result = default;

            //if (!reader.Read())
            //{
            //    throw new JsonException();
            //}

            //while (reader.TokenType != JsonTokenType.EndObject)
            //{
            //    if (reader.ValueTextEquals("Item1") && reader.Read())
            //    {
            //        result.Item1 = JsonSerializer.Deserialize<string>(ref reader, options);
            //    }
            //    else if (reader.ValueTextEquals("Item2") && reader.Read())
            //    {
            //        result.Item2 = JsonSerializer.Deserialize<string>(ref reader, options);
            //    }
            //    else
            //    {
            //        throw new JsonException();
            //    }
            //    reader.Read();
            //}

            //return result;
        }

        public override void Write(Utf8JsonWriter writer, (string, string) value, JsonSerializerOptions options)
        {
            //writer.WriteString(value.Item1.ToString(), value.Item2.ToString());//would be invalid json by itself

            writer.WriteStartObject();
            writer.WriteString(value.Item1.ToString(), value.Item2.ToString());
            writer.WriteEndObject();

        }

        public override bool CanConvert(Type typeToConvert)
        {
            return typeToConvert == typeof((string, string));
        }

    }


    //public class TupleConverter : Newtonsoft.Json.JsonConverter
    //{

    //    public override void WriteJson(JsonWriter writer, object value, Newtonsoft.Json.JsonSerializer serializer)
    //    {
    //        (string, string) tpl = ((string, string))value;

    //        writer.WriteStartObject();
    //        writer.WritePropertyName(tpl.Item1);
    //        writer.WriteValue(tpl.Item2);
    //        writer.WriteEndObject();

    //    }

    //    public override object ReadJson(JsonReader reader, Type objectType, object existingValue, Newtonsoft.Json.JsonSerializer serializer)
    //    {
    //        throw new NotImplementedException();
    //    }

    //    public override bool CanConvert(Type objectType)
    //    {
    //        return typeof((string, string)).IsAssignableFrom(objectType);
    //    }

    //}

    /// <summary>
    /// Mimics the way Dictionary is serialized (as this was originally used and worked well with PUT) but for List of string tuples
    /// </summary>
    public class TupleListConverter : Newtonsoft.Json.JsonConverter
    {
        public override void WriteJson(JsonWriter writer, object value, Newtonsoft.Json.JsonSerializer serializer)
        {
            List<(string, string)> tpll = (List<(string, string)>)value;

            List<string> items = new List<string>();

            foreach((string, string) tpl in tpll)
                items.Add($"\"{tpl.Item1}\": \"{tpl.Item2}\"");

            writer.WriteStartObject();

            writer.WriteRaw(string.Join(",", items));

            writer.WriteEndObject();
        }

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, Newtonsoft.Json.JsonSerializer serializer)
        {
            throw new NotImplementedException();
        }

        public override bool CanConvert(Type objectType)
        {
            return typeof(List<(string, string)>).IsAssignableFrom(objectType);
        }

    }

}



