﻿using AutoMapper;
using AutoMapper.Configuration;
using BridgeApi.DataEnrichment.Models;
using BridgeApi.LawyersProfessionalLiabilities.Domain;
using Nest;
using System;
using System.Collections.Generic;
using BridgeApi.DataEnrichment.Entities;
using System.Linq;
using BridgeApi.DataEnrichment.Exceptions;
using System.Xml;

namespace BridgeApi.DataEnrichment.Services
{
    public class AddressMapper<ExternalAddressType, ExternalBuildingCharacteristicsType, ExternalOccupancyType, ExternalConstructionType>
    {
        Mapper mapToProviderAddress;

        public AddressMapper(UniversalBdxdbContext dbContext,
            string providerUniqueName,
            System.Linq.Expressions.Expression<Func<ExternalBuildingCharacteristicsType, ExternalOccupancyType>> getExternalOccupancyField,
            System.Linq.Expressions.Expression<Func<ExternalBuildingCharacteristicsType, ExternalConstructionType>> getExternalConstructionField,
            Func<string, ExternalOccupancyType> newExternalOccupancy,
            Func<string, ExternalConstructionType> newExternalConstruction,
            ValuationTypes valuationType
            )
        {
            mapToProviderAddress = new Mapper(new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<Address, ExternalAddressType>();
                cfg.CreateMap<BuildingCharacteristics, ExternalBuildingCharacteristicsType>()
                   .ForMember<ExternalOccupancyType>(getExternalOccupancyField, opt => opt.MapFrom(new MapOccupancyToExternal(dbContext, providerUniqueName, newExternalOccupancy, valuationType)))
                   .ForMember<ExternalConstructionType>(getExternalConstructionField, opt => opt.MapFrom(new MapConstructionToExternal(dbContext, providerUniqueName, newExternalConstruction)));
            }));
        }

        public ExternalAddressType ToProviderAddress(Address address)
        {
            return mapToProviderAddress.Map<ExternalAddressType>(address);
        }

        class MapOccupancyToExternal : IValueResolver<BuildingCharacteristics, ExternalBuildingCharacteristicsType, ExternalOccupancyType>
        {
            UniversalBdxdbContext dbContext;
            string providerUniqueName;
            Func<string, ExternalOccupancyType> newExternalOccupancy;
            ValuationTypes valuationType;

            public MapOccupancyToExternal(UniversalBdxdbContext context, string providerUniqueName, Func<string, ExternalOccupancyType> newExternalOccupancy, ValuationTypes valuationType)
            {
                this.providerUniqueName = providerUniqueName;
                this.newExternalOccupancy = newExternalOccupancy;
                dbContext = context;
                this.valuationType = valuationType;
            }

            public ExternalOccupancyType Resolve(BuildingCharacteristics source, ExternalBuildingCharacteristicsType destination, ExternalOccupancyType member, ResolutionContext context)
            {
                if (source.Occupancy == null)
                    return default(ExternalOccupancyType);

                List<string> items = (from m in dbContext.DataEnrichmentOccupancyMappings
                                      join p in dbContext.DataEnrichmentProviders on m.ProviderId equals p.ProviderId
                                      where m.OccupancyScheme == source.Occupancy.Scheme
                                         && m.OccupancyCode == source.Occupancy.Code
                                         && p.UniqueName == providerUniqueName
                                      select m.ProviderCode).ToList();

                if (items.Count == 0 && valuationType == ValuationTypes.RESIDENTIAL)
                    return default(ExternalOccupancyType);
                else if (items.Count != 1)
                    throw new AddressMappingException($"Error mapping {source.Occupancy.Scheme}/{source.Occupancy.Code} for providerId {providerUniqueName}, items count {items.Count}");
                else
                    return newExternalOccupancy(items[0]);
            }

        }

        class MapConstructionToExternal : IValueResolver<BuildingCharacteristics, ExternalBuildingCharacteristicsType, ExternalConstructionType>
        {
            UniversalBdxdbContext dbContext;
            string providerUniqueName;
            Func<string, ExternalConstructionType> newExternalConstruction;


            public MapConstructionToExternal(UniversalBdxdbContext context, string providerUniqueName, Func<string, ExternalConstructionType> newExternalConstruction)
            {
                this.providerUniqueName = providerUniqueName;
                this.newExternalConstruction = newExternalConstruction;
                dbContext = context;
            }

            public ExternalConstructionType Resolve(BuildingCharacteristics source, ExternalBuildingCharacteristicsType destination, ExternalConstructionType member, ResolutionContext context)
            {
                if (source.Construction == null)
                    return default(ExternalConstructionType);

                List<string> items = (from m in dbContext.DataEnrichmentConstructionMappings
                                      join p in dbContext.DataEnrichmentProviders on m.ProviderId equals p.ProviderId
                                      where m.ConstructionScheme == source.Construction.Scheme
                                         && m.ConstructionCode == source.Construction.Code
                                         && p.UniqueName == providerUniqueName
                                      select m.ProviderCode).ToList();

                if (items.Count != 1)
                    throw new AddressMappingException($"Error mapping {source.Construction.Scheme}/{source.Construction.Code} for providerId {providerUniqueName}, items count {items.Count}");
                else
                    return newExternalConstruction(items[0]);
            }
        }

        class MapOccupancyToInternal
        {
            UniversalBdxdbContext dbContext;
            int providerId;
            Func<string, ExternalOccupancyType> newExternalOccupancy;

            public MapOccupancyToInternal(UniversalBdxdbContext context, int providerId, Func<string, ExternalOccupancyType> newExternalOccupancy)
            {
                this.providerId = providerId;
                this.newExternalOccupancy = newExternalOccupancy;
                dbContext = context;
            }

            public Occupancy Resolve(ExternalBuildingCharacteristicsType source, BuildingCharacteristics destination, ExternalOccupancyType member, ResolutionContext context)
            {
                if (source == null)
                    return null;

                List<Occupancy> items = (from m in dbContext.DataEnrichmentOccupancyMappings
                                      where m.ProviderCode == source.ToString()
                                         && m.ProviderId == providerId
                                      select new Occupancy {Scheme = m.OccupancyScheme, Code = m.OccupancyCode}).ToList();

                if (items.Count != 1)
                    throw new Exception($"Error mapping {source} for providerId {providerId}, items count {items.Count}");
                else
                    return items[0];
            }
        }
    }
}
