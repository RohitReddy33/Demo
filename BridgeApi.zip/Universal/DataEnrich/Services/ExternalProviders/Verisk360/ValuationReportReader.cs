﻿using BridgeApi.DataEnrichment.Interfaces;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Xml;

namespace BridgeApi.DataEnrichment.Services.ExternalProviders.VeriskValue360
{
    public /*abstract*/ class XmlValuationReportReader : IValuationReportReader
    {
        protected XmlDocument xmlReport;
        const string xPathCommercialSingleAnswersConfig = "VeriskValue360:xPathCommercial:SingleAnswers";
        const string xPathResidentialSingleAnswersConfig = "VeriskValue360:xPathResidential:SingleAnswers";
        const string xPathCommercialAnswerGroupsConfig = "VeriskValue360:xPathCommercial:AnswerGroups";
        const string xPathResidentialAnswerGroupsConfig = "VeriskValue360:xPathResidential:AnswerGroups";

        Dictionary<string, string> xPathSingleAnswers = new Dictionary<string, string>();
        Dictionary<string, string> xPathAnswerGroups = new Dictionary<string, string>();

        public XmlValuationReportReader(string/*Func<string>*/ getReport, DataEnrichment.Models.ValuationTypes valuationType)
        {
            IConfiguration config = new ConfigurationBuilder().AddJsonFile($"DataEnrich\\Services\\ExternalProviders\\Verisk360\\VeriskSettings.json").Build();

            xmlReport = new XmlDocument();

            if (getReport == null)
                return;

            BuildXPaths(config, valuationType);

            try
            {
                xmlReport.LoadXml(getReport);// ());
            }
            catch (Exception ex)
            {
                throw new Exception("Unable to load report into XmlDocument", ex);
            }
        }

        void BuildXPaths(IConfiguration config, DataEnrichment.Models.ValuationTypes valuationType)
        {
            xPathSingleAnswers.Clear();

            string singleAnswers = valuationType == DataEnrichment.Models.ValuationTypes.COMMERCIAL ? xPathCommercialSingleAnswersConfig : xPathResidentialSingleAnswersConfig;

            var _xPathSingleAnswers = config.GetSection(singleAnswers).GetChildren();

            foreach (IConfigurationSection s in _xPathSingleAnswers)
                xPathSingleAnswers.Add(s.Key, s.Value);

            string multipleAnwers = valuationType == DataEnrichment.Models.ValuationTypes.COMMERCIAL ? xPathCommercialAnswerGroupsConfig : xPathResidentialAnswerGroupsConfig;

            var _xPathAnswerGroups = config.GetSection(multipleAnwers).GetChildren();

            foreach (IConfigurationSection s in _xPathAnswerGroups)
                xPathAnswerGroups.Add(s.Key, s.Value);
        }

        //public bool TryGetSingleAnswerValue(string name, out string value)
        //{
        //    if (!xPathSingleAnswers.ContainsKey(name.ToString()))
        //    {
        //        value = null;
        //        return false;
        //    }

        //    value = xmlReport.SelectSingleNode(xPathSingleAnswers[name])?.Value;

        //    return value != null;
        //}

        public bool TryGetSingleAnswerValue<T>(string name, IValuationReportReader.TryParseHandler<T> parser, out T value) where T : struct
        {
            string _value = xmlReport.SelectSingleNode(xPathSingleAnswers[name])?.Value;

            if (string.IsNullOrEmpty(_value) || !parser(_value, out value))
            {
                value = default(T);
                return false;
            }
            else
            {
                return true;
            }
        }

        //public bool TryGetMultipleAnswerValues(string name, out string[] values)
        //{
        //    if (!xPathAnswerGroups.ContainsKey(name))
        //    {
        //        values = new string[0];
        //        return false;
        //    }

        //    XmlNodeList nodes = xmlReport.SelectNodes(xPathAnswerGroups[name]);

        //    List<string> _values = new List<string>();

        //    foreach (XmlNode node in nodes)
        //        _values.Add($"{node.Attributes["desc"].Value} - {node.Attributes["value"].Value}");

        //    values = _values.ToArray();

        //    return _values.Count > 0;
        //}

        public List<(string name, string value)> GetAllAnswers()
        {
            List<(string name, string value)> ret = new List<(string, string)>();

            foreach(string key in xPathSingleAnswers.Keys)
            {
                //string value = xmlReport.SelectSingleNode(xPathSingleAnswers[key])?.Value;

                //ret.Add((key, string.IsNullOrEmpty(value) ? "(not available)" : value));

                XmlNodeList nodes = xmlReport.SelectNodes(xPathSingleAnswers[key]);

                foreach(XmlNode node in nodes)
                    ret.Add((key, string.IsNullOrEmpty(node.Value) ? "(not available)" : node.Value));

            }

            foreach (string key in xPathAnswerGroups.Keys)
            {
                XmlNodeList nodes = xmlReport.SelectNodes(xPathAnswerGroups[key]);

                foreach (XmlNode node in nodes)
                    ret.Add((key, $"{node.Attributes["desc"].Value} - {node.Attributes["value"].Value}"));
            }

            return ret;
        }
    }

  
}
