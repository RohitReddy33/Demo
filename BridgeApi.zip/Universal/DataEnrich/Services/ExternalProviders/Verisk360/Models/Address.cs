﻿using System.Security.Policy;

namespace BridgeApi.DataEnrichment.Services.ExternalProviders.VeriskValue360.Models
{
    public class VeriskAddress
    {
        public string Name { get; set; }
        public string Street { get; set; }
        public string City { get; set; }
        public string County { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public string CountryCode { get; set; }

        public VeriskBuildingCharacteristics BuildingCharacteristics { get; set; }
    }

    public class VeriskBuildingCharacteristics
    {
        public int? NumberOfStories { get; set; }
        public int? YearBuilt { get; set; }
        public double? SquareFeet { get; set; }
        public string UseType { get; set; }
        public string OccupancyType { get; set; }
        public string ISOConstructionClass { get; set; }
        public VeriskSupportingWall SupportingWall { get; set; }
    }

    public class VeriskSupportingWall
    {
        public string Type { get; set; }
        public double? Value { get; set; }
    }
}
