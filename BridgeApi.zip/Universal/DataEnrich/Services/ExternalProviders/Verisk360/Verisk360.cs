﻿using System;
using VeriskValue360;
using BridgeApi.DataEnrichment.Entities;
using Microsoft.Extensions.Configuration;
using BridgeApi.DataEnrichment.Interfaces;
using System.Threading.Tasks;
using BridgeApi.DataEnrichment.Services.ExternalProviders.VeriskValue360.Models;
using BridgeApi.DataEnrichment.Models;
using System.Collections.Generic;

namespace BridgeApi.DataEnrichment.Services.ExternalProviders.VeriskValue360
{
    public class Verisk : IExternalProviderValuationService<valuationReportAndValuationIdResponse>
    {
        string ownerData = "";
        string ownerGroupId = "";
        string workflowCode = "";
        string valuationId = "";
        string reportFormat = "XML";
        string locale = "en_US";
        string options = "";
        bool detailedReport = false;
        //valuationClient valuationClient;

        private IConfiguration _config;
        UniversalBdxdbContext context;


        public Verisk(IConfiguration _config, UniversalBdxdbContext context)
        {
            this._config = _config;
            this.context = context;

            //string endpoint = _config.GetSection("VeriskValue360")["endpoint"];
            //valuationClient = new valuationClient(valuationClient.EndpointConfiguration.ValuationWebServiceImplPort, endpoint);
        }

        public async Task<IExternalProviderValuationResponse<valuationReportAndValuationIdResponse>> GetValuation(string callerReferenceId, DataEnrichment.Models.Address address, DataEnrichment.Models.ValuationTypes valuationType)
        {
            AddressMapper<VeriskAddress, VeriskBuildingCharacteristics, string, string> addressMapper = new AddressMapper<VeriskAddress, VeriskBuildingCharacteristics, string, string>(context, "VeriskValue360", dest => dest.UseType, dest => dest.ISOConstructionClass, occ => occ, con => con, valuationType);
            VeriskAddress veriskAddress = addressMapper.ToProviderAddress(address);

            if (veriskAddress.BuildingCharacteristics != null)
                veriskAddress.BuildingCharacteristics.OccupancyType = "PRIMARY";

            StructureData structureData = new StructureData(veriskAddress);
            structureData.Build(valuationType);

            string endpoint = _config.GetSection("VeriskValue360")["endpoint"];
            valuationClient valuationClient = new valuationClient(valuationClient.EndpointConfiguration.ValuationWebServiceImplPort, endpoint);

            await valuationClient.OpenAsync();

            try
            {
                string groupId = _config.GetSection("VeriskValue360")["groupId"];
                string password = _config.GetSection("VeriskValue360")["password"];
                string userData = _config.GetSection("VeriskValue360")["userData"];

                string _structureData = structureData.StructureDataXml.OuterXml;
                valuationReportAndValuationIdResponse rawResp = valuationClient.calculateRecalculatableValuationAsync(groupId, password, userData, ownerData, ownerGroupId, _structureData, workflowCode, valuationId, reportFormat, locale, detailedReport, callerReferenceId, options).Result;

                VeriskResponse response = new VeriskResponse(_structureData, rawResp, valuationType, _config);

                return response;
            }
            catch (Exception ex)
            {
                throw new Exception("Error calling valuationClient.calculateRecalculatableValuationAsync", ex);
            }
            finally
            {
                valuationClient.Close();
            }
        }

        public IExternalProviderValuationResponse<valuationReportAndValuationIdResponse> GetBlankResponse()
        {
            return new VeriskResponse();
        }

        public IExternalProviderValuationResponse<valuationReportAndValuationIdResponse> GetBlankResponse(valuationReportAndValuationIdResponse response)
        {
            return new VeriskResponse(response);
        }


    }

    public class VeriskResponse : IExternalProviderValuationResponse<valuationReportAndValuationIdResponse>
    {
        valuationReportAndValuationIdResponse response;
        XmlValuationReportReader reader;

        public VeriskResponse()
        {
            this.response = new valuationReportAndValuationIdResponse();
        }

        public VeriskResponse(valuationReportAndValuationIdResponse response)
        {
            this.response = response;
        }

        public VeriskResponse(string inputData, valuationReportAndValuationIdResponse response, DataEnrichment.Models.ValuationTypes valuationType, IConfiguration config)
        {
            this.InputData = inputData;
            this.response = response;

            reader = new XmlValuationReportReader(/*config,*/ /*() =>*/ this.response.report, valuationType);
        }

        public valuationReportAndValuationIdResponse ValuationResponse
        {
            get 
            {
                return response; 
            }
            set
            {
                response = value;
            }
        }

        public string FullReport
        {
            get
            {
                return response.report;
            }
        }

        public string InputData
        {
            get; 
            private set;
        }

        public int ProviderId
        {
            get
            {
                return 1;// "VeriskValue360";
            }
        }

        public string ProviderRef
        {
            get
            {
                return response.valuationId;
            }
        }

        public string CalculatedValue
        {
            get
            {
                return response.calculatedValue;
            }
        }

        public List<(string name, string value)> GetAllAnswers()
        {
            return reader.GetAllAnswers();
        }

        public bool TryGetSingleAnswerValue<T>(string name, IValuationReportReader.TryParseHandler<T> parser, out T value) where T : struct
        {
            if (reader == null)
            {
                value = default(T);
                return false;
            }

            return reader.TryGetSingleAnswerValue(name, parser, out value);
        }

    }
}
