﻿using System.Security.AccessControl;
using System.Xml;

using Nest;
using System.Collections.Generic;
using BridgeApi.DataEnrichment.Services.ExternalProviders.VeriskValue360.Models;
using BridgeApi.DataEnrichment.Models;

namespace BridgeApi.DataEnrichment.Services.ExternalProviders.VeriskValue360
{
    public class StructureData
    {
        VeriskAddress address;
      

        public StructureData(VeriskAddress address)
        {
            this.address = address;
        }

        public void Build(ValuationTypes valuationType)
        {
            if (valuationType == ValuationTypes.COMMERCIAL)
                BuildCommercial();
            else if (valuationType == ValuationTypes.RESIDENTIAL)
                BuildResidential();
        }

        void BuildResidential()
        {
            StructureDataXml = new XmlDocument();

            XmlNode xnResidential = StructureDataXml.CreateElement("RESIDENTIAL");

            XmlNode xnOwner = StructureDataXml.CreateElement("OWNER");
            AppendAttribute(xnOwner, "zipcode", address.ZipCode);
            AppendAttribute(xnOwner, "country", address.CountryCode);
            AppendAttribute(xnOwner, "city", address.City);
            AppendAttribute(xnOwner, "street", address.Street);
            AppendAttribute(xnOwner, "name", address.Name);
            AppendAttribute(xnOwner, "state", address.State);
            xnResidential.AppendChild(xnOwner);

            if (address.BuildingCharacteristics != null)
            {
                XmlNode xnGeneralInfo = StructureDataXml.CreateElement("GENERALINFO");
                AppendAttribute(xnGeneralInfo, "totalfinishedsqft", address.BuildingCharacteristics.SquareFeet?.ToString());
                //AppendAttribute(xnGeneralInfo, "use", address.BuildingCharacteristics.UseType);
                //AppendAttribute(xnGeneralInfo, "otype", address.BuildingCharacteristics.OccupancyType);
                //AppendAttribute(xnGeneralInfo, "numstories", address.BuildingCharacteristics.NumberOfStories?.ToString());
                AppendAttribute(xnGeneralInfo, "yearbuilt", address.BuildingCharacteristics.YearBuilt?.ToString());

                xnResidential.AppendChild(xnGeneralInfo);
            }

            XmlNode xnContext = StructureDataXml.CreateElement("CONTEXT");
            xnContext.AppendChild(xnResidential);

            StructureDataXml.AppendChild(xnContext);
        }

        void BuildCommercial()
        {
            StructureDataXml = new XmlDocument();

            XmlNode xnCommercial = StructureDataXml.CreateElement("COMMERCIAL");

            //OWNER element is left empty intentionally
            XmlNode xnOwner = StructureDataXml.CreateElement("OWNER");
            xnCommercial.AppendChild(xnOwner);

            if (address.BuildingCharacteristics != null)
            {
                XmlNode xnOccupancy = StructureDataXml.CreateElement("OCCUPANCY");
                AppendAttribute(xnOccupancy, "sqft", address.BuildingCharacteristics.SquareFeet?.ToString());
                AppendAttribute(xnOccupancy, "use", address.BuildingCharacteristics.UseType);
                AppendAttribute(xnOccupancy, "otype", address.BuildingCharacteristics.OccupancyType);
                AppendAttribute(xnOccupancy, "numstories", address.BuildingCharacteristics.NumberOfStories?.ToString());
                AppendAttribute(xnOccupancy, "yearbuilt", address.BuildingCharacteristics.YearBuilt?.ToString());
                AppendAttribute(xnOccupancy, "isoconstructionclass", address.BuildingCharacteristics.ISOConstructionClass?.ToString());

                if (address.BuildingCharacteristics.SupportingWall != null)
                {
                    XmlNode xnSupportingWalls = StructureDataXml.CreateElement("SUPPORTINGWALLS");
                    AppendAttribute(xnSupportingWalls, "type", address.BuildingCharacteristics.SupportingWall.Type);
                    AppendAttribute(xnSupportingWalls, "value", address.BuildingCharacteristics.SupportingWall.Value?.ToString());
                    xnOccupancy.AppendChild(xnSupportingWalls);
                }

                xnCommercial.AppendChild(xnOccupancy);
            }

            XmlNode xnProperty = StructureDataXml.CreateElement("PROPERTY");
            AppendAttribute(xnProperty, "zipcode", address.ZipCode);
            AppendAttribute(xnProperty, "country", address.CountryCode);
            AppendAttribute(xnProperty, "city", address.City);
            AppendAttribute(xnProperty, "street", address.Street);
            AppendAttribute(xnProperty, "name", address.Name);
            AppendAttribute(xnProperty, "state", address.State);
            xnCommercial.AppendChild(xnProperty);

            XmlNode xnContext = StructureDataXml.CreateElement("CONTEXT");
            xnContext.AppendChild(xnCommercial);

            StructureDataXml.AppendChild(xnContext);
        }

        void AppendAttribute(XmlNode target, string name, string value)
        {
            XmlAttribute xa = StructureDataXml.CreateAttribute(name);
            xa.Value = value;
            target.Attributes.Append(xa);
        }

        public XmlDocument StructureDataXml
        {
            get; private set;
        }

    }
}
