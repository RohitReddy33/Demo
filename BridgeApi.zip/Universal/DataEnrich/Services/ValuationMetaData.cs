﻿using System;

namespace BridgeApi.DataEnrichment.Services
{
    public class ValuationMetaData
    {
        public bool FromCache { get; set; }

        public DateTime DateOfDataRetrieval { get; set; }

        public string InputData { get; set; }

        public string RawData { get; set; }
    }
}
