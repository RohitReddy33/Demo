﻿using BridgeApi.DataEnrichment.Entities;
using BridgeApi.DataEnrichment.Interfaces;
using BridgeApi.DataEnrichment.Services;
using BridgeApi.DataEnrichment.Models;
using BridgeApi.DataEnrichment.Services.ExternalProviders.VeriskValue360;
using BridgeApi.UnstructuredStorage;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BridgeApi.DataEnrichment.Exceptions;

namespace BridgeApi.DataEnrichment.Services
{
    /// <summary>
    /// Takes care of checking local cache and calling external provider if local
    /// cache is stale or not present
    /// </summary>
    /// <typeparam name="TExternalProviderResponse"></typeparam>
    public class InternalValuationService<TExternalProviderResponse> : IInternalValuationService<TExternalProviderResponse>
    {
        //TODO: IInternalValuationService<ExternalProviderResponse> doesn't need type param?
        //add to this type param for blob storage (which will have instance VeriskResponse)

        UniversalBdxdbContext context;
        IExternalProviderValuationService<TExternalProviderResponse> valuation;
        IUnstructuredStorage<UnstructuredRecord<TExternalProviderResponse>> unstructuredStorage;
        private IConfiguration config, veriskConfig;
        int cacheExpiryDays;
        string[] homeownerOccupancies;
        Models.ValuationTypes valuationType;

        public InternalValuationService(IConfiguration config, UniversalBdxdbContext context, IExternalProviderValuationService<TExternalProviderResponse> valuation, IUnstructuredStorage<UnstructuredRecord<TExternalProviderResponse>> unstructuredStorage)
        {
            this.context = context;
            this.config = config;
            this.veriskConfig = new ConfigurationBuilder().AddJsonFile($"DataEnrich\\Services\\ExternalProviders\\Verisk360\\VeriskSettings.json").Build();
            this.valuation = valuation;
            this.unstructuredStorage = unstructuredStorage;
            cacheExpiryDays = int.Parse(config.GetSection("DataEnrichment")["CacheExpiryDays"]);
            homeownerOccupancies = veriskConfig.GetSection("VeriskValue360")["HomeOwnerOccupancies"].Split(',');

        }

        public async Task<IInternalValuationResponse> GetValuation(DataEnrichment.Models.Address address, bool forceRefresh, bool includeMetaData)
        {
            bool isHo = Array.Exists(homeownerOccupancies, x => x == address.BuildingCharacteristics?.Occupancy?.Code);

            return await GetValuation(address, isHo ? ValuationTypes.RESIDENTIAL : ValuationTypes.COMMERCIAL, forceRefresh, includeMetaData);
        }

        public async Task<IInternalValuationResponse> GetValuation(DataEnrichment.Models.Address address, Models.ValuationTypes valuationType, bool forceRefresh, bool includeMetaData)
        {
            string occScheme = address.BuildingCharacteristics?.Occupancy?.Scheme;//can't use null prop op in expr tree
            string occCode = address.BuildingCharacteristics?.Occupancy?.Code;
            string conScheme = address.BuildingCharacteristics?.Construction?.Scheme;
            string conCode = address.BuildingCharacteristics?.Construction?.Code;

            List<DataEnrichmentQuery> queries = (from de in context.DataEnrichmentQueries
                         where de.Street == address.Street
                            && de.City == address.City
                            && de.County == address.County
                            && de.State == address.State
                            && de.ZipCode == address.ZipCode
                            && de.CountryCode == address.CountryCode
                            && de.OccupancyScheme == occScheme
                            && de.OccupancyCode == occCode
                            && de.ConstructionScheme == conScheme
                            && de.ConstructionCode == conCode
                            && de.RecordCreatedOn >= DateTime.Now.AddMonths(-cacheExpiryDays)
                            && de.ValuationType == valuationType.ToString()
                            //TODO: additional data and valuation type R
                         select de).ToList();

            if (queries.Count >= 1 && !forceRefresh)
            {
                Entities.DataEnrichmentQuery dataEnrichment = queries[0];

                List<DataEnrichmentFieldValue> fieldValues = (from fv in context.DataEnrichmentFieldValues
                                   where fv.DataEnrichmentQueryId == dataEnrichment.DataEnrichmentQueryId
                                   select fv).ToList();

                dataEnrichment.DataEnrichmentFieldValues = fieldValues;

                InternalValuationResponse internalResponse = InternalValuationResponse.FromDataEnrichment(dataEnrichment, context);

                if (includeMetaData)
                {
                    //internalResponse.MetaData = new ValuationMetaData { FromCache = true, DateOfDataRetrieval = dataEnrichment.RecordCreatedOn, RawData = null };

                    bool cosmosEnabled = bool.Parse(config.GetSection("CosmosDB")["Enable"]);

                    if (cosmosEnabled)
                    {
                        //TODO: Wonder if this will work? To check when Cosmos available again.
                        IExternalProviderValuationResponse<TExternalProviderResponse> externalResponse = RetrieveOriginalResponse(dataEnrichment.Bcref);

                        internalResponse.MetaData = new ValuationMetaData { FromCache = true, DateOfDataRetrieval = dataEnrichment.RecordCreatedOn, RawData = externalResponse.FullReport };
                    }
                    else
                    {
                        internalResponse.MetaData = new ValuationMetaData { FromCache = true, DateOfDataRetrieval = dataEnrichment.RecordCreatedOn, RawData = "Not available no connection available to unstructured storage" };
                    }
                }

                return internalResponse;
            }
            else
            {
                string bcRef = Guid.NewGuid().ToString();

                //try catch and store any exception (eg mapping error) against DEQ table, then rethrow
                //also if response from VV360 is an error response, indicate this in DEQ (other than calc value = 0), check gets read and inserted into field values table

                try
                {
                    IExternalProviderValuationResponse<TExternalProviderResponse> externalResponse = await valuation.GetValuation(bcRef, address, valuationType);

                    StoreUnstructured(bcRef, externalResponse);

                    DataEnrichment.Entities.DataEnrichmentQuery dataEnrichment = StoreUniversal(bcRef, externalResponse.ProviderId, externalResponse.ProviderRef, address, valuationType, externalResponse);
                    InternalValuationResponse internalResponse = InternalValuationResponse.FromDataEnrichment(dataEnrichment, context);

                    if (includeMetaData)
                        internalResponse.MetaData = new ValuationMetaData { FromCache = false, DateOfDataRetrieval = dataEnrichment.RecordCreatedOn, InputData = externalResponse.InputData, RawData = externalResponse.FullReport };

                    return internalResponse;
                }
                catch (AddressMappingException amex) 
                {
                    IExternalProviderValuationResponse<TExternalProviderResponse> externalResponse = valuation.GetBlankResponse();

                    List<(string, string)> allAnswers = new List<(string, string)>();
                    allAnswers.Add(("AddressMappingException", amex.Message));

                    DataEnrichment.Entities.DataEnrichmentQuery dataEnrichment = StoreUniversal(bcRef, externalResponse.ProviderId, null, address, valuationType, externalResponse, allAnswers);
                    InternalValuationResponse internalResponse = InternalValuationResponse.FromDataEnrichment(dataEnrichment, context);

                    return internalResponse;//TODO: or rethrow exception???
                }
                catch (Exception ex)
                {
                    if (ex.InnerException.InnerException is AddressMappingException)
                    {

                        IExternalProviderValuationResponse<TExternalProviderResponse> externalResponse = valuation.GetBlankResponse();

                        List<(string, string)> allAnswers = new List<(string, string)>();
                        allAnswers.Add(("AddressMappingException", ex.InnerException.InnerException.Message));

                        DataEnrichment.Entities.DataEnrichmentQuery dataEnrichment = StoreUniversal(bcRef, externalResponse.ProviderId, null, address, valuationType, externalResponse, allAnswers);
                        InternalValuationResponse internalResponse = InternalValuationResponse.FromDataEnrichment(dataEnrichment, context);

                        return internalResponse;//TODO: or rethrow exception???
                    }
                    else
                    {
                        throw ex;
                    }


                }

            }
        }

        Entities.DataEnrichmentQuery StoreUniversal(string bcRef, int providerId, string providerRef, DataEnrichment.Models.Address address, DataEnrichment.Models.ValuationTypes valuationType, IExternalProviderValuationResponse<TExternalProviderResponse> response)
        {
            List<(string name, string value)> allAnswers = response.GetAllAnswers();

            return StoreUniversal(bcRef, providerId, providerRef, address, valuationType, response, allAnswers);
        }

        Entities.DataEnrichmentQuery StoreUniversal(string bcRef, int providerId, string providerRef, DataEnrichment.Models.Address address, DataEnrichment.Models.ValuationTypes valuationType, IExternalProviderValuationResponse<TExternalProviderResponse> response, List<(string name, string value)> allAnswers)
        {
            Entities.DataEnrichmentQuery de = new Entities.DataEnrichmentQuery();
            de.Bcref = bcRef;
            de.Street = address.Street;
            de.City = address.City;
            de.County = address.County;
            de.State = address.State;
            de.CountryCode = address.CountryCode;
            de.ZipCode = address.ZipCode;
            de.OccupancyScheme = address.BuildingCharacteristics?.Occupancy?.Scheme;
            de.OccupancyCode = address.BuildingCharacteristics?.Occupancy?.Code;
            de.ConstructionScheme = address.BuildingCharacteristics?.Construction?.Scheme;
            de.ConstructionCode = address.BuildingCharacteristics?.Construction?.Code;
            de.RecordCreatedOn = DateTime.Now;
            de.CalculatedValue = decimal.TryParse(response.CalculatedValue, out decimal calcValue) ? calcValue : (decimal?)null;
            de.ValuationType = valuationType.ToString();
            de.ProviderId = providerId;
            de.ProviderRef = providerRef;

            if (response.TryGetSingleAnswerValue<int>("YearBuilt", int.TryParse, out int yearBuilt))
                de.YearBuilt = yearBuilt;

            if (response.TryGetSingleAnswerValue<int>("SquareFootage", int.TryParse, out int squareFootage))
                de.SquareFootage = squareFootage;

            de.CountryCode = address.CountryCode;

            foreach((string name, string value) answer in allAnswers)
            {
                Entities.DataEnrichmentFieldValue defv = new DataEnrichmentFieldValue();
                defv.DataEnrichmentQuery = de;
                defv.FieldName = answer.name;
                defv.FieldValue = answer.value;

                de.DataEnrichmentFieldValues.Add(defv);

            }

            context.DataEnrichmentQueries.Add(de);

            context.SaveChanges();

            return de;
        }

        void StoreUnstructured(string bcRef, IExternalProviderValuationResponse<TExternalProviderResponse> response)
        {
            UnstructuredRecord<TExternalProviderResponse> vrw = new UnstructuredRecord<TExternalProviderResponse>
            {
                ChildRecord = response.ValuationResponse,

                Id = bcRef,
                PartitionKey = bcRef,
            };

            unstructuredStorage.InsertRecord(vrw);

        }

        /// <summary>
        /// TODO: Wonder if this will work? To check when Cosmos available again.
        /// <param name="bcRef"></param>
        /// <returns></returns>
        /// </summary>  
        IExternalProviderValuationResponse<TExternalProviderResponse> RetrieveOriginalResponse(string bcRef)
        {
            UnstructuredRecord<TExternalProviderResponse> vrw = unstructuredStorage.Query(bcRef);

            IExternalProviderValuationResponse<TExternalProviderResponse> response = valuation.GetBlankResponse(vrw.ChildRecord);

            return response;
        }
    }
}
