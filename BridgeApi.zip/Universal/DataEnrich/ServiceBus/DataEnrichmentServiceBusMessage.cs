﻿namespace BridgeApi.DataEnrichment.AzureServiceBus
{
    //TODO: move to BCShared
    public class DataEnrichmentServiceBusMessage
    {
        public DataEnrichment.Models.Address Address { get; set; }

        //public string BCRef { get; set; }
        public CorrelationObject<long> Correlation
        {
            get; set;
        }

        public class CorrelationObject<T>
        {
            public enum ObjectTypes
            {
                TempPremiumsID,
                TransID,
                RecordUniqueIdentifier
            }

            public CorrelationObject(ObjectTypes type, T value)
            {
                ObjectType = type;
                ObjectValue = value;
            }

            public ObjectTypes ObjectType
            {
                get; set;//public set for deserialization
            }

            public T ObjectValue
            {
                get;
                set;//public set for deserialization
            }
        }
    }
}
