﻿using BridgeApi.DataEnrichment.Interfaces;
using BridgeApi.DataEnrichment.Services;
using Newtonsoft.Json;
using System.Threading.Tasks;
using System;
using Azure.Messaging.ServiceBus;
using Microsoft.Extensions.Configuration;
using BridgeApi.Enquiry.Contexts;
using BridgeApi.DataEnrichment.Entities;
using Microsoft.Extensions.Logging;
using Serilog.Core;
using BridgeApi.UnstructuredStorage;
using Microsoft.EntityFrameworkCore;
using BridgeApi.DataEnrichment.Services.ExternalProviders;
using BridgeApi.UnstructuredStorage.Providers;
using BridgeApi.DataEnrichment.Services.ExternalProviders.VeriskValue360;
using VeriskValue360;

namespace BridgeApi.DataEnrichment.AzureServiceBus
{
    public class AzureServiceBus //: IDisposable
    {
        private readonly IConfiguration _configuration;
        //https://learn.microsoft.com/en-us/azure/service-bus-messaging/service-bus-dotnet-get-started-with-queues?tabs=connection-string
        ServiceBusClient client;
        ServiceBusProcessor processor;
        InternalValuationService<VeriskValue360.valuationReportAndValuationIdResponse> _internalValuationService;
        UniversalBdxdbContext contextVerisk, contextInternalVS;
        ILogger<AzureServiceBus> logger;

        public AzureServiceBus(IConfiguration configuration, ILogger<AzureServiceBus> logger)
        {
            _configuration = configuration;

            string connString = _configuration.GetConnectionString("universalDatabaseConnection");

            this.contextVerisk = new UniversalBdxdbContext(connString);
            IExternalProviderValuationService<VeriskValue360.valuationReportAndValuationIdResponse> valuation = new DataEnrichment.Services.ExternalProviders.VeriskValue360.Verisk(_configuration, contextVerisk);
            IUnstructuredStorage<UnstructuredRecord<VeriskValue360.valuationReportAndValuationIdResponse>> unstructuredStorage = new CosmosDatabaseContext<VeriskValue360.valuationReportAndValuationIdResponse>(_configuration);

            this.contextInternalVS = new UniversalBdxdbContext(connString);
            _internalValuationService = new InternalValuationService<VeriskValue360.valuationReportAndValuationIdResponse>(configuration, contextInternalVS, valuation, unstructuredStorage);

            this.logger = logger;

            var clientOptions = new ServiceBusClientOptions()
            {
                TransportType = ServiceBusTransportType.AmqpWebSockets
            };

            string connection = _configuration["ServiceBus:Endpoint"];
            string queue = _configuration["ServiceBus:DataEnrichmentQueue"];

            client = new ServiceBusClient(connection, clientOptions);

            processor = client.CreateProcessor(queue, new ServiceBusProcessorOptions());

            processor.ProcessMessageAsync += MessageHandler;

            // add handler to process any errors
            processor.ProcessErrorAsync += ErrorHandler;

            //processor.StartProcessingAsync();
        }



        public Task StartProcessing()
        {
            logger.LogInformation("ServiceBus StartProcessing called");
            return processor.StartProcessingAsync();
        }

        public bool IsProcessing
        {
            get
            {
                return processor.IsProcessing;
            }
        }

        // handle received messages
        async Task MessageHandler(ProcessMessageEventArgs args)
        {
            string body = args.Message.Body.ToString();

            DataEnrichmentServiceBusMessage dataEnrichServiceBusMessage = JsonConvert.DeserializeObject<DataEnrichmentServiceBusMessage>(body);

            string message = $"ServiceBus message received: body = {body}, address = {dataEnrichServiceBusMessage.Address}, about to call Verisk360";
            //Console.WriteLine(message);
            logger.LogInformation(message);

            System.Diagnostics.Debug.WriteLine(message);

            try
            {
                IInternalValuationResponse deResponse = _internalValuationService.GetValuation(dataEnrichServiceBusMessage.Address, true, false).Result;

                if (dataEnrichServiceBusMessage.Correlation?.ObjectType == DataEnrichmentServiceBusMessage.CorrelationObject<long>.ObjectTypes.TempPremiumsID)
                {
                    DataEnrichment.Entities.DataEnrichmentCorrelation dec = new Entities.DataEnrichmentCorrelation();
                    dec.Bcref = deResponse.Bcref;
                    dec.TempPremiumsId = dataEnrichServiceBusMessage.Correlation.ObjectValue;
                    contextVerisk.DataEnrichmentCorrelations.Add(dec);
                    contextVerisk.SaveChanges();
                }

                System.Diagnostics.Debug.WriteLine($"Verisk360 calc value: {deResponse.CalculatedValue}");
                logger.LogInformation($"Verisk360 calc value: {deResponse.CalculatedValue}");

            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"DataEnrich exception: {ex.Message}");
                logger.LogError($"DataEnrich exception handling ServiceBus message: {ex.Message}");

            }

            // complete the message. message is deleted from the queue. 
            await args.CompleteMessageAsync(args.Message);
        }

        // handle any errors when receiving messages
        Task ErrorHandler(ProcessErrorEventArgs args)
        {
            Console.WriteLine(args.Exception.ToString());
            System.Diagnostics.Debug.WriteLine($"ServiceBus: {args.Exception}");
            return Task.CompletedTask;
        }

        //public async void Dispose()
        //{
        //    await client.DisposeAsync();
        //}


    }
}
