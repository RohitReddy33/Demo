﻿using BridgeApi.DataEnrichment.Services;
using BridgeApi.DataEnrichment.Services.ExternalProviders.VeriskValue360;
using BridgeApi.DataEnrichment.Services.ExternalProviders.VeriskValue360.Models;
using System.Threading.Tasks;

namespace BridgeApi.DataEnrichment.Interfaces
{
    public interface IExternalProviderValuationService<ExternalProviderResponse>
    {
        Task<IExternalProviderValuationResponse<ExternalProviderResponse>> GetValuation(string bcref, DataEnrichment.Models.Address address, Models.ValuationTypes valuationType);

        IExternalProviderValuationResponse<ExternalProviderResponse> GetBlankResponse();

        IExternalProviderValuationResponse<ExternalProviderResponse> GetBlankResponse(ExternalProviderResponse response);
    }
}
