﻿using System.Threading.Tasks;

namespace BridgeApi.DataEnrichment.Interfaces
{
    public interface IInternalValuationService<TExternalProviderResponse>
    {
        Task<IInternalValuationResponse> GetValuation(DataEnrichment.Models.Address address, Models.ValuationTypes valuationType, bool forceRefresh, bool includeMetaData);
        Task<IInternalValuationResponse> GetValuation(DataEnrichment.Models.Address address, bool forceRefresh, bool includeMetaData);
    }
}
