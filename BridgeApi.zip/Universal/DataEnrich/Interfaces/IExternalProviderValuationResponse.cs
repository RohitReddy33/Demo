﻿

using BridgeApi.DataEnrichment.Models;
using System.Collections.Generic;
using static BridgeApi.DataEnrichment.Interfaces.IValuationReportReader;

namespace BridgeApi.DataEnrichment.Interfaces
{
    public interface IExternalProviderValuationResponse<ExternalProviderResponse>
    {
        string FullReport { get; }

        string InputData { get; }

        int ProviderId { get; }

        string ProviderRef { get; }

        string CalculatedValue { get; }

        //bool TryGetSingleAnswerValue(string name, out string value);

        bool TryGetSingleAnswerValue<T>(string name, TryParseHandler<T> parser, out T value) where T : struct;

        //public bool TryGetMultipleAnswerValues(string name, out string[] values);

        List<(string name, string value)> GetAllAnswers();

        ExternalProviderResponse ValuationResponse { get; set; }
    }
}
