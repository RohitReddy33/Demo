﻿using BridgeApi.DataEnrichment.Models;
using System.Collections.Generic;

namespace BridgeApi.DataEnrichment.Interfaces
{
    public interface IValuationReportReader
    {
        //string GetPropertyValue(FieldNames fieldName);

        //bool TryGetPropertyValue(SingleAnswers singleAnswer, out string value);
        public delegate bool TryParseHandler<T>(string value, out T result);

        public bool TryGetSingleAnswerValue<T>(string name, TryParseHandler<T> parser, out T value) where T : struct;
        //public bool TryGetSingleAnswerValue(string name, out string value);
        //public bool TryGetMultipleAnswerValues(string name, out string[] values);
        public List<(string name, string value)> GetAllAnswers();
    }
}
