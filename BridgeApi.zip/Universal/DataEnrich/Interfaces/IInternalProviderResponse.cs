﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using BridgeApi.DataEnrichment.Services;
namespace BridgeApi.DataEnrichment.Interfaces
{
    public interface IInternalValuationResponse
    {
        //int Id { get; set; }
        string Bcref { get; set; }
        DateTime RecordCreatedOn { get; set; }
        decimal? CalculatedValue { get; set; }
        string Street { get; set; }
        string City { get; set; }
        string County { get; set; }
        string State { get; set; }
        string ZipCode { get; set; }
        string CountryCode { get; set; }
        int? YearBuilt { get; set; }
        int? SquareFootage { get; set; }
        string ProviderUniqueName { get; set; }
        string ProviderRef { get; set; }

        public List<(string, string)> AllValues { get; set; }//not a dictionary, "keys" not nec unique
        //public List<object> AllValues { get; set; }
        //public List<FieldValueItem> AllValues {  get; set; }
        //public Dictionary<string, string> AllValues { get; set; }

        public List<(string, string)> ErrorMessages { get; set; }

        ValuationMetaData MetaData { get; set; }
    }

    public class FieldValueItem
    {
        public string Name
        {
            get; set;
        }

        public string Value
        {
            get; set;
        }
    }
}
