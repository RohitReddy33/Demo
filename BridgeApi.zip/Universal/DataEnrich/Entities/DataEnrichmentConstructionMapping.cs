﻿using System;
using System.Collections.Generic;

namespace BridgeApi.DataEnrichment.Entities
{
    public partial class DataEnrichmentConstructionMapping
    {
        public int Id { get; set; }

        public string ConstructionScheme { get; set; }

        public string ConstructionCode { get; set; }

        public int ProviderId { get; set; }

        public string ProviderCode { get; set; }

        public string ProviderDescription { get; set; }

        public virtual DataEnrichmentProvider Provider { get; set; }
    }
}