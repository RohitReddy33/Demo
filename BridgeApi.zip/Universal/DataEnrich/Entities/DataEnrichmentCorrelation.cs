﻿using System;
using System.Collections.Generic;

namespace BridgeApi.DataEnrichment.Entities
{
    public partial class DataEnrichmentCorrelation
    {
        public long Id { get; set; }

        public string Bcref { get; set; }

        public long TempPremiumsId { get; set; }
    }
}