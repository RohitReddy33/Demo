﻿using Nest;

namespace BridgeApi.DataEnrichment.Entities
{
    public partial class DataEnrichmentFieldValue
    {
        public override string ToString()
        {
            return $"{FieldName}={FieldValue}";
        }
    }
}
