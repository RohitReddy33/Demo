﻿using Microsoft.EntityFrameworkCore;

namespace BridgeApi.DataEnrichment.Entities
{
    public partial class UniversalBdxdbContext : DbContext
    {
        string connStr;
        public UniversalBdxdbContext(string connStr)
        {
            this.connStr = connStr;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(connStr, x => x.UseNetTopologySuite());
            }
        }


    }
}
