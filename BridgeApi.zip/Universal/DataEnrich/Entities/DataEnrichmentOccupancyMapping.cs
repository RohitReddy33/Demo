﻿using System;
using System.Collections.Generic;

namespace BridgeApi.DataEnrichment.Entities
{

    public partial class DataEnrichmentOccupancyMapping
    {
        public int Id { get; set; }

        public string OccupancyScheme { get; set; }

        public string OccupancyCode { get; set; }

        public int ProviderId { get; set; }

        public string ProviderCode { get; set; }

        public string ProviderDescription { get; set; }

        public virtual DataEnrichmentProvider Provider { get; set; }
    }
}