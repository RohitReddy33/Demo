﻿using System;
using System.Collections.Generic;

namespace BridgeApi.DataEnrichment.Entities
{

    public partial class DataEnrichmentProvider
    {
        public int ProviderId { get; set; }

        public string Name { get; set; }

        public string UniqueName { get; set; }

        public virtual ICollection<DataEnrichmentConstructionMapping> DataEnrichmentConstructionMappings { get; set; } = new List<DataEnrichmentConstructionMapping>();

        public virtual ICollection<DataEnrichmentOccupancyMapping> DataEnrichmentOccupancyMappings { get; set; } = new List<DataEnrichmentOccupancyMapping>();

        public virtual ICollection<DataEnrichmentQuery> DataEnrichmentQueries { get; set; } = new List<DataEnrichmentQuery>();
    }
}