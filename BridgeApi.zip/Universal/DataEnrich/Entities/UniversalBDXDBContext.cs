﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace BridgeApi.DataEnrichment.Entities
{

    public partial class UniversalBdxdbContext : DbContext
    {
        public UniversalBdxdbContext()
        {
        }

        public UniversalBdxdbContext(DbContextOptions<UniversalBdxdbContext> options)
            : base(options)
        {
        }

        public virtual DbSet<DataEnrichmentConstructionMapping> DataEnrichmentConstructionMappings { get; set; }

        public virtual DbSet<DataEnrichmentCorrelation> DataEnrichmentCorrelations { get; set; }

        public virtual DbSet<DataEnrichmentFieldValue> DataEnrichmentFieldValues { get; set; }

        public virtual DbSet<DataEnrichmentOccupancyMapping> DataEnrichmentOccupancyMappings { get; set; }

        public virtual DbSet<DataEnrichmentProvider> DataEnrichmentProviders { get; set; }

        public virtual DbSet<DataEnrichmentQuery> DataEnrichmentQueries { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DataEnrichmentConstructionMapping>(entity =>
            {
                entity.ToTable("DataEnrichment_ConstructionMapping");

                entity.Property(e => e.Id).HasColumnName("ID");
                entity.Property(e => e.ConstructionCode)
                    .IsRequired()
                    .HasMaxLength(6)
                    .IsUnicode(false);
                entity.Property(e => e.ConstructionScheme)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);
                entity.Property(e => e.ProviderCode)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
                entity.Property(e => e.ProviderDescription)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.HasOne(d => d.Provider).WithMany(p => p.DataEnrichmentConstructionMappings)
                    .HasForeignKey(d => d.ProviderId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DataEnrichment_ConstructionMapping_DataEnrichmentProviders");
            });

            modelBuilder.Entity<DataEnrichmentCorrelation>(entity =>
            {
                entity.ToTable("DataEnrichment_Correlation");

                entity.Property(e => e.Bcref)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("BCRef");
            });

            modelBuilder.Entity<DataEnrichmentFieldValue>(entity =>
            {
                entity.HasKey(e => e.FieldValueId);

                entity.ToTable("DataEnrichment_FieldValues");

                entity.Property(e => e.FieldValueId).HasColumnName("FieldValueID");
                entity.Property(e => e.DataEnrichmentQueryId).HasColumnName("DataEnrichmentQueryID");
                entity.Property(e => e.FieldName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
                entity.Property(e => e.FieldValue)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.HasOne(d => d.DataEnrichmentQuery).WithMany(p => p.DataEnrichmentFieldValues)
                    .HasForeignKey(d => d.DataEnrichmentQueryId)
                    .HasConstraintName("FK_DataEnrichment_FieldValues_DataEnrichmentQueries");
            });

            modelBuilder.Entity<DataEnrichmentOccupancyMapping>(entity =>
            {
                entity.ToTable("DataEnrichment_OccupancyMapping");

                entity.Property(e => e.Id).HasColumnName("ID");
                entity.Property(e => e.OccupancyCode)
                    .IsRequired()
                    .HasMaxLength(6)
                    .IsUnicode(false);
                entity.Property(e => e.OccupancyScheme)
                    .IsRequired()
                    .HasMaxLength(10)
                    .IsUnicode(false);
                entity.Property(e => e.ProviderCode)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
                entity.Property(e => e.ProviderDescription)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.HasOne(d => d.Provider).WithMany(p => p.DataEnrichmentOccupancyMappings)
                    .HasForeignKey(d => d.ProviderId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DataEnrichment_OccupancyMapping_DataEnrichmentProviders");
            });

            modelBuilder.Entity<DataEnrichmentProvider>(entity =>
            {
                entity.HasKey(e => e.ProviderId);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);
                entity.Property(e => e.UniqueName)
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<DataEnrichmentQuery>(entity =>
            {
                entity.HasKey(e => e.DataEnrichmentQueryId).HasName("PK_DataEnrichment");

                entity.Property(e => e.DataEnrichmentQueryId).HasColumnName("DataEnrichmentQueryID");
                entity.Property(e => e.Bcref)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("BCRef");
                entity.Property(e => e.CalculatedValue).HasColumnType("decimal(19, 4)");
                entity.Property(e => e.City)
                    .HasMaxLength(50)
                    .IsUnicode(false);
                entity.Property(e => e.ConstructionCode)
                    .HasMaxLength(4)
                    .IsUnicode(false);
                entity.Property(e => e.ConstructionScheme)
                    .HasMaxLength(10)
                    .IsUnicode(false);
                entity.Property(e => e.CountryCode)
                    .HasMaxLength(3)
                    .IsUnicode(false);
                entity.Property(e => e.County)
                    .HasMaxLength(50)
                    .IsUnicode(false);
                entity.Property(e => e.OccupancyCode)
                    .HasMaxLength(6)
                    .IsUnicode(false);
                entity.Property(e => e.OccupancyScheme)
                    .HasMaxLength(10)
                    .IsUnicode(false);
                entity.Property(e => e.ProviderRef)
                    .HasMaxLength(255)
                    .IsUnicode(false);
                entity.Property(e => e.RecordCreatedOn).HasColumnType("datetime");
                entity.Property(e => e.State)
                    .HasMaxLength(2)
                    .IsUnicode(false);
                entity.Property(e => e.Street)
                    .HasMaxLength(255)
                    .IsUnicode(false);
                entity.Property(e => e.ValuationType)
                    .HasMaxLength(15)
                    .IsFixedLength();
                entity.Property(e => e.ZipCode)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.HasOne(d => d.Provider).WithMany(p => p.DataEnrichmentQueries)
                    .HasForeignKey(d => d.ProviderId)
                    .HasConstraintName("FK_DataEnrichment_DataEnrichmentProviders");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }

}