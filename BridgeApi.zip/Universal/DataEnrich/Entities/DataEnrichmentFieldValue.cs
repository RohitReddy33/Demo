﻿using System;
using System.Collections.Generic;

namespace BridgeApi.DataEnrichment.Entities
{

    public partial class DataEnrichmentFieldValue
    {
        public int FieldValueId { get; set; }

        public int DataEnrichmentQueryId { get; set; }

        public string FieldName { get; set; }

        public string FieldValue { get; set; }

        public virtual DataEnrichmentQuery DataEnrichmentQuery { get; set; }
    }

}