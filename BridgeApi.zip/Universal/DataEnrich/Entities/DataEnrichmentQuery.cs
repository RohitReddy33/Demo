﻿using System;
using System.Collections.Generic;

namespace BridgeApi.DataEnrichment.Entities
{

    public partial class DataEnrichmentQuery
    {
        public int DataEnrichmentQueryId { get; set; }

        public string Bcref { get; set; }

        public string ValuationType { get; set; }

        public DateTime RecordCreatedOn { get; set; }

        public decimal? CalculatedValue { get; set; }

        public string Street { get; set; }

        public string City { get; set; }

        public string County { get; set; }

        public string State { get; set; }

        public string ZipCode { get; set; }

        public string CountryCode { get; set; }

        public int? YearBuilt { get; set; }

        public int? SquareFootage { get; set; }

        public int? NumberOfStories { get; set; }

        public int? ProviderId { get; set; }

        public string ProviderRef { get; set; }

        public string OccupancyScheme { get; set; }

        public string OccupancyCode { get; set; }

        public string ConstructionScheme { get; set; }

        public string ConstructionCode { get; set; }

        public virtual ICollection<DataEnrichmentFieldValue> DataEnrichmentFieldValues { get; set; } = new List<DataEnrichmentFieldValue>();

        public virtual DataEnrichmentProvider Provider { get; set; }
    }
}