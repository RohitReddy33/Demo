﻿namespace BridgeApi.DataEnrichment.Models
{
    public enum ValuationTypes
    {
        COMMERCIAL,
        RESIDENTIAL
    }

    //public enum SingleAnswers
    //{
    //    YearBuilt,
    //    SquareFootage,
    //    NumberOfStories,
    //    AverageStoryHeight,
    //    AcvActualAge,
    //    AcvCondition,
    //    Condition,
    //    RoofShape,
    //    Use,
    //    Basement,
    //    ErrorDetails
    //}

    //public enum AnswerGroups
    //{
    //    Foundation,
    //    FoundationType,
    //    FoundationMaterial,
    //    RoofCover,
    //    RoofMaterial,
    //    RoofStructure,
    //    RoofConstruction,
    //    Windows,
    //    ErrorDetails,
    //}


}
