﻿namespace BridgeApi.DataEnrichment.Models
{
  
}
