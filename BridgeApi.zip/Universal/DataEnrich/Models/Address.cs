﻿using System.Security.Policy;

namespace BridgeApi.DataEnrichment.Models
{
    public class Address
    {
        public string Name { get; set; }
        public string Street { get; set; }
        public string City { get; set; }
        public string County { get; set; }
        public string State { get; set; }
        public string ZipCode { get; set; }
        public string CountryCode { get; set; }

        public BuildingCharacteristics BuildingCharacteristics { get; set; }
    }

    public class BuildingCharacteristics
    {
        public int? YearBuilt { get; set; }
        public double? SquareFeet { get; set; }
        public int? NumberOfStories { get; set; }
        public Occupancy Occupancy { get; set; }
        public Construction Construction { get; set; }  
    }

    public class Construction
    {
        public string Scheme
        {
            get; set;
        }

        public string Code
        {
            get; set;
        }
    }

    public class Occupancy
    {
        public string Scheme
        {
            get; set;
        }

        public string Code
        {
            get; set;
        }
    }
}
