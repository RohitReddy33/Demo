﻿namespace BridgeApi.DataEnrichment.Models
{
   
}
