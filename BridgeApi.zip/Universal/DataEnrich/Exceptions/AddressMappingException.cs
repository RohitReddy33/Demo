﻿using System;

namespace BridgeApi.DataEnrichment.Exceptions
{
    public class AddressMappingException : Exception
    {
        public AddressMappingException(string message) 
            : base(message) 
        { 
        }
    }
}
