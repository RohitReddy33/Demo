﻿using BridgeApi.Constants;
using BridgeApi.DataEnrichment.Exceptions;
using BridgeApi.DataEnrichment.Interfaces;
using BridgeApi.DataEnrichment.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System;
using Serilog.Core;
using BridgeApi.Enquiry.Controllers;
using Microsoft.Extensions.Logging;
using BridgeApi.DataEnrichment.Services.ExternalProviders.VeriskValue360;

namespace BridgeApi.DataEnrichment.Controllers
{
    [ApiExplorerSettings(IgnoreApi = false)]
    [Route("api/[controller]")]
    [Authorize(Policy = PolicyConstants.InternalPolicy)]
    //[Authorize(Policy = PolicyConstants.PropertyUnderwritingToolPolicy)]
    [EnableCors("AllowSpecificOrigins")]
    [Authorize]
    [ApiController]
    public class DataEnrichmentController : ControllerBase
    {
        IExternalProviderValuationService<VeriskValue360.valuationReportAndValuationIdResponse> _valuationService;
        IInternalValuationService<VeriskValue360.valuationReportAndValuationIdResponse> _internalValuationService;
        private readonly ILogger<DataEnrichmentController> _logger;

        public DataEnrichmentController(IExternalProviderValuationService<VeriskValue360.valuationReportAndValuationIdResponse> valuationService, IInternalValuationService<VeriskValue360.valuationReportAndValuationIdResponse> internalValuationService, ILogger<DataEnrichmentController> logger)
        {
            _valuationService = valuationService;
            _internalValuationService = internalValuationService;
            _logger = logger;
        }

        /// <remarks>
        /// Data enrich
        /// </remarks>
        [HttpPost]
        [Route("CommercialValuation")]
        public async Task<ActionResult<IInternalValuationResponse>> GetCommercialValuation(DataEnrichment.Models.Address address, bool forceRefresh, bool includeMetaData)
        {
            //https://localhost:44320/api/DataEnrichment/Valuation?bcref=test

            try
            {
                IInternalValuationResponse valuation = await _internalValuationService.GetValuation(address, DataEnrichment.Models.ValuationTypes.COMMERCIAL, forceRefresh, includeMetaData);
                return Ok(valuation);
            }
            catch (AddressMappingException amex)
            {
                return UnprocessableEntity(amex.Message);
            }
            catch(Exception ex)
            {
                if (ex.InnerException.InnerException is AddressMappingException)
                    return UnprocessableEntity(ex.InnerException.InnerException.Message);
                else
                {
                    _logger.LogError(ex, "Unhandled Exception");
                    return StatusCode(500);
                }
            }
        }

        /// <remarks>
        /// Data enrich
        /// </remarks>
        [HttpPost]
        [Route("ResidentialValuation")]
        public async Task<ActionResult<IInternalValuationResponse>> GetResidentialValuation(DataEnrichment.Models.Address address, bool forceRefresh, bool includeMetaData)
        {
            //https://localhost:44320/api/DataEnrichment/Valuation?bcref=test
            try
            {
                IInternalValuationResponse valuation = await _internalValuationService.GetValuation(address, DataEnrichment.Models.ValuationTypes.RESIDENTIAL, forceRefresh, includeMetaData);
                return Ok(valuation);
            }
            catch (AddressMappingException amex)
            {
                return UnprocessableEntity(amex.Message);
            }
            catch (Exception ex)
            {
                if (ex.InnerException.InnerException is AddressMappingException)
                    return UnprocessableEntity(ex.InnerException.InnerException.Message);
                else
                {
                    _logger.LogError(ex, "Unhandled Exception");
                    return StatusCode(500);
                }
            }
        }

        [HttpPost]
        [Route("Valuation")]
        public async Task<ActionResult<IInternalValuationResponse>> GetValuation(DataEnrichment.Models.Address address, bool forceRefresh, bool includeMetaData)
        {
            //https://localhost:44320/api/DataEnrichment/Valuation?bcref=test
            try
            {
                IInternalValuationResponse valuation = await _internalValuationService.GetValuation(address, forceRefresh, includeMetaData);
                return Ok(valuation);
            }
            catch (AddressMappingException amex)
            {
                return UnprocessableEntity(amex.Message);
            }
            catch (Exception ex)
            {
                if (ex.InnerException.InnerException is AddressMappingException)
                    return UnprocessableEntity(ex.InnerException.InnerException.Message);
                else
                {
                    _logger.LogError(ex, "Unhandled Exception");
                    return StatusCode(500);
                }
            }
        }

        [HttpGet]
        [Route("Ping")]
        public OkResult Ping()
        {
            //https://localhost:44320/api/DataEnrichment/Ping
            return Ok();
        }
    }
}
