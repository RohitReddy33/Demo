﻿using Hangfire.Dashboard;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.DependencyInjection;
using System.Diagnostics.CodeAnalysis;

namespace BridgeApi.DataEnrichmentJobs.Helper
{
    public class HangfireAuthorizationFilter : IDashboardAuthorizationFilter
    {
        private readonly string policyName;

        public HangfireAuthorizationFilter(string policyName)
        {
            this.policyName = policyName;
        }

        public bool Authorize([NotNull] DashboardContext context)
        {
            var httpContext = context.GetHttpContext();
            var authService = httpContext.RequestServices.GetRequiredService<IAuthorizationService>();
            return authService.AuthorizeAsync(httpContext.User, this.policyName).ConfigureAwait(false).GetAwaiter().GetResult().Succeeded;
        }
    }
}
