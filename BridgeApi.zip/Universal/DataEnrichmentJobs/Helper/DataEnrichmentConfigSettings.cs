﻿namespace BridgeApi.DataEnrichmentJobs.Helper
{
    public class DataEnrichmentConfigSettings
    {    
        public string HangFireServerDatabaseConnection { get; set; }
        public DataikuTargetedRateCriteria DataikuTargetedRateCriteria { get; set; } = new DataikuTargetedRateCriteria();
    }

    public class DataikuTargetedRateCriteria
    {
        public string CronExp { get; set; }
        public string[] TransactionTypes { get; set; }
        public string[] BusinessArea { get; set; }
        public int ContractYear { get; set; }
        public decimal? Tivfgu { get; set; }
        public string ExcludedPolicyNo { get; set; }
        public int? NumberofLocations { get; set; }
        public decimal? PlacementType { get; set; }
        public decimal? HereonPercentage { get; set; }
    }
}
