﻿namespace BridgeApi.DataEnrichmentJobs.Models.Dataiku
{
    public class DataikuPolicyTransactions
    {
        public long ? TransID { get; set; }
        public long TempPremiumsId { get; set; }
        public string PolicyNo { get; set; }
        public string TransactionType { get; set; }
        public int? NumberofLocations { get; set; }
        public decimal? PlacementType { get; set; }
        public decimal? HereonPercentage { get; set; }
        public decimal? Tivfgu { get; set; }
        public string BusinessArea { get; set; }
        public int ContractYear { get; set; }


    }
}
