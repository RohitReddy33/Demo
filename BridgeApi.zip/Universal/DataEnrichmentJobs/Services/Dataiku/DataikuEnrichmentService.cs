﻿using BridgeApi.DataEnrichmentJobs.Helper;
using BridgeApi.DataEnrichmentJobs.Models.Dataiku;
using BridgeApi.Enquiry.Services;
using BridgeApi.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BridgeApi.DataEnrichmentJobs.Services.Dataiku
{
    public class DataikuEnrichmentService : IDataikuEnrichmentService
    {
       
        private readonly IUniversalBdxRepository _universalBdxRepository;               
        private readonly IDataikuService _dataikuService;
        private readonly DataEnrichmentConfigSettings _dataEnrichmentConfiguration;

        public DataikuEnrichmentService(IUniversalBdxRepository universalBdxRepository, IDataikuService dataikuService,
            DataEnrichmentConfigSettings dataEnrichmentConfiguration)
        {
            _universalBdxRepository = universalBdxRepository;           
            _dataikuService = dataikuService;
            _dataEnrichmentConfiguration = dataEnrichmentConfiguration;

        }

        /// <summary>
        /// SyncTempPolicyTargetedRateforhomeowner
        /// </summary>
        public void SyncTempPolicyTargetedRateforhomeowner()
        {
            foreach (var tempPremiumsIDs in GetHomeownerTempPolicyTransactions())
            {
                UpdateTempPolicyTransactionsTargetedRate(tempPremiumsIDs.TempPremiumsId, GetTargetedRate(tempPremiumsIDs.TempPremiumsId));
            }
        }

        /// <summary>
        /// SyncPolicyTargetedRateforhomeowner
        /// </summary>
        public void SyncPolicyTargetedRateforhomeowner()
        {           
            foreach (var tempPremiumsIDs in GetHomeownerPolicyTransactions())
            {
                UpdatePolicyTransactionsTargetedRate((long)tempPremiumsIDs.TransID, GetTargetedRate(tempPremiumsIDs.TempPremiumsId));
            }
        }

        /// <summary>
        ///  Get TargetedRate from Dataiku Service
        /// </summary>
        /// <param name="tempPremiumsId"></param>
        /// <returns></returns>
        public decimal? GetTargetedRate(long tempPremiumsId)
        {
            return _dataikuService.GetTargetedRate(tempPremiumsId).Result;
        }

        /// <summary>
        /// Get List of TempPremiumsIDs for the HomeOwner Contract 
        /// where TargetedRate is not set
        /// </summary>
        /// <returns></returns>
        public IReadOnlyCollection<DataikuPolicyTransactions> GetHomeownerTempPolicyTransactions()
        {
            var targetedRateCriteria = _dataEnrichmentConfiguration.DataikuTargetedRateCriteria;

            var tempIDs = _universalBdxRepository.GetHomeownerTempPolicyTransactions()
                 .Where(pt => targetedRateCriteria.TransactionTypes.Contains(pt.TransactionType)
                         && pt.NumberofLocations == targetedRateCriteria.NumberofLocations
                         && pt.PlacementType == targetedRateCriteria.PlacementType
                         && pt.HereonPercentage == targetedRateCriteria.HereonPercentage
                         && pt.PolicyNo != targetedRateCriteria.ExcludedPolicyNo
                         && (pt.Tivfgu ?? 0) < targetedRateCriteria.Tivfgu
                         && targetedRateCriteria.BusinessArea.Contains(pt.BusinessArea)
                         && pt.ContractYear > targetedRateCriteria.ContractYear
                         ).ToList().AsReadOnly();

            return tempIDs;
        }

        /// <summary>
        /// Get List of Policy TempPremiumsIDs for the HomeOwner Contract 
        /// where TargetedRate is not set
        /// </summary>
        /// <returns></returns>
        public IReadOnlyCollection<DataikuPolicyTransactions> GetHomeownerPolicyTransactions()
        {
            var targetedRateCriteria = _dataEnrichmentConfiguration.DataikuTargetedRateCriteria;

            var tempIDs = _universalBdxRepository.GetHomeownerPolicyTransactions()
                 .Where(pt => targetedRateCriteria.TransactionTypes.Contains(pt.TransactionType)
                         && pt.NumberofLocations == targetedRateCriteria.NumberofLocations
                         && pt.PlacementType == targetedRateCriteria.PlacementType
                         && pt.HereonPercentage == targetedRateCriteria.HereonPercentage
                         && pt.PolicyNo != targetedRateCriteria.ExcludedPolicyNo
                         && (pt.Tivfgu ?? 0) < targetedRateCriteria.Tivfgu
                         && targetedRateCriteria.BusinessArea.Contains(pt.BusinessArea)
                         && pt.ContractYear > targetedRateCriteria.ContractYear
                         )
                 .OrderByDescending(o=>o.TempPremiumsId).ToList().AsReadOnly();

            return tempIDs;
        }

        /// <summary>
        /// Update TemppolicyTransactions table TargetedRate column 
        /// </summary>
        /// <param name="tempPremiumsID"></param>
        /// <param name="targetedRate"></param>
        public void UpdateTempPolicyTransactionsTargetedRate(long tempPremiumsID, decimal? targetedRate)
        {
            if (targetedRate != null)
                _universalBdxRepository.UpdateTempPolicyTransactionsTargetedRate(tempPremiumsID, targetedRate);

        }

        /// <summary>
        /// Update PolicyTransactions table TargetedRate column
        /// </summary>
        /// <param name="transID"></param>
        /// <param name="targetedRate"></param>
        public void UpdatePolicyTransactionsTargetedRate(long transID, decimal? targetedRate)
        {
            if (targetedRate != null)
                _universalBdxRepository.UpdatePolicyTransactionsTargetedRate(transID, targetedRate);
        }

        /// <summary>
        /// SyncTempPolicyTargetedRateforhomeowner
        /// </summary>
        public void UpdateTempPolicyTargetedRateforId(long tempId)
        {
            foreach (var tempPremiumsIDs in GetHomeownerTempPolicyTransactions(tempId))
            {
                UpdateTempPolicyTransactionsTargetedRate(tempPremiumsIDs.TempPremiumsId, GetTargetedRate(tempPremiumsIDs.TempPremiumsId));
            }
        }

        /// <summary>
        /// SyncPolicyTargetedRateforhomeowner
        /// </summary>
        public void UpdatePolicyTargetedRateforId(long tempId)
        {
            foreach (var tempPremiumsIDs in GetHomeownerPolicyTransactions(tempId))
            {
                UpdatePolicyTransactionsTargetedRate((long)tempPremiumsIDs.TransID, GetTargetedRate(tempPremiumsIDs.TempPremiumsId));
            }
        }

        /// <summary>
        /// Get the TempPremiumsIDs for the HomeOwner Contract         
        /// </summary>
        /// <returns></returns>
        public IReadOnlyCollection<DataikuPolicyTransactions> GetHomeownerTempPolicyTransactions(long tempId)
        {          

            var tempIDs = _universalBdxRepository.GetHomeownerTempPolicyTransactions(tempId)
                .ToList().AsReadOnly();
            return tempIDs;
        }

        /// <summary>
        /// Get the Policy TempPremiumsIDs for the HomeOwner Contract 
        /// </summary>
        /// <returns></returns>
        public IReadOnlyCollection<DataikuPolicyTransactions> GetHomeownerPolicyTransactions(long tempId)
        {
            var tempIDs = _universalBdxRepository.GetHomeownerPolicyTransactions(tempId)                
                 .ToList().AsReadOnly();
            return tempIDs;
        }
    }
}
