﻿using BridgeApi.DataEnrichmentJobs.Models.Dataiku;
using System.Collections.Generic;

namespace BridgeApi.DataEnrichmentJobs.Services.Dataiku
{
    public interface IDataikuEnrichmentService
    {
        void SyncTempPolicyTargetedRateforhomeowner();
        void SyncPolicyTargetedRateforhomeowner();
        void UpdateTempPolicyTargetedRateforId(long tempId);
        void UpdatePolicyTargetedRateforId(long tempId);
        decimal? GetTargetedRate(long tempPremiumsId);
        IReadOnlyCollection<DataikuPolicyTransactions> GetHomeownerTempPolicyTransactions();
        void UpdateTempPolicyTransactionsTargetedRate(long tempPremiumsID, decimal? targetedRate);
        IReadOnlyCollection<DataikuPolicyTransactions> GetHomeownerPolicyTransactions();
       void UpdatePolicyTransactionsTargetedRate(long transID, decimal? targetedRate);
    }
}
