﻿using BridgeApi.Constants;
using BridgeApi.DataEnrichmentJobs.Helper;
using BridgeApi.DataEnrichmentJobs.Services.Dataiku;
using Hangfire;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;

namespace BridgeApi.DataEnrichmentJobs.Controllers.Dataiku
{
    [ApiExplorerSettings(IgnoreApi = false)]
    [Authorize(Policy = PolicyConstants.InternalPolicy)]
    [Route("api/dataikuenrichment")]
    [Authorize]
    [ApiController]
    public class DataikuEnrichmentController : ControllerBase
    {
        private IDataikuEnrichmentService _dataikuEnrichmentService;
        private readonly IBackgroundJobClient _backgroundJobClient;
        private readonly IRecurringJobManager _recurringJobManager;
        private readonly ILogger<DataikuEnrichmentController> _logger;
        private readonly DataEnrichmentConfigSettings _dataEnrichmentConfiguration;

        public DataikuEnrichmentController(IDataikuEnrichmentService dataikuEnrichmentService, IBackgroundJobClient backgroundJobClient,
            IRecurringJobManager recurringJobManager, ILogger<DataikuEnrichmentController> logger,
            DataEnrichmentConfigSettings dataEnrichmentConfiguration)
        {
            _dataikuEnrichmentService = dataikuEnrichmentService;
            _backgroundJobClient = backgroundJobClient;
            _recurringJobManager = recurringJobManager;
            _logger = logger;
            _dataEnrichmentConfiguration = dataEnrichmentConfiguration;
        }

        /// <summary>
        /// Seed Policy Transactions table with TargetedRate For Homeowner.        
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("SeedPolicyTargetedRateForHomeowner")]
        [DisableConcurrentExecution(timeoutInSeconds: 10 * 60), AutomaticRetry(Attempts = 10)]
        public IActionResult SeedPolicyTransactionsTargetedRateForHomeowner()
        {
            var fireAndForgetJob = _backgroundJobClient.Enqueue(() => _dataikuEnrichmentService.SyncPolicyTargetedRateforhomeowner());
            return Ok($"The job {fireAndForgetJob} has been executed.");
            //_dataikuEnrichmentService.SyncPolicyTargetedRateforhomeowner();
            //return Ok();
        }

        /// <summary>
        /// Seed Temp Policy Transactions table with TargetedRate For Homeowner.        
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("SeedTempPolicyTargetedRateForHomeowner")]
        [DisableConcurrentExecution(timeoutInSeconds: 10 * 60), AutomaticRetry(Attempts = 10)]
        public IActionResult SeedTempPolicyTransactionsTargetedRateForHomeowner()
        {
            var fireAndForgetJob = _backgroundJobClient.Enqueue(() => _dataikuEnrichmentService.SyncTempPolicyTargetedRateforhomeowner());
            return Ok($"The job {fireAndForgetJob} has been executed.");
            //_dataikuEnrichmentService.SyncTempPolicyTargetedRateforhomeowner();
            //return Ok();

        }

        /// <summary>
        /// Update TempPolicyTargetedRate with given tempid for the Homeowner
        /// </summary>
        /// <param name="tempid"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        [HttpGet]
        [Route("UpdateTempPolicyTargetedRateWithId")]      
        public IActionResult UpdateTempPolicyTargetedRateWithId(long tempid)
        {
            _dataikuEnrichmentService.UpdateTempPolicyTargetedRateforId(tempid);           
            return Ok();
        }

        /// <summary>
        /// Update PolicyTargetedRate with given tempid for the Homeowner
        /// </summary>
        /// <param name="tempid"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        [HttpGet]
        [Route("UpdatePolicyTargetedRateWithId")]       
        public IActionResult UpdatePolicyTargetedRateWithId(long tempid)
        {
            _dataikuEnrichmentService.UpdatePolicyTargetedRateforId(tempid);           
            return Ok();
        }

        /// <summary>
        /// Recurring Job to update PolicyTargetedRate for the Homeowner
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("HomeownerPolicyTargetedRate")]
        [DisableConcurrentExecution(timeoutInSeconds: 10 * 60)]
        public IActionResult HomeownerPolicyTargetedRate()
        {
            var CronExp = _dataEnrichmentConfiguration.DataikuTargetedRateCriteria.CronExp;
            _recurringJobManager.AddOrUpdate("HomeownerPolicyTargetedRate", () => _dataikuEnrichmentService.SyncPolicyTargetedRateforhomeowner(), CronExp);
            return Ok($"The recurring job has been scheduled.");
        }

        /// <summary>
        /// Recurring Job to update TempPolicyTargetedRate for the Homeowner
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("HomeownerTempPolicyTargetedRate")]
        [DisableConcurrentExecution(timeoutInSeconds: 10 * 60)]
        public IActionResult HomeownerTempPolicyTargetedRate()
        {
            var CronExp = _dataEnrichmentConfiguration.DataikuTargetedRateCriteria.CronExp;
            _recurringJobManager.AddOrUpdate("HomeownerTempPolicyTargetedRate", () => _dataikuEnrichmentService.SyncTempPolicyTargetedRateforhomeowner(), CronExp);
            return Ok($"The recurring job has been scheduled.");
        }
    }
}
