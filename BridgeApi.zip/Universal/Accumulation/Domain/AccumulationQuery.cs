﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BridgeApi.Accumulation.Domain
{
    public class AccumulationQuery
    {
        public double Latitude { get; set; }

        public double Longitude { get; set; }

        public int CompanyId { get; set; }

        public string ContractReference { get; set; }

        public int NumberOfRisks { get; set; }

        public int RadiusInMiles { get; set; }

        public string ConcentrationPeril { get; set; }
    }
}
