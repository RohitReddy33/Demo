﻿using BridgeApi.Accumulation.Domain;

namespace BridgeApi.Accumulation.Services
{
    public class AccumulationService : IAccumulationService
    {
        public void GetRisksWithinRadius(AccumulationQuery accumulationQuery)
        {

        }
    }
}
