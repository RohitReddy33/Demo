﻿namespace BridgeApi.Accumulation.Services
{
    public interface IAccumulationService
    {
    }
}