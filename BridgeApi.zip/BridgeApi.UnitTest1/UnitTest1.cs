using BridgeApi.DataEnrichment.Interfaces;
using BridgeApi.DataEnrichment.Models;
using BridgeApi.DataEnrichment.Services.ExternalProviders.VeriskValue360;
using BridgeApi.DataEnrichment.Services;
using BridgeApi.UnstructuredStorage.Providers;
using BridgeApi.UnstructuredStorage;
using Microsoft.Extensions.Configuration;
using VeriskValue360;

namespace BridgeApi.UnitTest1
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void UseValuationServiceWithUnstructuredStorage()
        {
            string environment = System.Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");

            if (string.IsNullOrEmpty(environment))
                environment = "Development";

            var config = new ConfigurationBuilder().AddJsonFile($"appsettings.{environment}.json").Build();

            Address address = new Address
            {
                ZipCode = "29801",
                CountryCode = "USA",
                City = "AIKEN",
                Street = "886 ALFRED ST NE",
                Name = "SAMPLE_TEST",
                State = "SC"
            };

            BridgeApi.DataEnrichment.Entities.UniversalBDXDBContext context = new BridgeApi.DataEnrichment.Entities.UniversalBDXDBContext();

            IExternalProviderValuationService<valuationReportAndValuationIdResponse> verisk = new Verisk(config, context);

            IUnstructuredStorage<UnstructuredRecord<valuationReportAndValuationIdResponse>> db = new CosmosDatabaseContext<valuationReportAndValuationIdResponse>(config);

            InternalValuationService<valuationReportAndValuationIdResponse> valuationService = new InternalValuationService<valuationReportAndValuationIdResponse>(config, context, verisk, db);

            IInternalProviderResponse de = valuationService.GetValuation(address, Enums.RESIDENTIAL, true, false).Result;

            UnstructuredRecord<valuationReportAndValuationIdResponse> check = db.Query(de.Bcref);

            double calcValue = double.Parse(check.ChildRecord.calculatedValue);

            Assert.IsTrue(calcValue > 0);

        }
    }
}