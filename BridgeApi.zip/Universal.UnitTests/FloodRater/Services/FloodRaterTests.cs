﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BridgeApi.FloodRater.Constants;
using BridgeApi.FloodRater.Domain;
using BridgeApi.FloodRater.Repositories;
using BridgeApi.FloodRater.Services;
using BridgeApi.Hazards.Domain;
using BridgeApi.Hazards.Repository;
using BridgeApi.Models.DataTransferObjects;
using BridgeApi.Repositories;
using BridgeApi.Shared.Services;
using FluentAssertions;
using Microsoft.Extensions.Configuration;
using Moq;
using NuGet.Frameworks;
using NUnit.Framework;

namespace BridgeApi.UnitTests.FloodRater.Services
{
    public class FloodRaterTests
    {
        private FloodLossCostEnquiry _floodLossCostEnquiryA;
        private Mock<IRmsRepository> _mockRmsRepository;
        private Mock<IUniversalBdxRepository> _mockUniversalBdxRepository;
        private Mock<INOAARepository> _mockNoaaRepository;
        private Mock<ITimingService> _mockTimingService;
        private Mock<IHazardRepository> _mockHazardRepository;
        private Mock<IConfiguration> _mockConfig;
        private Dictionary<int, HashSet<StateLimit>> _floodRaterStateLimits;
        private Dictionary<int, HashSet<string>> _floodRaterPermittedStates;

        [SetUp]
        public void Setup()
        {
            _mockConfig = new Mock<IConfiguration>();

            _floodRaterStateLimits = new Dictionary<int, HashSet<StateLimit>>()
            {
                { 6001, new HashSet<StateLimit> {
                        new StateLimit { Name = "GA", PermittedAggregate = true },
                        new StateLimit { Name = "TX", MinimumDistance = 1, MinimumBasementDistance = 5 },
                        new StateLimit { Name = "LA", MinimumDistance = 1, MinimumBasementDistance = 5 },
                        new StateLimit { Name = "MS", MinimumDistance = 1, MinimumBasementDistance = 5 },
                        new StateLimit { Name = "AL", MinimumDistance = 1, MinimumBasementDistance = 5, PermittedAggregate = true },
                        new StateLimit { Name = "FL", MinimumDistance = 1, MinimumBasementDistance = 5, PermittedAggregate = true, ExcludedCounties = new List<CountyLimit> { new CountyLimit { Name = "Miami-Dade"}, new CountyLimit { Name = "Broward" }, new CountyLimit { Name = "Palm Beach" } , new CountyLimit { Name = "Monroe" }}},
                        new StateLimit { Name = "GA", MinimumDistance = 1, MinimumBasementDistance = 5 },
                        new StateLimit { Name = "SC", MinimumDistance = 1, MinimumBasementDistance = 5 },
                        new StateLimit { Name = "NC", MinimumDistance = 1, MinimumBasementDistance = 5, PermittedAggregate = true },
                        new StateLimit { Name = "VA", MinimumDistance = 0.5, MinimumBasementDistance = 5 },
                        new StateLimit { Name = "MD", MinimumDistance = 0.5, MinimumBasementDistance = 5, PermittedAggregate = true },
                        new StateLimit { Name = "DE", MinimumDistance = 0.5, MinimumBasementDistance = 5, PermittedAggregate = true },
                        new StateLimit { Name = "NY", MinimumDistance = 0.5, MinimumBasementDistance = 5 },
                        new StateLimit { Name = "NJ", MinimumDistance = 0.5, MinimumBasementDistance = 5, PermittedAggregate = true },
                        new StateLimit { Name = "CT", MinimumDistance = 0.5, PermittedAggregate = true },
                        new StateLimit { Name = "RI", MinimumDistance = 0.5, PermittedAggregate = true  },
                        new StateLimit { Name = "MA", MinimumDistance = 0.5, PermittedAggregate = true },
                        new StateLimit { Name = "NH", MinimumDistance = 0.5, PermittedAggregate = true },
                        new StateLimit { Name = "ME", MinimumDistance = 0.5, PermittedAggregate = true },
                        new StateLimit { Name = "TN", PermittedAggregate = true },
                        new StateLimit { Name = "VT", PermittedAggregate = true },
                        new StateLimit { Name = "VA", PermittedAggregate = true }
                    }
                },
                { 6012, new HashSet<StateLimit> {
                        new StateLimit { Name = "TX", MinimumDistance = 5, MinimumBasementDistance = 5 }
                    }
                }
            };

            _floodRaterPermittedStates = new Dictionary<int, HashSet<string>>
            {
                {6001, new HashSet<string> {
                    "AL",
                    "CT",
                    "DE",
                    "FL",
                    "GA",
                    "ME",
                    "MD",
                    "MA",
                    "MS",
                    "NH",
                    "NJ",
                    "NC",
                    "RI",
                    "SC",
                    "TN",
                    "VT",
                    "VA"
                    }
                }
            };

            _floodLossCostEnquiryA = new FloodLossCostEnquiry
            {
                ApplicationSource = "test",
                CountryCode = "US",
                CountryScheme = "ISO2A",
                StreetAddress = "22 RIVERBEND DR",
                City = "Asheville",
                County = "Buncombe County",
                Admin1Code = "NC",
                PostalCode = "28805",
                ConstructionScheme = "ISOFIRE",
                ConstructionCode = "2",
                OccupancyScheme = "ISOPROP",
                OccupancyCode = "8012",
                YearBuilt = 1973,
                NumOfStories = 2,
                FirstFloorHeightAboveGround = 1,
                Basement = "N",
                IsMobileHome = false,
                IsVacant = false,
                IsBuildersRisk = false,
                HasStiltsOverWater = false,
                FoundationType = 0,
                BuildingCoverageLimit = 250000,
                ContentsCoverageLimit = 0,
                BusinessInterruptionCoverageLimit = 0,
                DeductibleType = 4,
                PlacementType = 2,
                LastLoss = new DateTime(2010,1,1,0,0,0),
                PolicyDateTime = new DateTime(2020, 1, 1, 0,0,0),
                CompanyId = 6001
            };


            _mockRmsRepository = new Mock<IRmsRepository>();
            _mockRmsRepository.Setup(x => x.GetFEMA(It.IsAny<FemaEnquiry>())).Returns(new List<FEMA>
            {
                new FEMA
                {
                    AnnualProbability = "Between 0.2% and 1%",
                    Bfe = "-999",
                    Cobra = "No",
                    Community = "120272",
                    FlMatch = "2",
                    Floodway = "No",
                    Levees = "No",
                    OtherZones = "AE,X",
                    PanFloodZoneel = "SHX",
                    Panel = "12107C0505C",
                    PanelDate = new DateTime(2012, 2, 2, 0, 0, 0)
                }
            });

            _mockRmsRepository.Setup(x => x.GetFloodLossCost(It.IsAny<FloodLossCostEnquiry>())).Returns(new List<FloodLossCost>
            {
                new FloodLossCost
                {
                    BuildingAlr = 0.0045072623,
                    BuildingAlrFlood = 0.0045072623,
                    BuildingAlrSurge = 0,
                    BusinessInterruptionAlr = 0.0016021609,
                    BusinessInterruptionAlrFlood = 0.0016021609,
                    BusinessInterruptionAlrSurge = 0,
                    ContentsAlr = 0.0094156076,
                    ContentsAlrFlood = 0.0094156076,
                    ContentsAlrSurge = 0,
                    GrossLoss = 1454.41
                }
            });

            _mockRmsRepository.Setup(x => x.GetFloodRiskScores(It.IsAny<FloodLossCostEnquiry>())).Returns(new List<FloodRiskScore>
            {
                new FloodRiskScore
                {
                    Score250Yr = "1",
                    Score100Yr = "1",
                    Score500Yr = "3",
                    ScoreOverall = "3"
                }
            });

            _mockRmsRepository.Setup(x => x.GetFloodSusceptibility(It.IsAny<FloodLossCostEnquiry>())).Returns(new List<FloodSusceptibility>
            {
                new FloodSusceptibility
                {
                    FirstFloorHeightAboveGround = "0"
                }
            });

            _mockUniversalBdxRepository = new Mock<IUniversalBdxRepository>();
            _mockUniversalBdxRepository.Setup(x => x.GetOccupancies()).Returns(
                new List<BridgeApi.Enquiry.Models.Entities.Occupancy>
                {
                    new BridgeApi.Enquiry.Models.Entities.Occupancy
                    {
                        OccupancyScheme = "ISOPROP",
                        OccupancyCode = "8012",
                        EquivalentAtccode = "1"
                    }
                });

            _mockUniversalBdxRepository.Setup(x => x.GetConstructionCodes()).Returns(
                new List<BridgeApi.Enquiry.Models.Entities.ConstructionCodes>
                {
                    new BridgeApi.Enquiry.Models.Entities.ConstructionCodes
                    {
                        ConstructionCodeScheme = "ISOFIRE",
                        ConstructionCode = "01",
                        EquivalentRmscode = "1A1"
                    },
                    new BridgeApi.Enquiry.Models.Entities.ConstructionCodes
                    {
                        ConstructionCodeScheme = "ISOFIRE",
                        ConstructionCode = "02",
                        EquivalentRmscode = "2B3"
                    }
                });

            _mockUniversalBdxRepository.Setup(x => x.GetGoogleGeoCoordinate(It.IsAny<AddressDTO>())).Returns(
                new GeoCoordinateDTO
                {
                    Latitude = 29.3748801,
                    Longitude = -81.6195845,
                    QualityScore = 95
                });

            _mockNoaaRepository = new Mock<INOAARepository>();

            _mockNoaaRepository.Setup(x =>
                x.GetDistanceToCoast(It.IsAny<GeoCoordinateDTO>(), It.IsAny<FloodLossCostEnquiry>())).Returns(new DistanceToCoastResult
            {
                DistanceToCoast = 48700.038779501381,
                FloodLossCostEnquiry = _floodLossCostEnquiryA
            });

            _mockTimingService = new Mock<ITimingService>();
            _mockTimingService.Setup(x => x.GetGuid()).Returns(Guid.Parse("cd741c27-c248-4f5d-999d-cfa8047b207b"));

            _mockHazardRepository = new Mock<IHazardRepository>();
            _mockHazardRepository.Setup(x => x.GetGeoCodeAsync(It.IsAny<Address>())).ReturnsAsync(new List<GeoCodeResponse>
            {
                new GeoCodeResponse
                {
                    geocodedAddress = new Geocodedaddress
                    {
                        coordinate = new Coordinate
                        {
                            latitude = 0,
                            longitude = 0,
                            geoquality = 95
                        }
                    }
                }
            });
        }

        [Test]
        [TestCase(1665.52, 4492.22)]
        [TestCase(611.78, 1650.09)]
        [TestCase(1253.05, 3379.71)]
        [TestCase(1287.66, 3473.06)]
        [TestCase(521.57, 1406.77)]
        public void Should_CalculateTechnicalPremium_When_InputIsGood(double grossLoss, decimal expectedTechnicalPremiumValue)
        {
            // Arrange
            var floodLossCost = new FloodLossCost
            {
                GrossLoss = grossLoss
            };

            // Act
            var technicalPremiumResult = floodLossCost.CalculateTechnicalPremium();
            var technicalPremium = technicalPremiumResult.TechnicalPremium;

            // Assert
            Assert.That(Math.Round(technicalPremium, 2), Is.EqualTo(expectedTechnicalPremiumValue));
        }

        [TestCase(1665.52, "AFloodZone", 100000, 4492.22)]
        public void Should_CalculateTechnicalQuotePremium_When_InputIsGood(double grossLoss, string floodZone, int limitAmount, decimal expectedTechnicalPremiumValue)
        {
            // Arrange
            var floodLossCost = new FloodLossCost
            {
                GrossLoss = grossLoss
            };

            // Act
            var quotePremium = floodLossCost.CalculateQuotePremium(floodZone, limitAmount);

            // Assert
            Assert.That(Math.Round(quotePremium.QuotePremium, 2), Is.EqualTo(expectedTechnicalPremiumValue));
        }

        [TestCase(100, "SHX", 1000000, 2000, Description= "For all other risks the minimum rate is 0.2% of limit amount")]
        [TestCase(100, "AZone", 1000000, 4000, Description = "If flood zone begins with “A” (any FEMA A Zone) then minimum rate is 0.4% of limit amount")]
        [TestCase(100, "VZone", 1000000, 10000, Description = "If flood zone begins with “A” (any FEMA A Zone) then minimum rate is 1.0% of limit amount")]
        [TestCase(100, "SHX", 1000, 400, Description = "For all risks the minimum premium is $400")]
        public void Should_CalculateQuotePremium_When_InputIsGood(double grossLoss, string floodZone, int limitAmount, decimal expectedQuotePremiumValue)
        {
            // Arrange
            var floodLossCost = new FloodLossCost
            {
                GrossLoss = grossLoss
            };

            // Act
            var quotePremium = floodLossCost.CalculateQuotePremium(floodZone, limitAmount);

            // Assert
            Assert.That(Math.Round(quotePremium.QuotePremium, 2), Is.EqualTo(expectedQuotePremiumValue));
        }

        [TestCase("SHX", 350000, 700, Description = "Minimum rate as risk score is <5")]
        [TestCase("X", 295000, 590, Description = "Minimum rate as risk score is <5")]
        public void Should_CalculateMinimumQuotePremium_When_InputIsGood(string floodZone, int limitAmount, decimal expectedQuotePremiumValue)
        {
            // Arrange
            var floodLossCost = new FloodLossCost();

            // Act
            var quotePremium = floodLossCost.CalculateMinimumQuotePremium(floodZone, limitAmount);

            // Assert
            Assert.That(Math.Round(quotePremium.QuotePremium, 2), Is.EqualTo(expectedQuotePremiumValue));
        }

        [TestCase(1454.41, "SHX", 268000, 1.464)]
        public void Should_CalculateQuoteRate_When_InputIsGood(double grossLoss, string floodZone, int limitAmount, decimal expectedQuoteRateValue)
        {
            // Arrange
            var floodLossCost = new FloodLossCost
            {
                GrossLoss = grossLoss
            };

            // Act
            var quotePremium = floodLossCost.CalculateQuotePremium(floodZone, limitAmount);
            var quoteRate = floodLossCost.CalculateQuoteRate(quotePremium.QuotePremium, limitAmount);

            // Assert
            Assert.That(Math.Round(quoteRate.Value, 3), Is.EqualTo(expectedQuoteRateValue));
        }

        [Test]
        public void Should_CalculateLimitAmount_When_InputIsGood()
        {
            // Arrange

            // Act
            var limitAmount = _floodLossCostEnquiryA.CalculateLimitAmount();

            // Assert
            Assert.That(limitAmount, Is.EqualTo(250000));
        }

        [Test]
        public void Should_GetMinimumQuote_When_LowFloodRiskScore()
        {
            // Arrange
            _mockRmsRepository.Setup(x => x.GetFEMA(It.IsAny<FemaEnquiry>())).Returns(new List<FEMA>
            {
                new FEMA
                {
                    AnnualProbability = "Between 0.2% and 1%",
                    Bfe = "-999",
                    Cobra = "No",
                    Community = "120272",
                    FlMatch = "2",
                    Floodway = "No",
                    Levees = "No",
                    OtherZones = "AE,X",
                    PanFloodZoneel = "A",
                    Panel = "12107C0505C",
                    PanelDate = new DateTime(2012, 2, 2, 0, 0, 0)
                }
            });

            var floodRaterCalculatorService = new FloodRaterCalculatorService(_mockRmsRepository.Object, _mockUniversalBdxRepository.Object, _mockNoaaRepository.Object, _mockTimingService.Object, _mockHazardRepository.Object, _mockConfig.Object);

            var guid = Guid.Parse("cd741c27-c248-4f5d-999d-cfa8047b207b");

            var expectedResult = new PremiumResult
            {
                BuildingAndContentsLimit = 250000,
                BuildingLimit = 250000,
                BusinessInterruptionLimit = 0,
                ContentsLimit = 0,
                DeclineReasons = null,
                Deductible = 1250M,
                IsValid = true,
                QuoteRate = 0.400M,
                TechnicalQuotePremium = 1000.000M,
                PricingEngineQuoteEnquiryID = guid.ToString(),
                TechnicalPremiumAudit = "Minimum rate applied",
                TechnicalPremiumFormula = "Minimum rate applied"
            };

            // Act
            var quotePremiumResult = floodRaterCalculatorService.GetTechnicalQuotePremium(_floodLossCostEnquiryA);

            // Assert
            quotePremiumResult.Should().BeEquivalentTo(expectedResult);
        }

        [Test]
        public void Should_GetQuote_When_InputIsGood()
        {
            // Arrange
            _mockRmsRepository.Setup(x => x.GetFloodLossCost(It.IsAny<FloodLossCostEnquiry>())).Returns(new List<FloodLossCost>
            {
                new FloodLossCost
                {
                    GrossLoss = 1253.05
                }
            });

            _mockRmsRepository.Setup(x => x.GetFloodRiskScores(It.IsAny<FloodLossCostEnquiry>())).Returns(new List<FloodRiskScore>
            {
                new FloodRiskScore
                {
                    Score250Yr = "1",
                    Score100Yr = "1",
                    Score500Yr = "3",
                    ScoreOverall = "5"
                }
            });

            var floodRaterCalculatorService = new FloodRaterCalculatorService(_mockRmsRepository.Object, _mockUniversalBdxRepository.Object, _mockNoaaRepository.Object, _mockTimingService.Object, _mockHazardRepository.Object, _mockConfig.Object);
            var guid = Guid.Parse("cd741c27-c248-4f5d-999d-cfa8047b207b");
            var expectedResult = new PremiumResult
            {
                BuildingAndContentsLimit = 250000,
                BuildingLimit = 250000,
                BusinessInterruptionLimit = 0,
                ContentsLimit = 0,
                DeclineReasons = null,
                Deductible = 1250M,
                IsValid = true,
                QuoteRate = 1.352M,
                TechnicalQuotePremium = 3379.71M,
                TechnicalPremiumFormula = "(GrossLoss * (1 + AALLoad) * (1 + LAELoad)) / (TargetCombinedRatio - (CoverHolderCommission + BellAndClementsBrokerage + GLISEFrontingFee + MRExpenses))",
                TechnicalPremiumAudit = "(1253.05 * 1.2 * 1.08) / (0.85 - (0.26 + 0.1 + 0.0055 + 0.004))",
                PricingEngineQuoteEnquiryID = guid.ToString()
            };

            // Act
            var quotePremiumResult = floodRaterCalculatorService.GetTechnicalQuotePremium(_floodLossCostEnquiryA);

            // Assert
            quotePremiumResult.Should().BeEquivalentTo(expectedResult);
        }

        [Test]
        public void Should_ReturnValidationReason_When_HighFloodRiskScore()
        {
            // Arrange
            var floodRiskScore = new FloodRiskScore
            {
                Score250Yr = "1",
                Score100Yr = "8",
                Score500Yr = "3",
                ScoreOverall = "3"
            };

            // Act
            var floodRiskScoreValidationResponse = floodRiskScore.Validate();

            // Assert
            Assert.Multiple(() =>
            {
                Assert.That(floodRiskScoreValidationResponse.HasValidationErrors, Is.True);
                Assert.That(floodRiskScoreValidationResponse.Reasons.First().Reason, Is.EqualTo($"Flood risk 100 year score {floodRiskScore.Score100Yr} is greater than 7 limit"));
            });
        }

        [Test]
        public void Should_ReturnValidationReason_When_PlacementTypeIsNotSupported()
        {
            // Arrange
            var floodRaterCalculatorService = new FloodRaterCalculatorService(_mockRmsRepository.Object, _mockUniversalBdxRepository.Object, _mockNoaaRepository.Object, _mockTimingService.Object, _mockHazardRepository.Object, _mockConfig.Object);
            _floodLossCostEnquiryA.PlacementType = 1;

            // Act
            var quotePremiumResult = floodRaterCalculatorService.GetTechnicalQuotePremium(_floodLossCostEnquiryA);

            // Assert
            Assert.Multiple(() => 
            { 
                Assert.That(quotePremiumResult.IsValid, Is.False);
                Assert.That(quotePremiumResult.DeclineReasons.First(), Is.EqualTo("Placement type must be Full Value or Primary"));
            });
        }

        [Test]
        public void Should_ReturnValidationReason_When_BuildingValueExceedsLimit()
        {
            // Arrange
            var floodRaterCalculatorService = new FloodRaterCalculatorService(_mockRmsRepository.Object, _mockUniversalBdxRepository.Object, _mockNoaaRepository.Object, _mockTimingService.Object, _mockHazardRepository.Object, _mockConfig.Object);
            _floodLossCostEnquiryA.BuildingCoverageLimit = 1200000;

            // Act
            var quotePremiumResult = floodRaterCalculatorService.GetTechnicalQuotePremium(_floodLossCostEnquiryA);

            // Assert
            Assert.Multiple(() =>
            {
                Assert.That(quotePremiumResult.IsValid, Is.False);
                Assert.That(quotePremiumResult.DeclineReasons.First(), Is.EqualTo($"Building value {_floodLossCostEnquiryA.BuildingCoverageLimit} is more than maximum Buildings TIVFGU of {FloodRaterVariables.MaxBuildingLimitFGU}"));
            });
        }

        [Test]
        public void Should_ReturnValidationReason_When_ContentsValueExceedsLimit()
        {
            // Arrange
            var floodRaterCalculatorService = new FloodRaterCalculatorService(_mockRmsRepository.Object, _mockUniversalBdxRepository.Object, _mockNoaaRepository.Object, _mockTimingService.Object, _mockHazardRepository.Object, _mockConfig.Object);
            _floodLossCostEnquiryA.ContentsCoverageLimit = 600000;

            // Act
            var quotePremiumResult = floodRaterCalculatorService.GetTechnicalQuotePremium(_floodLossCostEnquiryA);

            // Assert
            Assert.Multiple(() =>
            {
                Assert.That(quotePremiumResult.IsValid, Is.False);
                Assert.That(quotePremiumResult.DeclineReasons.First(), Is.EqualTo($"Contents value {_floodLossCostEnquiryA.ContentsCoverageLimit} is more than maximum Contents TIVFGU of {FloodRaterVariables.MaxContentsLimitFGU}"));
            });
        }

        [Test]
        public void Should_ReturnBusinessInterruptionLimit_When_BusinessInterruptionValueExceedsLimit()
        {
            // Arrange
            var floodRaterCalculatorService = new FloodRaterCalculatorService(_mockRmsRepository.Object, _mockUniversalBdxRepository.Object, _mockNoaaRepository.Object, _mockTimingService.Object, _mockHazardRepository.Object, _mockConfig.Object);
            _floodLossCostEnquiryA.BusinessInterruptionCoverageLimit = 6000;

            // Act
            var quotePremiumResult = floodRaterCalculatorService.GetTechnicalQuotePremium(_floodLossCostEnquiryA);

            // Assert
            Assert.Multiple(() =>
            {
                Assert.That(quotePremiumResult.IsValid, Is.True);
                Assert.That(quotePremiumResult.BusinessInterruptionLimit, Is.EqualTo(FloodRaterVariables.LossOfUseLimit));
            });
        }

        [Test]
        public void Should_ReturnBusinessInterruption_When_BusinessInterruptionValueIsLessThanLimit()
        {
            // Arrange
            var floodRaterCalculatorService = new FloodRaterCalculatorService(_mockRmsRepository.Object, _mockUniversalBdxRepository.Object, _mockNoaaRepository.Object, _mockTimingService.Object, _mockHazardRepository.Object, _mockConfig.Object);
            _floodLossCostEnquiryA.BusinessInterruptionCoverageLimit = 4000;

            // Act
            var quotePremiumResult = floodRaterCalculatorService.GetTechnicalQuotePremium(_floodLossCostEnquiryA);

            // Assert
            Assert.Multiple(() =>
            {
                Assert.That(quotePremiumResult.IsValid, Is.True);
                Assert.That(quotePremiumResult.BusinessInterruptionLimit, Is.EqualTo(_floodLossCostEnquiryA.BusinessInterruptionCoverageLimit));
            });
        }


        [Test]
        public void Should_ReturnValidationReason_When_OtherStructuresExceedsLimit()
        {
            // Arrange
            var floodRaterCalculatorService = new FloodRaterCalculatorService(_mockRmsRepository.Object, _mockUniversalBdxRepository.Object, _mockNoaaRepository.Object, _mockTimingService.Object, _mockHazardRepository.Object, _mockConfig.Object);
            _floodLossCostEnquiryA.OtherStructuresValue = 1000;

            // Act
            var quotePremiumResult = floodRaterCalculatorService.GetTechnicalQuotePremium(_floodLossCostEnquiryA);

            // Assert
            Assert.Multiple(() =>
            {
                Assert.That(quotePremiumResult.IsValid, Is.False);
                Assert.That(quotePremiumResult.DeclineReasons.First(), Is.EqualTo($"Other structures value {_floodLossCostEnquiryA.OtherStructuresValue} is greater than {FloodRaterVariables.OtherStructuresLimit} limit"));
            });
        }

        [Test]
        public void Should_ReturnValidationReason_When_BusinessValueIsBelowMinimumLimit()
        {
            // Arrange
            var floodRaterCalculatorService = new FloodRaterCalculatorService(_mockRmsRepository.Object, _mockUniversalBdxRepository.Object, _mockNoaaRepository.Object, _mockTimingService.Object, _mockHazardRepository.Object, _mockConfig.Object);
            _floodLossCostEnquiryA.BuildingCoverageLimit = 1000;

            // Act
            var quotePremiumResult = floodRaterCalculatorService.GetTechnicalQuotePremium(_floodLossCostEnquiryA);

            // Assert
            Assert.Multiple(() =>
            {
                Assert.That(quotePremiumResult.IsValid, Is.False);
                Assert.That(quotePremiumResult.DeclineReasons.First(), Is.EqualTo($"Building value {_floodLossCostEnquiryA.BuildingCoverageLimit} is less than the minimum limit {FloodRaterVariables.MinimumBuildingValueLimit}"));
            });
        }


        [Test]
        public void Should_ReturnValidationReason_When_OccupancyCodeIsNotSupported()
        {
            // Arrange
            var floodRaterCalculatorService = new FloodRaterCalculatorService(_mockRmsRepository.Object, _mockUniversalBdxRepository.Object, _mockNoaaRepository.Object, _mockTimingService.Object, _mockHazardRepository.Object, _mockConfig.Object);
            _floodLossCostEnquiryA.OccupancyScheme = "ATC";
            _floodLossCostEnquiryA.OccupancyCode = "999";

            // Act
            var quotePremiumResult = floodRaterCalculatorService.GetTechnicalQuotePremium(_floodLossCostEnquiryA);

            // Assert
            Assert.Multiple(() =>
            {
                Assert.That(quotePremiumResult.IsValid, Is.False);
                Assert.That(quotePremiumResult.DeclineReasons.First(), Is.EqualTo($"Occupancy {_floodLossCostEnquiryA.OccupancyScheme}{_floodLossCostEnquiryA.OccupancyCode} is not supported"));
            });
        }

        [Test]
        public void Should_ReturnValidationReason_When_IsoPropCodeIsNotSupported()
        {
            // Arrange
            var floodRaterCalculatorService = new FloodRaterCalculatorService(_mockRmsRepository.Object, _mockUniversalBdxRepository.Object, _mockNoaaRepository.Object, _mockTimingService.Object, _mockHazardRepository.Object, _mockConfig.Object);
            _floodLossCostEnquiryA.OccupancyScheme = "ATC";
            _floodLossCostEnquiryA.OccupancyCode = "2";
            // Act
            var quotePremiumResult = floodRaterCalculatorService.GetTechnicalQuotePremium(_floodLossCostEnquiryA);

            // Assert
            Assert.Multiple(() =>
            {
                Assert.That(quotePremiumResult.IsValid, Is.False);
                Assert.That(quotePremiumResult.DeclineReasons.First(), Is.EqualTo($"Occupancy {_floodLossCostEnquiryA.OccupancyScheme}{_floodLossCostEnquiryA.OccupancyCode} is not supported"));
            });
        }

        [Test]
        public void Should_ReturnValidationReason_When_MobilePropertyNotSupported()
        {
            // Arrange
            var floodRaterCalculatorService = new FloodRaterCalculatorService(_mockRmsRepository.Object, _mockUniversalBdxRepository.Object, _mockNoaaRepository.Object, _mockTimingService.Object, _mockHazardRepository.Object, _mockConfig.Object);
            _floodLossCostEnquiryA.IsMobileHome = true;

            // Act
            var quotePremiumResult = floodRaterCalculatorService.GetTechnicalQuotePremium(_floodLossCostEnquiryA);

            // Assert
            Assert.Multiple(() =>
            {
                Assert.That(quotePremiumResult.IsValid, Is.False);
                Assert.That(quotePremiumResult.DeclineReasons.First(), Is.EqualTo($"Mobile properties not supported"));
            });
        }

        [Test]
        public void Should_ReturnValidationReason_When_VacantPropertyNotSupported()
        {
            // Arrange
            var floodRaterCalculatorService = new FloodRaterCalculatorService(_mockRmsRepository.Object, _mockUniversalBdxRepository.Object, _mockNoaaRepository.Object, _mockTimingService.Object, _mockHazardRepository.Object, _mockConfig.Object);
            _floodLossCostEnquiryA.IsVacant = true;

            // Act
            var quotePremiumResult = floodRaterCalculatorService.GetTechnicalQuotePremium(_floodLossCostEnquiryA);

            // Assert
            Assert.Multiple(() =>
            {
                Assert.That(quotePremiumResult.IsValid, Is.False);
                Assert.That(quotePremiumResult.DeclineReasons.First(), Is.EqualTo($"Vacant properties not supported"));
            });
        }

        [Test]
        public void Should_ReturnValidationReason_When_BuildersRiskNotSupported()
        {
            // Arrange
            var floodRaterCalculatorService = new FloodRaterCalculatorService(_mockRmsRepository.Object, _mockUniversalBdxRepository.Object, _mockNoaaRepository.Object, _mockTimingService.Object, _mockHazardRepository.Object, _mockConfig.Object);
            _floodLossCostEnquiryA.IsBuildersRisk = true;

            // Act
            var quotePremiumResult = floodRaterCalculatorService.GetTechnicalQuotePremium(_floodLossCostEnquiryA);

            // Assert
            Assert.Multiple(() =>
            {
                Assert.That(quotePremiumResult.IsValid, Is.False);
                Assert.That(quotePremiumResult.DeclineReasons.First(), Is.EqualTo($"Builders risk not supported"));
            });
        }

        [Test]
        public void Should_ReturnValidationReason_When_PropertyBasementHasBasement()
        {
            // Arrange
            var floodRaterCalculatorService = new FloodRaterCalculatorService(_mockRmsRepository.Object, _mockUniversalBdxRepository.Object, _mockNoaaRepository.Object, _mockTimingService.Object, _mockHazardRepository.Object, _mockConfig.Object);
            _floodLossCostEnquiryA.Basement = "Y";

            // Act
            var quotePremiumResult = floodRaterCalculatorService.GetTechnicalQuotePremium(_floodLossCostEnquiryA);

            // Assert
            Assert.Multiple(() =>
            {
                Assert.That(quotePremiumResult.IsValid, Is.False);
                Assert.That(quotePremiumResult.DeclineReasons.First(), Is.EqualTo("Property with basements not supported"));
            });
        }

        [Test]
        public void Should_ReturnValid_When_PropertyHasNoBasement()
        {
            // Arrange
            var floodRaterCalculatorService = new FloodRaterCalculatorService(_mockRmsRepository.Object, _mockUniversalBdxRepository.Object, _mockNoaaRepository.Object, _mockTimingService.Object, _mockHazardRepository.Object, _mockConfig.Object);
            _floodLossCostEnquiryA.Basement = "NO";

            // Act
            var quotePremiumResult = floodRaterCalculatorService.GetTechnicalQuotePremium(_floodLossCostEnquiryA);

            // Assert
            Assert.That(quotePremiumResult.IsValid, Is.True);
        }

        [Test]
        public void Should_ReturnValidationReason_When_PropertyWithStiltsNotSupported()
        {
            // Arrange
            var floodRaterCalculatorService = new FloodRaterCalculatorService(_mockRmsRepository.Object, _mockUniversalBdxRepository.Object, _mockNoaaRepository.Object, _mockTimingService.Object, _mockHazardRepository.Object, _mockConfig.Object);
            _floodLossCostEnquiryA.HasStiltsOverWater = true;

            // Act
            var quotePremiumResult = floodRaterCalculatorService.GetTechnicalQuotePremium(_floodLossCostEnquiryA);

            // Assert
            Assert.Multiple(() =>
            {
                Assert.That(quotePremiumResult.IsValid, Is.False);
                Assert.That(quotePremiumResult.DeclineReasons.First(), Is.EqualTo("Stilts over water not supported"));
            });
        }

        [Test]
        public void Should_ReturnValidationReason_When_YearsSinceLastLossWithinCutoff()
        {
            // Arrange
            var floodRaterCalculatorService = new FloodRaterCalculatorService(_mockRmsRepository.Object, _mockUniversalBdxRepository.Object, _mockNoaaRepository.Object, _mockTimingService.Object, _mockHazardRepository.Object, _mockConfig.Object);
            _floodLossCostEnquiryA.PolicyDateTime = new DateTime(2011,1,1,0,0,0);

            // Act
            var quotePremiumResult = floodRaterCalculatorService.GetTechnicalQuotePremium(_floodLossCostEnquiryA);

            // Assert
            Assert.Multiple(() =>
            {
                Assert.That(quotePremiumResult.IsValid, Is.False);
                Assert.That(quotePremiumResult.DeclineReasons.First(), Is.EqualTo($"1 years since last loss is less than threshold of {FloodRaterVariables.LossThresholdInYears}"));
            });
        }

        [Test]
        public void Should_ReturnValidationReason_When_AddressIsWithinExcludedCounty()
        {
            // Arrange
            var floodRaterCalculatorService = new FloodRaterCalculatorService(_mockRmsRepository.Object, _mockUniversalBdxRepository.Object, _mockNoaaRepository.Object, _mockTimingService.Object, _mockHazardRepository.Object, _mockConfig.Object);
            _floodLossCostEnquiryA.Admin1Code = "FL";
            _floodLossCostEnquiryA.County = "Palm Beach";

            // Act
            var quotePremiumResult = floodRaterCalculatorService.GetTechnicalQuotePremium(_floodLossCostEnquiryA);

            // Assert
            Assert.Multiple(() =>
            {
                Assert.That(quotePremiumResult.IsValid, Is.False);
                Assert.That(quotePremiumResult.DeclineReasons.First(), Is.EqualTo($"Property is in an excluded county Palm Beach"));
            });
        }

        [Test]
        public void Should_ReturnValidationReason_When_AddressIsWithinExcludedState()
        {
            // Arrange
            var floodRaterCalculatorService = new FloodRaterCalculatorService(_mockRmsRepository.Object, _mockUniversalBdxRepository.Object, _mockNoaaRepository.Object, _mockTimingService.Object, _mockHazardRepository.Object, _mockConfig.Object);
            _floodLossCostEnquiryA.Admin1Code = "LA";

            // Act
            var quotePremiumResult = floodRaterCalculatorService.GetTechnicalQuotePremium(_floodLossCostEnquiryA);

            // Assert
            Assert.Multiple(() =>
            {
                Assert.That(quotePremiumResult.IsValid, Is.False);
                Assert.That(quotePremiumResult.DeclineReasons.First(), Is.EqualTo($"Address is in an excluded state {_floodLossCostEnquiryA.Admin1Code}"));
            });
        }

        [Test]
        public void Should_ReturnValidationReason_When_DistanceToCoastWithinStateLimit()
        {
            // Arrange
            var distanceToCoastResult = new DistanceToCoastResult
            {
                DistanceToCoast = 100,
                FloodLossCostEnquiry = _floodLossCostEnquiryA
            };

            var stateLimit = _floodRaterStateLimits[_floodLossCostEnquiryA.CompanyId].First(x => x.Name == _floodLossCostEnquiryA.Admin1Code);

            // Act
            var validationResponse = distanceToCoastResult.Validate(null, _floodRaterStateLimits[_floodLossCostEnquiryA.CompanyId]);

            // Assert
            Assert.Multiple(() =>
            {
                Assert.That(validationResponse.HasValidationErrors, Is.True);
                Assert.That(validationResponse.Reasons.First().Reason, Is.EqualTo($"Distance to coast {Math.Round(distanceToCoastResult.DistanceToCoast / DistanceToCoastResult.MetersInMile, 2)} is less than minimum distance of {stateLimit.MinimumDistance}"));
            });
        }

        [Test]
        public void Should_ReturnValidationReason_When_BasementDistanceToCoastWithinStateLimit()
        {
            // Arrange
            _floodLossCostEnquiryA.Basement = "Y";
            var distanceToCoastResult = new DistanceToCoastResult
            {
                DistanceToCoast = 8000, // 4.97 miles
                FloodLossCostEnquiry = _floodLossCostEnquiryA
            };

            var stateLimit = _floodRaterStateLimits[_floodLossCostEnquiryA.CompanyId].First(x => x.Name == _floodLossCostEnquiryA.Admin1Code);

            // Act
            var validationResponse = distanceToCoastResult.Validate(null, _floodRaterStateLimits[_floodLossCostEnquiryA.CompanyId]);

            // Assert
            Assert.Multiple(() =>
            {
                Assert.That(validationResponse.HasValidationErrors, Is.True);
                Assert.That(validationResponse.Reasons.First().Reason, Is.EqualTo($"Distance to coast {Math.Round(distanceToCoastResult.DistanceToCoast / DistanceToCoastResult.MetersInMile, 2)} is less than minimum basement distance of {stateLimit.MinimumBasementDistance}"));
            });
        }

        [Test]
        public void Should_ReturnValidationReason_When_PropertyGeocodeIsApproximate()
        {
            // Arrange
            var floodRaterCalculatorService = new FloodRaterCalculatorService(_mockRmsRepository.Object, _mockUniversalBdxRepository.Object, _mockNoaaRepository.Object, _mockTimingService.Object, _mockHazardRepository.Object, _mockConfig.Object);
            _mockHazardRepository.Setup(x => x.GetGeoCodeAsync(It.IsAny<Address>())).ReturnsAsync(new List<GeoCodeResponse>
            {
                new GeoCodeResponse
                {
                    geocodedAddress = new Geocodedaddress
                    {
                        coordinate = new Coordinate
                        {
                            latitude = 0,
                            longitude = 0,
                            geoquality = -1
                        }
                    }
                }
            });

            // Act
            var quotePremiumResult = floodRaterCalculatorService.GetTechnicalQuotePremium(_floodLossCostEnquiryA);

            // Assert
            Assert.Multiple(() =>
            {
                Assert.That(quotePremiumResult.IsValid, Is.False);
                Assert.That(quotePremiumResult.DeclineReasons.First(), Is.EqualTo("Geocode quality score -1 is insufficient to provide a precise location for this address."));
            });
        }

        [Test]
        [TestCase(130000, 60000, 0.013158)]
        [TestCase(110000, 0, 0.011364)]
        public void Should_CalculateDeductibleAmount_When_InputIsGood(decimal buildingValue, decimal contentsValue, decimal expectedValue)
        {
            // Arrange
            _floodLossCostEnquiryA.BuildingCoverageLimit = buildingValue;
            _floodLossCostEnquiryA.ContentsCoverageLimit = contentsValue;

            // Act
            var deductibleAmount = _floodLossCostEnquiryA.CalculateDeductibleAmount();

            // Assert
            Assert.That(Math.Round(deductibleAmount.Value, 6), Is.EqualTo(expectedValue));
        }

        [Test]
        [TestCase(36, 1, 243.75)]
        [TestCase(37, 1, 243.75)]
        [TestCase(41, 1, 243.75)]
        [TestCase(41, 2, 243.75)]
        public void Should_Calculate_Endorsement_Premium_When_Property_Limit_Increased(int scenario, int tier, decimal expectedValue)
        {
            // Arrange
            var cancelPremium = new EndorsementPremium
            {
                PolicyEffectiveDate = new DateTime(2021,1,1),
                PolicyExpirationDate = new DateTime(2022, 1, 1),
                PropertyLimit = 200000,
                Rate = 0.5m,
                PropertyPremium = 1000,
                EndorsementEffectiveDate = new DateTime(2021, 3, 1),
                EndorsementPropertyLimit = 250000m,
                Scenario = scenario,
                Tier = tier
            };

            // Act
            var premium = cancelPremium.GetEndorsementPremium();

            // Assert
            Assert.That(Math.Round(premium.TechnicalQuotePremium.Value, 2), Is.EqualTo(expectedValue));
        }

        [Test]
        public void Should_Calculate_Endorsement_Premium_When_Property_Limit_Increased_And_In_Wind_Period()
        {
            // Arrange
            var cancelPremium = new EndorsementPremium
            {
                PolicyEffectiveDate = new DateTime(2021, 1, 1),
                PolicyExpirationDate = new DateTime(2022, 1, 1),
                PropertyLimit = 200000,
                Rate = 0.5m,
                PropertyPremium = 1000,
                EndorsementEffectiveDate = new DateTime(2021, 3, 1),
                EndorsementPropertyLimit = 250000m,
                Scenario = 36,
                Tier = 1
            };

            // Act
            var premium = cancelPremium.GetEndorsementPremium();

            // Assert
            Assert.That(Math.Round(premium.TechnicalQuotePremium.Value, 2), Is.EqualTo(243.75m));
        }

        [Test]
        [TestCase(2021, 12, 1)]
        public void Should_Calculate_Endorsement_Premium_When_Property_Limit_Increased_And_Not_In_Wind_Period(int year, int month, int day)
        {
            // Arrange
            var cancelPremium = new EndorsementPremium
            {
                PolicyEffectiveDate = new DateTime(2021, 1, 1),
                PolicyExpirationDate = new DateTime(2022, 1, 1),
                PropertyLimit = 200000,
                Rate = 0.5m,
                PropertyPremium = 1000,
                EndorsementEffectiveDate = new DateTime(year, month, day),
                EndorsementPropertyLimit = 250000m,
                Scenario = 36,
                Tier = 1
            };

            // Act
            var premium = cancelPremium.GetEndorsementPremium();

            // Assert
            Assert.That(Math.Round(premium.TechnicalQuotePremium.Value, 2), Is.EqualTo(21.23m));
        }

        [Test]
        public void Should_Calculate_Endorsement_Premium_When_Property_Limit_Increased_And_Has_Claim()
        {
            // Arrange
            var cancelPremium = new EndorsementPremium
            {
                PolicyEffectiveDate = new DateTime(2021, 1, 1),
                PolicyExpirationDate = new DateTime(2022, 1, 1),
                PropertyLimit = 200000,
                Rate = 0.5m,
                PropertyPremium = 1000,
                EndorsementEffectiveDate = new DateTime(2021, 3, 1),
                EndorsementPropertyLimit = 250000m,
                Scenario = 36,
                HasClaim = true
            };

            // Act
            var premium = cancelPremium.GetEndorsementPremium();

            // Assert
            Assert.That(Math.Round(premium.TechnicalQuotePremium.Value, 2), Is.EqualTo(0));
        }

        [Test]
        public void Should_Calculate_Endorsement_Premium_When_Not_In_Scenario()
        {
            // Arrange
            var cancelPremium = new EndorsementPremium
            {
                PolicyEffectiveDate = new DateTime(2021, 1, 1),
                PolicyExpirationDate = new DateTime(2022, 1, 1),
                PropertyLimit = 200000,
                Rate = 0.5m,
                PropertyPremium = 1000,
                EndorsementEffectiveDate = new DateTime(2021, 3, 1),
                EndorsementPropertyLimit = 250000m,
                Scenario = 1
            };

            // Act
            var premium = cancelPremium.GetEndorsementPremium();

            // Assert
            Assert.That(Math.Round(premium.TechnicalQuotePremium.Value, 2), Is.EqualTo(209.59));
        }

        [Test]
        public void Should_Calculate_Endorsement_Premium_When_Not_In_Tier()
        {
            // Arrange
            var cancelPremium = new EndorsementPremium
            {
                PolicyEffectiveDate = new DateTime(2021, 1, 1),
                PolicyExpirationDate = new DateTime(2022, 1, 1),
                PropertyLimit = 200000,
                Rate = 0.5m,
                PropertyPremium = 1000,
                EndorsementEffectiveDate = new DateTime(2021, 3, 1),
                EndorsementPropertyLimit = 250000m,
                Scenario = 41,
                Tier = 3
            };

            // Act
            var premium = cancelPremium.GetEndorsementPremium();

            // Assert
            Assert.That(Math.Round(premium.TechnicalQuotePremium.Value, 2), Is.EqualTo(209.59));
        }


        [Test]
        public void Should_Calculate_Endorsement_Premium_When_Property_Limit_Decreased_And_In_Scenario()
        {
            // Arrange
            var cancelPremium = new EndorsementPremium
            {
                PolicyEffectiveDate = new DateTime(2021, 1, 1),
                PolicyExpirationDate = new DateTime(2022, 1, 1),
                PropertyLimit = 200000,
                Rate = 0.5m,
                PropertyPremium = 1000,
                EndorsementEffectiveDate = new DateTime(2021, 7, 1),
                EndorsementPropertyLimit = 150000m,
                Scenario = 36,
                SumOfPreviousPremium = 1000
            };

            // Act
            var premium = cancelPremium.GetEndorsementPremium();

            // Assert
            Assert.That(Math.Round(premium.TechnicalQuotePremium.Value, 2), Is.EqualTo(-37.5));
        }

        [Test]
        public void Should_Calculate_Endorsement_Premium_When_Property_Limit_Decreased_And_Not_In_Wind_Period()
        {
            // Arrange
            var cancelPremium = new EndorsementPremium
            {
                PolicyEffectiveDate = new DateTime(2021, 1, 1),
                PolicyExpirationDate = new DateTime(2022, 1, 1),
                PropertyLimit = 200000,
                Rate = 0.5m,
                PropertyPremium = 1000,
                EndorsementEffectiveDate = new DateTime(2021, 12, 1),
                EndorsementPropertyLimit = 150000m,
                Scenario = 36,
                SumOfPreviousPremium = 1000
            };

            // Act
            var premium = cancelPremium.GetEndorsementPremium();

            // Assert
            Assert.That(Math.Round(premium.TechnicalQuotePremium.Value, 2), Is.EqualTo(-21.23m));
        }

        [Test]
        public void Should_Calculate_Endorsement_Premium_When_Property_Limit_Decreased_And_Exceeds_Minimum_Premium()
        {
            // Arrange
            var cancelPremium = new EndorsementPremium
            {
                PolicyEffectiveDate = new DateTime(2021, 1, 1),
                PolicyExpirationDate = new DateTime(2022, 1, 1),
                PropertyLimit = 200000,
                Rate = 0.5m,
                PropertyPremium = 1000,
                EndorsementEffectiveDate = new DateTime(2021, 7, 1),
                EndorsementPropertyLimit = 150000m,
                Scenario = 36,
                SumOfPreviousPremium = 410
            };

            // Act
            var premium = cancelPremium.GetEndorsementPremium();

            // Assert
            Assert.That(Math.Round(premium.TechnicalQuotePremium.Value, 2), Is.EqualTo(-10));
        }

        [Test]
        public void Should_Calculate_Endorsement_Premium_When_Property_Limit_Decreased_And_Not_In_Scenario()
        {
            // Arrange
            var cancelPremium = new EndorsementPremium
            {
                PolicyEffectiveDate = new DateTime(2021, 1, 1),
                PolicyExpirationDate = new DateTime(2022, 1, 1),
                PropertyLimit = 200000,
                Rate = 0.5m,
                PropertyPremium = 1000,
                EndorsementEffectiveDate = new DateTime(2021, 7, 1),
                EndorsementPropertyLimit = 150000m,
                Scenario = 0,
                SumOfPreviousPremium = 1000,
            };

            // Act
            var premium = cancelPremium.GetEndorsementPremium();

            // Assert
            Assert.That(Math.Round(premium.TechnicalQuotePremium.Value, 2), Is.EqualTo(-126.03));
        }

        [Test]
        public void Should_Calculate_Endorsement_Premium_When_Property_Limit_Decreased_And_Has_Total_Loss()
        {
            // Arrange
            var cancelPremium = new EndorsementPremium
            {
                PolicyEffectiveDate = new DateTime(2021, 1, 1),
                PolicyExpirationDate = new DateTime(2022, 1, 1),
                PropertyLimit = 200000,
                Rate = 0.5m,
                PropertyPremium = 1000,
                EndorsementEffectiveDate = new DateTime(2021, 7, 1),
                EndorsementPropertyLimit = 150000m,
                Scenario = 0,
                HasTotalLoss = true
            };

            // Act
            var premium = cancelPremium.GetEndorsementPremium();

            // Assert
            Assert.That(Math.Round(premium.TechnicalQuotePremium.Value, 2), Is.EqualTo(0));
        }

        [Test]
        public void Should_Calculate_Cancellation_Premium_When_In_Scenario()
        {
            // Arrange
            var cancelPremium = new CancellationPremium
            {
                PolicyEffectiveDate = new DateTime(2021, 1, 1),
                PolicyExpirationDate = new DateTime(2022, 1, 1),
                PropertyLimit = 200000,
                Rate = 0.5m,
                PropertyPremium = 1000,
                CancellationEffectiveDate = new DateTime(2021, 7, 1),
                Scenario = 36,
                CancellationCode = 2
            };

            // Act
            var premium = cancelPremium.GetCancelPremium();

            // Assert
            Assert.That(Math.Round(premium.TechnicalQuotePremium.Value, 2), Is.EqualTo(-150));
        }

        [Test]
        public void Should_Calculate_Cancellation_Premium_When_Not_In_Wind_Period()
        {
            // Arrange
            var cancelPremium = new CancellationPremium
            {
                PolicyEffectiveDate = new DateTime(2021, 1, 1),
                PolicyExpirationDate = new DateTime(2022, 1, 1),
                PropertyLimit = 200000,
                Rate = 0.5m,
                PropertyPremium = 1000,
                CancellationEffectiveDate = new DateTime(2021, 5, 31),
                Scenario = 36,
                CancellationCode = 2
            };

            // Act
            var premium = cancelPremium.GetCancelPremium();

            // Assert
            Assert.That(Math.Round(premium.TechnicalQuotePremium.Value, 2), Is.EqualTo(-589.04m));
        }

        [Test]
        public void Should_Calculate_Cancellation_Premium_When_In_Scenario_And_Cancelled_By_Insured()
        {
            // Arrange
            var cancelPremium = new CancellationPremium
            {
                PolicyEffectiveDate = new DateTime(2021, 1, 1),
                PolicyExpirationDate = new DateTime(2022, 1, 1),
                PropertyLimit = 200000,
                Rate = 0.5m,
                PropertyPremium = 1000,
                CancellationEffectiveDate = new DateTime(2021, 7, 1),
                Scenario = 36,
                CancellationCode = 2
            };

            // Act
            var premium = cancelPremium.GetCancelPremium();

            // Assert
            Assert.That(Math.Round(premium.TechnicalQuotePremium.Value, 2), Is.EqualTo(-150));
        }

        [Test]
        public void Should_Calculate_Cancellation_Premium_When_In_Scenario_And_Cancelled_By_Underwriter()
        {
            // Arrange
            var cancelPremium = new CancellationPremium
            {
                PolicyEffectiveDate = new DateTime(2021, 1, 1),
                PolicyExpirationDate = new DateTime(2022, 1, 1),
                PropertyLimit = 200000,
                Rate = 0.5m,
                PropertyPremium = 1000,
                CancellationEffectiveDate = new DateTime(2021, 7, 1),
                Scenario = 36,
                CancellationCode = 1
            };

            // Act
            var premium = cancelPremium.GetCancelPremium();

            // Assert
            Assert.That(Math.Round(premium.TechnicalQuotePremium.Value, 2), Is.EqualTo(-504.11m));
        }


        [Test]
        public void Should_Calculate_Cancellation_Premium_When_Not_In_Scenario()
        {
            // Arrange
            var cancelPremium = new CancellationPremium
            {
                PolicyEffectiveDate = new DateTime(2021, 1, 1),
                PolicyExpirationDate = new DateTime(2022, 1, 1),
                PropertyLimit = 200000,
                Rate = 0.5m,
                PropertyPremium = 1000,
                CancellationEffectiveDate = new DateTime(2021, 7, 1),
                Scenario = 0,
                CancellationCode = 2
            };

            // Act
            var premium = cancelPremium.GetCancelPremium();

            // Assert
            Assert.That(Math.Round(premium.TechnicalQuotePremium.Value, 2), Is.EqualTo(-504.11));
        }

        [Test]
        public void Should_Calculate_Cancellation_Premium_When_There_Is_Total_Loss()
        {
            // Arrange
            var cancelPremium = new CancellationPremium
            {
                PolicyEffectiveDate = new DateTime(2021, 1, 1),
                PolicyExpirationDate = new DateTime(2022, 1, 1),
                PropertyLimit = 200000,
                Rate = 0.5m,
                PropertyPremium = 1000,
                CancellationEffectiveDate = new DateTime(2021, 7, 1),
                Scenario = 0,
                HasTotalLoss = true
            };

            // Act
            var premium = cancelPremium.GetCancelPremium();

            // Assert
            Assert.That(Math.Round(premium.TechnicalQuotePremium.Value, 2), Is.EqualTo(0));
        }

        [Test]
        public void Should_Calculate_Extension_Premium_When_In_Scenario()
        {
            // Arrange
            var extensionPremium = new ExtensionPremium
            {
                PolicyEffectiveDate = new DateTime(2021, 1, 1),
                PolicyExpirationDate = new DateTime(2022, 1, 1),
                PropertyLimit = 200000,
                Rate = 0.5m,
                PropertyPremium = 1000,
                ExtensionExpiryDate = new DateTime(2022, 7, 1),
                Scenario = 36
            };

            // Act
            var premium = extensionPremium.GetExtensionPremium();

            // Assert
            Assert.That(Math.Round(premium.TechnicalQuotePremium.Value, 2), Is.EqualTo(850));
        }

        [Test]
        public void Should_Calculate_Extension_Premium_When_Not_In_Wind_Period()
        {
            // Arrange
            var extensionPremium = new ExtensionPremium
            {
                PolicyEffectiveDate = new DateTime(2021, 1, 1),
                PolicyExpirationDate = new DateTime(2021, 5, 1),
                PropertyLimit = 200000,
                Rate = 0.5m,
                PropertyPremium = 1000,
                ExtensionExpiryDate = new DateTime(2021, 5, 31),
                Scenario = 36
            };

            // Act
            var premium = extensionPremium.GetExtensionPremium();

            // Assert
            Assert.That(Math.Round(premium.TechnicalQuotePremium.Value, 2), Is.EqualTo(250m));
        }

        [Test]
        public void Should_Calculate_Extension_Premium_When_Not_In_Scenario()
        {
            // Arrange
            var extensionPremium = new ExtensionPremium
            {
                PolicyEffectiveDate = new DateTime(2021, 1, 1),
                PolicyExpirationDate = new DateTime(2022, 1, 1),
                PropertyLimit = 200000,
                Rate = 0.5m,
                PropertyPremium = 1000,
                ExtensionExpiryDate = new DateTime(2022, 7, 1),
                Scenario = 0
            };

            // Act
            var premium = extensionPremium.GetExtensionPremium();

            // Assert
            Assert.That(Math.Round(premium.TechnicalQuotePremium.Value, 0), Is.EqualTo(496));
        }

        [Test]
        public void Should_Calculate_Extension_Premium_When_Has_Claim()
        {
            // Arrange
            var extensionPremium = new ExtensionPremium
            {
                PolicyEffectiveDate = new DateTime(2021, 1, 1),
                PolicyExpirationDate = new DateTime(2022, 1, 1),
                PropertyLimit = 200000,
                Rate = 0.5m,
                PropertyPremium = 1000,
                ExtensionExpiryDate = new DateTime(2022, 7, 1),
                HasClaim = true,
                Scenario = 36
            };

            // Act
            var premium = extensionPremium.GetExtensionPremium();

            // Assert
            Assert.That(Math.Round(premium.TechnicalQuotePremium.Value, 0), Is.EqualTo(0));
        }
    }
}
