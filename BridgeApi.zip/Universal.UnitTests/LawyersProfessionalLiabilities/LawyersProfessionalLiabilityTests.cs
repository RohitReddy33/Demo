﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BridgeApi.FloodRater.Domain;
using BridgeApi.FloodRater.Repositories;
using BridgeApi.LawyersProfessionalLiabilities.Domain;
using BridgeApi.LawyersProfessionalLiabilities.Repositories;
using BridgeApi.LawyersProfessionalLiabilities.Services;
using BridgeApi.Repositories;
using BridgeApi.Shared.Services;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using Newtonsoft.Json;
using NUnit.Framework;

namespace BridgeApi.UnitTests.LawyersProfessionalLiabilities
{
    public class LawyersProfessionalLiabilityTests
    {
        private MrsiBatch _mrsiBatch;
        private List<LawyersProfessionalLiabilityPolicy> _policies;

        [SetUp]
        public void Setup()
        {
            var directory = Environment.CurrentDirectory;
            var testPoliciesFile = Path.Combine(directory, "LawyersProfessionalLiabilities\\TestData", "policies.json");
            _policies = JsonConvert.DeserializeObject<List<LawyersProfessionalLiabilityPolicy>>(File.ReadAllText(testPoliciesFile));

            var testMrsiBatchFile = Path.Combine(directory, "LawyersProfessionalLiabilities\\TestData", "MrsiBatch.json");
            _mrsiBatch = JsonConvert.DeserializeObject<MrsiBatch>(File.ReadAllText(testMrsiBatchFile));
        }

        [Test]
        public void Should_Construct_Mrsi_Batch_When_Input_is_Good()
        {
            var universalBdxRepository = new Mock<IUniversalBdxRepository>();
            var lawyersTransactionsRepository = new Mock<ILawyersTransactionsRepository>();
            var timingService = new Mock<ITimingService>();
                timingService.Setup(x => x.GetGuid()).Returns(Guid.Parse("f3c6338e-e11c-4846-823a-93e24e8edd17"));
            var logger = new Mock<ILogger<LawyersProfessionalLiabilitiesService>>();
            var lawyersService = new Mock<LawyersProfessionalLiabilitiesService>(universalBdxRepository.Object, lawyersTransactionsRepository.Object,
                                          logger.Object,timingService.Object) { CallBase = true };
           
            lawyersService.Setup(x => x.GetPolicies(It.IsAny<int>(), It.IsAny<int>(),It.IsAny<int>(), It.IsAny<List<string>>())).Returns(_policies);

            // Act
            var batchId = "JJPR20200915153520";
            var mrsiBatch = lawyersService.Object.GetBatch(2020, 7, 9701, null, batchId);

            // Assert
            mrsiBatch.Should().BeEquivalentTo(_mrsiBatch);
        }
    }
}
