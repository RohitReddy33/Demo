﻿using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using BridgeApi.Enquiry.Models.Entities;
using BridgeApi.Enquiry.Repositories;
using BridgeApi.Enquiry.Services;
using BridgeApi.Repositories;
using BridgeApi.Shared.AutoMapper;
using Moq;
using NUnit.Framework;

namespace BridgeApi.UnitTests.Enquiry.Services
{
    public class UniversalServiceTests
    {
        private IMapper _mapper;
        private Mock<IUniversalBdxRepository> _mockUniversalBdxRepository;

        [SetUp]
        public void Setup()
        {
            var config = new MapperConfiguration(opts =>
            {
                // Add your mapper profile configs or mappings here
                var myProfile = new UserProfile();
                var configuration = new MapperConfiguration(cfg => cfg.AddProfile(myProfile));
            });

            _mapper = config.CreateMapper();

            _mockUniversalBdxRepository = new Mock<IUniversalBdxRepository>();
        }

        [Test]
        public void Should_CalculateTotalInsuredValueFromGroundUp_When_InputIsGood()
        {
            // Arrange
            var tempPolicyTransactionsLocations = new List<TempPolicyTransactionsLocations>
            {
                new TempPolicyTransactionsLocations
                {
                    TempPremiumsId = 1,
                    LimitBuildingCoverageA = 1,
                    LimitContentsCoverageC = 2,
                    LimitBusinessInterruptionCoverageD = 3
                },
                new TempPolicyTransactionsLocations
                {
                    TempPremiumsId = 1,
                    LimitBuildingCoverageA = 4,
                    LimitContentsCoverageC = 5,
                    LimitBusinessInterruptionCoverageD = 6
                }
            };

            var universalService = new EnquiryService(_mockUniversalBdxRepository.Object, _mapper);

            // Act
            var totalInsuredValueFromGroundUpResult = universalService.CalculateTotalInsuredValueFromGroundUp(tempPolicyTransactionsLocations);

            // Assert
            Assert.That(totalInsuredValueFromGroundUpResult.Total(), Is.EqualTo(21));
        }

        [Test]
        public void Should_CalculateTotalInsuredValueFromGroundUp_When_InputHasNulls()
        {
            // Arrange
            var tempPolicyTransactionsLocationsWithNulls = new List<TempPolicyTransactionsLocations>
            {
                new TempPolicyTransactionsLocations
                {
                    TempPremiumsId = 1,
                    LimitBuildingCoverageA = 1,
                    LimitContentsCoverageC = 2,
                    LimitBusinessInterruptionCoverageD = null
                },
                new TempPolicyTransactionsLocations
                {
                    TempPremiumsId = 1,
                    LimitBuildingCoverageA = 4,
                    LimitContentsCoverageC = 5,
                    LimitBusinessInterruptionCoverageD = null
                }
            };

            var universalService = new EnquiryService(_mockUniversalBdxRepository.Object, _mapper);

            // Act
            var totalInsuredValueFromGroundUp = universalService.CalculateTotalInsuredValueFromGroundUp(tempPolicyTransactionsLocationsWithNulls);

            // Assert
            Assert.That(totalInsuredValueFromGroundUp.Total(), Is.EqualTo(12));
        }

        [Test]
        [TestCase("6900  : Air Conditioning Equipment Mfg. – Precision parts", ExpectedResult = "6900")]
        [TestCase(null, ExpectedResult = null)]
        [TestCase("", ExpectedResult = "")]
        public string Should_TreatOccupancyCodes(string occupancyCode)
        {
            // Arrange
            var dataFetchTempResult = new DataFetchTempResult
            {
                OccupancyCode = occupancyCode,
            };

            // Act
            dataFetchTempResult.TreatCodes();

            // Assert
            return dataFetchTempResult.OccupancyCode;
        }

        [Test]
        [TestCase("04  : Masonry non-combustible", ExpectedResult = "04")]
        [TestCase(null, ExpectedResult = null)]
        [TestCase("", ExpectedResult = "")]
        public string Should_TreatConstructionCodes(string constructionCode)
        {
            // Arrange
            var dataFetchTempResult = new DataFetchTempResult
            {
                ConstructionCode = constructionCode,
            };

            // Act
            dataFetchTempResult.TreatCodes();

            // Assert
            return dataFetchTempResult.ConstructionCode;
        }

        [Test]
        public void Should_CalculateMaxLocationNumber_When_InputIsGood()
        {
            // Arrange
            const long premiumsId = 123;
            var tempPolicyTransactionLocations = new List<TempPolicyTransactionsLocations>
            {
                new TempPolicyTransactionsLocations
                {
                    TempPremiumsId = 123,
                    LocationNumber = "1"
                },
                new TempPolicyTransactionsLocations
                {
                    TempPremiumsId = 123,
                    LocationNumber = "3"
                }
                ,
                new TempPolicyTransactionsLocations
                {
                    TempPremiumsId = 123,
                    LocationNumber = "2"
                }
            };
            _mockUniversalBdxRepository.Setup(x => x.GetTempPolicyTransactionsLocations(premiumsId)).Returns(tempPolicyTransactionLocations.AsQueryable);
            var universalService = new EnquiryService(_mockUniversalBdxRepository.Object, _mapper);

            // Act
            var maxLocationNumber = universalService.GetMaxLocationNumber(premiumsId);

            // Assert
            Assert.That(maxLocationNumber, Is.EqualTo(3));
        }

        [Test]
        public void Should_CalculateMaxLocationNumberAsZero_When_TempPolicyTransactionsLocationsIsEmpty()
        {
            // Arrange
            const long premiumsId = 123;
            var tempPolicyTransactionLocations = new List<TempPolicyTransactionsLocations>();
            _mockUniversalBdxRepository.Setup(x => x.GetTempPolicyTransactionsLocations(premiumsId)).Returns(tempPolicyTransactionLocations.AsQueryable);
            var universalService = new EnquiryService(_mockUniversalBdxRepository.Object, _mapper);

            // Act
            var maxLocationNumber = universalService.GetMaxLocationNumber(premiumsId);
            // Assert
            Assert.That(maxLocationNumber, Is.EqualTo(0));
        }
    }
}
