﻿using BridgeApi.DataEnrichment.Entities;
using BridgeApi.DataEnrichment.Interfaces;
using BridgeApi.DataEnrichment.Models;
using BridgeApi.DataEnrichment.Services;
using BridgeApi.DataEnrichment.Services.ExternalProviders.VeriskValue360;
using BridgeApi.DataEnrichment.Services.ExternalProviders.VeriskValue360.Models;
using BridgeApi.UnstructuredStorage;
using BridgeApi.UnstructuredStorage.Providers;
using Microsoft.Extensions.Configuration;
using NUnit.Framework;
using NUnit.Framework.Internal;
using System;
using VeriskValue360;

namespace BridgeApi.UnitTests.DataEnrichment
{
    public class DataEnrichmentTests
    {
        [Test]
        public void TestExternalValuationService_CommercialCall()
        {
            string environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");

            if (string.IsNullOrEmpty(environment))
                environment = "Development";

            var config = new Microsoft.Extensions.Configuration.ConfigurationBuilder().AddJsonFile($"appsettings.{environment}.json").Build();

            string bcRef = Guid.NewGuid().ToString();


            Address address = new Address
            {
                ZipCode = "84043",
                CountryCode = "USA",
                City = "Lehi",
                Street = "1100 W Traverse Pkwy",
                State = "UT",

                BuildingCharacteristics = new BuildingCharacteristics
                {
                    SquareFeet = 3873,
                    YearBuilt = 1963,
                    Occupancy = new Occupancy { Scheme = "ISOPROP", Code = "3009" },
                    Construction = new Construction { Scheme = "ISOFIRE", Code = "01" }
                }
            };

            UniversalBdxdbContext context = new UniversalBdxdbContext();

            IExternalProviderValuationService<valuationReportAndValuationIdResponse> verisk = new Verisk(config, context);

            IExternalProviderValuationResponse<valuationReportAndValuationIdResponse> valuationResponse = verisk.GetValuation(bcRef, address, ValuationTypes.COMMERCIAL).Result;

            int? yearBuilt = null, squareFootage = null;

            if (valuationResponse.TryGetSingleAnswerValue<int>("YearBuilt", int.TryParse, out int _yearBuilt))
                yearBuilt = _yearBuilt;

            if (valuationResponse.TryGetSingleAnswerValue<int>("SquareFootage", int.TryParse, out int _squareFootage))
                squareFootage = _squareFootage;

            Assert.IsNotNull(valuationResponse);
            Assert.IsTrue(yearBuilt > 0);
            Assert.IsTrue(squareFootage > 0);

        }
  
        [Test]
        public void TestInternalValuationService_CommercialCall()
        {
            string environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");

            if (string.IsNullOrEmpty(environment))
                environment = "Development";

            var config = new ConfigurationBuilder().AddJsonFile($"appsettings.{environment}.json").Build();

            Address address = new Address
            {
                ZipCode = "84043",
                CountryCode = "USA",
                City = "Lehi",
                Street = "1100 W Traverse Pkwy",
                State = "UT",

                BuildingCharacteristics = new BuildingCharacteristics
                {
                    SquareFeet = 3873,
                    YearBuilt = 1963,
                    Occupancy = new Occupancy { Scheme = "RSM", Code = "3009" },//ISOPROP
                    Construction = new Construction { Scheme = "ISOFIRE", Code = "01" }
                }
            };

            UniversalBdxdbContext context = new UniversalBdxdbContext(config.GetConnectionString("universalDatabaseConnection"));

            IExternalProviderValuationService<valuationReportAndValuationIdResponse> verisk = new Verisk(config, context);

            IUnstructuredStorage<UnstructuredRecord<valuationReportAndValuationIdResponse>> db = new CosmosDatabaseContext<valuationReportAndValuationIdResponse>(config);

            //IUnstructuredStorage<UnstructuredRecord<IExternalProviderValuationResponse<valuationReportAndValuationIdResponse>>> unstructuredStorage1 = new CosmosDatabaseContext<IExternalProviderValuationResponse<valuationReportAndValuationIdResponse>>(config);

            InternalValuationService<valuationReportAndValuationIdResponse> valuationService = new InternalValuationService<valuationReportAndValuationIdResponse>(config, context, verisk, db);//, unstructuredStorage1);

            IInternalValuationResponse de = valuationService.GetValuation(address, ValuationTypes.COMMERCIAL, true, false).Result;

            Assert.IsTrue(de.SquareFootage > 0);

            int? yearBuilt = de.YearBuilt;

            int? squareFootage = de.SquareFootage;

            Assert.IsNotNull(de?.ProviderRef);
            Assert.IsNotNull(de?.Bcref);
            Assert.IsTrue(yearBuilt > 0);
            Assert.IsTrue(squareFootage > 0);

        }

        [Test]
        public void TestExternalValuationService_CommercialCall_WithUnstructuredStorage()
        {
            string environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");

            if (string.IsNullOrEmpty(environment))
                environment = "Development";

            var config = new ConfigurationBuilder().AddJsonFile($"appsettings.{environment}.json").Build();

            string bcRef = Guid.NewGuid().ToString();


            Address address = new Address
            {
                ZipCode = "84043",
                CountryCode = "USA",
                City = "Lehi",
                Street = "1100 W Traverse Pkwy",
                State = "UT"
            };

            UniversalBdxdbContext context = new UniversalBdxdbContext();

            IExternalProviderValuationService<valuationReportAndValuationIdResponse> vh = new Verisk(config, context);

            IExternalProviderValuationResponse<valuationReportAndValuationIdResponse> valuationResponse = vh.GetValuation(bcRef, address, ValuationTypes.COMMERCIAL).Result;

            int? yearBuilt = null, squareFootage = null;

            if (valuationResponse.TryGetSingleAnswerValue<int>("YearBuilt", int.TryParse, out int _yearBuilt))
                yearBuilt = _yearBuilt;

            if (valuationResponse.TryGetSingleAnswerValue<int>("SquareFootage", int.TryParse, out int _squareFootage))
                squareFootage = _squareFootage;

            IUnstructuredStorage<UnstructuredRecord<valuationReportAndValuationIdResponse>> db = new CosmosDatabaseContext<valuationReportAndValuationIdResponse>(config);

            UnstructuredRecord<valuationReportAndValuationIdResponse> vrw = new UnstructuredRecord<valuationReportAndValuationIdResponse>
            {
                ChildRecord = valuationResponse.ValuationResponse,
                Id = bcRef,
                PartitionKey = bcRef,
            };

            db.InsertRecord(vrw);

            UnstructuredRecord<valuationReportAndValuationIdResponse> inserted = db.Query(vrw.Id);

            Assert.AreEqual(inserted.Id, bcRef);
            Assert.IsNotNull(inserted.ChildRecord.valuationId);
            Assert.IsTrue(yearBuilt > 0);
            Assert.IsTrue(squareFootage > 0);

        }

        [Test]
        public void TestExternalValuationService_ResidentialCall_WithUnstructuredStorage()
        {
            string environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");

            if (string.IsNullOrEmpty(environment))
                environment = "Development";

            var config = new ConfigurationBuilder().AddJsonFile($"appsettings.{environment}.json").Build();

            string bcRef = Guid.NewGuid().ToString();

            Address address = new Address
            {
                ZipCode = "29801",
                CountryCode = "USA",
                City = "AIKEN",
                Street = "886 ALFRED ST NE",
                Name = "SAMPLE_TEST",
                State = "SC"
            };

            UniversalBdxdbContext context = new UniversalBdxdbContext();

            IExternalProviderValuationService<valuationReportAndValuationIdResponse> vh = new Verisk(config, context);

            IExternalProviderValuationResponse<valuationReportAndValuationIdResponse> valuationResponse = vh.GetValuation(bcRef, address, ValuationTypes.RESIDENTIAL).Result;

            int? yearBuilt = null, squareFootage = null;

            if (valuationResponse.TryGetSingleAnswerValue<int>("YearBuilt", int.TryParse, out int _yearBuilt))
                yearBuilt = _yearBuilt;

            if (valuationResponse.TryGetSingleAnswerValue<int>("SquareFootage", int.TryParse, out int _squareFootage))
                squareFootage = _squareFootage;

            IUnstructuredStorage<UnstructuredRecord<valuationReportAndValuationIdResponse>> db = new CosmosDatabaseContext<valuationReportAndValuationIdResponse>(config);

            UnstructuredRecord<valuationReportAndValuationIdResponse> vrw = new UnstructuredRecord<valuationReportAndValuationIdResponse>
            {
                ChildRecord = valuationResponse.ValuationResponse,
                Id = bcRef,
                PartitionKey = bcRef,
            };

            db.InsertRecord(vrw);

            UnstructuredRecord<valuationReportAndValuationIdResponse> inserted = db.Query(vrw.Id);

            Assert.AreEqual(inserted.Id, bcRef);
            Assert.IsNotNull(inserted.ChildRecord.valuationId);
            Assert.IsTrue(yearBuilt > 0);
            Assert.IsTrue(squareFootage > 0);
        }

        [Test]
        public void UseValuationServiceWithUnstructuredStorage()
        {
            string environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");

            if (string.IsNullOrEmpty(environment))
                environment = "Development";

            var config = new ConfigurationBuilder().AddJsonFile($"appsettings.{environment}.json").Build();

            Address address = new Address
            {
                ZipCode = "29801",
                CountryCode = "USA",
                City = "AIKEN",
                Street = "886 ALFRED ST NE",
                Name = "SAMPLE_TEST",
                State = "SC"
            };

            BridgeApi.DataEnrichment.Entities.UniversalBdxdbContext context = new BridgeApi.DataEnrichment.Entities.UniversalBdxdbContext();
            
            IExternalProviderValuationService<valuationReportAndValuationIdResponse> verisk = new Verisk(config, context);

            IUnstructuredStorage<UnstructuredRecord<valuationReportAndValuationIdResponse>> db = new CosmosDatabaseContext<valuationReportAndValuationIdResponse>(config);

            InternalValuationService<valuationReportAndValuationIdResponse> valuationService = new InternalValuationService<valuationReportAndValuationIdResponse>(config, context, verisk, db);//, unstructuredStorage1);

            IInternalValuationResponse de = valuationService.GetValuation(address, ValuationTypes.RESIDENTIAL, true, false).Result;

            UnstructuredRecord<valuationReportAndValuationIdResponse> check = db.Query(de.Bcref);

            double calcValue = double.Parse(check.ChildRecord.calculatedValue);

            Assert.IsTrue(calcValue > 0);

        }

        [Test]
        public void TestAddressMapping()
        {
            Address address = new Address
            {
                ZipCode = "84043",
                CountryCode = "USA",
                City = "Lehi",
                Street = "1100 W Traverse Pkwy",
                State = "UT",

                BuildingCharacteristics = new BuildingCharacteristics
                {
                    Occupancy = new Occupancy { Scheme = "ISOPROP", Code = "3009" },
                    Construction = new Construction { Scheme = "ISOFIRE", Code = "01" }                    
                }
            };


            BridgeApi.DataEnrichment.Entities.UniversalBdxdbContext context = new BridgeApi.DataEnrichment.Entities.UniversalBdxdbContext();
            AddressMapper<VeriskAddress, VeriskBuildingCharacteristics, string, string> addressMapper = new AddressMapper<VeriskAddress, VeriskBuildingCharacteristics, string, string>(context, "VeriskValue360", dest => dest.UseType, dest => dest.ISOConstructionClass, occ => occ, con => con, ValuationTypes.RESIDENTIAL);
            VeriskAddress va = addressMapper.ToProviderAddress(address);

            Assert.IsTrue(va.BuildingCharacteristics.UseType == "LMF");
            Assert.IsTrue(va.BuildingCharacteristics.ISOConstructionClass == "1");
        }


    }
}
