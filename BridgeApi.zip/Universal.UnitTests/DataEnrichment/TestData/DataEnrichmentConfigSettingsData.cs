﻿using BridgeApi.DataEnrichmentJobs.Helper;
using System;
using System.Collections.Generic;
using System.Text;

namespace BridgeApi.UnitTests.DataEnrichment.TestData
{
    public static class DataEnrichmentConfigSettingsData
    {
        private static readonly string[] TransactionTypes = { "NEW", "QTE", "ENQ" };
        private static readonly string[] BusinessArea = { "GLUK", "Lloyds" };

        public static DataEnrichmentConfigSettings GetDataikuTargetedRateCriteria()
        {           
            return new DataEnrichmentConfigSettings()
            {
                HangFireServerDatabaseConnection = string.Empty,
                DataikuTargetedRateCriteria = new DataikuTargetedRateCriteria()
                {
                    CronExp = string.Empty,
                    ContractYear = 2009,
                    Tivfgu = 2000000,
                    ExcludedPolicyNo = "GLUK2309",
                    NumberofLocations = 1,
                    PlacementType = 2,
                    HereonPercentage = 100,
                    TransactionTypes = TransactionTypes,
                    BusinessArea = BusinessArea
                }              
            };
        }
    }
}

