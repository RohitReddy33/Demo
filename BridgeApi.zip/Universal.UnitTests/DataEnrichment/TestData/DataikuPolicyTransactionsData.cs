﻿using BridgeApi.DataEnrichmentJobs.Models.Dataiku;
using BridgeApi.Enquiry.Models.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BridgeApi.UnitTests.DataEnrichment.TestData
{
    public static class DataikuPolicyTransactionsData
    {
        public static IQueryable<DataikuPolicyTransactions> GetTempPolicyTransactions()
        {
            return new List<DataikuPolicyTransactions>()
            {
                new DataikuPolicyTransactions()
                {
                    TempPremiumsId = 3366771,
                    PolicyNo = "TestPolicy01",
                    TransactionType = "NEW",
                    BusinessArea = "GLUK",
                    NumberofLocations = 1,
                    PlacementType = 2,
                    HereonPercentage = 100,
                    Tivfgu = 1700000,
                    ContractYear = 2019
                },

                new DataikuPolicyTransactions()
                {
                    TempPremiumsId = 3366772,
                    PolicyNo = "TestPolicy02",
                    TransactionType = "NEW",
                    BusinessArea = "GLUK",
                    NumberofLocations = 1,
                    PlacementType = 2,
                    HereonPercentage = 100,
                    Tivfgu = 1800000,
                    ContractYear = 2019
                },

                new DataikuPolicyTransactions()
                {
                    TempPremiumsId = 3366773,
                    PolicyNo = "TestPolicy03",
                    TransactionType = "NEW",
                    BusinessArea = "GLUK",
                    NumberofLocations = 1,
                    PlacementType = 2,
                    HereonPercentage = 100,
                    Tivfgu = 1900000,
                    ContractYear = 2019
                },

                new DataikuPolicyTransactions()
                {
                    TempPremiumsId = 3366774,
                    PolicyNo = "TestPolicy04",
                    TransactionType = "NEW",
                    BusinessArea = "GLUK",
                    NumberofLocations = 1,
                    PlacementType = 2,
                    HereonPercentage = 100,
                    Tivfgu = 2100000,
                    ContractYear = 2019
                },

                new DataikuPolicyTransactions()
                {
                    TempPremiumsId = 3366775,
                    PolicyNo = "GLUK2309",
                    TransactionType = "NEW",
                    BusinessArea = "GLUK",
                    NumberofLocations = 1,
                    PlacementType = 2,
                    HereonPercentage = 100,
                    Tivfgu = 1900000,
                    ContractYear = 2019
                },

                new DataikuPolicyTransactions()
                {
                    TempPremiumsId = 3366776,
                    PolicyNo = "TestPolicy06",
                    TransactionType = "BND",
                    BusinessArea = "GLUK",
                    NumberofLocations = 1,
                    PlacementType = 2,
                    HereonPercentage = 100,
                    Tivfgu = 1900000,
                    ContractYear = 2019
                },

            }.AsQueryable();
        }
    }
}
