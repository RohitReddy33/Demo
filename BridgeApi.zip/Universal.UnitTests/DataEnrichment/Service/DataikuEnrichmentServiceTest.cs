﻿using BridgeApi.DataEnrichmentJobs.Helper;
using BridgeApi.DataEnrichmentJobs.Models.Dataiku;
using BridgeApi.DataEnrichmentJobs.Services.Dataiku;
using BridgeApi.Enquiry.Services;
using BridgeApi.Repositories;
using BridgeApi.UnitTests.DataEnrichment.TestData;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BridgeApi.UnitTests.DataEnrichment.Service
{
    public class DataikuEnrichmentServiceTest
    {
        private Mock<IUniversalBdxRepository> _mockUniversalBdxRepository;
        private Mock<IDataikuService>  _dataikuService;
        private DataEnrichmentConfigSettings _dataEnrichmentConfiguration;        

        [SetUp]
        public void Setup()
        {
            _mockUniversalBdxRepository = new Mock<IUniversalBdxRepository>();
            _dataikuService = new Mock<IDataikuService>();            
            _dataEnrichmentConfiguration = DataEnrichmentConfigSettingsData.GetDataikuTargetedRateCriteria();            
        }

        [Test]
        [TestCase(3366771, 200 , ExpectedResult = 200)]      
        public decimal? GetTargetedRate_ShouldReturnsRate(long input, decimal expected)
        {
            // Arrange
            _dataikuService.Setup(d => d.GetTargetedRate(input).Result).Returns(expected);
            var dataikuEnrichmentService = new DataikuEnrichmentService(_mockUniversalBdxRepository.Object, _dataikuService.Object, _dataEnrichmentConfiguration);
            
            // Act
            var targetedRate = dataikuEnrichmentService.GetTargetedRate(input);

            // Assert
            return targetedRate;
        }

        [Test]      
        public void GetTempPremiumsIDsForUpdate_ShouldReturnsPolicyTransactions()
        {
            // Arrange
            _mockUniversalBdxRepository.Setup(r => r.GetHomeownerTempPolicyTransactions()).Returns(DataikuPolicyTransactionsData.GetTempPolicyTransactions());
            var dataikuEnrichmentService = new DataikuEnrichmentService(_mockUniversalBdxRepository.Object, _dataikuService.Object, _dataEnrichmentConfiguration);           
            
            // Act
            var tempPremiumsIDs = dataikuEnrichmentService.GetHomeownerTempPolicyTransactions().ToList();

            // Assert
           Assert.IsTrue(tempPremiumsIDs.Any());
            
        }

        [Test]        
        public void GetTempPremiumsIDsForUpdate_ShouldNotReturns_HigherTivfguTempId()
        {
            // Arrange
            _mockUniversalBdxRepository.Setup(r => r.GetHomeownerTempPolicyTransactions()).Returns(DataikuPolicyTransactionsData.GetTempPolicyTransactions());
            var dataikuEnrichmentService = new DataikuEnrichmentService(_mockUniversalBdxRepository.Object, _dataikuService.Object, _dataEnrichmentConfiguration);
            var excludedTempid = 3366774;
            // Act
            var tempPremiumsIDs = dataikuEnrichmentService.GetHomeownerTempPolicyTransactions().ToList();

            // Assert
            Assert.IsFalse(tempPremiumsIDs.Any(x=> x.TempPremiumsId == excludedTempid));

        }

        [Test]
        public void GetTempPremiumsIDsForUpdate_ShouldNotReturns_ExcludedPolicyNo()
        {
            // Arrange
            _mockUniversalBdxRepository.Setup(r => r.GetHomeownerTempPolicyTransactions()).Returns(DataikuPolicyTransactionsData.GetTempPolicyTransactions());
            var dataikuEnrichmentService = new DataikuEnrichmentService(_mockUniversalBdxRepository.Object, _dataikuService.Object, _dataEnrichmentConfiguration);
            var excludedPolicyNo = "GLUK2309";
            // Act
            var tempPremiumsIDs = dataikuEnrichmentService.GetHomeownerTempPolicyTransactions().ToList();

            // Assert
            Assert.IsFalse(tempPremiumsIDs.Any(x => x.PolicyNo.Equals(excludedPolicyNo)));

        }
        [Test]
        public void GetTempPremiumsIDsForUpdate_ShouldNotReturns_BND_TransactionType()
        {
            // Arrange
            _mockUniversalBdxRepository.Setup(r => r.GetHomeownerTempPolicyTransactions()).Returns(DataikuPolicyTransactionsData.GetTempPolicyTransactions());
            var dataikuEnrichmentService = new DataikuEnrichmentService(_mockUniversalBdxRepository.Object, _dataikuService.Object, _dataEnrichmentConfiguration);
            var transactionType = "BND";
            // Act
            var tempPremiumsIDs = dataikuEnrichmentService.GetHomeownerTempPolicyTransactions().ToList();

            // Assert
            Assert.IsFalse(tempPremiumsIDs.Any(x => x.TransactionType.Equals(transactionType)));

        }
    }
}
