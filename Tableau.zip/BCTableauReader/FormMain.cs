﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.IO;
using System.Diagnostics;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Threading;
using System.Runtime.InteropServices;
using System.Net;

namespace BCTableauReaderAutomation
{
    public partial class FormMain : Form
    {
        string masterFolderPath = @"\\bctableau\Tableau Reader Extracts";
        string tabCMDpath = @"C:\Program Files\Tableau\Tableau Server\2021.3\extras\Command Line Utility\tabcmd.exe";
        string tabUsername = "administrator";
        string tabPassword = "fkd#Ky8f<C.63T";
        string tabServer = "https://bctableau.ad.bellandclements.co.uk";

        public delegate void LogMessageDelegate(string logMessage);

        public FormMain()
        {
            InitializeComponent();
        }

        public void LogMessage(string messageText)
        {
            if (this.InvokeRequired)
            {
                // We're not in the UI thread, so we need to call BeginInvoke
                BeginInvoke(new LogMessageDelegate(LogMessage), new object[] { messageText });
                return;
            }

            if (this.listBoxLog.Items.Count > 2000)
            {
                this.listBoxLog.Items.RemoveAt(0);
                this.listBoxLog.SelectedIndex = this.listBoxLog.Items.Count - 1;
            }
            this.listBoxLog.Items.Add(DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss:fff") + " - " + messageText);

            using (UniversalBDXDB_Warehouse_TableauReaderEntities tRE = new UniversalBDXDB_Warehouse_TableauReaderEntities())
            {
                tRE.usp_BCReaderGenerationLogLogInsert(DateTime.Now, messageText);
                Thread.Sleep(1000);
            }
        }

        private void backgroundWorkerTableau_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                using (UniversalBDXDB_Warehouse_TableauReaderEntities tRE = new UniversalBDXDB_Warehouse_TableauReaderEntities())
                {
                    tRE.Database.CommandTimeout = 3600;
                    //Loop Through Clients
                    var coverHolders = from newRecord in tRE.dimCoverholders
                                       select newRecord;

                    foreach (var client in coverHolders.ToList())
                    {
                        LogMessage("=======================================================");
                        LogMessage("Processing Client: " + client.CompanyID.ToString() + " : " + client.ShortName);
                        try
                        {
                            DateTime clientStartTime = DateTime.Now;

                            string clientFolderpath = Path.Combine(masterFolderPath, client.ShortName);

                            if (Directory.Exists(clientFolderpath))
                            {
                                LogMessage("Removing folder and files: " + clientFolderpath);
                                Directory.Delete(clientFolderpath, true);
                            }

                            if (!Directory.Exists(clientFolderpath))
                            {
                                LogMessage("Creating folder: " + clientFolderpath);
                                Directory.CreateDirectory(clientFolderpath);
                            }

                            //Run PDF Reports
                            var results = tRE.sp_GetPDFReportsToRunForClient((int)client.CompanyID);

                            foreach (var i in results)
                            {
                                if (i.ReportType == "Tableau")
                                {
                                    //Logout Existing TabCMD session
                                    TabCMDLogout();

                                    string folderpath = clientFolderpath;
                                    if (i.ReportFolder != "")
                                    {
                                        folderpath = Path.Combine(clientFolderpath, i.ReportFolder);
                                        if (!Directory.Exists(folderpath)) Directory.CreateDirectory(folderpath);
                                    }

                                    ProduceTableauReport(i.ReportURL, Path.Combine(folderpath, i.ReportFileName));
                                }
                                else
                                {
                                    string folderpath = clientFolderpath;
                                    if (i.ReportFolder != "")
                                    {
                                        folderpath = Path.Combine(clientFolderpath, i.ReportFolder);
                                        if (!Directory.Exists(folderpath)) Directory.CreateDirectory(folderpath);
                                    }

                                    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(i.ReportURL);
                                    request.Credentials = CredentialCache.DefaultCredentials;
                                    request.Timeout = 600000;
                                    request.ReadWriteTimeout = 600000;

                                    LogMessage("\tRunning Reporting Serices Report");

                                    var wresp = (HttpWebResponse)request.GetResponse();

                                    using (Stream file = File.OpenWrite(Path.Combine(folderpath, i.ReportFileName)))
                                    {
                                        wresp.GetResponseStream().CopyTo(file);
                                    }
                                }
                            }

                            LogMessage("Client Total Processing Time (seconds): " + DateTime.Now.Subtract(clientStartTime).TotalSeconds);
                        }
                        catch (Exception ex)
                        {
                            LogMessage(ex.Message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogMessage(ex.Message);
            }
        }

        private void RunTableauReaderExtractsPerClient(int companyID, string clientFolderpath)
        {
            using (UniversalBDXDB_Warehouse_TableauReaderEntities tRE = new UniversalBDXDB_Warehouse_TableauReaderEntities())
            {
                tRE.Database.CommandTimeout = 3600;
                //Update Current Run Table
                tRE.usp_TableauReaderCurrentRunUpdateCurrentRunClient(companyID);
                tRE.SaveChanges();

                //Update DataExtracts
                bool dataSourcesUpdated = true;
                var dataSourceToRefreshes = from newRecord in tRE.TableauReaderDataSourceToRefreshes
                                            select newRecord;

                foreach (var dataSource in dataSourceToRefreshes.ToList())
                {
                    LogMessage("DataSource: " + dataSource.DataSourceName);
                    LogMessage("\tRunning Data Refresh");
                    if (RunTableauDataRefreshDataSource(dataSource.DataSourceName, dataSource.Project))
                    {
                        LogMessage("\tRefresh Data Extract Completed");
                    }
                    else
                    {
                        LogMessage("\tRefresh Data Extract Failed");
                        dataSourcesUpdated = false;
                    }
                }

                //loop through reports
                if (dataSourcesUpdated)
                {
                    var reports = from newRecord in tRE.TableauReaderReports
                                  select newRecord;

                    foreach (var report in reports.ToList())
                    {
                        LogMessage("Report: " + report.FileName);
                        LogMessage("\tRunning Data Refresh");
                        if (RunTableauDataRefreshReport(report.WorkBook, report.Project))
                        {
                            LogMessage("\tRefresh Data Extract Completed");
                            LogMessage("\tProducing Report");
                            //Produce File
                            string fileName = Path.Combine(clientFolderpath, report.FileName);
                            if (ProduceTableauReport(report.URL, fileName))
                            {
                                LogMessage("\tFile produced. Updating Database");

                                tRE.usp_TableauReaderAddReportAgent(report.ReportID, companyID, File.ReadAllBytes(fileName));
                            }
                            else
                            {
                                LogMessage("\tProducing File Failed");
                            }
                        }
                        else
                        {
                            LogMessage("\tRefresh Data Extract Failed");
                        }
                    }
                }
                else
                {
                    LogMessage("Cannot produce reports if data extracts refresh failed");
                }
            }
        }

        private void TabCMDLogout()
        {
            string produceFileCommand = " logout";
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo = new System.Diagnostics.ProcessStartInfo(tabCMDpath, produceFileCommand);
            proc.StartInfo.RedirectStandardOutput = true;
            proc.StartInfo.RedirectStandardError = true;
            proc.StartInfo.UseShellExecute = false;
            proc.OutputDataReceived += CaptureOutput;
            proc.ErrorDataReceived += CaptureError;

            Debug.Print(tabCMDpath + produceFileCommand);
            proc.EnableRaisingEvents = true;
            proc.Start();
            // Asynchronously read the standard output of the spawned process. 
            // This raises OutputDataReceived events for each line of output.
            proc.BeginOutputReadLine();
            proc.WaitForExit();
            proc.Close();
        }

        private bool ProduceTableauReport(string URL, string FileName)
        {
            //Run tableau Extract
            string produceFileCommand = " get \"" + URL + "\" -f \"" + FileName + "\" --username \"" + tabUsername + "\" --password \"" + tabPassword + "\" --server \"" + tabServer + "\"";
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo = new System.Diagnostics.ProcessStartInfo(tabCMDpath, produceFileCommand);
            proc.StartInfo.RedirectStandardOutput = true;
            proc.StartInfo.RedirectStandardError = true;
            proc.StartInfo.UseShellExecute = false;
            proc.OutputDataReceived += CaptureOutput;
            proc.ErrorDataReceived += CaptureError;

            Debug.Print(tabCMDpath + produceFileCommand);
            proc.EnableRaisingEvents = true;
            proc.Start();
            // Asynchronously read the standard output of the spawned process. 
            // This raises OutputDataReceived events for each line of output.
            proc.BeginOutputReadLine();
            proc.WaitForExit();
            proc.Close();

            return true;
        }

        static void CaptureOutput(object sender, DataReceivedEventArgs e)
        {
            Debug.Print(e.Data);
        }

        static void CaptureError(object sender, DataReceivedEventArgs e)
        {
            Debug.Print(e.Data);
        }

        private bool RunTableauDataRefreshReport(string workBook, string project)
        {
            //Run tableau Extract
            string extractCommand = " refreshextracts --workbook \"" + workBook + "\" --project \"" + project + "\" --username \"" + tabUsername + "\" --password \"" + tabPassword + "\" --server \"" + tabServer + "\" --synchronous --timeout 18000";

            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo = new System.Diagnostics.ProcessStartInfo(tabCMDpath, extractCommand);
            proc.StartInfo.RedirectStandardOutput = true;
            proc.StartInfo.RedirectStandardError = true;
            proc.StartInfo.UseShellExecute = false;
            proc.EnableRaisingEvents = true;
            proc.OutputDataReceived += CaptureOutput;
            proc.ErrorDataReceived += CaptureError;

            Debug.Print(tabCMDpath + extractCommand);
            DateTime runTime = DateTime.Now;
            proc.Start();
            // Asynchronously read the standard output of the spawned process. 
            // This raises OutputDataReceived events for each line of output.
            proc.BeginOutputReadLine();
            proc.WaitForExit();
            proc.Close();

            //Check that it has run to 100%
            using (UniversalBDXDB_Warehouse_TableauReaderEntities tRE = new UniversalBDXDB_Warehouse_TableauReaderEntities())
            {
                bool? jobRan = tRE.usp_TableauReaderHasJobRun(workBook, runTime).First();

                if (jobRan.Value) return true;
            }

            LogMessage("Data Extact Failed");
            return false;
        }

        private bool RunTableauDataRefreshDataSource(string dataSourceName, string project)
        {
            //Run tableau Extract
            string extractCommand = " refreshextracts --datasource  \"" + dataSourceName + "\" --project \"" + project + "\" --username \"" + tabUsername + "\" --password \"" + tabPassword + "\" --server \"" + tabServer + "\" --synchronous --timeout 18000";

            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo = new System.Diagnostics.ProcessStartInfo(tabCMDpath, extractCommand);
            proc.StartInfo.RedirectStandardOutput = true;
            proc.StartInfo.RedirectStandardError = true;
            proc.StartInfo.UseShellExecute = false;
            proc.EnableRaisingEvents = true;
            proc.OutputDataReceived += CaptureOutput;
            proc.ErrorDataReceived += CaptureError;

            Debug.Print(tabCMDpath + extractCommand);
            DateTime runTime = DateTime.Now;
            proc.Start();
            // Asynchronously read the standard output of the spawned process. 
            // This raises OutputDataReceived events for each line of output.
            proc.BeginOutputReadLine();
            proc.WaitForExit();
            proc.Close();

            //Check that it has run to 100%
            using (UniversalBDXDB_Warehouse_TableauReaderEntities tRE = new UniversalBDXDB_Warehouse_TableauReaderEntities())
            {
                bool? jobRan = tRE.usp_TableauReaderHasJobRun(dataSourceName, runTime).First();

                if (jobRan.Value) return true;
            }

            LogMessage("Data Extact Failed");
            return false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lock (this)
            {
                if (!backgroundWorkerTableau.IsBusy)
                {
                    try
                    {
                        bool runWorker = false;
                        //Are we Due To Run
                        using (UniversalBDXDB_Warehouse_TableauReaderEntities tRE = new UniversalBDXDB_Warehouse_TableauReaderEntities())
                        {
                            var control = (from newRecord in tRE.Controls
                                                         select newRecord).First();

                            if (control.NextRunDate < DateTime.Now && control.EveryXDays>0)
                            {
                                //Update Next Run Date
                                control.LastRunDate = DateTime.Now;
                                control.NextRunDate = DateTime.Now.AddDays(control.EveryXDays);
                                tRE.SaveChanges();

                                //Run
                                runWorker = true;
                            }
                        }      
                        
                        if (runWorker) backgroundWorkerTableau.RunWorkerAsync(this);
                    }
                    catch (Exception ex)
                    {
                        LogMessage("Error: " + ex.Message);
                    }
                }
            }
        } 

        private void toolStripMenuItemSaveLog_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog(this) == DialogResult.OK)
            {
                StreamWriter sr = System.IO.File.CreateText(saveFileDialog1.FileName);
                foreach (string i in listBoxLog.Items)
                {
                    sr.WriteLine(i);
                }
                sr.Close();
            }
        }

        private void toolStripMenuItemClearLog_Click(object sender, EventArgs e)
        {
            listBoxLog.Items.Clear();
        }

        private void toolStripMenuItemProcess_Click(object sender, EventArgs e)
        {
            lock (this)
            {
                if (!backgroundWorkerTableau.IsBusy)
                {
                    backgroundWorkerTableau.RunWorkerAsync(this);
                }
            }
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            /*lock (this)
            {
                if (!backgroundWorkerTableau.IsBusy)
                {
                    backgroundWorkerTableau.RunWorkerAsync(this);
                }
            }*/
        }

        private void backgroundWorkerTableau_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            //this.Close();
        }
    }
}
