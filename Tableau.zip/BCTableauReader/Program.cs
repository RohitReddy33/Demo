﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace BCTableauReaderAutomation
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new FormMain());

            Mutex m = new Mutex(true, "Global\\" + Application.ProductName);
            bool ableToLock = (m.WaitOne(1, true));
            if (ableToLock)
            {
                Application.Run(new FormMain());
                m.ReleaseMutex();
            }
            else
            {
                System.Windows.Forms.MessageBox.Show(Application.ProductName + " is already running, can only create one instance", "Sorry", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Stop);
            }
        }
    }
}
